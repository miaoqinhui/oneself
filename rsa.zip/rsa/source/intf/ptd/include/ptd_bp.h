#ifndef _PTD_BP_H_
#define _PTD_BP_H_

typedef enum {
    BP_BCM_HG_SP_10G = 10000,
    BP_BCM_HG_SP_42G = 42000,
    BP_BCM_HG_SP_100G = 100000,
} bp_bcm_hg_sp_e;

typedef enum {
    BP_HG_DUPLEX_HALF,            /* ��˫�� */
    BP_HG_DUPLEX_FULL,            /* ȫ˫�� */
    BP_HG_DUPLEX_AUTO,            /* �Զ� */
    BP_HG_DUPLEX_NUM,
} bp_bcm_hg_duplex_e;

typedef enum {
    BP_HG2_MODE_FORBID = -1,
    BP_HG2_MODE_OFF = 0,
    BP_HG2_MODE_8BYTE = 1,
    BP_HG2_MODE_9BYTE = 2,
} bp_bcm_hg2_mode_e;

typedef struct bp_unit_port_conf_eff_s
{
    int unit;
    int port;

    int speed;
    int hg2_code;
    int ifg;
    int if_type;
    int cl72;
} bp_unit_port_conf_eff_t;

#endif /* _PTD_BP_H_ */
