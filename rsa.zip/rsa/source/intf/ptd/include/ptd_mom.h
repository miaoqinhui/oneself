/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */
#ifndef _PTD_MOM_H_
#define _PTD_MOM_H_

#include <arch/unit_thread.h>
#include <arch/config_end_comm.h>
#include <rg_at/ssat_intf.h> 
#include <sw_intf/ddm/libddm.h>
#include "../../frm/intf_frm_serv.h"
#include <libpub/rg_thread/rg_thread.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include "ptd_com.h"


#define PORT_PTM_MEDIUM_FIBER           S_INTF__MEDIUM_TYPE_E__FIBER
#define PORT_PTM_MEDIUM_COPPER          S_INTF__MEDIUM_TYPE_E__COPPER

/* service provided by rgos_adapter layer */
extern int ptd_rgos_get_medium(ptd_info_t *ptd, int *ptm_medium);
extern int ptd_rgos_medium_drv_to_ptm(int drv_medium);

extern int ptd_rgos_admin_set(unsigned int lphyid, int enable, 
    vsd_unit_thread_info_t *unit_t_info);   /* for intf-comm */
extern int ptd_rgos_attr_set(unsigned int lphyid, ptd_attr_info_t* ptd_attr_info, 
    vsd_unit_thread_info_t *unit_t_info);   /* for intf-comm */
extern int ptd_rgos_mtu_set(unsigned int lphyid, int mtu, 
    vsd_unit_thread_info_t *unit_t_info);
extern int ptd_rgos_loopback_set(unsigned int lphyid, int loopback, 
    vsd_unit_thread_info_t *unit_t_info);

/* service provided by rgos_adapter layer VSL version in these funs we DONT filter vsl conf */
extern int ptd_rgos_admin_set_vsl(unsigned int lphyid, int enable, 
    vsd_unit_thread_info_t *unit_t_info);   /* for intf-comm */
extern int ptd_rgos_vsl_set(unsigned int lphyid, int mode, 
    vsd_unit_thread_info_t *unit_t_info);
extern int ptd_rgos_attr_set_vsl(unsigned int lphyid, ptd_attr_info_t* ptd_attr_info, 
    vsd_unit_thread_info_t *unit_t_info);   /* for intf-comm */
extern int ptd_rgos_mtu_set_vsl(unsigned int lphyid, int mtu, 
    vsd_unit_thread_info_t *unit_t_info);
extern int ptd_rgos_loopback_set_vsl(unsigned int lphyid, int loopback, 
    vsd_unit_thread_info_t *unit_t_info);

/* mom mib notify related func */
/* mib-normal */
extern int ptd_mib_unitport_mib_update(int unit, int port, uint64_t *buf);
extern int ptd_mib_unitport_mib_need_notify(int unit, int port, uint64_t *buf);
/* mib-ex */
extern int ptd_mib_unitport_mib_ex_update(int unit, int port, uint64_t *dbg_cnt_urpf);
extern int ptd_mib_unitport_mib_ex_need_notify(int unit, int port, uint64_t *dbg_cnt_urpf);

#endif /* _PTD_MOM_H_ */
