#ifndef __PTD_COM_H_
#define __PTD_COM_H_
/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "ptd_sdk_xgs.h"

#define CPLD_DEV_PATH  "/dev/cpld0"

/* PTD���õ�λͼ�жϺ� */
#define PTD_BIT_IS_SET(var, offset)  ((var) & (1 << offset))

/* PTD���õ�λͼ��λ�� */
#define PTD_BIT_SET(var, offset)  ((var) | (1 << offset))

typedef struct ptd_info_s {
    /* narmal infos below */
    unsigned int phyid;
    int unit;
    int port;
    
    int handle_type;      /* is this lport should be notified to PTM as a plug or unplug action */
    int lport; 
    int present; 
    int is_vsl;
    int split_port_type;

    /* below one are lport physical capability */
    int lport_max_rate;   /* lport type get from XML key from lsm ETH_10G etc. mainly the max rate capability of lport */
    
    /* medium type */
    int dev_medium;       /* medium get from NDM */
    int ptm_medium;       /* medium to PTM */

    /* below two are trans physical capability */
    int trans_rate;       /* trans_type really means max rate capability of transiever */
    int trans_model;      /* this arg is intended to identify type of transiever, like copper-wire trans optical-fiber wire and GT-moduler */

    int trans_cap_detail; /* detail info of trans cap like SSA_PORT_QSFP28_100GBASE_LR4 etc. */
} ptd_info_t;

typedef struct ptd_attr_info_s {
    int speed;
    int flow;
    int duplex;
    int an;
    int link;
    int medium;
    int fec;   /* we now add fec into attr config list */
} ptd_attr_info_t;

/* the effective attr val
 * some effective attr cant be decide unless the SDK-set is configed
 * for now fec need notify
 */
typedef struct ptd_attr_eff_info_s {
    int fec;   
} ptd_attr_eff_info_t;

typedef struct ptd_bp_attr_info_s {
    int speed;
    int hg2_code;
    int ifg;
    int if_type;
    int link;
    int cl72;
} ptd_bp_attr_info_t;

typedef enum {
    SPLIT_MODE_HOT,
    SPLIT_MODE_COLD
} split_mode_t;

/* struct to make link notify
 
* to seperate mom from sdk   
 */
typedef struct ptd_link_notify_info_s {
    int linkstatus; 
    int autoneg; 
    int speed; 
    int duplex;
    int pause_tx; 
    int pause_rx; 
    int drv_medium;  /* medium in SDK */
} ptd_link_notify_info_t;

typedef struct link_notify_port_info_s {
    int32_t unit;
    int32_t port;
    ptd_link_notify_info_t port_info; 
    struct list_head node;
} link_notify_port_info_t;


#define MAX_LOCAL_UNIT          (8)
#define MAX_UNIT_PORT           (256)

#define DEFAULT_CNT_MAX_SIZE     (1518)           /* Ĭ�ϵ�Oversize packetsͳ��ˮ��ֵ */

/* mib type-num macro */
#define SSA_PORT_STAT_BUF_NUM           39
#define PTD_MIB_NO_NEED_NOTI               0
#define PTD_MIB_NEED_NOTI               1

typedef enum lb_type_e {
    TYPE_NORMAL,
    TYPE_PHYLB_RE_MACLB,    /* PHY�ػ�����mac�ػ� */
    TYPE_MACLB_RE_PHYLB,    /* mac�ػ�����phy�ػ� */
} lb_type_t;

typedef enum {
    PTD_ETH_PORT, /* ETH? */
    PTD_VSL_PORT  /* VSL? */
} ptd_port_type_t;


/* can stay here */
int ptd_read_cpld(char *path, int addr, unsigned char *val, int size);
int ptd_write_cpld(char *path, int addr, unsigned char *val, int size);
int ptd_read_i2c(char *i2c_name, unsigned short dev_addr, unsigned short offset_addr,
                                   unsigned char *recv_buf, int size, int addr_type);
int ptd_write_i2c(char *i2c_name, unsigned short dev_addr, unsigned short offset_addr,
                                    unsigned char *write_buf, int size, int addr_type);

/**
 * ssa_port_get_medium - ��ȡ�豸�����ǵ�ڻ��ǹ��
 * @ulong phyid�� ָ���˿�
 * @int32_t medium(out)��         ��������
 *
 * return: �ɹ�����OK�����򷵻�errno
 */
extern int ptd_get_medium(int unit, int port, int *medium);
/**
 * ssa_port_set_medium - ���ö˿ڵĽ�������
 * @uint32_t phyid�� ָ���˿�
 * @int32_t type��         ��������
 *
 * return: �ɹ�����OK�����򷵻�errno
 */
extern int ptd_set_medium(unsigned int phyid, int medium);

/**
 *  ssa_port_set_admin - ����ָ�������˿ڵĴ򿪻��߹ر�
 *  @phy_id: ָ���˿�
 *  @port_stat: ָ���ǿ������ǹر�
 *
 *  return: �ɹ�����SSA_PORT_E_NONE�����򷵻�errno
 */
extern int xgs_set_admin(ptd_info_t *ptd, int port_stat);

/**
 *  ssa_port_set_attr_dsf - ���ö˿ڵ����ʡ�˫���� ����
 *  @phyid:  �˿�����
 *  @port_att���˿����ʡ�˫���� ����
 *
 *  return: �ɹ�����0�����򷵻�errno
 */
extern int xgs_set_attr_dsf(ptd_info_t *ptd, ptd_attr_info_t *port_att, ptd_attr_eff_info_t *ptd_attr_eff_info);

/**
 * ssa_port_set_mtu - ���ö˿ڵ�MTUֵ
 * @uint32_t phyid�� ָ���˿�
 * @int32_t mtu��            MTUֵ
 *
 * return: �ɹ�����0�����򷵻ظ�ֵ
 */
extern int xgs_set_mtu(ptd_info_t *ptd, int mtu);

extern int bp_set_port_admin(ptd_info_t *ptd, int port_stat);
extern int bp_set_port_attr(ptd_info_t *ptd_bp, ptd_bp_attr_info_t *port_bp_attr);

/**
 * ssa_port_set_mac_loopback - ���ö˿�MAC�ػ�
 * @phyid�� ָ���˿�
 * @loopback: ָ���ػ�(0��ʾnone, 1��ʾmac)
 *
 * return: �ɹ�����0�����򷵻ظ�ֵ
 */
extern int xgs_set_loopback(ptd_info_t *ptd, int lb);

extern int xgs_set_vsl(ptd_info_t *ptd, int mode);


extern int32_t ptd_mib_get_mib_ex_info(int32_t unit, int32_t port, uint64_t *value);
extern int ptd_clear_mib_ex(int unit, int port);
extern int ptd_set_preemphasis(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new);
extern int ptd_set_firmode(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new);
extern int ptd_set_interface(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new);
extern int ptd_set_fec(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new);


/* �ж�ǧ�׻������׹�ģ���Ƿ���ڣ�����0��ʾ���ڣ�1��ʾ������
 * sync_type = 0  means get from software cache which is updated by last sfp-irq
 * sync_type = 1  means get from hardware and sync to software cache
 */
extern int32_t ptd_trans_get_ts_exist(int32_t lport, int sync_type);
extern int in_ssa_port_get_trans_max_support_rate(int32_t lport, int32_t lport_max_rate, int32_t *trans_rate, int is_split, int trans_cap);
extern int in_ssa_port_get_sfp_plug_mode(int32_t lport, int32_t lport_max_rate, int32_t *trans_model, int is_split, int trans_cap);


/* ptd��ʼ������ */
extern int ptd_fac_begin_bc_test(int unit);
extern int ptd_fac_stop_bc_test(int unit);
extern int ptd_get_bc_test_res(int port_id, uint64_t *fcs);
extern int ptd_fac_begin_lb_test(int unit);
extern int ptd_fac_stop_lb_test(int unit);
extern int ptd_fac_get_fcs_count(int unit, int port, uint64_t *fcs_count);


extern int ptd_client_socket_send(int unit);
extern void ptd_set_port_type(int unit, int port, int type);
extern int ptd_get_port_type(int unit, int port, int *type);

extern void ptd_get_trans_info_by_lport(int lport, ptd_info_t *ptd);
extern int ptd_get_port_info_by_lport(int lport, ptd_info_t *ptd);
extern int ptd_get_port_info_by_phyid(unsigned int phyid, ptd_info_t *ptd);
extern int ptd_get_lport_from_unit_port(int unit, int port, int *lport);
extern int ptd_get_bp_port_info_by_phyid(unsigned int phyid, ptd_info_t *ptd);

/* split service related func */
extern int ptd_unit_port_split_info_get(int unit, int port, split_port_cache_t *split_port_cache);
extern bool ptd_unit_port_split_support(int unit, int port);
extern int ptd_unit_port_split_num_get(int unit, int port);

#endif /* __PTD_COM_H_ */

