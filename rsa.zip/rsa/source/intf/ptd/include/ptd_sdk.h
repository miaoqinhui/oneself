/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */
#ifndef _PTD_SDK_H_
#define _PTD_SDK_H_


#endif /* _PTD_SDK_H_ */
