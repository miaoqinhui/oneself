#ifndef PTD_CONFIG_H_
#define PTD_CONFIG_H_
/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */

#define MAX_LPORT_NUM   256        /* reference to PJ18 fix to 256 consideration of split port */
#define MAX_NAME_LEN    64
#define MAX_VALUE_LEN   1000
#define MAX_CPLD_DECT_REG_NUM  32  /* MAX cpld reg num for sfp present detection */
#define MAX_BP_PORT_NUM 64
#define MAX_EXTERNAL_PHY_NUM   8

#define PORT_CONFIG_FILE_DIR       "/etc/cfg/card_config/"  /* �����ļ�·�� */
#define PORT_CONFIG_FILE_BCM       ".bcm"                              /* �����ļ���׺ */

typedef struct ssa_port_lc_str_s {
    int32_t type;
    char str[100];
} ssa_port_lc_str_t;

extern void ssa_port_read_cfg(void);

extern int32_t ssa_port_cfg_get_set_protect(void);

extern int32_t ssa_port_cfg_get_protect_trunk(void);

extern uint32_t ssa_port_cfg_get_read_cfgfile_time(void);

extern int32_t ssa_port_cfg_get_cpld_state0(int32_t lport);

extern int32_t ssa_port_cfg_get_cpld_state1(int32_t lport);

extern int32_t ssa_port_cfg_get_debug_ssa(void);

extern int32_t ssa_port_cfg_get_mtu_reset(void);

extern int32_t ssa_port_cfg_get_irq_adjust(void);

extern int32_t ssa_port_cfg_get_led_address(void);

extern int32_t ssa_port_cfg_get_led_value(void);

extern int32_t ssa_port_cfg_get_interrupt_address(void);

extern int32_t ssa_port_cfg_get_interrupt_value(void);

extern int32_t ssa_port_cfg_get_giga_copper_1000_an_en(void);

extern int32_t ssa_port_cfg_get_set_jam(void);

extern int32_t ssa_port_cfg_get_set_edc(void);

extern int32_t ssa_port_cfg_get_cpld_dect_sfp_addr(int32_t lport);

extern int32_t ssa_port_cfg_get_cpld_open_sfp_addr(int32_t lport);

extern int32_t ssa_port_cfg_get_cpld_exchange(int32_t lport);

extern int32_t ssa_port_cfg_get_cpld_offset_reg(int32_t lport);

extern int32_t ssa_port_cfg_get_sfp_on_i2c_addr(void);

extern int32_t ssa_port_cfg_get_sfp_type_offset(void);

extern char *ssa_port_cfg_get_sfp_i2c_dev_name(int32_t lport);
extern char *ptd_cfg_get_sfp_cpld_dev_name(int32_t lport);

extern int32_t ssa_port_cfg_get_irq_num(void);

extern int32_t ssa_port_cfg_get_rdbgc8_set64_bit(void);

extern int32_t ssa_port_cfg_get_rdbgc8_over_size(void);

extern int32_t ssa_port_cfg_get_first_fiber_port_offset(void);

extern int32_t ssa_port_cfg_get_cpld_pnum_group(void);

extern int32_t ssa_port_cfg_get_giga_fiber_speed_auto_to_max(void);

extern int32_t ssa_port_cfg_get_giga_copper_thread(void);

extern int32_t ssa_port_cfg_get_cfg_adj_thread_time(void);

extern int32_t ssa_port_cfg_get_port_to_lane(int32_t lport);

extern int32_t ssa_port_cfg_get_mac_and_phy_not_an(void);

extern int32_t ssa_port_cfg_get_qsfp_open_method_i2c(void);

extern int32_t ssa_port_cfg_get_qsfp_power_en_addr(void);

extern unsigned char ssa_port_cfg_get_qsfp_power_en_value(void);

extern int32_t ssa_port_cfg_get_linkscan_time(void);

extern int32_t ssa_port_cfg_get_linkscan_type(void);

extern int32_t ssa_port_cfg_get_copper_pre(int32_t lport, int32_t lane);

extern int32_t ssa_port_cfg_get_copper_drv(int32_t lport, int32_t lane);

extern int32_t ssa_port_cfg_get_fiber_pre(int32_t lport, int32_t lane);

extern int32_t ssa_port_cfg_get_fiber_drv(int32_t lport, int32_t lane);

extern int32_t ssa_port_cfg_get_def_pre(void);

extern int32_t ssa_port_cfg_get_def_drv(void);

extern int32_t ssa_port_cfg_get_set_preemphasis(void);

extern int32_t ssa_port_cfg_get_cpld_pnum_pgroup(void);

extern uint32_t ssa_port_cfg_get_adjust_lport_min(void);

extern uint32_t ssa_port_cfg_get_adjust_lport_max(void);

extern int32_t ssa_port_cfg_get_admin_sleep_time(void);

extern int32_t ssa_port_cfg_get_fast_linkscan_adjust_pnum(void);

extern int32_t ssa_port_cfg_get_fast_linkscan_time(void);

extern int32_t ssa_port_cfg_get_fast_linkscan_adjust_time(void);

extern int32_t ssa_port_cfg_get_copper_fastlink_type(void);

extern char * ssa_port_cfg_get_led_code(void);
extern char * ssa_port_cfg_get_poe_led_code(void);

extern int32_t ssa_port_cfg_get_led_port_max(void);

extern int32_t ssa_port_cfg_get_led_40g_data_ram(int32_t lport);

extern int32_t ssa_port_cfg_get_led_callback_type(void);

extern void ssa_port_cfg_get_qsfp_reset_addr(int32_t *addr);

extern void ssa_port_cfg_get_qsfp_reset_val(int32_t *val);

extern int32_t ssa_port_cfg_get_adver_type(void);

extern int32_t ssa_port_cfg_get_phy_scan(int32_t lport);

extern int32_t ssa_port_cfg_get_wcmode(void);

extern int32_t ssa_port_cfg_get_mdixmode(void);

extern int32_t ssa_port_cfg_get_mtu_add_len(int32_t lport);

extern int32_t ssa_port_cfg_get_oversize_frm_add_len(int32_t lport);

extern int32_t ssa_port_cfg_get_need_unreliable_los(int32_t lport);

extern int32_t ssa_port_cfg_get_lb_type(void);

extern int32_t ssa_port_cfg_get_gt_always_an(void);

extern int32_t ssa_port_cfg_get_firmware_dfe_enable(void);

extern int32_t ssa_port_cfg_get_fir_mode(void);

extern int32_t ssa_port_cfg_get_set_preamble(void);

extern int32_t ssa_port_cfg_get_set_pcie(void);

extern int32_t ssa_port_cfg_get_flow_extern(void);

extern int32_t ssa_port_cfg_get_pause_init(void);

extern int32_t ssa_port_cfg_get_default_mtu(void);

extern int32_t ssa_port_cfg_get_counter_down_update(void);

extern int32_t ssa_port_cfg_get_port_if_change(int32_t lport);

extern int32_t ssa_port_cfg_get_nosup_linedet(void);

extern int32_t ssa_port_cfg_get_gt_fake_link(void);

extern int32_t ssa_port_cfg_get_wc_100m_nolink(void);

extern int32_t ssa_port_cfg_get_serdes_if_type(void);

extern int32_t ssa_port_cfg_get_if_type_copper_tengi(void);

extern int32_t ssa_port_cfg_get_if_type_fiber_tengi(void);

extern int32_t ssa_port_cfg_get_if_type_copper_fortygi(void);

extern int32_t ssa_port_cfg_get_if_type_fiber_fortygi(void);

extern int32_t ssa_port_cfg_get_inerror_exclude_rmtu(void);

extern int32_t ssa_port_cfg_get_mac_lb_force_link(void);

extern int32_t ssa_port_cfg_get_apd_type(void);

extern int32_t ssa_port_cfg_get_use_xfp(void);

extern int32_t ssa_port_cfg_get_module_ready_time(void);

extern int32_t ssa_port_cfg_get_forced_100m_on_xt(void);

extern int32_t ssa_port_cfg_get_split_40g_maxport(void);

extern int32_t ssa_port_cfg_get_linkscan_state(int32_t lport);

extern int32_t ssa_port_cfg_get_feature_vsl_no_speed_set(void);
extern int32_t ssa_port_cfg_get_sfp_do_antifake(void);
extern int32_t ssa_port_cfg_get_split_lport_lane_info(int32_t lport);
extern int32_t ssa_port_cfg_get_override_an_conf_in_cache(int32_t lport);
extern int32_t ssa_port_cfg_get_prt_min_supp_vsl_speed(int32_t lport);
extern int32_t ssa_port_cfg_get_sfp_present_cache_dect(int32_t lport);
extern int32_t ssa_port_cfg_get_sfp_present_cache(int32_t num);
extern int32_t ssa_port_cfg_get_mib_notify_linger_cnt(void);
extern int32_t ssa_port_cfg_get_an_ensure_port_enabled(void);
extern int32_t ssa_port_cfg_get_backplane_port_spec(int32_t port);
extern int32_t ssa_port_cfg_get_ls_type_lport(int32_t lport);
extern int32_t ssa_port_cfg_get_ext_phy_type(int32_t phyid);
extern uint16_t ssa_port_cfg_get_copper_interrupt_value(void);
extern uint16_t ssa_port_cfg_get_fiber_interrupt_value(void);
extern int32_t ssa_port_cfg_get_an_unsupported(void);
extern int32_t ssa_port_cfg_get_speed_change_flow_ctrl(void);

extern int32_t ssa_port_conf_file_init(void);
extern int ptd_config_get(char *config_line, int def);
#endif  /* PTD_CONFIG_H_ */

