#ifndef PTD_DEBUG_H_
#define PTD_DEBUG_H_

/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */

#include <rg_zlog/zct.h>
#include <rg_zlog/rgdf_zlog.h>

/* ptd common error */
typedef enum {
    SSA_PORT_E_NONE     = 0,
    SSA_PORT_E_IVPARAM     = -1,
    SSA_PORT_E_RETURN    = -2,
    SSA_PORT_E_MEMORY    = -3,
} port_com_error_t;

/* split error */
typedef enum {
    SPLIT_E_NONE     = 0,
    SPLIT_E_FAIL     = -1,
    SPLIT_E_PARAM    = -2,
    SPLIT_E_MEM      = -3,
    SPLIT_E_EXIST    = -4,
    SPLIT_E_INVALID  = -5,
    SPLIT_E_INIT     = -6,
} port_cfg_error_t;

/* for fac ret value */
typedef enum port_fac_err_e {
    PORT_FAC_NONE     = 0,                  /* ��ȷ����ֵ */
    PORT_FAC_ERROR    = -1,                 /* ���󷵻�ֵ*/
    PORT_FAC_INVALID  = -2,                 /* �쳣����ֵ*/
} port_fac_err_t;

#define    SSA_PORT_FUNCTION_NAME() (__FUNCTION__)

extern int32_t g_ssa_port_debug;
extern int32_t g_ssa_port_debug_error;
extern int32_t g_ssa_port_debug_test;

extern rgdf_zlog_level_t g_ssa_ptd_zlog_level;
extern zlog_category_t * g_ssa_ptd_zlog_category;

#define SSA_PTD_ZLOG_FATAL(fmt, arg...)   RGDF_ZLOG_FATAL(ssa_ptd, fmt, ##arg)
#define SSA_PTD_ZLOG_ERROR(fmt, arg...)   RGDF_ZLOG_ERROR(ssa_ptd, fmt, ##arg)
#define SSA_PTD_ZLOG_WARN(fmt, arg...)    RGDF_ZLOG_WARN(ssa_ptd, fmt, ##arg)
#define SSA_PTD_ZLOG_NOTICE(fmt, arg...)  RGDF_ZLOG_NOTICE(ssa_ptd, fmt, ##arg)
#define SSA_PTD_ZLOG_INFO(fmt, arg...)    RGDF_ZLOG_INFO(ssa_ptd, fmt, ##arg)
#define SSA_PTD_ZLOG_DEBUG(fmt, arg...)   RGDF_ZLOG_DEBUG(ssa_ptd, fmt, ##arg)


#define SSA_PORT_INIT_FUNC_ENTER    SSA_PTD_ZLOG_NOTICE("\n enter!") 
#define SSA_PORT_INIT_FUNC_LEAVER   SSA_PTD_ZLOG_NOTICE("leaver!\n")

#define SPLIT_DBG_ERR(fmt, args...) do {                                           \
        (void)printf("[ERROR] FUN [%s], LINE [%d], " fmt, __FUNCTION__,   \
             __LINE__, ## args);                                    \
} while (0)

#define SSA_PORT_DEBUG(fmt, args...) do {                                           \
    if (g_ssa_port_debug) {                                                           \
        (void)printf("FILE [%s], LINE [%d], FUN [%s], " fmt,  __FILE__, __LINE__,   \
             SSA_PORT_FUNCTION_NAME(), ## args);                                    \
    }                                                                               \
} while (0)

#define SSTEST_DBG_ERR(fmt, args...) do {                                           \
    if (g_ssa_port_debug || g_ssa_port_debug_error) {                               \
        (void)printf("FILE [%s], LINE [%d], FUN [%s], " fmt,  __FILE__, __LINE__,   \
             SSA_PORT_FUNCTION_NAME(), ## args);                                    \
    }                                                                               \
} while (0)

#define SSTEST_DBG_TEST(fmt, args...) do {                                          \
    if (g_ssa_port_debug || g_ssa_port_debug_test) {                                \
        (void)printf("FILE [%s], LINE [%d], FUN [%s], " fmt,  __FILE__, __LINE__,   \
             SSA_PORT_FUNCTION_NAME(), ## args);                                    \
    }                                                                               \
} while (0)  

#define PTD_CHK_RET_RETURN_VAL(ret, fmt, args...)       do { \
    if ((ret) != 0) { \
        SSA_PTD_ZLOG_ERROR(fmt, ##args);\
        return (ret); \
    } \
} while(0)

#define SSA_PORT_NULL_PARAM_CHECK_RETURN(_param) do {            \
    if ((_param) == NULL) {                                      \
        SSA_PTD_ZLOG_ERROR("pointer NULL!\n");                       \
        return SSA_PORT_E_IVPARAM;                               \
    }                                                            \
} while (0)

#define SSA_PORT_NULL_PARAM_WARN_CHECK_RETURN(_param) do {       \
    if ((_param) == NULL) {                                      \
        SSA_PTD_ZLOG_WARN("pointer NULL!\n");                       \
        return SSA_PORT_E_IVPARAM;                               \
    }                                                            \
} while (0)

#define SSA_PORT_NULL_PARAM_CHECK_NO_RETURN(_param) do {         \
    if ((_param) == NULL) {                                      \
        SSA_PTD_ZLOG_ERROR("pointer NULL!\n");                       \
        return;                                                  \
    }                                                            \
} while (0)

#define SSA_PORT_INTF_ERRFNC_RET(func)                                            \
do {                                                                              \
    int32_t   __rv = (func);                                                      \
    if (__rv < 0) {                                                               \
        SSA_PTD_ZLOG_ERROR("return rv %d, msg(%s)\n", __rv, bcm_errmsg(__rv));       \
        return SSA_PORT_E_RETURN;                                                 \
    }                                                                             \
} while (0)

extern int port_fac_debug_level;
extern int port_fac_test_mode;

    /* ������Ϣ*/
#define PORT_FAC_ERR(fmt, args...)                                       \
    do {                                                                     \
        if (port_fac_debug_level & 0x1) {                                     \
            printf("[%s][%d][%s]: " fmt, __FUNCTION__, __LINE__, "ERR", ##args);\
        }                                                                    \
    } while(0)
    
#define PORT_FAC_INFO(fmt, args...)                                       \
    do {                                                                     \
        if (port_fac_debug_level & 0x2) {                                     \
            printf("[%s][%d][%s]: " fmt, __FUNCTION__, __LINE__, "PRT", ##args);\
        }\
    } while(0)
    
#define SSA_PORT_FAC_BCM_ERR_RET(func)                                            \
    do {                                                                              \
        int _rv = (func);                                                      \
        if (_rv < 0) {                                                               \
            PORT_FAC_ERR("SSA_PORT_FAC_BCM_ERR_RET bcm_api_rv %d\n", _rv);                                   \
            return PORT_FAC_ERROR;                                                 \
        }                                                                             \
    } while (0)

#endif  /* PTD_DEBUG_H_ */

