/*
  * Copyright(C) 2019 Ruijie Network. All rights reserved.
  */
/*
  * ptd_fastlink.h
  * Original Author: linxiao@ruijie.com.cn 2019-2-14
  * 
  * port fast link
  *      
  * History
  */
#ifndef PTD_FASTLINK_H_
#define PTD_FASTLINK_H_

typedef enum fastlink_type_e {
    TYPE_NONE,
    TYPE_SCAN,  /* 定时扫描 */
    TYPE_PHY,   /* phy中断 */
    TYPE_SCAN_ALL_PORT,
} fastlink_type_t;      /* 电口快速link 类型 */

#define PHY_BCM452XX_REG_COPPER_LINK_STAT_CHANGE           (1 << 1)
#define PHY_BCM452XX_REG_FIBER_LINK_STAT_CHANGE            (1 << 6)

#endif /* PTD_FASTLINK_H_ */
