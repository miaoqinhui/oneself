/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */

#ifndef _PTD_LED_H_
#define _PTD_LED_H_

#include <stdint.h>
#define DATARAM_LINK_DOWN_PHYPORT            30

/**
 * out_ssa_port_led_init - led�Ƶĳ�ʼ��
 *
 * return:�ɹ�����0,ʧ�ܸ�ֵ
 */
extern int ptd_led_init(int unit);

extern void out_ssa_port_led_fiber_copper_set(int32_t unit, int32_t lport, int32_t is_copper);


void cust_ssa_port_led_oper(int unit, int addr, int is_copper);


#endif /* _PTD_LED_H_ */

