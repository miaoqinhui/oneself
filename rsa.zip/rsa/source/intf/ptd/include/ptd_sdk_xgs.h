#ifndef _PTD_SDK_XGS_H_
#define _PTD_SDK_XGS_H_
#include <stdio.h>
#include <rg_sys/list.h>

/* the currently using cache info struct
 * unit_port_conf_eff_s : this cache maintains the effective SDK attr conf cache, which can be seen as a hardware cache
 * split_port_cache_s : this cahce maintains the map of dev-fack-unit-port and sdk-real-unit-port of the split-port for
 *                      1:N split situation. and this cache also contains some cap info like split port_num split_sup_type(cold or hot)
 */    
#define EXTERNAL_PHY_542XXX                    1
#define EXTERNAL_PHY_84844                     2

typedef struct unit_port_conf_eff_s
{
    int unit;
    int port;
    
    int sdk_speed;
    int sdk_duplex;

    /* flowctrl config */
    int sdk_pause_t;
    int sdk_pause_r;

    /* an ability */
    int sdk_adv_mask;
    int sdk_an;
    
    int admin;
    int loopback;

    /* SDK trans related */
    int iftype;
    int firmode;
    int fec;
} unit_port_conf_eff_t;

#define MAX_SPLIT_PORT_NUM     10     /* MAX split num a port can split */

typedef struct split_port_cache_s
{
    /* splited port info */
    int unit;
    int port;

    int split_port_sup_type;   /* cold or hot */
    int count;     /* split port num */
    int dev_chip_port[MAX_SPLIT_PORT_NUM];  /* dev unit-port */
    int real_chip_port[MAX_SPLIT_PORT_NUM]; /* sdk unit-port */
} split_port_cache_t;

/* the ptd universal list cache api and struct
 * this list struct only realizes a list whose head is for per unit and node is the unit-port of this unit
 * the specific data struct is void* and can be anything related to unit-port
 */
typedef struct unit_port_info_list_s {
    struct list_head list;
    int         port;
    void *cache_info;
} unit_port_info_list_t;

typedef struct ptd_sdk_fiber_conf_info_s {
    int iftype;
    int firmode;
    int fec;
    /* preeph not neeed cache now */
} ptd_sdk_fiber_conf_info_t;

#endif /*_PTD_SDK_XGS_H_*/

