/*   ��׼��ͷ�ļ� */
#ifndef __PTD_INIT_H_
#define __PTD_INIT_H_
/* xiamengbing@duijie.com.cn hugely modified -- 20081030 */

/* common */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/prctl.h>
#include <time.h>
#include <signal.h>
#include <sys/time.h>
#include <semaphore.h>
#include <rg_sys/list.h>
#include <sys/mman.h>

/* free to include */
#include "ptd_trans.h"
#include "ptd_led.h"
#include "ptd_fiber.h"
#include "ptd_config.h"
#include "ptd_sdk_xgs.h"
#include "ptd_com.h"

/* proto */
#include <libpub/rg_protobuf_rt/s/intf/sdp_ptm.pb-c.h>
#include <libpub/rg_protobuf_rt/s/frame/config_end_comm.pb-c.h>
#include <libpub/rg_protobuf_rt/s/bsp/dfd.pb-c.h>
#include <libpub/rg_protobuf_rt/s/dev/ptd.pb-c.h>
#include <libpub/rg_protobuf_rt/p/dev/dad.pb-c.h>

/* split and frm */
//#include "../../split/intf_split.h"
//#include "../../split/intf_split_file.h"

/* DEFAULT min vsl support speed bug460237 */
#define PORT_VSL_SUPP_MIN_SP_DEFAULT    10000

/* backplane do not care the unit */
#define BACK_PLANE_UNIT            0

/* �˿������ܹ����ͺ�ö�� */
typedef enum ptd_arch_type_e
{
    PTD_NPS = 0,
    PTD_DNX,
    PTD_RTK,
    PTD_MARVEL,
    PTD_XGS,
    PTD_COUNT,
} ptd_arch_type_t;

typedef enum ptd_bp_type_e {
    BP_TYPE_CM,
    BP_TYPE_FE,
    BP_TYPE_LC,
    BP_COUNT,
} ptd_bp_type_t;

/**********�����ӿ����********/
typedef int (*ptd_set_admin_fun)(ptd_info_t *ptd, int port_stat);
typedef int (*ptd_get_admin_fun)(ptd_info_t *ptd, int *port_stat);
typedef int (*ptd_set_attr_fun)(ptd_info_t *ptd, ptd_attr_info_t *port_att, ptd_attr_eff_info_t *ptd_attr_eff_info);
typedef int (*ptd_del_attr_fun)(ptd_info_t *ptd);   /* sdk attr cache DEL func */
typedef int (*ptd_set_mtu_fun)(ptd_info_t *ptd, int mtu);
typedef int (*ptd_set_medium_fun)(unsigned int phyid, int medium);
typedef int (*ptd_get_medium_fun)(int unit, int port, int *medium);
typedef int (*ptd_set_loopback_fun)(ptd_info_t *ptd, int lb);
typedef int (*ptd_get_loopback_fun)(ptd_info_t *ptd, int *lb);
typedef int (*ptd_clear_mib_fun)(int unit, int port);
typedef int (*ptd_clear_mib_ex_fun)(int unit, int port);
typedef int (*ptd_get_mib_fun)(void);
typedef int (*ptd_set_vsl_fun)(ptd_info_t *ptd, int mode);
typedef int (*ptd_init_port_fun)(int unit);
typedef int (*ptd_fiber_set_fun)(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_old, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new);
typedef int (*ptd_get_attr_fun)(int unit, int port ,ptd_attr_info_t *port_att);
typedef int (*ptd_drv_medium_to_ptm)(int drv_medium);

/******** interfaces relate to backplane *********/
typedef int (*ptd_set_bp_attr_fun)(ptd_info_t *ptd_bp, ptd_bp_attr_info_t *port_bp_attr);
typedef int (*ptd_get_bp_attr_fun)(int unit, int port ,ptd_bp_attr_info_t *port_att);
typedef int (*ptd_del_bp_attr_fun)(ptd_info_t *ptd_bp);
typedef int (*ptd_get_mib_fun)(void);
typedef int (*ptd_clr_mib_fun)(int unit, int port);

typedef struct ptd_ops_s {
    ptd_set_admin_fun               set_admin;
    ptd_get_admin_fun               get_admin;
    ptd_set_attr_fun                set_attr;
    ptd_del_attr_fun                del_attr;
    ptd_set_mtu_fun                 set_mtu;
    ptd_set_medium_fun              set_medium;
    ptd_set_loopback_fun            set_loopback;
    ptd_get_loopback_fun            get_loopback;
    ptd_set_vsl_fun                 set_vsl;
    ptd_clear_mib_fun               clear_mib;
    ptd_clear_mib_ex_fun            clear_mib_ex;
    ptd_get_mib_fun                 get_mib;
    ptd_get_medium_fun              get_medium;
    ptd_fiber_set_fun               set_interface;
    ptd_fiber_set_fun               set_firemode;
    ptd_fiber_set_fun               set_preemphasis;
    ptd_fiber_set_fun               set_fec;
    ptd_init_port_fun               init_port;
    ptd_get_attr_fun                get_attr;
    ptd_drv_medium_to_ptm           drv_medium_to_ptm;
} ptd_ops_t;

typedef struct ptd_bp_ops_s {
    ptd_set_admin_fun             set_bp_admin;
    ptd_get_admin_fun             get_bp_admin;
    ptd_set_bp_attr_fun           set_bp_attr;
    ptd_get_bp_attr_fun           get_bp_attr;
    ptd_del_bp_attr_fun           del_bp_attr;
    ptd_clear_mib_fun             clear_bp_mib;
    ptd_get_mib_fun               get_bp_mib;
    ptd_init_port_fun          init_port;
} ptd_bp_ops_t;

typedef struct ptd_arch_s {
    int type;
    ptd_ops_t *ptd_ops;
} ptd_arch_t;

typedef struct ptd_bp_arch_s {
    ptd_bp_type_t type;
    ptd_bp_ops_t *ptd_bp_ops;
} ptd_bp_arch_t;

extern ptd_ops_t *g_ptd;
extern ptd_bp_ops_t *g_bp_ptd;

/***************����ܹ� оƬ����� ����ӿ� ���¹ҽ� ����ֱ��Ų����***************/
typedef int (*ptd_set_admin_spec_fun)(int unit, int port, int enable);
typedef int (*ptd_set_attr_spec_fun)(int unit, int port, ptd_attr_info_t *port_att);
typedef int (*ptd_link_noitify_spec_fun)(int unit, int port, int link);
typedef int (*ptd_set_vsl_spec_fun)(int unit, int port, int mode);


typedef struct ptd_spec_ops_s {
    ptd_set_admin_spec_fun      set_admin;
    ptd_set_attr_spec_fun       set_attr;
    ptd_set_vsl_spec_fun        set_vsl;
    ptd_link_noitify_spec_fun    link_noitify_spec;
} ptd_spec_ops_t;

extern ptd_spec_ops_t *g_spec_ptd[MAX_LOCAL_UNIT];
extern ptd_ops_t *ptd_get_driver_fun(int unit);
extern int ptd_trnas_update_sfp_dect_state(void);
extern void ptd_trans_dump_sfp_present(void);


#endif /* __PTD_INIT_H_ */


