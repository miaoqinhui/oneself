#include "../include/ptd_fastlink.h"
#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#include "../include/ptd_type.h"
#include <libpub/rg_mom/rg_mom_sync.h>
#include <libpub/rg_thread/rg_thread.h>

extern void ptd_write_port_link_inter(ptd_info_t *ptd);
extern void ptd_read_port_link_inter(ptd_info_t *ptd, uint16_t *p_cdata, uint16_t *p_fdata);
extern void ptd_write_phy_link_inter(ptd_info_t *ptd);
extern int32_t ptd_get_phy_recvstatus(ptd_info_t *ptd, int32_t *recv_stus, int32_t speed);

static uint8_t fastlink_st_first[MAX_LOCAL_UNIT][MAX_UNIT_PORT];/* 外部phy的link状态 */
struct timeval clear_phyinter_timer = {0, 300000};

int ptd_fastlink_init(void)
{
#if 0
	int32_t fast_type, rv;
    uint32_t lport;
    int linkscan_type;
    ptd_info_t ptd;

    SSA_PTD_ZLOG_FATAL("ptd_fastlink_init start\n");
    fast_type = ssa_port_cfg_get_copper_fastlink_type();

    switch (fast_type) {
    case TYPE_SCAN:
    case TYPE_SCAN_ALL_PORT:
        break;
    case TYPE_PHY:
        /* 使能phy中断 */
        for(lport = 1; lport <= MAX_LPORT_NUM; lport++) {
            if (!ssa_port_cfg_get_phy_scan(lport)) {
                continue;
            }

            memset(&ptd, 0, sizeof(ptd_info_t));
            rv = ptd_get_port_info_by_lport(lport, &ptd);
            if (rv != 0) {
                SSA_PTD_ZLOG_ERROR("ptd_get_port_info_by_lport fail, lport %d\n", lport);
                continue;
            }

            linkscan_type = BCM_LINKSCAN_MODE_SW;
            SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_get(ptd.unit, ptd.port, &linkscan_type));
            SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd.unit, ptd.port, BCM_LINKSCAN_MODE_NONE));
            ptd_write_phy_link_inter(&ptd);
            /* 获取Phy及port中断寄存器 */
            ptd_write_port_link_inter(&ptd);
            SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd.unit, ptd.port, linkscan_type));
        }
        break;
    default:
        break;
    }

    SSA_PTD_ZLOG_FATAL("ptd_fastlink_init end\n");
#else
// NPS需要重新实现 ，pengcheng
#endif
    return 0;
}

int ptd_clear_phy_interrupt(struct rg_thread *thread)
{
#if 0
	int rv;
    rg_global_t *global;
    uint32_t lport;
    ptd_info_t ptd;
    int linkscan_type;
    uint16_t copper_data;
    uint16_t fiber_data;
    int count_inter;    /* 用于标记中断是否完全清除 */

    if (thread == NULL) {
        SSA_PTD_ZLOG_WARN("arg is null\n");
        return -1;
    }

    global = extphy_info->global;

    SSA_PTD_ZLOG_INFO("start clear interrupt\n");
    count_inter = 0;
    PBMP_ITER(extphy_info->iter_pbmp, lport) {
        memset(&ptd, 0, sizeof(ptd_info_t));
        rv = ptd_get_port_info_by_lport(lport, &ptd);
        if (rv != 0) {
            SSA_PTD_ZLOG_ERROR("get port info by lport fail lport %d\n", lport);
            continue;
        }

        SSA_PTD_ZLOG_DEBUG("unit %d port %d clear\n", ptd.unit, ptd.port);
        linkscan_type = BCM_LINKSCAN_MODE_SW;
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_get(ptd.unit, ptd.port, &linkscan_type));
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd.unit, ptd.port, BCM_LINKSCAN_MODE_NONE));

        copper_data = 0;
        ptd_read_port_link_inter(&ptd, &copper_data, &fiber_data);
        copper_data &= PHY_BCM452XX_REG_COPPER_LINK_STAT_CHANGE;
        fiber_data &= PHY_BCM452XX_REG_FIBER_LINK_STAT_CHANGE;
        /* 清除中断 */
        if (ptd.ptm_medium == S_INTF__MEDIUM_TYPE_E__COPPER)
        {
            if (copper_data != 0) {
                count_inter = 1;
            }
        } else {
            if (fiber_data != 0) {
                count_inter = 1;
            }
        }
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd.unit, ptd.port, linkscan_type));
    }

    /* 完全清除退出 */
    if (count_inter == 0) {
        SSA_PTD_ZLOG_INFO("complete clear interrupt\n");
        /* 在此清除 */
        free(extphy_info);
        return 0;
    }
    //定时写入mib统计信息 传入unit
    rg_thread_add_timer_timeval_withname(global->master, ptd_clear_phy_interrupt, extphy_info, clear_phyinter_timer, "ptd_clear_phy_interrupt");
#else
	// NPS需要重新实现 ，pengcheng
#endif
    return 0;
}

int ptd_phy_irq_handle(rg_global_t *global, int cpld_inter_val, int unit)
{
// NPS需要重新实现，pengcheng
    return 0;
}
