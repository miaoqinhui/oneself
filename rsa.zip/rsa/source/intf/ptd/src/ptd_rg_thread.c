#include<sys/stat.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<sys/un.h>
#include<stddef.h>
#include<unistd.h>

#include "../include/ptd_com.h"
#include "../include/ptd_debug.h"
#include "../include/ptd_mom.h"

#define PTD_THREAD_NAME_LEN        (32)
#define PTD_SOCK_FILE_NAME_LEN     (32)
#define PTD_SOCK_FILE_NAME         "/tmp/ptd_srv_%d"

int  g_ptd_listen_fd[MAX_LOCAL_UNIT];      /* 主线程监听fd */
int  g_ptd_conn_fd[MAX_LOCAL_UNIT];       /* 主线程客户端连接fd */
char ptd_filename[MAX_LOCAL_UNIT][PTD_SOCK_FILE_NAME_LEN];
int g_ptd_client_fd[MAX_LOCAL_UNIT];
int g_ptd_client_socket_init[MAX_LOCAL_UNIT] = {0};

rg_global_t *g_ptd_thread_glb = NULL;
static ptd_port_type_t g_ptd_port_type[MAX_LOCAL_UNIT][MAX_UNIT_PORT];

static int g_ptd_link_conn_db[] = {
    RG_MOM_ASIC_DB,
    RG_MOM_TUNNER_DB,
    RG_MOM_IBC_DB,
};

typedef struct ptd_thread_info_s {
    rg_global_t *global;      /* !< the global of this thread */
    int unit;                 /* !< the unit that this thread manages */
} ptd_thread_info_t;

#define MAX_CONNECT_NUM 2
#define MSG_SIZE 5

extern int ptd_link_notify_msg_process(int unit, rg_global_t *global); 
extern int32_t ptd_mom_sub_format(rg_global_t *glb, rg_mom_pubsub_msg_t *pmsg, void *prvd);
extern int ptd_link_notify_msg_process(int unit, rg_global_t *global); 
extern int ptd_link_msg_to_local_list(int unit, struct list_head *link_notify_list_head_local);
extern int ptd_mom_link_notify(int unit, int port, ptd_link_notify_info_t *link_info, rg_global_t *global);

void ssa_port_link_notify_sync(int unit, int port, ptd_link_notify_info_t *info, rg_global_t *global)
{
    int  rv;

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] stat[%d] start\n", unit, port, info->linkstatus);

    rv = ptd_mom_link_notify(unit, port, info, global);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("ptd_link_notify fail\n");
    }

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] stat[%d] over\n", unit, port, info->linkstatus);

    return;
}

int ptd_link_notify_msg_process(int unit, rg_global_t *global) 
{
    struct list_head link_notify_list_head_local;
    link_notify_port_info_t *body, *body_del;
    int ret;
    
    INIT_LIST_HEAD(&link_notify_list_head_local);
          
    SSA_PTD_ZLOG_NOTICE("ptd_link_notify_process unit %d start\n", unit);
    
    /* copy the msg to local list */
    ret = ptd_link_msg_to_local_list(unit, &link_notify_list_head_local);
    if (ret != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_NOTICE("ptd_link_msg_to_local_list unit %d fail\n", unit);
        return SSA_PORT_E_RETURN;
    }
            
    /* 遍历本地节点 开始link通告 */
    list_for_each_entry_safe(body_del, body, &link_notify_list_head_local, node) {
        ssa_port_link_notify_sync(body_del->unit, body_del->port, &body_del->port_info, global);
        list_del(&body_del->node);
        free(body_del);
    }
         
    return 0;
}

/* 服务端收到link通告消息 */
int ptd_recv_msg_thread(struct rg_thread *recv_thread)
{
    struct rg_thread   *thread;
    int ret;
    char buffer[MSG_SIZE];
    struct timeval tv;
    uint32_t recv_time1, recv_time2;
    ptd_thread_info_t *ptd_thread_info;
    rg_global_t * global;
    int unit;

    SSA_PTD_ZLOG_WARN("enter.");
    if (recv_thread == NULL) {
        SSA_PTD_ZLOG_ERROR("rg_thread NULL\n");
        return SSA_PORT_E_IVPARAM;
    }

    ptd_thread_info = (ptd_thread_info_t *)(recv_thread->arg);
    global = ptd_thread_info->global;
    unit = ptd_thread_info->unit;
 
    memset(buffer, 0, sizeof(char) * MSG_SIZE);
    SSA_PTD_ZLOG_NOTICE("unit[%d] before recv.", unit);
    ret = recv(g_ptd_conn_fd[unit], buffer, MSG_SIZE, 0);
    if (ret < 0) {
        SSA_PTD_ZLOG_ERROR("recv failed unit %d\n", unit);
        return SSA_PORT_E_RETURN;
    }
    SSA_PTD_ZLOG_NOTICE("unit[%d], buffer=%d\n", unit, buffer[0]);
    (void)gettimeofday(&tv, NULL); 
    recv_time1 = tv.tv_sec * 1000 * 1000 + tv.tv_usec;
    /* 处理队列中的消息 */
    ptd_link_notify_msg_process(unit, global);  
    (void)gettimeofday(&tv, NULL); 
    recv_time2 = tv.tv_sec * 1000 * 1000 + tv.tv_usec;
    SSA_PTD_ZLOG_NOTICE("unit [%d], socket recv, recv_time1=%u, end link noitify recv_time2=%u\n", unit, recv_time1, recv_time2);
    /* 执行完需要再添加一个伪线程,客户端发送消息时触发执行函数 */
    thread = rg_thread_add_read_high_withname(global->master, ptd_recv_msg_thread, ptd_thread_info, g_ptd_conn_fd[unit],
        "ptd_connect");
    if (thread == NULL) {        
        SSA_PTD_ZLOG_ERROR("create ssa_mac_recv_aumsg thread fail\n");
        return SSA_PORT_E_RETURN;
    }
    SSA_PTD_ZLOG_WARN("done.");
    
    return SSA_PORT_E_NONE;
}

/* 监听客户端连接线程 */
int ptd_recv_client_accept_thread(struct rg_thread *accep_thread)
{
    struct rg_thread   *thread;
    rg_global_t * global;
    int unit;
    ptd_thread_info_t *ptd_thread_info;	

    if (accep_thread == NULL) {
        printf("rg_thread NULL\n");
        return -1;
    }

    ptd_thread_info = (ptd_thread_info_t *)(accep_thread->arg);
    global = ptd_thread_info->global;
    unit = ptd_thread_info->unit;

    if ((g_ptd_conn_fd[unit] = accept(g_ptd_listen_fd[unit], NULL, NULL)) < 0) {
        printf("Accept Error unit %d\n", unit);
        return -1;
    }
    SSTEST_DBG_TEST("Server get from client conn_fd=%d unit %d!\n", g_ptd_conn_fd[unit], unit);

    /* 再添加一个带名字的伪线程,客户端发送消息时触发执行函数 */
    thread = rg_thread_add_read_withname(global->master, ptd_recv_msg_thread, ptd_thread_info, g_ptd_conn_fd[unit],
        "ptd_connect"); 
    if (thread == NULL) {        
        printf("create ptd_recv_aumsg thread fail\n");
        close(g_ptd_conn_fd[unit]);
        return -1;
    }
    
    return 0;    
}

int ptd_server_socket_init(int unit, rg_global_t *global, ptd_thread_info_t *ptd_thread_info) 
{
    struct sockaddr_un un;
    struct rg_thread *thread;
    int rv;

    g_ptd_listen_fd[unit] = socket(AF_UNIX, SOCK_STREAM, 0);
    if (g_ptd_listen_fd[unit] < 0) {
        printf("request socket failed!\n");
        return -1;
    }
    printf("socket listen fd=%d unit %d\n", g_ptd_listen_fd[unit], unit);

    un.sun_family = AF_UNIX;
    memset(ptd_filename[unit], 0, sizeof(char) * PTD_SOCK_FILE_NAME_LEN);
    snprintf(ptd_filename[unit], PTD_SOCK_FILE_NAME_LEN, PTD_SOCK_FILE_NAME, unit);
    unlink(ptd_filename[unit]);
    strncpy(un.sun_path, ptd_filename[unit], sizeof(un.sun_path));
    rv = bind(g_ptd_listen_fd[unit], (struct sockaddr *)&un, sizeof(un));
    if (rv < 0) {
        perror("bind failed!\n");
        close(g_ptd_listen_fd[unit]);
        return -1;
    }

    if (listen(g_ptd_listen_fd[unit], MAX_CONNECT_NUM) < 0) {
        printf("listen failed!\n");
        close(g_ptd_listen_fd[unit]);
        return -1;
    }

    /* 添加一个带名字的伪线程,客户端连接时触发执行函数 */
    thread = rg_thread_add_read_withname(global->master, ptd_recv_client_accept_thread, ptd_thread_info, 
        g_ptd_listen_fd[unit], "ptd_accept");
    if (thread == NULL) {
        printf("create ptd_recv_client_accept_thread thread fail!\n");
        close(g_ptd_listen_fd[unit]);
        return -1;
    }
    SSTEST_DBG_TEST("ptd_server_socket_init unit %d OK!\n", unit);
    return 0;    
}

int ptd_client_socket_send(int unit)
{
    struct sockaddr_un un;
    char buffer[MSG_SIZE] = {1,2,3};
    struct timeval tv;
    uint32_t begin_time;
    int rv;

    SSA_PTD_ZLOG_WARN("start send.");
    if (g_ptd_client_socket_init[unit] == 0) {
        un.sun_family = AF_UNIX;
        strncpy(un.sun_path, ptd_filename[unit], sizeof(un.sun_path));

        /*  建立套接字  */
        g_ptd_client_fd[unit] = socket(AF_UNIX, SOCK_STREAM, 0);
        if (g_ptd_client_fd[unit] < 0) {
            SSA_PTD_ZLOG_ERROR("request socket failed!\n");
            return -1;
        }
        SSTEST_DBG_TEST("client socket create OK client_fd=%d unit %d\n", g_ptd_client_fd[unit], unit);
        if (connect(g_ptd_client_fd[unit], (struct sockaddr *)&un, sizeof(un)) < 0) {
            SSA_PTD_ZLOG_ERROR("connect socket failed unit %d\n", unit);
            close(g_ptd_client_fd[unit]);
            return -1;
        }
        g_ptd_client_socket_init[unit] = 1;
    }
  
    (void)gettimeofday(&tv, NULL); 
    begin_time = tv.tv_sec * 1000 * 1000 + tv.tv_usec;
    SSA_PTD_ZLOG_NOTICE("socket send, begin=%u", begin_time);
    rv = send(g_ptd_client_fd[unit], buffer, MSG_SIZE, 0);
    if (rv != MSG_SIZE) {
        SSA_PTD_ZLOG_ERROR("socket send return fail rv=%d", rv);
    }        
    SSA_PTD_ZLOG_WARN("after send.");

    return SSA_PORT_E_NONE;
}

int ptd_socket_thread_init(int unit, rg_global_t *global, ptd_thread_info_t *ptd_thread_info)
{
    int rv;

    rv = ptd_server_socket_init(unit, global, ptd_thread_info);
    if (rv < SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("ptd_socket_thread_init fail rv=%d unit %d\n", rv, unit);
    }
    
    return rv;
}

void ptd_set_port_type(int unit, int port, int type)
{
    g_ptd_port_type[unit][port] = type;

    return;
}

int ptd_get_port_type(int unit, int port, int *type)
{
    if (unit < 0 || unit >= MAX_LOCAL_UNIT || port < 0 || port >= MAX_UNIT_PORT) {
        return SSA_PORT_E_IVPARAM;
    }

    *type = g_ptd_port_type[unit][port];

    return SSA_PORT_E_NONE;
}

static void *ptd_link_thread(void *arg)
{
    int max_unit_num, i, db_id;
    uint32_t phyid;
    libddm_lport_ctrl_t port;
    ptd_thread_info_t ptd_thread_info;
    char name[PTD_THREAD_NAME_LEN] = "ptd_link_thread";
    PDev__VslFormat     format = P_DEV__VSL_FORMAT__INIT;
    PDev__VslPortIndex  vslindex = P_DEV__VSL_PORT_INDEX__INIT;
    int ret;

    prctl(PR_SET_NAME, name);

    g_ptd_thread_glb = rg_global_init(name, g_ptd_thread_glb);
    if (g_ptd_thread_glb == NULL) {
        SSTEST_DBG_ERR("rg_global_init fail!\n");
        return NULL;
    }
    ptd_thread_info.global = g_ptd_thread_glb;
    SSA_PTD_ZLOG_WARN("ptd_thread global:%p!", ptd_thread_info.global);

    max_unit_num = dm_get_board_switch_unit();
    if (max_unit_num <= 0) {
        SSTEST_DBG_ERR("max_unit_num:%d get error!\n", max_unit_num);
        return NULL;
    }

    for (i = 0; i < max_unit_num; i++) {
        /* init cache */
        libddm_for_each_unit_port(phyid, i, port) {
            SSA_PTD_ZLOG_DEBUG("phyid = 0x%x", phyid);
            ptd_set_port_type(i, port.cp, PTD_ETH_PORT);
            SSA_PTD_ZLOG_WARN("[unit:%d port:%d] port_type is unknown!\n", i, port.cp);
        }
        /* COV:XMB ptd_thread_info.unit not init here must be i */
        ret = ptd_socket_thread_init(i, ptd_thread_info.global, &ptd_thread_info);
        SSA_PTD_ZLOG_WARN("ptd_socket_thread_init over, ret:%d", ret);
    }

    for (db_id = 0; db_id < SSA_FRM_ARRAY_SIZE(g_ptd_link_conn_db); db_id++) {
        ret = rg_mom_client_connect_sync(ptd_thread_info.global, g_ptd_link_conn_db[db_id]);
        if (ret != 0) {
            SSA_PTD_ZLOG_ERROR("rg_mom_client_connect_sync db:%d fail!", g_ptd_link_conn_db[db_id]);
            return NULL;
        }
        SSA_PTD_ZLOG_WARN("ptd_link_thread connect to db:%d succ", g_ptd_link_conn_db[db_id]);
    }

    format.index = &vslindex;
    ret = rg_mom_subscribe(ptd_thread_info.global, RG_MOM_IBC_DB, (const rg_obj*)&format, 0, ptd_mom_sub_format, NULL);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("sub PDev__VslFormat fail!");
        return NULL;
    }

    SSA_PTD_ZLOG_WARN("run ptd_link_thread name[%s]!", name);
    rg_global_run(ptd_thread_info.global);
    rg_global_finish(ptd_thread_info.global);

    return NULL;
}

int ptd_thread_init(void)
{
    pthread_t pthread;
    int ret;

    ret = pthread_create(&pthread, NULL, (void *)ptd_link_thread, NULL);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("create ptd_link_thread failed: ret:%d", ret);
        return -1;
    }
    pthread_detach(pthread);

    return 0;
}
