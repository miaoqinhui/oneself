/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * ssa_port_stat.c
 * Original Author:  xudongxu@ruijie.com.cn, 2018-12-7
 *
 * port模块ssa统计计数实现文件
 *
 * History
 */

#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"


/* mib cache for mom to update unit-port that has traffic */
typedef struct ptd_mib_cache_s {
    uint64_t buf[SSA_PORT_STAT_BUF_NUM]; /* for normal mib */
    uint64_t dbg_cnt_urpf;               /* for mib-ex */
    int mib_notify_linger_cnt;           /* this arg is intended for temperorily solving 472187
                                          * make the mib for no traffic port to linger serveral time for LSM to calculate the rate to 0
                                          */
    int mib_ex_notify_linger_cnt;
} ptd_mib_cache_t;

static ptd_mib_cache_t *ptd_mib_cache[MAX_LOCAL_UNIT];

static int ptd_mib_cache_init(int unit)
{
    int unit_port_count;
    int len;

    unit_port_count = 256;//BCM_PBMP_PORT_MAX;根据NPS的实际端口数修订 ，pengcheng
    SSA_PTD_ZLOG_WARN("ptd_mib_cache_init unit[%d], port_num[%d]\n", unit, unit_port_count);

    len = unit_port_count * sizeof(ptd_mib_cache_t);
    ptd_mib_cache[unit] = (ptd_mib_cache_t *)malloc(len);
    SSA_PORT_NULL_PARAM_WARN_CHECK_RETURN(ptd_mib_cache[unit]);
    memset(ptd_mib_cache[unit], 0, len);
    SSA_PTD_ZLOG_NOTICE("ptd_mib_cache_init unit[%d], port_num[%d] OK\n", unit, unit_port_count);

    return SSA_PORT_E_NONE;
}

int ptd_mib_unitport_mib_update(int unit, int port, uint64_t *buf)
{
    SSA_PORT_NULL_PARAM_WARN_CHECK_RETURN(buf);
    SSA_PORT_NULL_PARAM_WARN_CHECK_RETURN(ptd_mib_cache[unit]);

    memcpy(&(ptd_mib_cache[unit][port].buf), buf, (sizeof(uint64_t) * SSA_PORT_STAT_BUF_NUM));

    return SSA_PORT_E_NONE;
}

int ptd_mib_unitport_mib_ex_update(int unit, int port, uint64_t *dbg_cnt_urpf)
{

    SSA_PORT_NULL_PARAM_WARN_CHECK_RETURN(dbg_cnt_urpf);
    SSA_PORT_NULL_PARAM_WARN_CHECK_RETURN(ptd_mib_cache[unit]);

    memcpy(&(ptd_mib_cache[unit][port].dbg_cnt_urpf), dbg_cnt_urpf, sizeof(uint64_t));

    return SSA_PORT_E_NONE;
}


int ptd_mib_unitport_mib_need_notify(int unit, int port, uint64_t *buf)
{
    int i;
    int rv;

    if (ptd_mib_cache[unit] == NULL) {
        return PTD_MIB_NEED_NOTI;
    }

    rv = PTD_MIB_NO_NEED_NOTI;
    for (i = 0; i < SSA_PORT_STAT_BUF_NUM; i++) {
        SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] type[%d] sdk[%llu] cache[%llu] mib need notify!",
            unit, port, i, buf[i], ptd_mib_cache[unit][port].buf[i]);
        if (buf[i] != ptd_mib_cache[unit][port].buf[i]) {
            rv = PTD_MIB_NEED_NOTI;
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] type[%d] mib need notify def[%d]!",
                unit, port, i, ptd_mib_cache[unit][port].mib_notify_linger_cnt);
            break;
        }
    }

    /* here to determine the linger time
     * see whether we will override the dicision or restore the mib_notify_linger_cnt to default
     */
    if ((rv == PTD_MIB_NO_NEED_NOTI) && (ptd_mib_cache[unit][port].mib_notify_linger_cnt > 0)) {
        /* if this port PTD_MIB_NO_NEED_NOTI and we still has linger-cnt remaining
         * we override the vr to PTD_MIB_NEED_NOTI and consume a linger-cnt
         */
        ptd_mib_cache[unit][port].mib_notify_linger_cnt--;
        rv = PTD_MIB_NEED_NOTI;
        SSA_PTD_ZLOG_DEBUG("override unit[%d] port[%d] type[%d] mib_notify_linger_cnt[%d] rv[%d]!",
            unit, port, i, ptd_mib_cache[unit][port].mib_notify_linger_cnt, rv);
    } else if (rv == PTD_MIB_NEED_NOTI) {
        /* if need notify mib, linger cnt is set to defaut */
        ptd_mib_cache[unit][port].mib_notify_linger_cnt = ssa_port_cfg_get_mib_notify_linger_cnt();
    }

    return rv;
}

int ptd_mib_unitport_mib_ex_need_notify(int unit, int port, uint64_t *dbg_cnt_urpf)
{
    int rv;

    if (ptd_mib_cache[unit] == NULL) {
        return PTD_MIB_NEED_NOTI;
    }

    rv = PTD_MIB_NO_NEED_NOTI;
    if (ptd_mib_cache[unit][port].dbg_cnt_urpf != *dbg_cnt_urpf) {
        SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] mib-ex need notify!", unit, port);
        rv = PTD_MIB_NEED_NOTI;
    }

    /* here to determine the linger time
     * see whether we will override the dicision or restore the mib_notify_linger_cnt to default
     */
    if ((rv == PTD_MIB_NO_NEED_NOTI) && (ptd_mib_cache[unit][port].mib_ex_notify_linger_cnt > 0)) {
        /* if this port PTD_MIB_NO_NEED_NOTI and we still has linger-cnt remaining
         * we override the vr to PTD_MIB_NEED_NOTI and consume a linger-cnt
         */
        ptd_mib_cache[unit][port].mib_ex_notify_linger_cnt--;
        rv = PTD_MIB_NEED_NOTI;
        SSA_PTD_ZLOG_DEBUG("override unit[%d] port[%d] mib_ex_notify_linger_cnt[%d] rv[%d]!",
            unit, port, ptd_mib_cache[unit][port].mib_ex_notify_linger_cnt, rv);
    } else if (rv == PTD_MIB_NEED_NOTI) {
        /* if need notify mib, linger cnt is set to defaut */
        ptd_mib_cache[unit][port].mib_ex_notify_linger_cnt = ssa_port_cfg_get_mib_notify_linger_cnt();
    }

    return rv;
}
#if 0
/* 用来存放需要从线卡发送回去的端口统计�?*/
/**********************剥离到cust_ssa_port.c**********************************/
static int32_t buf_rt[SSA_PORT_STAT_BUF_NUM] = {
    [0] = snmpDot1dTpPortInFrames,
    [1] = snmpIfInUcastPkts,
    [2] = snmpIfHCInMulticastPkts,
    [3] = snmpIfHCInBroadcastPkts,
    [4] = snmpEtherStatsUndersizePkts,
    [5] = snmpEtherStatsOversizePkts,
    [6] = snmpEtherStatsFragments,
    [7] = snmpEtherStatsJabbers,
    [8] = snmpEtherStatsCollisions,
    [9] = snmpBcmReceivedPkts64Octets,
    [10] = snmpBcmReceivedPkts65to127Octets,
    [11] = snmpBcmReceivedPkts128to255Octets,
    [12] = snmpBcmReceivedPkts256to511Octets,
    [13] = snmpBcmReceivedPkts512to1023Octets,
    [14] = snmpBcmReceivedPkts1024to1518Octets,
    [15] = snmpIfInErrors,
    [16] = snmpIfInUnknownProtos,
    [17] = snmpIfInDiscards,
    [18] = snmpEtherStatsCRCAlignErrors,
    [19] = snmpDot3StatsAlignmentErrors,
    [20] = snmpEtherStatsPkts64Octets,
    [21] = snmpDot3StatsFrameTooLongs,
    [22] = snmpDot3StatsSingleCollisionFrames,
    [23] = snmpDot3StatsMultipleCollisionFrames,
    [24] = snmpDot3StatsSQETTestErrors,
    [25] = snmpDot3StatsDeferredTransmissions,
    [26] = snmpDot3StatsLateCollisions,
    [27] = snmpDot3StatsExcessiveCollisions,
    [28] = snmpDot3StatsInternalMacTransmitErrors,
    [29] = snmpDot3StatsInternalMacReceiveErrors,
    [30] = snmpDot3StatsCarrierSenseErrors,
    [31] = snmpDot1dTpPortOutFrames,
    [32] = snmpIfOutUcastPkts,
    [33] = snmpIfHCOutMulticastPkts,
    [34] = snmpIfHCOutBroadcastPckts,
    [35] = snmpIfOutErrors,
    [36] = snmpIfOutDiscards,
    [37] = snmpIfInOctets,
    [38] = snmpIfOutOctets
};
#endif
void ptd_convertmib_to_ptm(int unit, int port, uint64_t *buf, SIntf__StatMibinfo *buf_sport)
{
    struct timespec mib_time;
    uint64_t stp_block_cnt;

    /* get monotonic itme, in consideration of set clock action and performance */
    clock_gettime(CLOCK_MONOTONIC, &mib_time);

    /*fix bug 95134*/
    buf_sport->in_pkts = buf[0];// + cust_ssa_port_get_runts_pkt(unit, port);
    buf_sport->in_ucast_pkts = buf[1];
    buf_sport->in_multicast_pkts = buf[2];
    buf_sport->in_broadcast_pkts = buf[3];
    buf_sport->inp_small_pkts_ok = buf[4];
    /* fix bug 89003,大于MTU的报文需要统计到oversize字段 */
    buf_sport->inp_large_pkts_ok = buf[5] + buf[21];
    buf_sport->inp_small_pkts_err = buf[6];
    buf_sport->inp_large_pkts_err = buf[7];
    buf_sport->etherstatscollisions = buf[8];
    buf_sport->etherstatspkts64octets = buf[9];
    buf_sport->etherstatspkts65to127octets = buf[10];
    buf_sport->etherstatspkts128to255octets = buf[11];
    buf_sport->etherstatspkts256to511octets = buf[12];
    buf_sport->etherstatspkts512to1023octets = buf[13];
    buf_sport->etherstatspkts1024to1518octets = buf[14];
    buf_sport->inp_error_pkts = buf[15];
    /* snmpIfInErrors不包括RMTUEr的统计值的时候需要加�?*/
    if (ssa_port_cfg_get_inerror_exclude_rmtu()) {
        buf_sport->inp_error_pkts += buf[21];
    }
    buf_sport->inp_unknown_pkts = buf[16];
    buf_sport->inp_drop_pkts = buf[17];
    buf_sport->inp_crcerror_pkts = buf[18];
    buf_sport->inp_overrun_pkts = 0;
    buf_sport->inp_abort_pkts = 0;
    buf_sport->inp_alignerror_pkts = buf[19];
    buf_sport->inp_res_lack_pkts = 0;
    buf_sport->inp_small_pkts = buf[20];
    buf_sport->inp_large_pkts = buf[21];
    buf_sport->inp_qos_drops = 0;
    buf_sport->sing_collsn = buf[22];
    buf_sport->mult_collsn = buf[23];
    buf_sport->sqe_test = buf[24];
    buf_sport->defe_trans = buf[25];
    buf_sport->late_collsn = buf[26];
    buf_sport->exce_collsn = buf[27];
    buf_sport->int_mact_err = buf[28];
    buf_sport->int_macr_err = buf[29];
    buf_sport->carsens_err = buf[30];
    buf_sport->out_pkts = buf[31];
    buf_sport->out_ucast_pkts = buf[32];
    buf_sport->out_multicast_pkts = buf[33];
    buf_sport->out_broadcast_pkts = buf[34];
    /* 包含出口单播拥塞丢包报文个数 */
    buf_sport->outp_error_pkts = buf[35];
    buf_sport->outp_drop_pkts = buf[36];
    /* 出口丢弃的报文不需要包括stp block丢弃的报�?*/
    //customer_ssa_port_read_tdbgc8r(&stp_block_cnt, unit, port);
    if (stp_block_cnt >= buf_sport->outp_drop_pkts) {
        buf_sport->outp_drop_pkts = 0;
    } else {
        buf_sport->outp_drop_pkts -= stp_block_cnt;
    }
    buf_sport->outp_collision_pkts = 0;
    buf_sport->outp_underrun_pkts = 0;
    buf_sport->outp_res_lack_pkts = 0;
    buf_sport->no_buffer_count = 0;
    buf_sport->reset_count = 0;
    buf_sport->trans_count = 0;
    buf_sport->parity_err_count = 0;
     /* fix bug  95134 需加上run报文*/
    buf_sport->in_octets = buf[37];
    buf_sport->out_octets = buf[38];
    buf_sport->inp_small_pkts = buf_sport->inp_small_pkts_ok + buf_sport->inp_small_pkts_err;

    buf_sport->timestamp = mib_time.tv_sec * 1000 + mib_time.tv_nsec / 1000000;
    SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] timestamp[%llu]", unit, port,buf_sport->timestamp);
    buf_sport->tx_byte_giga = 0;
    buf_sport->rx_byte_giga = 0;

    return;
}

int32_t ptd_mib_get_mib_ex_info(int32_t unit, int32_t port, uint64_t *value)
{
#if 0
	uint64_t ex_mib_cnt;

    if (!SOC_UNIT_VALID(unit)) {
        return SSA_PORT_E_NONE;
    }

    /* urpf统计到rdbgc8 */
    customer_ssa_port_read_rdbgc8r(&ex_mib_cnt, unit, port);
    SSA_PTD_ZLOG_DEBUG("===>unit[%d], port [%d] rdbgc8r valude[%lu]\n", unit, port, ex_mib_cnt);
    *value = ex_mib_cnt;
#else
	//NPS need to do ,pengcheng
#endif
    return SSA_PORT_E_NONE;
}

/* mib related */
/* 设置tdbgc8的值为0x8000 */
static void ptd_mib_ex_count_init(int unit)
{
#if 0
	uint32_t  bitmap_value;
    int32_t rv;

        bitmap_value = 0x8000;
        rv = customer_ssa_port_write_tdbgc8_selectr(bitmap_value, unit);
        if (rv != 0) {
            SSTEST_DBG_ERR("set tdbgc8_select to 0x8000 fail\n");
        }
#else
		//NPS need to do ,pengcheng
#endif
    return;
}

/* 扩展统计计数初始�?*/
static void ptd_mib_ex_init(int unit)
{
#if 0
	int32_t port;
    bcm_pbmp_t pbmp;

    pbmp = CUST_PBMP_E_ALL(unit);
    CUST_PBMP_ITER(pbmp, port) {
        if (bcm_stat_custom_add(unit, port, snmpBcmCustomReceive8, bcmDbgCntURPF) != 0) {
            SSTEST_DBG_ERR("bcm_stat_custom_add failed, unit %d, port %d\n", unit, port);
            /* 就算某一个端口清除失败了，其他的端口也要继续 */
        }
    }
#else
	//NPS need to do ,pengcheng
#endif
    return;
}

/**
 * out_ssa_port_stat_init - mib初始�? *
 * return: 成功0，失败负�? */
int ptd_mib_init(int unit)
{
    int ret;

    SSA_PORT_INIT_FUNC_ENTER;
    ptd_mib_ex_init(unit);
    ptd_mib_ex_count_init(unit);
    SSTEST_DBG_TEST("in_ssa_port_stat_ex_count_init success\n");

    /* init mib cache of this unit */
    ret = ptd_mib_cache_init(unit);
    if (ret != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("ptd_mib_cache_init failed, unit[%d]\n", unit);
        return SSA_PORT_E_RETURN;
    }

    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
}

/* mib related refugee puts here for now */
int ptd_clear_mib(int unit, int port)
{
#if 0
	SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], clear mib", unit, port);

    if (!SOC_UNIT_VALID(unit)) {
         return SSA_PORT_E_NONE;
    }

    SSA_PORT_INTF_ERRFNC_RET(bcm_stat_clear(unit, port));
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] mib clean", unit, port);
#else
	//NPS need to do ,pengcheng
#endif
    return SSA_PORT_E_NONE;
}

/**
 * ptd_clear_mib_ex - 清除端口统计
 * @unit:   芯片�? * @port :    端口�? * return: 成功返回0，否则返回负�? */
int ptd_clear_mib_ex(int unit, int port)
{
#if 0
	uint32_t zero_value;

    SSA_PORT_INIT_FUNC_ENTER;
    if (!SOC_UNIT_VALID(unit)) {
        return SSA_PORT_E_NONE;
    }

    zero_value = 0;
    customer_ssa_port_write_rdbgc8r(zero_value, unit, port);
    SSA_PORT_INIT_FUNC_LEAVER;
#else
	//NPS need to do ,pengcheng
#endif
    return SSA_PORT_E_NONE;
}

int32_t in_ssa_port_stat_get_mib(int32_t unit, int32_t port, uint64_t *buf)
{
#if 0
	uint32_t type;
    int32_t  rv;

    if (!SOC_UNIT_VALID(unit)) {
         return SSA_PORT_E_NONE;
    }
    for (type = 0; type < SSA_PORT_STAT_BUF_NUM; type++) {
        rv = bcm_stat_get(unit, port, buf_rt[type], &(buf[type]));
        if (rv != BCM_E_NONE) {
            SSA_PTD_ZLOG_WARN("bcm_stat_get fail unit[%d] port[%d] [%d]\n", unit, port, rv);
        }

    }
#else
//NPS need to do ,pengcheng
#endif
    return SSA_PORT_E_NONE;
}

