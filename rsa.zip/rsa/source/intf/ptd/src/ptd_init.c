/* ssa port驱动框架代码 框架负责调用相关函数 */

#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#include "../include/ptd_mom.h"

extern ptd_arch_t  ptd_nps_driver;
extern ptd_bp_arch_t ptd_cm_bp_driver;
extern ptd_bp_arch_t ptd_fe_bp_driver;
extern ptd_bp_arch_t ptd_lc_bp_driver;
ptd_arch_t *p = NULL;

//extern ssa_port_driver_arch_t ssa_port_dune_driver;
//extern ssa_port_driver_arch_t ssa_port_rtk_driver;
//extern ssa_port_driver_arch_t ssa_port_marvel_driver;

ptd_arch_t *ptd_arch[PTD_COUNT] = {
	&ptd_nps_driver,
//&ptd_xgs_driver,
//&ssa_port_dune_driver,
//&ssa_port_rtk_driver,
//&ssa_port_marvel_driver,
};

ptd_bp_arch_t *ptd_bp_arch[BP_COUNT] = {
    &ptd_cm_bp_driver,
    &ptd_fe_bp_driver,
    &ptd_lc_bp_driver,
};

ptd_ops_t *g_ptd; /* 全局芯片驱动挂载指针 */
ptd_bp_ops_t *g_bp_ptd; /* Global backplane driver mount pointer */
ptd_spec_ops_t *g_spec_ptd[MAX_LOCAL_UNIT]; /* 特殊芯片驱动处理挂载指针 */

extern ptd_ops_t *ptd_get_driver(int type);
extern void ptd_debug_init(rg_global_t *global, int unit);
extern void ptd_zlog_debug_init(void);
extern int ptd_fac_mom_init(rg_global_t *global, int unit); 
extern int ptd_fac_hw_init(int unit);
extern int ptd_mom_init(rg_global_t *global, int unit, vsd_unit_thread_info_t *unit_t_info);
extern int ptd_thread_init(void);
extern int ptd_register_linkscan(int unit);
extern void ut_ptd_debug_init(rg_global_t *global);
extern int ptd_fastlink_init(void);

ptd_ops_t *ptd_get_driver_fun(int unit)
{
    int type;

    type = PTD_NPS;
    return ptd_get_driver(type);

}

ptd_ops_t *ptd_get_driver(int type)
{
    //ptd_arch_t *p;
    int i;

    for (i = 0; i < PTD_COUNT; i++) {
        p = ptd_arch[i]; 
        if (p && p->type == type && p->ptd_ops) {
            return p->ptd_ops;
        }
    }
    /* 后期考虑是否要动态库打开 动态加载 */
    return NULL;
}

/* get backplane driver */
ptd_bp_ops_t *ptd_get_bp_driver(int type)
{
    int i;
    ptd_bp_arch_t *p;

    for (i = 0; i < BP_COUNT; i++) {
        p = ptd_bp_arch[i];
        if (p && p->type == type && p->ptd_bp_ops) {
            return p->ptd_bp_ops;
        }
    }

    return NULL;
}

static int ptd_driver_init(int unit)
{
    int type;

    //获取当前芯片架构类型 
    //type = ptd_get_soc_type(unit);

    /* 获取当前type 后期考虑抽成配置文件读取 */
    type = PTD_NPS;
    g_ptd = ptd_get_driver(type);
   	if (g_ptd == NULL) {
        SSTEST_DBG_ERR("get ssa_port_driver failed, driver is NULL\n");
        return SSA_PORT_E_RETURN;
    }
    return SSA_PORT_E_NONE;
}

static int ptd_bp_driver_init(int unit, int node_type)
{
    int rv;

    g_bp_ptd = ptd_get_bp_driver(node_type);
    if (g_bp_ptd == NULL) {
        SSTEST_DBG_ERR("get ssa_bp_port_driver failed, driver is NULL\n");
        return SSA_PORT_E_RETURN;
    }

    rv = g_bp_ptd->init_port(unit);
    if (rv != 0) {
        SSTEST_DBG_ERR("ptd driver init port failed, rv %d\n", rv);
        return rv;
    }

    return SSA_PORT_E_NONE;

}

/* cant put this in ptd_init.h, cause this func is now involving mom */
extern int ptd_trans_init(rg_global_t *global, int unit);

/* 硬件初始化在主线程里面 */
int ptd_hw_init(rg_global_t *global, int unit)
{
    int rv;
    char *app_name = "ptd_process";

    SSTEST_DBG_ERR("ptd_hw_init start");
    SSA_PORT_INIT_FUNC_ENTER;
    rv = libddm_init(global, app_name);
    if (rv != 0) {
        SSTEST_DBG_ERR("libddm init fail rv %d\n", rv);
    }
    SSTEST_DBG_ERR("libddm_init over");

    (void)ssa_port_conf_file_init();
    SSTEST_DBG_ERR("ssa_port_conf_file_init over");

    rv = ptd_driver_init(unit);
    if (rv != 0) {
        SSTEST_DBG_ERR("ssa_port_driver_init failed, rv: %d\r\n", rv);
        return rv;
    }
    SSTEST_DBG_ERR("ptd_driver_init over");

    /* not unit related. may considering do it in per unit way */
    rv = ptd_trans_init(global, unit);
    if (rv != 0) {
        SSTEST_DBG_ERR("ptd_trans_init fail, rv: %d\r\n", rv);
        return rv;
    }
    SSTEST_DBG_ERR("ptd_driver_init over");

    /* 针对特定架构 init port */
    rv = g_ptd->init_port(unit);
    if (rv != 0) {
        SSTEST_DBG_ERR("ptd driver init port failed, rv %d\n", rv);
        return rv;
    }
    SSTEST_DBG_ERR("g_ptd init_port over");

    /* fastlink初始化 */
    rv = ptd_fastlink_init();
    if (rv != 0) {
        SSTEST_DBG_ERR("ptd fastlink init port failed, rv %d\n", rv);
        return rv;
    }
    SSTEST_DBG_ERR("g_ptd fast_link_init over");

    ptd_fac_hw_init(unit);
    SSA_PORT_INIT_FUNC_LEAVER;
    SSTEST_DBG_ERR("ptd_hw_init over");
    return 0;
}


int ptd_bp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info, int node_type)
{
    int ret;
    SSTEST_DBG_ERR("ptd_bp_init enter\n");

    if ((node_type == BP_TYPE_CM) || (node_type == BP_TYPE_FE)) {
        ret = ptd_thread_init();
        if (ret != 0) {
            SSTEST_DBG_ERR("ptd_thread_init fail[%d]!\n", ret);
            return -1;
        }

        ptd_zlog_debug_init();
        SSTEST_DBG_TEST("ptd_init ptd_zlog_debug_init over\n");

        ut_ptd_debug_init(global);
        SSTEST_DBG_TEST("ptd_init ut_ptd_debug_init over\n");

        ret = ptd_register_linkscan(unit_t_info->unit);
        if (ret != SSA_PORT_E_NONE) {
            SSTEST_DBG_ERR("in_ssa_port_register_linkscan set failed, ret %d\n", ret);
            return ret;
        }
        SSTEST_DBG_TEST("ptd_register_linkscan over\n");
    }

    ret = ptd_bp_driver_init(unit_t_info->unit, node_type);
    if (ret != 0) {
        SSTEST_DBG_ERR("get ssa_bp_port_driver failed, driver is NULL\n");
        return SSA_PORT_E_RETURN;
    }

    SSTEST_DBG_ERR("ptd_bp_mom_init over\n");

    return SSA_PORT_E_NONE;
}

int ptd_fe_bp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    return ptd_bp_init(global, unit_t_info, BP_TYPE_FE);
}

int ptd_cm_bp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    return ptd_bp_init(global, unit_t_info, BP_TYPE_CM);
}

int ptd_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info) 
{
    int unit;

    SSTEST_DBG_ERR("ptd_init enter\n");
printf("%s %d.\n", __FUNCTION__, __LINE__);    
    unit = get_unit_from_unit_thread_info(unit_t_info);
    ptd_zlog_debug_init();
    SSTEST_DBG_ERR("ptd_init ptd_zlog_debug_init over\n");
    ptd_hw_init(global, unit);
    SSTEST_DBG_ERR("ptd_init ptd_hw_init over\n");
    (void)ptd_debug_init(global, unit);
    SSTEST_DBG_ERR("ptd_init ptd_debug_init over\n");
    ptd_bp_init(global, unit_t_info ,BP_TYPE_LC);
    SSTEST_DBG_ERR("ptd_init ptd_bp_init over\n");
    ptd_mom_init(global, unit, unit_t_info);    
printf("%s %d.\n", __FUNCTION__, __LINE__);
    SSTEST_DBG_ERR("ptd_init ptd_mom_init over\n");
    ptd_fac_mom_init(global, unit);
    
    SSTEST_DBG_ERR("ptd_init leave\n");
    return SSA_PORT_E_NONE;
}

