/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * ssa_port_led.c
 * Original Author:  xudongxu@ruijie.com.cn, 2018-12-7
 *
 * portģ����ģ�鹲�����ݳ�ʼ��
 *
 * History
 */
/*
 */
#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#define SSA_PORT_LED_DEBUG(fmt, args...) do {                                       \
    if (g_ssa_port_led_debug) {                                                     \
        (void)printf("FILE [%s], LINE [%d], FUN [%s], " fmt,  __FILE__, __LINE__,   \
             __FUNCTION__, ##args);                                                 \
    }                                                                               \
} while (0)

extern char * ssa_port_cfg_get_fac_led_code(void);
extern int ptd_fac_get_led_num(void);
extern int ptd_fac_get_led_code_len(void);
extern int32_t led_cb_type;

void ptd_fac_set_test_mode(int unit)
{

//nps需要重新实现，pengcheng

    return;
}

static int in_ssa_port_led_init(int unit)
{
    int rv;

    rv = 0;

	// NPS需要重新实现speed get函数 ，pengcheng
    //rv = ssa_port_led_tr3_init((char (*)[LED_CTRL_NUM][LED_CODE_LENTH])ssa_port_cfg_get_led_code(), unit);
    return rv;
}

/**
 * out_ssa_port_led_init - led�Ƶĳ�ʼ��
 *
 * return:�ɹ�����0,ʧ�ܸ�ֵ
 */
int ptd_led_init(int unit)
{
    int32_t rv, addr_led;
    uint8_t value;
    rv = in_ssa_port_led_init(unit);
    if (rv != 0) {
        SSTEST_DBG_ERR("in_ssa_port_led_init failed, rv %d\n", rv);
        return rv;
    }

    addr_led = 0;
    value = 0;
    addr_led = 0xB0; //ssa_port_cfg_get_led_address();
    if (addr_led != 0) {
        rv = ptd_read_cpld(CPLD_DEV_PATH, addr_led, &value, 1);
        if (rv < 0) {
            SSTEST_DBG_ERR("dfd_cpld_read failed, rv %d\n", rv);
            return SSA_PORT_E_RETURN;
        }
        SSTEST_DBG_TEST("read register 0x%x, value %d\n", addr_led, value);
        value |= 0xFF;//(unsigned char)ssa_port_cfg_get_led_value();
        SSTEST_DBG_ERR("write register 0x%x, value %d\n", addr_led, value);
        rv = ptd_write_cpld(CPLD_DEV_PATH, addr_led, &value, 1);
        if (rv < 0) {
            SSTEST_DBG_TEST("dfd_cpld_write failed, rv %d\n", rv);
            return SSA_PORT_E_RETURN;
        }
    }

    return SSA_PORT_E_NONE;
}

extern int32_t ssa_port_cfg_get_led_fiber_copper_addr(int32_t lport);

void out_ssa_port_led_fiber_copper_set(int unit, int lport, int is_copper)
{
    int addr;

    addr = ssa_port_cfg_get_led_fiber_copper_addr(lport);
    if (addr <= 0) {
        SSTEST_DBG_TEST("fiber copper addr is none.just return. unit%d, lport %d,is_copper %d\n",
            unit, lport, is_copper);
        return;
    }
    SSTEST_DBG_TEST("fiber copper addr 0x%x.unit%d, lport %d,is_copper %d\n",
            addr, unit, lport, is_copper);
   //cust_ssa_port_led_oper(unit, addr, is_copper);
}

