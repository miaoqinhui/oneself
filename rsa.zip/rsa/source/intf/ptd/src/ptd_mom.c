#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sched.h>
#include <stdarg.h>
#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#include "../include/ptd_mom.h"
#include <rg_dev/dm_lib/rg_ndm.h>
#include "../include/ptd_fastlink.h"

#define PTD_VSL_MAX_LPORT         (256)
#define BCM_PORT_MEDIUM_NONE   0
struct timeval timer1 = {3, 0};
/* enable框架标记 */
int g_ptd_enable_flag[MAX_LOCAL_UNIT] = {0};

/* dad shut port flag
 * these flag and pbmp is set and init when ptd get dad-isolate publish from TOPO
 * and CURRENTLY we will NOT CLEAR the flag and pbmp, ONLY because that in our circumstances
 * the slave(in VSU) get the dad-isolate msg will SURELY be POWER DOWN later.
 * but in DCN circumstances, the slave that get the dad-isolate msg will probably RECOVER.
 * so under such circumstances, this FLAG and PBMP must be reinit, or the baisc function will fail
 */
int g_ptd_dad_isolate_flag[MAX_LOCAL_UNIT] = {0};

static int32_t g_ptd_local_devid = 1;
static bool g_ptd_vsl_link_state[PTD_VSL_MAX_LPORT];

/* fec notify cache we dont want to renotify fec status
 * so we make a cache to filter this
 * but this is bad way to do this. since fec is now a upper-config,
 * so its better for us to filter this at mom-lever
 * but now we dare not do this, save this to nex project
 * maybe its better to decide all the data conf to SDK here
 * some conf may call drv-callback to determine the final config to SDK
 */
static int ptd_fec_notify_cache[MAX_LPORT_NUM];

typedef struct unit_port_conf_enable_s {
    int unit;
    int port;
    ptd_info_t ptd;
    int admin;
} unit_port_conf_enable_t;
/* enable cache list */
struct list_head enable_conf_cache_head[MAX_LOCAL_UNIT];

typedef enum ptd_mom_attr_set_e {
    PTD_ATTR_SPEED_SET = 0,
    PTD_ATTR_DUPLEX_SET,
    PTD_ATT_FLOW_SET,
    PTD_ATTR_AN_SET,
    PTD_ATTR_MEDIUM_SET,
    PTD_ATTR_ADMIM_SET,
    PTD_ATTR_MTU_SET,
    PTD_ATTR_FEC_SET,
    PTD_MIB_CLEAR_SET,
    //PTD_MIB_ATTR_GET,
    PTD_BC_BEGIN,
    PTD_BC_STOP,
    PTD_LB_BEGIN,
    PTD_LB_STOP,
    PTD_SFP_IRQ,
    PTD_GET_TRANS_INFO,
    PTD_SET_LOOPBACK,
    PTD_PRBS_OP,
    PTD_PRBS_GET_RES,
    PTD_PHY_IRQ,
    PTD_MOM_ATTR_COUNT,
} ptd_mom_attr_set_t;

#define USED_IN_VSL_CONF 1    /* MEANS this conf MUST be in effect on VSL port */
#define USED_IN_ETH_CONF 0    /* MEANS this conf MUST be in effect on ETH port */
#define PTD_ARRAY_SIZE(a) (sizeof(a) /sizeof((a)[0]))

extern int ptd_mom_data_check(int key_index, const rg_obj *attr, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info);
extern int ptd_mom_subscribe(rg_global_t *global, int unit, vsd_unit_thread_info_t *unit_t_info);
extern int ptd_mom_attr_fail_noitify(unsigned int phyid, unsigned int set_val, unsigned int oper_val, int type, rg_global_t *global);

/* 端口使能/禁止设置 */

extern int32_t intf_vsl_link_ntfy(rg_global_t *glb, uint32_t fe_phyid, bool is_up);
extern int32_t intf_vsl_plug_eth_to_vsl_ntfy(rg_global_t *glb, uint32_t fe_phyid, SIntf__StatPluginfo *plug);
extern int32_t intf_vsl_mib_ntfy(rg_global_t *glb, uint32_t fe_phyid, SIntf__StatMibinfo *ethmib);
int ptd_port_vsl_eth_chg_event_callback(int phyid, ptchg_evt_t event);
extern int ptd_sfp_irq_handle(rg_global_t *global, int unit);
extern int ptd_unit_port_is_e_port(int unit, int port);
extern int ptd_fac_set_port_prbs(int lphyid);
extern int ptd_fac_cancel_port_prbs(int lphyid);
extern int ptd_fac_get_prbs_result(int lphyid, int* result);
extern int ptd_phy_irq_handle(rg_global_t *global, int cpld_inter_val, int unit);

/* for port chg frame
 * we want to sense the event where vsl chg to eth
 */
ptchg_cb_reg_t ptd_port_event_args[] = {
     {.type = PTCHG_TYPE_ETH,
      .cb = (ptchg_cb_f)ptd_port_vsl_eth_chg_event_callback},
};

static int duplex_ptd_to_ptm(int duplex)
{
    switch (duplex) {
    case 0:
        return S_INTF__DUPLEX_TYPE_E__HALF;                        /* 半双工为0 */
    case 1:
        return S_INTF__DUPLEX_TYPE_E__FULL;                        /* 全双工为1 */
    default:
        return S_INTF__DUPLEX_TYPE_E__DUPLEX_UNKNOWN;
    }
}

/* mom层使用的针对rgos的, ptd端口信息获取和配置过滤接口
 * ptd由caller负责分配和初始化
 * 返回0时, ptd里的数据才有效
 * 返回非0时, 则说明需要过滤mom层逻辑不再往下执行
 * IMPORTANT when use to conf vsl port 'use_in_vsl' must be set
 */
static int ptd_rgos_adapter_filter(rg_global_t *global,
    unsigned int phyid, ptd_info_t *ptd, vsd_unit_thread_info_t *unit_t_info, int use_in_vsl)
{
    int rv;
    /* 用于VSL口或拆分口特殊逻辑判断 */
    int ptype;

    /* 入参合法判断 这里只判断unit_t_info 因为这个是外层透传,  ptd肯定是caller已经初始化的, 不检查*/
    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_NOTICE("ptd_rgos_vsl_set phyid[0x%x] unit_t_info invalid\n", phyid);
        return -1;
    }

    if (unit_t_info->global == NULL) {
        SSA_PTD_ZLOG_NOTICE("ptd_rgos_vsl_set phyid[0x%x] global invalid\n", phyid);
        return -1;
    }

    /* 获取ptd的端口信息 */
    rv = ptd_get_port_info_by_phyid(phyid, ptd);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("get port info fail phyid 0x%x\n", phyid);
        return -1;
    }

    /* 查看unit是否匹配 */
    SSA_PTD_ZLOG_NOTICE("phyid[%u] ptd->unit[%d] unit_t_info->unit[%d] use_in_vsl[%d] test\n",
        phyid, ptd->unit, get_unit_from_unit_thread_info(unit_t_info), use_in_vsl);
    if (ptd->unit != get_unit_from_unit_thread_info(unit_t_info)) {
        SSA_PTD_ZLOG_ERROR("[%u]ptd->unit[%d] match not unit_t_info->unit[%d]\n",
            phyid, ptd->unit, get_unit_from_unit_thread_info(unit_t_info));
        return -1;
    }

    /* 这里获取端口类型准备过滤 */
    ptype = PT_TYPE_ETH; /* 默认都是以太口 */
    rv = intf_frm_serv_get_pt_type_by_lphyid(global, phyid, (pt_type_t *)&ptype);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("intf_frm_serv_get_pt_type_by_lphyid[0x%x] fail %d\n", phyid, rv);
        return -1;
    }
    if ((ptype == PT_TYPE_RES) || (ptype == PT_TYPE_UNK)) {
        /* reserve port and unknown port is default to be filtered */
        SSA_PTD_ZLOG_ERROR("intf_frm_serv_get_pt_type_by_lphyid[0x%x] ptype[%d] pass\n", phyid, ptype);
        return -1;
    }

    if (ptype == PT_TYPE_VSL) {
        if (use_in_vsl == USED_IN_ETH_CONF) {
            /* 只有在以太口场景下才过滤VSL口配置 */
            SSA_PTD_ZLOG_ERROR("intf_frm_serv_get_pt_type_by_lphyid[0x%x] is vsl pass\n", phyid);
            return -1;
        }
        ptd->is_vsl = 1;
    }

    return 0;
}

    /* for intf_comm_vsl */
int ptd_rgos_vsl_set(unsigned int lphyid, int mode,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;

    /* when we set-vsl we dont filter the vsl situation
     * so we dont use ptd_rgos_adapter_filter
     */
    SSA_PTD_ZLOG_FATAL("ptd_rgos_vsl_set phyid[0x%x] mode[%d] start\n", lphyid, mode);
    /* 入参合法判断 这里只判断unit_t_info 因为这个是外层透传,  ptd肯定是caller已经初始化的, 不检查*/
    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_VSL_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]admin_set will be filtered [%d]\n", lphyid, rv);

    if (g_ptd != NULL && g_ptd->set_vsl) {
         rv = g_ptd->set_vsl(&ptd, mode);
         PTD_CHK_RET_RETURN_VAL(rv, "[%u]vsl_set[%d] fail [%d]\n", lphyid, mode, rv);
    }

    SSA_PTD_ZLOG_NOTICE("ptd_rgos_vsl_set phyid[0x%x] admin[%d] over\n", lphyid, mode);

    return 0;
}

/* for intf_comm_vsl */
int ptd_rgos_admin_set_vsl(unsigned int lphyid, int enable,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;

    SSA_PTD_ZLOG_FATAL("ptd_rgos_admin_set_vsl phyid[0x%x] admin[%d] start", lphyid, enable);
    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_VSL_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]admin_set will be filtered [%d]\n", lphyid, rv);

    if (g_ptd != NULL && g_ptd->set_admin) {
         rv = g_ptd->set_admin(&ptd, enable);
         PTD_CHK_RET_RETURN_VAL(rv, "[%u]admin_set[%d] fail [%d]\n", lphyid, enable, rv);
    }

    SSA_PTD_ZLOG_NOTICE("ptd_rgos_admin_set_vsl phyid[0x%x] admin[%d] over\n", lphyid, enable);

    return 0;
}



static int ptd_info_cache_update_from_eff_conf(struct list_head *head, int port,
	void *cache_info, int cache_info_len)
{
	struct list_head *pos, *n;
	unit_port_info_list_t *node, *new_node;

	list_for_each_safe(pos, n, head) {
		node = list_entry(pos, unit_port_info_list_t, list);
		if (node->port == port) {
			if (node->cache_info == NULL) {
				/* normally this cache_info must not be NULL */
				return SSA_PORT_E_IVPARAM;
			}
			/* not NULL, we copy the content of cache_info to node */
			memcpy(node->cache_info, cache_info, cache_info_len);
			return SSA_PORT_E_NONE;
		}
	}

	/* getting here no node is find we alloc the new one */
	new_node = (unit_port_info_list_t *)malloc(sizeof(unit_port_info_list_t));
	if (new_node == NULL) {
		return SSA_PORT_E_MEMORY;
	}
	memset(new_node, 0, sizeof(unit_port_info_list_t));
	new_node->port = port;
	new_node->cache_info = (void *)malloc(cache_info_len);
	if (new_node->cache_info == NULL) {
		free(new_node);
		new_node = NULL;
		return SSA_PORT_E_MEMORY;
	}
	memcpy(new_node->cache_info, cache_info, cache_info_len);
	list_add_tail(&new_node->list, head);

	return SSA_PORT_E_NONE;
}


int ptd_rgos_admin_set(unsigned int lphyid, int enable,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;
    unit_port_conf_enable_t enable_conf;

    SSA_PTD_ZLOG_FATAL("ptd_mom_admin_set phyid[0x%x] admin[%d] start\n", lphyid, enable);
    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_ETH_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]admin_set will be filtered [%d]\n", lphyid, rv);
#if 0
    /* see if this unit in dad isolate flag */
    if ((g_ptd_dad_isolate_flag[unit_t_info->unit] == 1)
        && (!BCM_PBMP_MEMBER(g_ptd_dad_isolate_excp_pbmp[unit_t_info->unit], ptd.port))) {
        /* if we are in dad isolate, and we are not in the dad exception pbmp.
         * this means we are ment to shut so just skip cause dad already shut us down
         */
        SSA_PTD_ZLOG_FATAL("this phyid[0x%x] is dad isolate skip!", lphyid);
        return 0;
    }
#endif
    /* enable框架使能前缓存配置 */
    if (g_ptd_enable_flag[ptd.unit] == 0) {
        memset(&enable_conf, 0, sizeof(unit_port_conf_enable_t));
        enable_conf.unit = ptd.unit;
        enable_conf.port = ptd.port;
        memcpy(&enable_conf.ptd, &ptd, sizeof(ptd_info_t));
        enable_conf.admin = enable;
        rv = ptd_info_cache_update_from_eff_conf(&enable_conf_cache_head[ptd.unit], ptd.port,
            &enable_conf, sizeof(unit_port_conf_enable_t));
        if (rv != 0) {
            /* just print to notify, DNOT return, cause nothing we can do */
            SSA_PTD_ZLOG_WARN("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] add FAIL", ptd.unit, ptd.port);
        }
        SSA_PTD_ZLOG_NOTICE("before system enable do admin cache conf, lphyid[%u] unit[%d]port[%d] enable[%d], ",
            lphyid, ptd.unit, ptd.port, enable);
        return 0;
    }

    if (g_ptd != NULL && g_ptd->set_admin) {
        rv = g_ptd->set_admin(&ptd, enable);
        PTD_CHK_RET_RETURN_VAL(rv, "[%u]admin_set[%d] fail [%d]\n", lphyid, enable, rv);
    }

    SSA_PTD_ZLOG_NOTICE("ptd_mom_admin_set phyid[0x%x] admin[%d] over\n", lphyid, enable);

    return 0;
}

static int ptd_mom_admin_set(SIntf__CfgAttr *cfg_attr, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    unsigned int phyid;
    int enable;
    int rv;

    phyid =cfg_attr->index->phyid;
    enable = (int)cfg_attr->power;

    rv = ptd_rgos_admin_set(phyid, enable, unit_t_info);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]ptd_rgos_admin_set[%d] fail [%d]\n", phyid, enable, rv);

    return rv;
}

int ptd_mom_admin_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgAttr *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SIntf__CfgAttr *)res->value;

    SSA_PTD_ZLOG_NOTICE("DS to ptd_mom_admin_set! \n");
    (void)ptd_mom_admin_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_NOTICE("DS out ptd_mom_admin_set! \n");

    return 0;
}

int ptd_mom_admin_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgAttr *cfg_attr;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__CfgAttr cfg_attr_scan = S_INTF__CFG_ATTR__INIT;
    cfg_attr_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_WARN("ptd_mom_admin_msg_handle RG_MOM_SUBSCRIBE\n");
        ptd_mom_data_check(PTD_ATTR_ADMIM_SET, (const rg_obj *)&cfg_attr_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        SSA_PTD_ZLOG_WARN("ptd_mom_admin_msg_handle RG_MOM_HSET\n");
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        cfg_attr = (SIntf__CfgAttr *)res->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_admin_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

/* for intf_comm_vsl */
int ptd_rgos_mtu_set_vsl(unsigned int lphyid, int mtu,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;

    SSA_PTD_ZLOG_NOTICE("ptd_rgos_mtu_set_vsl phyid[0x%x] mtu[%d] enter", lphyid, mtu);
    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_VSL_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]mtu_set will be filtered [%d]\n", lphyid, rv);

    if (g_ptd != NULL && g_ptd->set_mtu) {
         rv = g_ptd->set_mtu(&ptd, mtu);
         PTD_CHK_RET_RETURN_VAL(rv, "[%u]mtu_set[%d] fail [%d]\n", lphyid, mtu, rv);
    }

    return 0;
}

int ptd_rgos_mtu_set(unsigned int lphyid, int mtu,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;

    SSA_PTD_ZLOG_NOTICE("ptd_rgos_mtu_set phyid[0x%x] mtu[%d] enter\n", lphyid, mtu);
    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_ETH_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]mtu_set will be filtered [%d]\n", lphyid, rv);

    if (g_ptd != NULL && g_ptd->set_mtu) {
         rv = g_ptd->set_mtu(&ptd, mtu);
         PTD_CHK_RET_RETURN_VAL(rv, "[%u]mtu_set[%d] fail [%d]\n", lphyid, mtu, rv);
    }

    return 0;
}

static int ptd_mom_mtu_set(SIntf__CfgAttr *cfg_attr, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int mtu;
    unsigned int phyid;
    int rv;

    phyid = cfg_attr->index->phyid;
    mtu = cfg_attr->mtu;

    rv = ptd_rgos_mtu_set(phyid, mtu, unit_t_info);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]ptd_rgos_mtu_set[%d] fail [%d]\n", phyid, mtu, rv);

    return 0;
}

int ptd_mom_mtu_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgAttr *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SIntf__CfgAttr *)res->value;

    (void)ptd_mom_mtu_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_mtu_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{

    SIntf__CfgAttr *cfg_attr;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__CfgAttr cfg_attr_scan = S_INTF__CFG_ATTR__INIT;
    cfg_attr_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_NOTICE("ptd_mom_mtu_msg_handle RG_MOM_SUBSCRIBE\n");
        ptd_mom_data_check(PTD_ATTR_MTU_SET, (const rg_obj *)&cfg_attr_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        SSA_PTD_ZLOG_NOTICE("ptd_mom_mtu_msg_handle RG_MOM_HSET\n");
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        cfg_attr = (SIntf__CfgAttr *)res->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_mtu_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

static int ptd_mom_medium_set(SIntf__CfgAttr *cfg_attr, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int medium;
    unsigned int phyid;
    int unit;
    int port, rv, ptype;

    phyid = cfg_attr->index->phyid;
    medium = cfg_attr->medium;

    SSA_PTD_ZLOG_NOTICE("ptd_mom_medium_set[0x%x] medieum[%d] start\n", phyid, medium);

    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_ERROR("ptd_mom_medium_set[0x%x] in valid arg %d\n", medium);
        return 0;
    }

    /* 这里过滤vsl配置 */
    ptype = PT_TYPE_ETH; /* 默认都是以太口 */
    rv = intf_frm_serv_get_pt_type_by_lphyid(global, phyid, (pt_type_t *)&ptype);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("intf_frm_serv_get_pt_type_by_lphyid[0x%x] fail %d\n", phyid, rv);
        return 0;
    }
    if (ptype == PT_TYPE_VSL) {
        SSA_PTD_ZLOG_ERROR("intf_frm_serv_get_pt_type_by_lphyid[0x%x] is vsl pass\n", phyid, rv);
        return 0;
    }

    rv = libddm_get_unit_port_by_lphyid(phyid, &unit, &port);
    if (rv != 0 || unit != unit_t_info->unit) {
        SSA_PTD_ZLOG_ERROR("no same unit current unit %d get unit %d\n", unit_t_info->unit, unit);
        return 0;
    }

    if (g_ptd != NULL && g_ptd->set_medium) {
        return g_ptd->set_medium(phyid, medium);
    }

    SSA_PTD_ZLOG_NOTICE("ptd_mom_medium_set[0x%x] medieum[%d] over\n", phyid, rv);
    return 0;
}

int ptd_mom_medium_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgAttr *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {

        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SIntf__CfgAttr *)res->value;

    SSA_PTD_ZLOG_NOTICE("DS to ptd_mom_medium_set! \n");
    (void)ptd_mom_medium_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_NOTICE("DS out ptd_mom_medium_set! \n");

    return 0;
}


int ptd_mom_medium_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgAttr *cfg_attr;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__CfgAttr cfg_attr_scan = S_INTF__CFG_ATTR__INIT;
    cfg_attr_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_NOTICE("ptd_mom_medium_msg_handle RG_MOM_SUBSCRIBE\n");
        ptd_mom_data_check(PTD_ATTR_MEDIUM_SET, (const rg_obj *)&cfg_attr_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        SSA_PTD_ZLOG_NOTICE("ptd_mom_medium_msg_handle RG_MOM_HSET\n");
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        cfg_attr = (SIntf__CfgAttr *)res->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    SSA_PTD_ZLOG_DEBUG("to ptd_mom_medium_set\n");

    (void)ptd_mom_medium_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_DEBUG("out ptd_mom_medium_set\n");

    return 0;
}

int ptd_rgos_attr_eff_info_notify(rg_global_t *global, unsigned int lphyid, int lport, ptd_attr_eff_info_t *ptd_attr_eff_info)
{
    SIntf__Ptindex ptindex = S_INTF__PTINDEX__INIT;
    SIntf__StatEffectinfo attr_eff_info = S_INTF__STAT_EFFECTINFO__INIT;
    attr_eff_info.index = &ptindex;
    int ret;

    /* for now we only filter fec */
    if (ptd_fec_notify_cache[lport] == ptd_attr_eff_info->fec) {
        SSA_PTD_ZLOG_ERROR("[lport:%d] fec[%d] the same filtered\n", ptd_attr_eff_info->fec);
        return 0;
    }

    size_t attr_eff_info_array[1] = {6};
    rg_mom_hmset_op_t op;

    memset(&op, 0, sizeof(rg_mom_hmset_op_t));
    op.select_fields = attr_eff_info_array;
    op.fields_number = 1;
    op.flag = 3;

    (attr_eff_info.index)->phyid = lphyid;
    attr_eff_info.fec_mode = ptd_attr_eff_info->fec;

    ret = rg_mom_hmset_ext_sync(global, RG_MOM_ASIC_DB, &op, (const rg_obj *)&attr_eff_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("mom link info write fail\n");
        return ret;
    }
    SSA_PTD_ZLOG_WARN("rg_mom_hmset_ext_sync phyid[0x%x] fec_mode[%d] over", lphyid, attr_eff_info.fec_mode);

    return 0;
}

/* for intf_comm_vsl */
int ptd_rgos_attr_set_vsl(unsigned int lphyid, ptd_attr_info_t* ptd_attr_info,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;
    ptd_attr_eff_info_t ptd_attr_eff_info;

    SSA_PTD_ZLOG_FATAL("start ptd_mom_attr_set phyid[%d] speed[%d] duplex[%d] flow[%d] an[%d] fec[%d]",
        lphyid, ptd_attr_info->speed, ptd_attr_info->duplex, ptd_attr_info->flow, ptd_attr_info->an, ptd_attr_info->fec);
    memset(&ptd, 0, sizeof(ptd_info_t));
    memset(&ptd_attr_eff_info, 0, sizeof(ptd_attr_eff_info_t));

    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_VSL_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]admin_set will be filtered [%d]\n", lphyid, rv);

    if (g_ptd != NULL && g_ptd->set_attr) {
        rv = g_ptd->set_attr(&ptd, ptd_attr_info, &ptd_attr_eff_info);
        PTD_CHK_RET_RETURN_VAL(rv, "[%u]attr_set fail [%d]\n", lphyid, rv);
    }

    SSA_PTD_ZLOG_NOTICE("over ptd_mom_attr_set phyid[%d] speed[%d] duplex[%d] flow[%d] an[%d]\n",
        lphyid, ptd_attr_info->speed, ptd_attr_info->duplex, ptd_attr_info->flow, ptd_attr_info->an);

    (void)ptd_rgos_attr_eff_info_notify(unit_t_info->global, lphyid, ptd.lport, &ptd_attr_eff_info);

    return 0;
}

int ptd_rgos_attr_set(unsigned int lphyid, ptd_attr_info_t* ptd_attr_info,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    /* 用于获取unit port */
    ptd_info_t ptd;
    ptd_attr_eff_info_t ptd_attr_eff_info;

    SSA_PTD_ZLOG_FATAL("start ptd_rgos_attr_set phyid[%d] speed[%d] duplex[%d] flow[%d] an[%d] fec[%d]\n",
        lphyid, ptd_attr_info->speed, ptd_attr_info->duplex, ptd_attr_info->flow, ptd_attr_info->an, ptd_attr_info->fec);
    memset(&ptd, 0, sizeof(ptd_info_t));
    memset(&ptd_attr_eff_info, 0, sizeof(ptd_attr_eff_info_t));

    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_ETH_CONF);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]attr_set will be filtered [%d]\n", lphyid, rv);

    if (g_ptd != NULL && g_ptd->set_attr) {
        rv = g_ptd->set_attr(&ptd, ptd_attr_info, &ptd_attr_eff_info);
        PTD_CHK_RET_RETURN_VAL(rv, "[%u]attr_set fail [%d]\n", lphyid, rv);
    }

    (void)ptd_rgos_attr_eff_info_notify(unit_t_info->global, lphyid, ptd.lport, &ptd_attr_eff_info);

    return 0;
}
/* 端口属性(speed, duplex, flowctrl, autoneg)设置 */
static int ptd_mom_attr_set(SIntf__CfgAttr *cfg_attr, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    unsigned int phyid;
    ptd_attr_info_t ptd_attr_info;
    int rv;

    SSA_PTD_ZLOG_DEBUG("in ptd_mom_attr_set\n");
    /* when judge invalid conf we dont count fec in, cause we dont want fec to influence attr conf */
    if ((cfg_attr->speed < 0) || (cfg_attr->duplex <= 0) || (cfg_attr->flowctrl <= 0) || (cfg_attr->nego <= 0)) {
        SSA_PTD_ZLOG_FATAL("cfg_attr->speed[%d] cfg_attr->duplex[%d] cfg_attr->flowctrl[%d] cfg_attr->nego[%d] invalid!",
            cfg_attr->speed, cfg_attr->duplex, cfg_attr->flowctrl, cfg_attr->nego);
        return 0;
    }
    memset(&ptd_attr_info, 0, sizeof(ptd_attr_info_t));
    ptd_attr_info.speed = cfg_attr->speed;
    ptd_attr_info.duplex = cfg_attr->duplex;
    ptd_attr_info.flow = cfg_attr->flowctrl;
    ptd_attr_info.an = cfg_attr->nego;
    ptd_attr_info.fec = cfg_attr->fec_mode;
    phyid = cfg_attr->index->phyid;

    rv = ptd_rgos_attr_set(phyid, &ptd_attr_info, unit_t_info);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]ptd_rgos_attr_set fail [%d]\n", phyid, rv);

    return 0;
}

int ptd_mom_attr_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgAttr *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SIntf__CfgAttr *)res->value;

    SSA_PTD_ZLOG_NOTICE("DS to ptd_mom_attr_set! \n");
    (void)ptd_mom_attr_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_NOTICE("DS out ptd_mom_attr_set! \n");

    return 0;
}


int ptd_mom_attr_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
     SIntf__CfgAttr *cfg_attr;
     SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
     SIntf__CfgAttr cfg_attr_scan = S_INTF__CFG_ATTR__INIT;
     cfg_attr_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_DEBUG("ptd_mom_attr_msg_handle RG_MOM_SUBSCRIBE\n");
        ptd_mom_data_check(PTD_ATTR_SPEED_SET, (const rg_obj *)&cfg_attr_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        SSA_PTD_ZLOG_DEBUG("ptd_mom_attr_msg_handle RG_MOM_HSET\n");
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        cfg_attr = (SIntf__CfgAttr *)res->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_attr_set(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

/* negociation factor key DEL process func
 * only sense DEL action NEED NOT to DS
 * this del oper only occurs when eth chg to vsl
 * so this is a USED_IN_VSL_CONF situation
 */
int ptd_rgos_attr_del(unsigned int lphyid, vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    ptd_info_t ptd;

    SSA_PTD_ZLOG_NOTICE("start ptd_rgos_attr_del phyid[%d]", lphyid);
    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_phyid(lphyid, &ptd);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]attr_set will be filtered [%d]", lphyid, rv);

    if (g_ptd != NULL && g_ptd->del_attr) {
        rv = g_ptd->del_attr(&ptd);
        PTD_CHK_RET_RETURN_VAL(rv, "[%u]del_attr fail [%d]", lphyid, rv);
    }

    SSA_PTD_ZLOG_NOTICE("over ptd_rgos_attr_del phyid[%d]", lphyid);

    return 0;
}

int ptd_port_vsl_eth_chg_event_callback(int phyid, ptchg_evt_t event)
{
    int rv;

    SSA_PTD_ZLOG_FATAL("enter");
    if (event != PTCHG_EVT_ADD) {
        SSA_PTD_ZLOG_FATAL("err phyid[%d] envent[%d]", phyid, event);
        /* not err just dont care */
        return SSA_PORT_E_NONE;
    }

    rv = ptd_rgos_attr_del(phyid, NULL);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]ptd_rgos_attr_set fail [%d]\n", phyid, rv);

    SSA_PTD_ZLOG_DEBUG("leave");

    return rv;
}

/* coverity fix */
static int ptd_mom_mib_clr(SIntf__EvtMibclr *mib_clr, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    unsigned int phyid;
    int unit;
    int port, rv;

    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_ERROR("invalid arg");
        return SSA_PORT_E_IVPARAM;
    }

    phyid = mib_clr->index->phyid;
    rv = libddm_get_unit_port_by_lphyid(phyid, &unit, &port);
    if (rv != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("libddm_get_unit_port_by_lphyid fail unit %d\n", unit);
        return SSA_PORT_E_RETURN;
    }

    if (unit != unit_t_info->unit) {
        SSA_PTD_ZLOG_ERROR("no same unit current unit %d get unit %d\n", unit_t_info->unit, unit);
        return SSA_PORT_E_IVPARAM;
    }

    if (g_ptd != NULL && g_ptd->clear_mib) {
        return g_ptd->clear_mib(unit, port);
    }

    return SSA_PORT_E_NONE;
}

static int ptd_mom_mib_ex_clr(rg_global_t * global, SIntf__EvtMibclrExt *mib_ex_clr, vsd_unit_thread_info_t *unit_t_info)
{
    unsigned int phyid;
    int unit;
    int port, rv;

    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_ERROR("invalid arg");
        return SSA_PORT_E_IVPARAM;
    }

    phyid = mib_ex_clr->index->phyid;
    rv = libddm_get_unit_port_by_lphyid(phyid, &unit, &port);
    if (rv != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("libddm_get_unit_port_by_lphyid fail unit %d\n", unit);
        return SSA_PORT_E_RETURN;
    }

    if (unit != unit_t_info->unit) {
        SSA_PTD_ZLOG_ERROR("no same unit current unit %d get unit %d\n", unit_t_info->unit, unit);
        return SSA_PORT_E_IVPARAM;
    }

    if ((g_ptd != NULL) && (g_ptd->clear_mib_ex != NULL)) {
        return g_ptd->clear_mib_ex(unit, port);
    }

    return SSA_PORT_E_NONE;
}

int ptd_mom_clr_mib_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__EvtMibclr *mib_clr;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;

    SIntf__EvtMibclr mib_clr_scan = S_INTF__EVT_MIBCLR__INIT;
    mib_clr_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_MIB_CLEAR_SET, (const rg_obj *)&mib_clr_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

  if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        mib_clr = (SIntf__EvtMibclr *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_mib_clr(mib_clr, global, (vsd_unit_thread_info_t *)privdata);
    //删除key
    rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)mib_clr);

    return 0;
}

int ptd_mom_clr_mib_ex_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__EvtMibclrExt *mib_ex_clr;
    SIntf__EvtMibclrExt mib_ex_clr_scan = S_INTF__EVT_MIBCLR_EXT__INIT;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    mib_ex_clr_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        rg_mom_scan_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&mib_ex_clr_scan, 0, ptd_mom_clr_mib_ex_msg_handle, privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_SET) {
        SSA_PTD_ZLOG_DEBUG("in RG_MOM_SET clr_ex_mib info\n");
        mib_ex_clr = (SIntf__EvtMibclrExt *)msg->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_mib_ex_clr(global, mib_ex_clr, (vsd_unit_thread_info_t *)privdata);
    //删除key
    rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)mib_ex_clr);

    return 0;
}

int ptd_mom_mib_clr_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__EvtMibclr *mib_clr;
    int ret;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    mib_clr = (SIntf__EvtMibclr *)res->value;

    SSA_PTD_ZLOG_NOTICE("DS to ptd_mom_mib_clr! \n");
    (void)ptd_mom_mib_clr(mib_clr, global, (vsd_unit_thread_info_t *)privdata);
    //删除key
    ret = rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)mib_clr);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("ptd_mom_mib_clr del, error!\n");
    }
    SSA_PTD_ZLOG_NOTICE("DS out ptd_mom_mib_clr! \n");

    return 0;
}

/*  中断处理相关 */
static int ptd_mom_sfp_irq(SBsp__SfpIrqEvent *sfp_irq, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int ret;

    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_ERROR("arg is null\n");
        return -1;
    }

    ret = ptd_sfp_irq_handle(global, unit_t_info->unit);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("ptd_sfp_irq_handle, error[%d]!", ret);
    }

    return 0;
}

int ptd_mom_sfp_irq_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SSA_PTD_ZLOG_NOTICE("DS to ptd_mom_sfp_irq! \n");
    (void)ptd_mom_sfp_irq(NULL, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_NOTICE("DS out ptd_mom_sfp_irq! \n");
    return 0;
}

/* phy中断处理相关 */
static int ptd_mom_phy_irq(SBsp__PhyIrqEvent *phy_irq, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    int32_t cpld_inter_value;

    SSA_PTD_ZLOG_DEBUG("in ptd_mom_phy_irq\n");
    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_ERROR("arg is null\n");
        return -1;
    }

    cpld_inter_value = phy_irq->in_out;
    if (cpld_inter_value <= 0) {
        SSA_PTD_ZLOG_FATAL("cpld interrupt value [%x]\n", cpld_inter_value);
        return 0;
    }

    rv = ptd_phy_irq_handle(global, cpld_inter_value, unit_t_info->unit);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("ptd_phy_irq_handle, error[%d]!", rv);
    }

    SSA_PTD_ZLOG_DEBUG("out ptd_mom_phy_irq\n");

    return 0;
}

int ptd_mom_phy_irq_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SBsp__PhyIrqEvent *phy_irq;
    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    phy_irq = (SBsp__PhyIrqEvent *)res->value;

    SSA_PTD_ZLOG_NOTICE("DS to ptd_mom_phy_irq! \n");
    (void)ptd_mom_phy_irq(phy_irq, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_NOTICE("DS out ptd_mom_phy_irq! \n");
    return 0;
}

/* 模块防伪主动通告 */
static int ptd_mom_trans_info_publish(unsigned int phyid, rg_global_t * global)
{
    int rv;
    unsigned char normal_buf[TRANS_NOR_INFO_LEN];
    unsigned char ddm_buf[TRANS_DDM_INFO_LEN];
    unsigned char antifake_buf[TRANS_ANTIFAKE_LEN];
    trans_info_t info_from_trans;

    rg_mom_set_op_t op;
    SIntf__StatFiber trans_stat_pub = S_INTF__STAT_FIBER__INIT;
    SIntf__Ptindex ptindex = S_INTF__PTINDEX__INIT;

    SSA_PTD_ZLOG_DEBUG("phyid[0x%x]!\n", phyid);

    ptindex.phyid = phyid;
    trans_stat_pub.index = &ptindex;
    /* 对象值的初始化 */
    rv = S_INTF__FIBER_RES_E__FIBER_ABSENT;

    trans_stat_pub.normal_info.data = normal_buf;
    memset(trans_stat_pub.normal_info.data, 0, TRANS_NOR_INFO_LEN);
    trans_stat_pub.normal_info.len = TRANS_NOR_INFO_LEN;

    trans_stat_pub.ddm_info.data = ddm_buf;
    memset(trans_stat_pub.ddm_info.data, 0, TRANS_DDM_INFO_LEN);
    trans_stat_pub.ddm_info.len = TRANS_DDM_INFO_LEN;

    trans_stat_pub.antifake_key2.data = antifake_buf;
    memset(trans_stat_pub.antifake_key2.data, 0, TRANS_ANTIFAKE_LEN);
    trans_stat_pub.antifake_key2.len = TRANS_ANTIFAKE_LEN;

    /* 初始化trans_info_t结构体 */
    info_from_trans.normal_buf = trans_stat_pub.normal_info.data;
    info_from_trans.ddm_buf = trans_stat_pub.ddm_info.data;
    info_from_trans.antifake_buf = trans_stat_pub.antifake_key2.data;
    info_from_trans.antifake_support = 0;
    info_from_trans.ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_SUPPORTLESS;
    info_from_trans.is_trans_online = 0;

    /* 这里实际获取信息 */
    rv = in_ssa_ptd_trans_info_collect(phyid, &info_from_trans);
    SSA_PTD_ZLOG_DEBUG("in_ssa_ptd_trans_info_collect return val[%d] antifake-support[%d] ptm_port_type[&d] is_trans_online[%d]\n",
        rv, info_from_trans.antifake_support, info_from_trans.ptm_port_type, info_from_trans.is_trans_online);

    /* 这里写对象里的antifake支持情况 */
    trans_stat_pub.is_fiber_online = info_from_trans.is_trans_online;
    trans_stat_pub.ret = rv;
    trans_stat_pub.type = info_from_trans.ptm_port_type;
    trans_stat_pub.type_unknown = 0; /* 默认给识别 */
    /* 模块类型和模块未识别的域需要判断模块在位来写 */
    if ((trans_stat_pub.is_fiber_online == 1)
        && (info_from_trans.ptm_port_type == S_INTF__FIBER_TYPE_E__FIBER_SUPPORTLESS)) {
        /* 只有模块在位且不识别才写1 */
        trans_stat_pub.type_unknown = 1;
    }

    SSA_PTD_ZLOG_DEBUG("obj filled OK\n");

    memset(&op, 0, sizeof(rg_mom_set_op_t));
    op.flag = 1;
    SSA_PTD_ZLOG_DEBUG("op filled OK\n");

    rv = rg_mom_set_ext_sync(global, RG_MOM_ASIC_DB, &op, (const rg_obj *)&trans_stat_pub);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("rg_mom_set_ext_sync fail[%d]\n", rv);
        return -1;
    }

    SSA_PTD_ZLOG_DEBUG("obj set OK[%d]!\n", rv);

    return 0;
}

int ptd_mom_sfp_irq_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SBsp__SfpIrqEvent *sfp_irq;
    SBsp__SfpIrqEvent sfp_irq_scan = S_BSP__SFP_IRQ_EVENT__INIT;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_SFP_IRQ, (const rg_obj *)&sfp_irq_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        sfp_irq = (SBsp__SfpIrqEvent *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_sfp_irq(sfp_irq, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_phy_irq_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SBsp__PhyIrqEvent *phy_irq;
    SBsp__PhyIrqEvent phy_irq_scan = S_BSP__PHY_IRQ_EVENT__INIT;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_PHY_IRQ, (const rg_obj *)&phy_irq_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        phy_irq = (SBsp__PhyIrqEvent *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_phy_irq(phy_irq, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

/* 模块信息处理相关 */
static int ptd_mom_trans_info_get(SIntf__TaskFiber *trans_info, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    unsigned int phyid;
    int rv;
    unsigned char normal_buf[TRANS_NOR_INFO_LEN];
    unsigned char ddm_buf[TRANS_DDM_INFO_LEN];
    unsigned char antifake_buf[TRANS_ANTIFAKE_LEN];
    char fail_reason[TRANS_INFO_GET_FAIL_LOG];
    int fail_reason_ret;
    trans_info_t info_from_trans;

    rg_mom_set_op_t op;
    SIntf__TaskFiber trans_info_set = S_INTF__TASK_FIBER__INIT;
    SIntf__Ptindex ptindex = S_INTF__PTINDEX__INIT;

    /* PTM每次set会把ret设置为-1, PTD会填上自己的返回值, 因此判断下是否是-1, 只有是-1才处理,
     * 不是-1说明是PTD更新key造成的publish, 直接不处理
     */
    if (trans_info->ret != -1) {
        SSA_PTD_ZLOG_ERROR("self publish skip!\n");
        return S_INTF__FIBER_RES_E__READ_OK;
    }

    phyid = trans_info->index->phyid;
    ptindex.phyid = phyid;
    trans_info_set.index = &ptindex;
    rv = S_INTF__FIBER_RES_E__FIBER_ABSENT;

    trans_info_set.normal_info.data = normal_buf;
    memset(trans_info_set.normal_info.data, 0, TRANS_NOR_INFO_LEN);
    trans_info_set.normal_info.len = TRANS_NOR_INFO_LEN;

    trans_info_set.ddm_info.data = ddm_buf;
    memset(trans_info_set.ddm_info.data, 0, TRANS_DDM_INFO_LEN);
    trans_info_set.ddm_info.len = TRANS_DDM_INFO_LEN;

    trans_info_set.antifake_key2.data = antifake_buf;
    memset(trans_info_set.antifake_key2.data, 0, TRANS_ANTIFAKE_LEN);
    trans_info_set.antifake_key2.len = TRANS_ANTIFAKE_LEN;

    memset(&info_from_trans, 0, sizeof(trans_info_t));
    /* 初始化trans_info_t结构体 */
    info_from_trans.normal_buf = trans_info_set.normal_info.data;
    info_from_trans.ddm_buf = trans_info_set.ddm_info.data;
    info_from_trans.antifake_buf = trans_info_set.antifake_key2.data;
    info_from_trans.antifake_support = 0;
    info_from_trans.ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_SUPPORTLESS;
    info_from_trans.is_trans_online = 0;

    /* 这个在第一个可能出现错误返回之前就要初始化 */
    if (unit_t_info == NULL) {
        SSA_PTD_ZLOG_ERROR("unit_t_info is null\n");
        rv = S_INTF__FIBER_RES_E__OPEN_CHANNEL_FAIL;
        goto err_out;
    }

    /* 这里实际获取信息 */
    rv = in_ssa_ptd_trans_info_collect(phyid, &info_from_trans);
    SSA_PTD_ZLOG_DEBUG("in_ssa_ptd_trans_info_collect return val[%d] antifake-support[%d] ptm_port_type[&d] is_trans_online[%d]\n",
        rv, info_from_trans.antifake_support, info_from_trans.ptm_port_type, info_from_trans.is_trans_online);

err_out:
    /* 这里找到err-log打印然后填入对象 */
    trans_info_set.fail_reason = fail_reason;
    memset(trans_info_set.fail_reason, 0, TRANS_INFO_GET_FAIL_LOG);
    fail_reason_ret = in_ssa_port_trans_fail_msg(rv, trans_info_set.fail_reason);
    if (fail_reason_ret != 0) {
        SSA_PTD_ZLOG_ERROR("[%d]fail info get fail[%d]!\n", phyid, rv);
    }

    SSA_PTD_ZLOG_DEBUG("final return val[%d] antifake-support[%d] ptm_port_type[&d] is_trans_online[%d]\n",
        rv, info_from_trans.antifake_support, info_from_trans.ptm_port_type, info_from_trans.is_trans_online);

    /* 这里写对象里的antifake支持情况 */
    trans_info_set.is_get_anti_key2 = (info_from_trans.antifake_support == 1) ? true : false;
    trans_info_set.ret = rv;
    trans_info_set.type = info_from_trans.ptm_port_type;
    SSA_PTD_ZLOG_DEBUG("obj filled OK\n");

    memset(&op, 0, sizeof(rg_mom_set_op_t));
    op.flag = 1;
    SSA_PTD_ZLOG_DEBUG("op filled OK\n");

    rv = rg_mom_set_ext_sync(global, RG_MOM_ASIC_DB, &op, (const rg_obj *)&trans_info_set);
    if (rv) {
        printf("mom link info write fail\n");
        rv = S_INTF__FIBER_RES_E__OPEN_CHANNEL_FAIL;

    }
    SSA_PTD_ZLOG_DEBUG("obj hmset OK[%d]!\n", rv);

    return rv;
}

int ptd_mom_trans_info_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__TaskFiber *trans_info;

    SSA_PTD_ZLOG_DEBUG("in ptd_mom_trans_info_data_check_handle CMD[%d]!\n", msg->cmd);
    trans_info = (SIntf__TaskFiber *)msg->value;

    (void)ptd_mom_trans_info_get(trans_info, global, (vsd_unit_thread_info_t *)privdata);
    return 0;
}

int ptd_mom_trans_info_get_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__TaskFiber *trans_info;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__TaskFiber trans_info_scan = S_INTF__TASK_FIBER__INIT;
    trans_info_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_DEBUG("in RG_MOM_SUBSCRIBE trans info\n");
        ptd_mom_data_check(PTD_GET_TRANS_INFO, (const rg_obj *)&trans_info_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_SET) {
        SSA_PTD_ZLOG_DEBUG("in RG_MOM_SET trans info\n");
        trans_info = (SIntf__TaskFiber *)msg->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_trans_info_get(trans_info, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_rgos_loopback_set(unsigned int lphyid, int loopback,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    ptd_info_t ptd;

    SSA_PTD_ZLOG_NOTICE("ptd_mom_loopback_set[0x%x] loopback[%d] start\n", lphyid, loopback);

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_ETH_CONF);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("[%u]loopback_set will be filtered [%d]\n", lphyid, rv);
        return 0;
    }
    /* getting here means that config is not filtered, we can proceed */
    /* set loopback to asic as desired */
    if ((g_ptd != NULL) && g_ptd->set_loopback) {
        rv = g_ptd->set_loopback(&ptd, loopback);
        SSA_PTD_ZLOG_NOTICE("set_loopback rv %d\n", rv);
    }

    return 0;
}

int ptd_rgos_loopback_set_vsl(unsigned int lphyid, int loopback,
    vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    ptd_info_t ptd;

    SSA_PTD_ZLOG_NOTICE("ptd_mom_loopback_set[0x%x] loopback[%d] start\n", lphyid, loopback);

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_rgos_adapter_filter(unit_t_info->global, lphyid, &ptd, unit_t_info, USED_IN_VSL_CONF);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("[%u]loopback_set will be filtered [%d]\n", lphyid, rv);
        return 0;
    }
    /* getting here means that config is not filtered, we can proceed */
    /* set loopback to asic as desired */
    if ((g_ptd != NULL) && g_ptd->set_loopback) {
        rv = g_ptd->set_loopback(&ptd, loopback);
        SSA_PTD_ZLOG_NOTICE("set_loopback rv %d\n", rv);
    }

    return 0;
}

/* 回环相关配置 */
static int ptd_mom_loopback_set(SIntf__CfgLoopback *loopback, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    /* config basic info */
    int lb;
    unsigned int phyid;
    /* for drv config & return val */
    int rv;
    /* 用于模块操作 */

    /* aquire basic config info */
    phyid = loopback->index->phyid;
    lb = loopback->lb;

    rv = ptd_rgos_loopback_set(phyid, lb, unit_t_info);
    PTD_CHK_RET_RETURN_VAL(rv, "[%u]ptd_rgos_attr_set fail [%d]\n", phyid, rv);

    SSA_PTD_ZLOG_NOTICE("[0x%x] lb[%d] set over\n", phyid, lb);
    return 0;
}

int ptd_mom_loopback_set_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgLoopback *loopback;

    SSA_PTD_ZLOG_DEBUG("in ptd_mom_loopback_set_check_handle CMD[%d]!\n", msg->cmd);
    loopback = (SIntf__CfgLoopback *)msg->value;

    (void)ptd_mom_loopback_set(loopback, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_DEBUG("over [0x%x]!\n", loopback->index->phyid);
    return 0;
}

int ptd_mom_loopback_set_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SIntf__CfgLoopback *loopback;
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__CfgLoopback loopback_scan = S_INTF__CFG_LOOPBACK__INIT;
    loopback_scan.index = &keyindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_DEBUG("in RG_MOM_SUBSCRIBE trans info\n");
        ptd_mom_data_check(PTD_SET_LOOPBACK, (const rg_obj *)&loopback_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_SET) {
        SSA_PTD_ZLOG_DEBUG("in RG_MOM_SET trans info\n");
        loopback = (SIntf__CfgLoopback *)msg->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_loopback_set(loopback, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_DEBUG("over\n");

    return 0;
}

int ptd_mom_intf_port_end_handler(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    /* obj of intf port end flag */
    SIntf__StatDatasync *intf_port_end;
    SIntf__StatDatasync intf_port_end_scan = S_INTF__STAT_DATASYNC__INIT;
    int rv;

    if (!global || !msg) {
        SSA_PTD_ZLOG_ERROR("global[%p]/msg[%p] param err.", global, msg);
        return SSA_PORT_E_IVPARAM;
    }

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_FATAL("in RG_MOM_SUBSCRIBE intf_port_end\n");
        rg_mom_scan_sync(global, msg->db,  (const rg_obj *)&intf_port_end_scan, 0, ptd_mom_intf_port_end_handler, privdata);
        return SSA_PORT_E_NONE;
    } else if (msg->cmd == RG_MOM_HSET) {
        SSA_PTD_ZLOG_FATAL("in RG_MOM_SET intf_port_end\n");
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return SSA_PORT_E_IVPARAM;
        }
        intf_port_end = (SIntf__StatDatasync *)res->value;
        if (intf_port_end == NULL) {
            SSA_PTD_ZLOG_ERROR("msg value null.");
            return SSA_PORT_E_IVPARAM;
        }
    }  else {
        SSA_PTD_ZLOG_FATAL("error cmd = %d\n", msg->cmd);
        return SSA_PORT_E_IVPARAM;
    }
    /* 通告就绪 */
    if (intf_port_end->is_core_ds_over == true) {
        rv = ssa_set_key_module_cfg_end((vsd_unit_thread_info_t *)privdata, KEY_MODULE_INTF_PORT);
        SSA_PTD_ZLOG_FATAL("done rv: %d", rv);
    }

    return SSA_PORT_E_NONE;
}

/* system enable 设置 */
static int ptd_mom_system_enable(SFrame__UnitEnable *unit_enable_key, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    /* config basic info */
    int unit;
    /* for drv config & return val */
    int rv;
    int ptype;
    unit_port_conf_enable_t *enable_conf;
    struct list_head *pos, *n;
    unit_port_info_list_t *node;

    /* aquire basic config info */
    unit = unit_enable_key->index->unit;

    if (unit != unit_t_info->unit) {
        SSA_PTD_ZLOG_FATAL("unit[%d] unit_t_info[%d] not match\n", unit);
        return SSA_PORT_E_IVPARAM;
    }
    SSA_PTD_ZLOG_FATAL("unit[%d] system_enable START\n", unit);

    if (g_ptd_enable_flag[unit]) {
        /* enable 框架已经完成 */
        SSA_PTD_ZLOG_FATAL("unit[%d] system_enable already done\n", unit);
        return SSA_PORT_E_NONE;
    }

    /* 下发cache缓存的enable配置 */
    list_for_each_safe(pos, n, &enable_conf_cache_head[unit]) {
        node = list_entry(pos, unit_port_info_list_t, list);
        enable_conf = node->cache_info;
        if (enable_conf == NULL) {
            SSA_PTD_ZLOG_ERROR("unit[%d] cache err!", unit);
            continue;
        }
        rv = intf_frm_serv_get_pt_type_by_lphyid(global, enable_conf->ptd.phyid, (pt_type_t *)&ptype);
        if (rv == 0 && ptype == PT_TYPE_VSL) {
            SSA_PTD_ZLOG_WARN("phy[0x%x] is vsl, unit[%s] port[%d] admin_set[%d]\n",
                enable_conf->ptd.phyid, enable_conf->unit, enable_conf->port, enable_conf->admin);
            continue;
        }
        if (g_ptd != NULL && g_ptd->set_admin) {
            rv = g_ptd->set_admin(&(enable_conf->ptd), enable_conf->admin);
            /* if fail, we just notice here, this node will still be deleted and the enable process will proceed so as not to
             * influence other port
             */
            SSA_PTD_ZLOG_NOTICE("unit[%d] port [%d]admin_set[%d] rv [%d]\n", unit, enable_conf->ptd.port, enable_conf->admin, rv);
        }
        list_del(&node->list);
        if (node->cache_info) {
            free(node->cache_info);
            node->cache_info = NULL;
        }
        free(node);
        node = NULL;
    }
    /* enable 框架完成*/
    g_ptd_enable_flag[unit] = 1;
    SSA_PTD_ZLOG_FATAL("unit[%d] system_enable OVER\n", unit);

    return SSA_PORT_E_NONE;
}

int ptd_mom_system_enable_handler(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    /* obj of system-enable */
    SFrame__UnitEnable *unit_enable_key;
    SFrame__KeyIndex key_index = S_FRAME__KEY_INDEX__INIT;
    SFrame__UnitEnable unit_enable_key_scan = S_FRAME__UNIT_ENABLE__INIT;
    unit_enable_key_scan.index = &key_index;

    if (!global || !msg) {
        SSA_PTD_ZLOG_ERROR("global[%p]/msg[%p] param err.", global, msg);
        return SSA_PORT_E_IVPARAM;
    }

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_FATAL("in RG_MOM_SUBSCRIBE system_enable\n");
        rg_mom_scan_sync(global, msg->db,  (const rg_obj *)&unit_enable_key_scan, 0, ptd_mom_system_enable_handler, privdata);
        return 0;
      } else if (msg->cmd == RG_MOM_SET) {
        SSA_PTD_ZLOG_FATAL("in RG_MOM_SET system_enable\n");
        unit_enable_key = (SFrame__UnitEnable *)msg->value;
        if (unit_enable_key == NULL) {
            SSA_PTD_ZLOG_ERROR("msg value null.");
            return SSA_PORT_E_IVPARAM;
        }
    }  else {
        SSA_PTD_ZLOG_FATAL("error cmd = %d\n", msg->cmd);
        return SSA_PORT_E_IVPARAM;
    }

    (void)ptd_mom_system_enable(unit_enable_key, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_FATAL("over\n");

    return SSA_PORT_E_NONE;
}

/* system enable 设置 */
static int ptd_mom_dad_isolate(PDev__DadPortShut *dad_shut_exception, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
#if 0
    /* config basic info */
    int slot_notify, slot_my, unit;
    /* for drv config & return val */
    int rv;
    /* for logic */
    bcm_pbmp_t pbmp;
    int i, excp_port_num;
    int32_t *excp_port_array;
    int32_t unit_noti, port;
    unsigned int lphyid;

    /* aquire basic config info */
    slot_notify = dad_shut_exception->index->slot;
    unit = unit_t_info->unit;

    /* get my slot to see if notify_slot is my_slot */
    rv = ndm_get_my_phy_slot(&slot_my);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("ndm_get_my_phy_slot fail[%d]\n", rv);
        return SSA_PORT_E_RETURN;
    }
    if (slot_notify != slot_my) {
        SSA_PTD_ZLOG_FATAL("notify_slot[%d] is not my_slot[%d] just return\n", slot_notify, slot_my);
        return SSA_PORT_E_NONE;
    }

    excp_port_num = dad_shut_exception->n_lport;
    excp_port_array = dad_shut_exception->lport;
    /* init the exceptional port cache of my unit */
    for (i = 0; i < excp_port_num; i++) {
        rv = libddm_get_unit_port_by_slot_lport(slot_notify, excp_port_array[i], &unit_noti, &port);
        if (rv != 0) {
            SSA_PTD_ZLOG_WARN("libddm_get_unit_port_by_slot_lport fail[%d] slot[%d] lport[%d]\n",
                rv, slot_notify, excp_port_array[i]);
            continue;
        }
        if (unit_noti != unit) {
            SSA_PTD_ZLOG_WARN("unit_noti[%d] not equal to unit_my[%d]\n", unit_noti, unit);
            continue;
        }
        /* since this unit-port is my unit-port add it to excp_pbmp */
        BCM_PBMP_PORT_ADD(g_ptd_dad_isolate_excp_pbmp[unit], port);
        SSA_PTD_ZLOG_FATAL("unit[%d] port[%d] is dad exception\n", unit, port);
    }

    pbmp = PBMP_E_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    BCM_PBMP_REMOVE(pbmp, g_ptd_dad_isolate_excp_pbmp[unit]);
    BCM_PBMP_ITER(pbmp, port) {
        rv = libddm_get_lphyid_by_unit_port(unit, port, &lphyid);
        if (rv != 0) {
            SSA_PTD_ZLOG_FATAL("libddm_get_lphyid_by_unit_port fail[%d] unit[%d] port[%d]\n",
                rv, unit, port);
            continue;
        }
        rv = ptd_rgos_admin_set(lphyid, 0, unit_t_info);
        SSA_PTD_ZLOG_FATAL("ptd_rgos_admin_set [%d] lphyid[%u]\n", rv, lphyid);
    }

    /* set this unit in dad_isolate status at last
     * cause ptd_rgos_admin_set will judge this flag to see if
     * unit-port will be skipped, THE FLAG SET MUST BEHIND the dad shut operation
     */
    g_ptd_dad_isolate_flag[unit] = 1;
    SSA_PTD_ZLOG_FATAL("unit[%d] ptd_mom_dad_isolate OVER\n", unit);
#else
//NPS是否需要实现？ pengcheng
#endif
    return SSA_PORT_E_NONE;
}

int ptd_mom_dad_shut_exception_handler(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    /* obj of dad_isolate */
    PDev__DadPortShut *dad_shut_exception;
    PDev__DadPortShutIndex dad_shut_slot_index = P_DEV__DAD_PORT_SHUT_INDEX__INIT;
    PDev__DadPortShut dad_shut_exception_scan = P_DEV__DAD_PORT_SHUT__INIT;
    dad_shut_exception_scan.index = &dad_shut_slot_index;

    if (!global || !msg) {
        SSA_PTD_ZLOG_ERROR("global[%p]/msg[%p] param err.", global, msg);
        return SSA_PORT_E_IVPARAM;
    }

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        SSA_PTD_ZLOG_FATAL("in RG_MOM_SUBSCRIBE dad_shut_exception\n");
        rg_mom_scan_sync(global, msg->db,  (const rg_obj *)&dad_shut_exception_scan, 0, ptd_mom_dad_shut_exception_handler, privdata);
        return 0;
      } else if (msg->cmd == RG_MOM_HSET) {
        SSA_PTD_ZLOG_FATAL("in RG_MOM_HSET dad_shut_exception\n");
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        dad_shut_exception = (PDev__DadPortShut *)res->value;
        if (dad_shut_exception == NULL) {
            SSA_PTD_ZLOG_ERROR("msg value null.");
            return SSA_PORT_E_IVPARAM;
        }
    }  else {
        SSA_PTD_ZLOG_FATAL("error cmd = %d\n", msg->cmd);
        return SSA_PORT_E_IVPARAM;
    }

    (void)ptd_mom_dad_isolate(dad_shut_exception, global, (vsd_unit_thread_info_t *)privdata);
    SSA_PTD_ZLOG_FATAL("over\n");

    return SSA_PORT_E_NONE;
}

int ptd_mom_init(rg_global_t *global, int unit, vsd_unit_thread_info_t *unit_t_info)
{
    SSA_PORT_INIT_FUNC_ENTER;

    INIT_LIST_HEAD(&enable_conf_cache_head[unit]);
    ptd_mom_subscribe(global, unit, unit_t_info);
    SSA_PORT_INIT_FUNC_LEAVER;

    return 0;
}

/**************************add the backplane mom functions*********************************************/
int ptd_rgos_bp_attr_set(unsigned int lphyid, ptd_bp_attr_info_t* ptd_bp_attr_info)
{
    int rv;
    /* using to get unit port */
    ptd_info_t ptd_bp;
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd_bp_attr_info);

    SSA_PTD_ZLOG_DEBUG("start ptd_mom_attr_set phyid[%d] speed[%d] hg2_code[%d] ifg[%d] if_type[%d]\n",
        lphyid, ptd_bp_attr_info->speed, ptd_bp_attr_info->hg2_code, ptd_bp_attr_info->ifg, ptd_bp_attr_info->if_type);

    memset(&ptd_bp, 0, sizeof(ptd_info_t));
    /* get backplane port info */
    rv = ptd_get_bp_port_info_by_phyid(lphyid, &ptd_bp);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("get port info fail phyid 0x%x\n", lphyid);
        return -1;
    }

    if (g_bp_ptd != NULL && g_bp_ptd->set_bp_attr) {
        rv = g_bp_ptd->set_bp_attr(&ptd_bp, ptd_bp_attr_info);
        PTD_CHK_RET_RETURN_VAL(rv, "[%u]set_bp_attr fail [%d]\n", lphyid, rv);
    }

    SSA_PTD_ZLOG_DEBUG("over ptd_mom_attr_set phyid[%d] speed[%d] hg2_code[%d] ifg[%d] if_type[%d]\n",
        lphyid, ptd_bp_attr_info->speed, ptd_bp_attr_info->hg2_code, ptd_bp_attr_info->ifg, ptd_bp_attr_info->if_type);

    return 0;
}

int ptd_rgos_bp_admin_set(unsigned int lphyid, int enable)
{
    int rv;
    /* using to get unit port */
    ptd_info_t ptd_bp;

    SSA_PTD_ZLOG_DEBUG("ptd_mom_admin_set phyid[0x%x] admin[%d] start\n", lphyid, enable);

    memset(&ptd_bp, 0, sizeof(ptd_info_t));
    /* get backplane port info */
    rv = ptd_get_bp_port_info_by_phyid(lphyid, &ptd_bp);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("get port info fail phyid 0x%x\n", lphyid);
        return -1;
    }

    if (g_bp_ptd != NULL && g_bp_ptd->set_bp_admin) {
        rv = g_bp_ptd->set_bp_admin(&ptd_bp, enable);
        PTD_CHK_RET_RETURN_VAL(rv, "[%u]bp_admin_set[%d] fail [%d]\n", lphyid, enable, rv);
    }

    SSA_PTD_ZLOG_DEBUG("ptd_rgos_bp_admin_set phyid[0x%x] admin[%d] over\n", lphyid, enable);

    return 0;
}

/*************************外部使用的API************************/
static int flow_ptd_to_ptm(int tx, int rx)
{
    if (tx == 1 && rx == 1) {
        return S_INTF__FLOWCTRL_TYPE_E__ON;
    } else if (tx == 0 && rx == 1) {
        return S_INTF__FLOWCTRL_TYPE_E__OFF;
    } else if (tx == 1 && rx == 0) {
        return S_INTF__FLOWCTRL_TYPE_E__OFF;
    } else if (tx == 0 && rx == 0) {
        return S_INTF__FLOWCTRL_TYPE_E__OFF;
    } else {
        return S_INTF__FLOWCTRL_TYPE_E__FLOWCTRL_UNKNOWN;
    }
}

static int32_t ptd_mom_scan_PDev__VslFormat(rg_global_t *glb, rg_mom_pubsub_msg_t *pmsg,
                                rg_mom_response_cb scan_cb)
{
    int32_t ret;
    PDev__VslFormat     vslFormat = P_DEV__VSL_FORMAT__INIT;
    PDev__VslPortIndex  vslindex = P_DEV__VSL_PORT_INDEX__INIT;

    vslFormat.index = &vslindex;
    SSA_PTD_ZLOG_WARN("scan PDev__VslFormat key %s cmd: %d db: %d", pmsg->key, pmsg->cmd, pmsg->db);
    ret = rg_mom_scan_sync(glb, pmsg->db, (const rg_obj *)&vslFormat, 0, scan_cb, NULL);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("rg_mom_scan_sync PDev__VslFormat failed %d", ret);
    }

    return 0;
}

static int32_t ptd_mom_set_format(rg_global_t *glb, rg_mom_pubsub_msg_t *pmsg, void *prvd)
{
    PDev__VslFormat *format;
    rg_mom_hash_res_t *res;

    SSA_PTD_ZLOG_WARN("key %s cmd: %d.", pmsg->key, pmsg->cmd);
    if (pmsg->cmd == RG_MOM_HSET) {
        res = (rg_mom_hash_res_t *)pmsg->value;
        if (res == NULL || res->error_code != 0) {
            return (-6);
        }
        format = (PDev__VslFormat *)res->value;
    } else if (pmsg->cmd == RG_MOM_DEL || pmsg->cmd == RG_MOM_EXPIRE) {
        format = (PDev__VslFormat *)pmsg->value;
        format->mode = 0;/* ??????????? */
    } else {
        return 0;
    }
    SSA_PTD_ZLOG_WARN("dev %d slot: %d. lport:%d format %d", format->index->devid, format->index->slotid,
                        format->index->lport, format->mode);
    g_ptd_local_devid = format->index->devid;

    return 0;
}

int32_t ptd_mom_sub_format(rg_global_t *glb, rg_mom_pubsub_msg_t *pmsg, void *prvd)
{
    int32_t ret;

    ret = 0;
    SSA_PTD_ZLOG_WARN("key %s cmd: %d.", pmsg->key, pmsg->cmd);
    if (pmsg->cmd == RG_MOM_SUBSCRIBE) {
        ret = ptd_mom_scan_PDev__VslFormat(glb, pmsg, ptd_mom_set_format);
    } else {
        ret = ptd_mom_set_format(glb, pmsg, prvd);
    }
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("sub or scan handle PDev__VslFormat failed %d..", ret);
    }

    return 0;
}
static int32_t ptd_mom_get_my_lslot(rg_global_t *glb, int32_t *lslot)
{
    PDev__DpLibMyInfo *my_info_ptr;
    rg_mom_hash_res_t *res;
    int32_t sleep_cnt = 0;
    int32_t ret = 0;

    PDev__DpLibMyInfo my_info_obj = P_DEV__DP_LIB_MY_INFO__INIT;
    while (sleep_cnt++ < 600) {
        ret = rg_mom_exists_sync(glb, RG_MOM_TUNNER_DB, (const rg_obj*)&my_info_obj);
        if (ret) {
            SSA_PTD_ZLOG_WARN("PDev__DpLibMyInfo obj is not exist, glb:%p ret:%d", glb, ret);
            usleep(100000);
            continue;
        }

        res = rg_mom_hgetall_sync(glb, RG_MOM_TUNNER_DB, (const rg_obj*)&my_info_obj);
        if (res != NULL && res->value != NULL && res->error_code == RG_MOM_OK) {
            my_info_ptr = (PDev__DpLibMyInfo *)res->value;
            *lslot = my_info_ptr->slotid;
            SSA_PTD_ZLOG_DEBUG("lslot=%d", *lslot);
        }
        rg_mom_hash_res_free(res);

        break;
    }

    return ret;
}

int ptd_mom_link_notify(int unit, int port, ptd_link_notify_info_t *link_info, rg_global_t *global)
{
    unsigned int phyid = 0xfffff;
    int port_type, cur_port_type;
    phyid_info_t phyid_info;
    int32_t lslot, max_port = 0;
    PDev__UnitCportInfo *local;
    int ret = 0;

    SIntf__Ptindex   ptindex = S_INTF__PTINDEX__INIT;
    SDev__Ifindex    ifindex = S_DEV__IFINDEX__INIT;
    SIntf__StatLinkinfo  statLinkinfo = S_INTF__STAT_LINKINFO__INIT;
    SDev__StatBpLinkinfo bp_link_info = S_DEV__STAT_BP_LINKINFO__INIT;
    bp_link_info.index = &ifindex;
    statLinkinfo.index = &ptindex;
    size_t link_array[6] = {6, 7, 8, 9, 10, 11};
    rg_mom_hmset_op_t op;
    SSA_PTD_ZLOG_WARN("ptd_link_notify, unit 0x%x port %d up %d", unit, port, link_info->linkstatus);

    (void)libddm_get_max_port_by_unit(unit, &max_port);
    SSA_PTD_ZLOG_WARN("ptd_link_notify, unit %d port %d up %d max_port %d", unit, port,
        link_info->linkstatus, max_port);

    if ((port > max_port) || (ssa_port_cfg_get_backplane_port_spec(port) == 0)) {
        /* backplane port */
        lslot = ndm_get_my_lslotid();
        if (lslot < 0) {
            SSA_PTD_ZLOG_ERROR("ndm_get_my_lslotid fail, lslot=%d\n", lslot);
            ret = ptd_mom_get_my_lslot(global, &lslot);
            if (ret) {
                SSA_PTD_ZLOG_ERROR("ptd_mom_get_my_lslot fail, ret=%d\n", ret);
                return -1;
            }
        }
        phyid = DDM_SET_BP_PHYID(lslot, unit, port);
        (bp_link_info.index)->phyid = phyid;
        bp_link_info.speed = link_info->speed;
        bp_link_info.is_up = (link_info->linkstatus == 1) ? true : false;
        SSA_PTD_ZLOG_DEBUG("backplane port link notify! set to IBC_DB, lslot[%d], unit[%d], "
            "port[%d], phyid[0x%x]", lslot, unit, port, phyid);

        ret = rg_mom_set_sync(global, RG_MOM_IBC_DB, (const rg_obj *)&bp_link_info);
        if (ret) {
            SSA_PTD_ZLOG_ERROR("bp mom link info write fail\n");
            return ret;
        }

        return 0;
    }

    /* eth/vsl port */
    memset(&op, 0, sizeof(rg_mom_hmset_op_t));
    op.select_fields = link_array;
    op.fields_number = 6;
    op.flag = 3;

    (void)libddm_get_lphyid_by_unit_port(unit, port, &phyid);

    (statLinkinfo.index)->phyid = phyid;
    statLinkinfo.speed = link_info->speed;
    statLinkinfo.duplex = duplex_ptd_to_ptm(link_info->duplex);
    statLinkinfo.flowctrl = flow_ptd_to_ptm(link_info->pause_tx, link_info->pause_rx);
    statLinkinfo.is_up = (link_info->linkstatus == 1) ? true : false;
    statLinkinfo.nego = link_info->autoneg ? S_INTF__NEGO_TYPE_E__NEGO_ENABLE : S_INTF__NEGO_TYPE_E__NEGO_DISABLE;
    /* 切VSL口，由于底层介质切成backplane，上送的介质为0,导致上层CLI显示有问题,背板口link不影响 */
    if (link_info->drv_medium == BCM_PORT_MEDIUM_NONE) {
        ret = ndm_get_local_port_by_unit_cport(unit, port, &local);
        if (ret) {
            SSA_PTD_ZLOG_ERROR("get local port by unit port fail, ret = %d. unit %d port %d", ret, unit, port);
            return ret;
        }
        /* 不考虑是光电复用口，若是光电复用口需要判断生效介质，默认为电介质 */
        statLinkinfo.medium = ((int)local->static_info->pd_medium_type == PORT_MEDIUM_FIBER)
                                ? S_INTF__MEDIUM_TYPE_E__FIBER : S_INTF__MEDIUM_TYPE_E__COPPER;
    } else {
        statLinkinfo.medium = ptd_rgos_medium_drv_to_ptm(link_info->drv_medium);
    }

    SSA_PTD_ZLOG_WARN("intf_vsl_link_ntfy phyid[0x%x] unit[%d] port[%d] is_up[%d] [%u] start", phyid, unit, port, statLinkinfo.is_up, get_timer_now());

    ret = ptd_get_port_type(unit, port, &port_type);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("ptd_get_port_type fail, unit:%d port:%d\n", unit, port);
        return ret;
    }
    SSA_PTD_ZLOG_WARN("cache_port_type, unit 0x%x port %d port_type %s", unit, port, port_type == PTD_ETH_PORT ? "ETH" : "VSL");
    cur_port_type = ptd_unit_port_is_e_port(unit, port) == 1 ? PTD_ETH_PORT : PTD_VSL_PORT;
    SSA_PTD_ZLOG_WARN("cur_port_type, unit 0x%x port %d port_type %s", unit, port, cur_port_type == PTD_ETH_PORT ? "ETH" : "VSL");

    memset(&phyid_info, 0, sizeof(phyid_info_t));
    ret = libddm_get_unit_port_by_lphyid(phyid, &phyid_info.unit, &phyid_info.port);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("libddm_get_unit_port_by_lphyid lphyid 0x%x failed %d..", phyid, ret);
        return ret;
    }
    ret = libddm_get_slot_lport_by_unit_port(phyid_info.unit, phyid_info.port, &phyid_info.slot, &phyid_info.lport);
    if (ret != 0) {
        SSA_PTD_ZLOG_ERROR("libddm_get_slot_lport_by_unit_port unit %d port %d failed %d..", phyid_info.unit, phyid_info.port, ret);
        return ret;
    }
    phyid_info.dev = g_ptd_local_devid;

    if (port_type == PTD_ETH_PORT && cur_port_type == PTD_ETH_PORT) {
        goto exit;
    } else {
#if 0
by pengcheng
        /* VSL */
        if (cur_port_type == PTD_VSL_PORT) {
            ret = intf_vsl_db_set_PDev__VslPhyLink(global, RG_MOM_IBC_DB, &phyid_info, statLinkinfo.is_up);
            if (ret != 0) {
                SSA_PTD_ZLOG_ERROR("set PDev__VslPhyLink unit %d port %d failed %d..", phyid_info.unit, phyid_info.port, ret);
            }
            g_ptd_vsl_link_state[phyid_info.lport] = statLinkinfo.is_up;
            SSA_PTD_ZLOG_WARN("vsl unit %d port %d link %s notify succ.", phyid_info.unit, phyid_info.port,
                                    statLinkinfo.is_up ? "up" : "down");
        } else if (g_ptd_vsl_link_state[phyid_info.lport]) {
            ret = intf_vsl_db_del_PDev__VslPhyLink(global, RG_MOM_IBC_DB, &phyid_info);
            if (ret != 0) {
                SSA_PTD_ZLOG_ERROR("set PDev__VslPhyLink unit %d port %d failed %d..", phyid_info.unit, phyid_info.port, ret);
            }
            g_ptd_vsl_link_state[phyid_info.lport] = false;
            SSA_PTD_ZLOG_WARN("vsl unit %d port %d link down notify succ.", phyid_info.unit, phyid_info.port);
        }
        SSA_PTD_ZLOG_WARN("intf_vsl_link_ntfy phyid[0x%x] unit[%d] port[%d] is_up[%d] [%u] over", phyid, unit, port, statLinkinfo.is_up, get_timer_now());
#endif
    }

exit:

    ptd_set_port_type(unit, port, cur_port_type);

    ret = rg_mom_hmset_ext_sync(global, RG_MOM_ASIC_DB, &op, (const rg_obj *)&statLinkinfo);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("mom link info write fail\n");
        return ret;
    }
    SSA_PTD_ZLOG_WARN("rg_mom_hmset_ext_sync phyid[0x%x] unit[%d] port[%d] is_up[%d] [%u] over", phyid, unit, port,statLinkinfo.is_up, get_timer_now());
    return 0;
}

/* 失败之后回滚信息 */
int ptd_mom_attr_fail_noitify(unsigned int phyid, unsigned int set_val, unsigned int oper_val, int type, rg_global_t *global)
{
    int ret;

    SIntf__Ptindex   ptindex = S_INTF__PTINDEX__INIT;
    SIntf__CfgrbFailRes   cfg_fail = S_INTF__CFGRB_FAIL_RES__INIT;
    cfg_fail.index = &ptindex;
    size_t fail_array[3] = {6, 7, 8};
    //phyid get by unit port
    (cfg_fail.index)->phyid = phyid;
    cfg_fail.set_ival = set_val;
    cfg_fail.oper_ival = oper_val;
    cfg_fail.type = type;
    ret = rg_mom_hmset_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&cfg_fail, fail_array, 3);
    if (ret) {
        printf("mom cfg fail info write fail\n");
        return ret;
    }

    return 0;
}

static int ptd_check_soc_an(int unit)
{

    return 1;

}

static int ptd_mom_trans_info_notify_event(struct rg_thread *trans_info_noti_thread)
{
    int ret;
    rg_global_t *global;
    unsigned int phyid;

    SSA_PTD_ZLOG_NOTICE("ptd_mom_trans_info_notify_event start!!");
    if (trans_info_noti_thread == NULL) {
        SSA_PTD_ZLOG_ERROR("rg_thread NULL\n");
        return SSA_PORT_E_IVPARAM;
    }

    global = (rg_global_t *)(trans_info_noti_thread->arg);
    phyid = trans_info_noti_thread->u.val;

    SSA_PTD_ZLOG_NOTICE("phyid[0x%x]", phyid);
    /* 模块信息通告完以后再通告模块相关防伪信息 */
    ret = ptd_mom_trans_info_publish(phyid, global);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("ptd_mom_trans_info_publish fail\n");
        return ret;
    }
    SSA_PTD_ZLOG_NOTICE("ptd_mom_trans_info_notify_event over!!");

    return SSA_PORT_E_NONE;
}

int ptd_mom_fiber_notify(ptd_info_t *ptd, rg_global_t *global)
{

    int ret;
    struct rg_thread *thread;

    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__StatPluginfo plug_info = S_INTF__STAT_PLUGINFO__INIT;
    plug_info.index = &keyindex;
    size_t fiber_array[5] = {6, 7, 8, 9, 10};
    rg_mom_hmset_op_t op;
    //vsl_pluginfo_t vsl_plug;
    int supp_min_speed;

    memset(&op, 0, sizeof(rg_mom_hmset_op_t));
    op.select_fields = fiber_array;
    op.fields_number = 5;
    op.flag = 3;

    (plug_info.index)->phyid = ptd->phyid;
    plug_info.is_present = (ptd->present != 0 ? true : false);
    plug_info.is_supp_nego = ptd_check_soc_an(ptd->unit);
    //by pengcheng  plug_info.plug_speed = (ptd->split_port_type != 1) ? ptd->trans_rate : (ptd->trans_rate / ptd_unit_port_split_num_get(ptd->unit, ptd->port));
    plug_info.plug_speed = ptd->trans_rate;
	plug_info.effect_medium = ptd->ptm_medium;
    plug_info.plug_type = ptd->trans_model;
    SSA_PTD_ZLOG_NOTICE("ptd sfp intr detected, write mom plug info is present %d plug_speed %d  plug_type %d phyid 0x%x [%u]\n",
        plug_info.is_present, plug_info.plug_speed, plug_info.plug_type, ptd->phyid, get_timer_now());

    /* get port min vsl supp speed */
    //vsl_plug.is_present = plug_info.is_present;
   // vsl_plug.is_supp_nego = plug_info.is_supp_nego;
    //vsl_plug.plug_type = plug_info.plug_type;
   // vsl_plug.effect_medium = plug_info.effect_medium;
    //vsl_plug.plug_speed = plug_info.plug_speed;
    //supp_min_speed = PORT_VSL_SUPP_MIN_SP_DEFAULT;
    //if (ssa_port_cfg_get_prt_min_supp_vsl_speed(ptd->lport) != 0) {
    //    supp_min_speed = ssa_port_cfg_get_prt_min_supp_vsl_speed(ptd->lport);
    //}
    //SSA_PTD_ZLOG_NOTICE("lport[%d] PORT_VSL_SUPP_MIN_SP[%d]  [%u]\n", ptd->lport, supp_min_speed, get_timer_now());
    //vsl_plug.supp_min_speed = supp_min_speed;

    //ret = intf_vsl_plug_ntfy(global, ptd->phyid, &vsl_plug);
    //if (ret) {
    //    SSA_PTD_ZLOG_ERROR("vsl 0x%d mom plug fail info write fail\n", ptd->phyid);
   // }
    ret = rg_mom_hmset_ext_sync(global, RG_MOM_ASIC_DB, &op, (const rg_obj *)&plug_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("mom plug fail info write fail\n");
        return ret;
    }

    thread = rg_thread_add_event_withname(global->master, ptd_mom_trans_info_notify_event, global, ptd->phyid, "ptd_trans_info_noti");
    if (thread == NULL) {
        SSA_PTD_ZLOG_ERROR("create ssa_mac_recv_aumsg thread fail\n");
        return SSA_PORT_E_RETURN;
    }
#if 0
    /* 模块信息通告完以后再通告模块相关防伪信息 */
    ret = ptd_mom_trans_info_publish(ptd->phyid, global);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("ptd_mom_trans_info_publish fail\n");
        return ret;
    }
#endif

    return SSA_PORT_E_NONE;
}
extern int in_ssa_port_stat_get_mib(int unit, int port, uint64_t *buf);
extern void ptd_convertmib_to_ptm(int unit, int port, uint64_t *buf, SIntf__StatMibinfo *buf_sport);


int ptd_mom_get_mib(struct rg_thread *thread)     //unit  需要区分本unit 以及其他unit
{
    unsigned int phyid;
    int port;
    int unit = 0, rv;
    uint64_t buf[SSA_PORT_STAT_BUF_NUM]; /* for normal mib */
    uint64_t dbg_cnt_urpf;               /* for mib-ex */
    vsd_unit_thread_info_t *unit_t_info;
    rg_global_t *global;
    int mib_noti_flag;
    int mib_ex_noti_flag;

    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__StatMibinfo mib_info = S_INTF__STAT_MIBINFO__INIT;
    mib_info.index = &keyindex;

    SIntf__Ptindex ptindex = S_INTF__PTINDEX__INIT;
    SIntf__StatMibinfoExt mib_info_ex = S_INTF__STAT_MIBINFO_EXT__INIT;
    mib_info_ex.index = &ptindex;

    if (thread == NULL) {
        SSA_PTD_ZLOG_WARN("arg is null\n");
        return -1;
    }

    unit_t_info = (vsd_unit_thread_info_t *)(thread->arg);
    global = unit_t_info->global;
    unit = unit_t_info->unit;
#if 0
    pbmp = PBMP_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    BCM_PBMP_ITER(pbmp, port) {
        rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
        if (rv != 0) {
            SSA_PTD_ZLOG_WARN("ptd_mom_get_mib libddm_get_phyid_by_unit_port failed! rv %d unit %d port %d\n", rv, unit, port);
            continue;
        }

        /* 背板口不mib统计 */
        if (libddm_is_phyid_fit(phyid, DDM_PHY_BP) == true) {
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] phyid[%u] is hg", unit, port, phyid);
            continue;
        }

        /* get normal mib from SDK */
        (void)memset(buf, 0, sizeof(buf));
        rv = in_ssa_port_stat_get_mib(unit, port, buf);
        if (rv != SSA_PORT_E_NONE){
            SSA_PTD_ZLOG_WARN("in_ssa_port_stat_get_mib failed! rv %d unit %d port %d\n", rv, unit, port);
        }

        /* get mib-ex from SDK */
        dbg_cnt_urpf = 0;
        rv = ptd_mib_get_mib_ex_info(unit, port, &(dbg_cnt_urpf));
        if (rv) {
            SSA_PTD_ZLOG_WARN("ptd_mib_get_mib_ex_info failed! rv %d unit %d port %d\n", rv, unit, port);
        }

        /* get mib noti flag */
        mib_noti_flag = ptd_mib_unitport_mib_need_notify(unit, port, buf);
        mib_ex_noti_flag = ptd_mib_unitport_mib_ex_need_notify(unit, port, &(dbg_cnt_urpf));

        /* here we judge if normal mib of this lport is to notify */
        if (mib_noti_flag == PTD_MIB_NEED_NOTI) {
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] phyid[%u] mib need to notify", unit, port, phyid);

            /* getting here means we need notify the mib, so update it to cache */
            rv = ptd_mib_unitport_mib_update(unit, port, buf);
            if (rv != SSA_PORT_E_NONE){
                SSA_PTD_ZLOG_WARN("ptd_mib_unitport_mib_update failed! rv %d unit[%d] port[%d] phyid[%u]", rv, unit, port, phyid);
                /* update fail we will notify anyway! */
            }

            /* normal mib notify */
            ptd_convertmib_to_ptm(unit, port, buf, &mib_info);
            (mib_info.index)->phyid = phyid;
            rv = rg_mom_hmset_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&mib_info, NULL, 0);
            if (rv) {
                SSA_PTD_ZLOG_WARN("mom mib info write fail[%d]\n", rv);
            }
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] phyid[%u] rg_mom_hmset_sync update OK", unit, port, phyid);

            rv = intf_vsl_mib_ntfy(global, phyid, &mib_info);
            if (rv) {
                SSA_PTD_ZLOG_WARN("mom vsl 0x%x mib info fail[%d]\n", phyid, rv);
            }
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] phyid[%u] intf_vsl_mib_ntfy update OK", unit, port, phyid);

        }

        /* here we judge if mib-ex of this lport is to notify */
        if (mib_ex_noti_flag == PTD_MIB_NEED_NOTI) {
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] phyid[%u] mib-ex need to notify", unit, port, phyid);
            /* getting here means we need notify the mib, so update it to cache */
            rv = ptd_mib_unitport_mib_ex_update(unit, port, &(dbg_cnt_urpf));
            if (rv != SSA_PORT_E_NONE){
                SSA_PTD_ZLOG_WARN("ptd_mib_unitport_mib_ex_update failed! rv %d unit[%d] port[%d] phyid[%u]", rv, unit, port, phyid);
                /* update fail we will notify anyway! */
            }

            /* mib-ex notify */
            (mib_info_ex.index)->phyid = phyid;
            mib_info_ex.dbg_cnt_urpf = 0;

            mib_info_ex.dbg_cnt_urpf = dbg_cnt_urpf;

            rv = rg_mom_set_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&mib_info_ex);
            if (rv) {
                SSA_PTD_ZLOG_WARN("mom mib_ex info write fail[%d]\n", rv);
            }
            SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] phyid[%u] rg_mom_set_sync mib_ext OK", unit, port, phyid);
        }
    }
#endif
    rg_thread_add_timer_timeval_withname(global->master, ptd_mom_get_mib, unit_t_info, timer1, "ptd_get_mib");

    return SSA_PORT_E_NONE;
}

static int ptd_mom_mib_thread(rg_global_t *global, int unit, vsd_unit_thread_info_t *unit_t_info)
{
    timer1.tv_sec = ssa_port_cfg_get_admin_sleep_time();
    if (timer1.tv_sec <= 0) {
        timer1.tv_sec = 3;
    }

    //定时写入mib统计信息 传入unit
    rg_thread_add_timer_timeval_withname(global->master, ptd_mom_get_mib, unit_t_info, timer1, "ptd_get_mib");

    return 0;
}

/**************生测相关*******************/
static int ptd_mom_lb_begin(SDev__LbTest *cfg_attr, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv;

    if (unit_t_info == NULL) {
        SSTEST_DBG_ERR("arg is null\n");
        return -1;
    }

    rv = ptd_fac_begin_lb_test(unit_t_info->unit);
    if (rv != 0) {
        (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)cfg_attr);
    }

    return 0;
}

int ptd_mom_lb_begin_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__LbTest *cfg_attr;
    //PtdPt__Ifindex ptdindex = PTD_PT__IFINDEX__INIT;
    SDev__LbTest lb_test = S_DEV__LB_TEST__INIT;
    //lb_test.index = &ptdindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_LB_BEGIN, (const rg_obj *)&lb_test, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        cfg_attr = (SDev__LbTest *)res->value;
    } else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_lb_begin(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_lb_begin_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__LbTest *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SDev__LbTest *)res->value;

    (void)ptd_mom_lb_begin(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

static int ptd_mom_lb_stop(SDev__LbTest *cfg_attr, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv;

    if (unit_t_info == NULL) {
        SSTEST_DBG_ERR("arg is null\n");
        return -1;
    }

    rv = ptd_fac_stop_lb_test(unit_t_info->unit);
    if (rv != 0) {
        (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)cfg_attr);
    }
    //rg_mom_hmset_sync(global, RG_MOM_DB_HOST, (const rg_obj *)cfg_attr, NULL, 0);
    return 0;
}

int ptd_mom_lb_stop_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__LbTest *cfg_attr;
    // PtdPt__Ifindex ptdindex = PTD_PT__IFINDEX__INIT;
    SDev__LbTest lb_test = S_DEV__LB_TEST__INIT;
    //lb_test.index = &ptdindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_LB_STOP, (const rg_obj *)&lb_test, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        cfg_attr = (SDev__LbTest *)res->value;
    } else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_lb_stop(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_lb_stop_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__LbTest *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SDev__LbTest *)res->value;

    (void)ptd_mom_lb_stop(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_get_fcs(struct rg_thread *thread)
{
    unsigned int phyid;
    int unit, p;
    libddm_lport_ctrl_t port;
    vsd_unit_thread_info_t *unit_t_info;
    rg_global_t *global;
    struct timeval tv;
    int recv_time;

    SDev__GetFcs  get_fcs = S_DEV__GET_FCS__INIT;
    SDev__Ifindex ptdindex = S_DEV__IFINDEX__INIT;
    size_t fcs_array[1] = {6};
    get_fcs.index = &ptdindex;

    if (thread == NULL) {
        SSTEST_DBG_ERR("arg is null\n");
        return -1;
    }

    unit_t_info = (vsd_unit_thread_info_t *)(thread->arg);
    global = unit_t_info->global;
    unit = unit_t_info->unit;

    libddm_for_each_unit_port(phyid, unit, port) {
        (get_fcs.index)->phyid = phyid;
        p = port.cp;
        (void)ptd_fac_get_fcs_count(unit, p, &(get_fcs.fcs));

        (void)rg_mom_hmset_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&get_fcs, fcs_array, 1);

    }
    (void)gettimeofday(&tv, NULL);

    recv_time = tv.tv_sec + tv.tv_usec/(1000 * 1000);
    SSTEST_DBG_TEST("get fcs end, end time %d\n", recv_time);
    rg_thread_add_timer_timeval_withname(global->master, ptd_mom_get_fcs, unit_t_info, timer1, "ptd_get_fcs_num");
    return 0;
}

static int ptd_mom_bc_begin(SDev__BcTest *cfg_attr, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    //struct timeval timer1 = {5, 0};
    if (unit_t_info == NULL) {
        SSTEST_DBG_ERR("arg is null\n");
        return -1;
    }

    rv = ptd_fac_begin_bc_test(unit_t_info->unit);
    if (rv != 0) {
        (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)cfg_attr);
    }

    //rg_mom_hmset_sync(global, RG_MOM_DB_HOST, (const rg_obj *)cfg_attr, NULL, 0);
    //定时获取fcs报文数目
    rg_thread_add_timer_timeval_withname(global->master, ptd_mom_get_fcs, unit_t_info, timer1, "ptd_get_fcs_num");

    return 0;
}

int ptd_mom_bc_begin_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__BcTest *cfg_attr;
    //PtdPt__Ifindex ptdindex = PTD_PT__IFINDEX__INIT;
    SDev__BcTest bc_test = S_DEV__BC_TEST__INIT;
    //bc_test.index = &ptdindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_BC_BEGIN, (const rg_obj *)&bc_test, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

  if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        cfg_attr = (SDev__BcTest *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_bc_begin(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_bc_begin_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__BcTest *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SDev__BcTest *)res->value;

    (void)ptd_mom_bc_begin(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

static int ptd_mom_bc_stop(SDev__BcTest *cfg_attr, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv;
    if (unit_t_info == NULL) {
        SSTEST_DBG_ERR("arg is null\n");
        return -1;
    }

    rv = ptd_fac_stop_bc_test(unit_t_info->unit);
    if (rv != 0) {
        (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)cfg_attr);
    }

    rg_thread_cancel_by_arg_func(global->master, ptd_mom_get_fcs, unit_t_info);

    //rg_mom_hmset_sync(global, RG_MOM_DB_HOST, (const rg_obj *)cfg_attr, NULL, 0);
    return 0;
}

int ptd_mom_bc_stop_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__BcTest *cfg_attr;
    //PtdPt__Ifindex ptdindex = PTD_PT__IFINDEX__INIT;
    SDev__BcTest bc_test = S_DEV__BC_TEST__INIT;
    //bc_test.index = &ptdindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_BC_STOP, (const rg_obj *)&bc_test, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

  if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        cfg_attr = (SDev__BcTest *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_bc_stop(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_bc_stop_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__BcTest *cfg_attr;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    cfg_attr = (SDev__BcTest *)res->value;

    (void)ptd_mom_bc_stop(cfg_attr, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

#if 0
static int ptd_mom_bc_get(PtdPt__BcTest *cfg_attr, rg_global_t * global)
{
	int lport;
	unsigned long long fcs = 0;

	lport = cfg_attr->lport;

	(void)ptd_get_bc_test_res(lport, &fcs);
	cfg_attr->fcs = fcs;
	rg_mom_hmset_sync(global, RG_MOM_DB_HOST, (const rg_obj *)cfg_attr, NULL, 0);
    return 0;
}

int ptd_mom_bc_get_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{

	 PtdPt__BcTest *cfg_attr;
	 PtdPt__Ifindex ptdindex = PTD_PT__IFINDEX__INIT;
	 PtdPt__BcTest bc_test = PTD_PT__BC_TEST__INIT;
	bc_test.index = &ptdindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_BC_STOP, (const rg_obj *)&bc_test, global);
        return 0;
    }

  if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        cfg_attr = (PtdPt__BcTest *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

	(void)ptd_mom_bc_get(cfg_attr, global);

	return 0;
}

int ptd_mom_bc_get_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    PtdPt__BcTest *cfg_attr;

   if( msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

		if (!res || res->error_code != RG_MOM_OK) {
            printf("unexpected, error! \n");
            return 0;
        }
        cfg_attr = (PtdPt__BcTest *)res->value;
    } else {
		printf("error cmd = %d\n", msg->cmd);
        return 0;

	}

	(void)ptd_mom_bc_get(cfg_attr, global);

	return 0;
}
#endif
#if 0
static int ptd_mom_attr_get(PtdPt__GetAttr *cfg_attr, rg_global_t * global)
{
	int ret;
	unsigned int phyid;
	ptd_attr_info_t ptd;
	int slot = 0;

	memset(&ptd, 0, sizeof(ptd_attr_info_t));
	phyid = cfg_attr->index->phyid;

	if (g_ptd != NULL && g_ptd->get_attr) {
	   (void)g_ptd->get_attr(slot, phyid, &ptd);

		cfg_attr->speed = ptd.speed;
		cfg_attr->duplex = ptd.duplex;
		cfg_attr->nego = ptd.an;
		cfg_attr->medium = ptd.medium;
		cfg_attr->link = ptd.link;   /* 不是1 认为都是down */
		ret = rg_mom_hmset_sync(global, RG_MOM_DB_HOST, (const rg_obj *)cfg_attr, NULL, 0);
		if (ret) {
			printf("mom get attr info write fail\n");
			return ret;

		}

	}


    return 0;
}


int ptd_mom_get_data_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    PtdPt__GetAttr *cfg_attr;

   if( msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

		if (!res || res->error_code != RG_MOM_OK) {
            printf("unexpected, error! \n");
            return 0;
        }
        cfg_attr = (PtdPt__GetAttr *)res->value;
    } else {
		printf("error cmd = %d\n", msg->cmd);
        return 0;

	}

	(void)ptd_mom_attr_get(cfg_attr, global);

	return 0;
}

int ptd_mom_attr_get_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{

	 PtdPt__GetAttr *cfg_attr;
	 PtdPt__Ifindex ptdindex = PTD_PT__IFINDEX__INIT;
	PtdPt__GetAttr get_attr = PTD_PT__GET_ATTR__INIT;
	get_attr.index = &ptdindex;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_MIB_ATTR_GET, (const rg_obj *)&get_attr, global);
        return 0;
    }

  if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("hash error happen\n");
            return 0;
        }
        cfg_attr = (PtdPt__GetAttr *)res->value;
    }  else {
        printf("error cmd = %d\n", msg->cmd);
        return 0;
    }

	(void)ptd_mom_attr_get(cfg_attr, global);


	return 0;
}
#endif

int ptd_fac_prbs_result_pub(rg_global_t * global, int lphyid, int result)
{
    int rv;
    rg_mom_hmset_op_t op;
    SDev__Ifindex ifindex = S_DEV__IFINDEX__INIT;
    SDev__PrbsResult prbs_res_pub = S_DEV__PRBS_RESULT__INIT;

    SSA_PTD_ZLOG_INFO("ptd_fac_prbs_result_pub enter");

    size_t select_array[1] = {6};
    op.flag = 3;
    op.select_fields = select_array;
    op.fields_number = 1;
    ifindex.phyid = lphyid;
    prbs_res_pub.index = &ifindex;
    prbs_res_pub.result = result;
    rv = rg_mom_hmset_ext_sync(global, RG_MOM_ASIC_DB, &op, (const rg_obj*)&prbs_res_pub);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("rg_mom_hmset_ext_sync error!\n");
        return -1;
    }
    SSA_PTD_ZLOG_INFO("ptd_fac_prbs_result_pub over");

    return 0;
}

static int ptd_mom_prbs_op(SDev__PrbsExecute *prbs_op, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv, lphyid;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(unit_t_info);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(global);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(prbs_op);

    SSA_PTD_ZLOG_INFO("ptd_mom_prbs_op enter");

    lphyid = prbs_op->index->phyid;

    if (prbs_op->status == S_DEV__PRBS_STATUS_E__PRBS_STAT_START) {
        printf("ptd_fac_set_port_prbs start, lphyid=0x%x\n", lphyid);
        rv = ptd_fac_set_port_prbs(lphyid);
    } else if (prbs_op->status == S_DEV__PRBS_STATUS_E__PRBS_STAT_STOP) {
        printf("ptd_fac_set_port_prbs cancel, lphyid=0x%x\n", lphyid);
        rv = ptd_fac_cancel_port_prbs(lphyid);
    } else {
        SSA_PTD_ZLOG_ERROR("Invalid prbs_status, operations for prbs is fail\n");
        return -1;
    }

    if (rv != 0) {
        (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)prbs_op);
        SSA_PTD_ZLOG_ERROR("unexpected, rg_mom_del_sync!\n");
    }

    SSA_PTD_ZLOG_INFO("ptd_mom_prbs_op over");

    return 0;
}

static int ptd_mom_prbs_get_res(SDev__PrbsResult *prbs_get_res, rg_global_t * global, vsd_unit_thread_info_t *unit_t_info)
{
    int rv, result, lphyid;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(unit_t_info);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(global);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(prbs_get_res);

    SSA_PTD_ZLOG_INFO("ptd_mom_prbs_op enter");

    lphyid = prbs_get_res->index->phyid;
    result = -2;

    if ( prbs_get_res->result == S_DEV__PRBS_RESULT_E__PRBS_RES_UNK) {

        rv = ptd_fac_get_prbs_result(lphyid, &result);
        if (rv != 0) {
            (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)prbs_get_res);
            SSA_PTD_ZLOG_ERROR("unexpected, rg_mom_del_sync!\n");
        }

        rv = ptd_fac_prbs_result_pub(global, lphyid, result);
        if (rv != 0) {
            (void)rg_mom_del_sync(global, RG_MOM_ASIC_DB, (rg_obj *)prbs_get_res);
            SSA_PTD_ZLOG_ERROR("unexpected, rg_mom_del_sync!\n");
        }
    } else {
        SSA_PTD_ZLOG_INFO("Don't care the cmd, prbs_get_res->result = [%d]", prbs_get_res->result);

        return 0;
    }

    SSA_PTD_ZLOG_INFO("ptd_mom_prbs_op enter");

    return 0;
}

int ptd_mom_prbs_op_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__PrbsExecute *prbs_op;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || !(res->value) || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    prbs_op = (SDev__PrbsExecute *)res->value;

    (void)ptd_mom_prbs_op(prbs_op, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_prbs_get_res_check_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__PrbsResult *prbs_get_res;

    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;

    if (!res || res->error_code != RG_MOM_OK) {
        SSA_PTD_ZLOG_ERROR("unexpected, error! \n");
        return 0;
    }
    prbs_get_res = (SDev__PrbsResult *)res->value;

    (void)ptd_mom_prbs_get_res(prbs_get_res, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_prbs_op_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__PrbsExecute* prbs_op;
    SDev__Ifindex if_index = S_DEV__IFINDEX__INIT;
    SDev__PrbsExecute prbs_op_scan = S_DEV__PRBS_EXECUTE__INIT;
    prbs_op_scan.index = &if_index;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_PRBS_OP, (const rg_obj *)&prbs_op_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        prbs_op = (SDev__PrbsExecute *)res->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_prbs_op(prbs_op, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

int ptd_mom_prbs_get_res_msg_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SDev__PrbsResult *prbs_get_res;
    SDev__Ifindex if_index = S_DEV__IFINDEX__INIT;
    SDev__PrbsResult prbs_get_res_scan = S_DEV__PRBS_RESULT__INIT;
    prbs_get_res_scan.index = &if_index;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ptd_mom_data_check(PTD_PRBS_GET_RES, (const rg_obj *)&prbs_get_res_scan, global, (vsd_unit_thread_info_t *)privdata);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            SSA_PTD_ZLOG_ERROR("hash error happen\n");
            return 0;
        }
        prbs_get_res = (SDev__PrbsResult *)res->value;
    }  else {
        SSA_PTD_ZLOG_ERROR("error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)ptd_mom_prbs_get_res(prbs_get_res, global, (vsd_unit_thread_info_t *)privdata);

    return 0;
}

rg_mom_response_cb ptd_mom_attr_set_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_attr_msg_handle,
    ptd_mom_attr_msg_handle,
    ptd_mom_attr_msg_handle,
    ptd_mom_attr_msg_handle,
    ptd_mom_medium_msg_handle,
    ptd_mom_admin_msg_handle,
    ptd_mom_mtu_msg_handle,
    ptd_mom_attr_msg_handle,

};

rg_mom_response_cb ptd_mom_attr_check_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_attr_data_check_handle,
    ptd_mom_attr_data_check_handle,
    ptd_mom_attr_data_check_handle,
    ptd_mom_attr_data_check_handle,
    ptd_mom_medium_data_check_handle,
    ptd_mom_admin_data_check_handle,
    ptd_mom_mtu_data_check_handle,
    ptd_mom_attr_data_check_handle,
    ptd_mom_mib_clr_data_check_handle,
    //ptd_mom_get_data_check_handle,
    ptd_mom_bc_begin_check_handle,
    ptd_mom_bc_stop_check_handle,
    ptd_mom_lb_begin_check_handle,
    ptd_mom_lb_stop_check_handle,
    ptd_mom_sfp_irq_data_check_handle,
    ptd_mom_trans_info_data_check_handle,
    ptd_mom_loopback_set_check_handle,
    ptd_mom_prbs_op_check_handle,
    ptd_mom_prbs_get_res_check_handle,
    ptd_mom_phy_irq_data_check_handle,
};

/*
rg_mom_response_cb ptd_mom_attr_get_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_attr_get_msg_handle,
};
*/
rg_mom_response_cb ptd_mom_attr_bc_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_bc_begin_msg_handle,
    ptd_mom_bc_stop_msg_handle,
    //ptd_mom_bc_get_msg_handle,
};

rg_mom_response_cb ptd_mom_attr_lb_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_lb_begin_msg_handle,
    ptd_mom_lb_stop_msg_handle,
};

rg_mom_response_cb ptd_mom_prbs_op_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_prbs_op_msg_handle,
};

rg_mom_response_cb ptd_mom_prbs_get_res_cb_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_prbs_get_res_msg_handle,
};


rg_mom_response_cb ptd_mom_intf_port_end_arr[PTD_MOM_ATTR_COUNT] = {
    ptd_mom_intf_port_end_handler,

};

int ptd_mom_data_check(int key_index, const rg_obj *attr, rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    rg_mom_scan_sync(global, RG_MOM_ASIC_DB, attr, 0, ptd_mom_attr_check_cb_arr[key_index], unit_t_info);
    return 0;
}

int ptd_mom_subscribe(rg_global_t *global, int unit, vsd_unit_thread_info_t *unit_t_info)
{
    SIntf__Ptindex keyindex = S_INTF__PTINDEX__INIT;
    SIntf__CfgAttr cfg_attr = S_INTF__CFG_ATTR__INIT;
    SIntf__EvtMibclr mib_clr = S_INTF__EVT_MIBCLR__INIT;
    SIntf__CfgLoopback loopback = S_INTF__CFG_LOOPBACK__INIT;
    SIntf__EvtMibclrExt mib_ex_clr = S_INTF__EVT_MIBCLR_EXT__INIT;
    mib_ex_clr.index = &keyindex;
    cfg_attr.index = &keyindex;
    mib_clr.index = &keyindex;
    loopback.index = &keyindex;
    /* obj of intf port end flag */
    SIntf__StatDatasync intf_port_end = S_INTF__STAT_DATASYNC__INIT;
    size_t intf_port_end_array[1] = {5};
    vsd_unit_thread_info_t *intf_port_end_arr_info[1]={unit_t_info};
    /* obj of system-enable */
    SFrame__KeyIndex key_index = S_FRAME__KEY_INDEX__INIT;
    SFrame__UnitEnable unit_enable_key = S_FRAME__UNIT_ENABLE__INIT;
    unit_enable_key.index = &key_index;
    /* obj of dad_isolate */
    PDev__DadPortShutIndex dad_shut_slot_index = P_DEV__DAD_PORT_SHUT_INDEX__INIT;
    PDev__DadPortShut dad_shut_exception = P_DEV__DAD_PORT_SHUT__INIT;
    dad_shut_exception.index = &dad_shut_slot_index;

    /* obj of fac */
    SDev__BcTest bc_test = S_DEV__BC_TEST__INIT;
    SDev__LbTest lb_test = S_DEV__LB_TEST__INIT;
    SBsp__SfpIrqEvent sfp_intr = S_BSP__SFP_IRQ_EVENT__INIT;
    SBsp__PhyIrqEvent phy_intr = S_BSP__PHY_IRQ_EVENT__INIT;

    SDev__Ifindex if_index = S_DEV__IFINDEX__INIT;
    SDev__PrbsExecute prbs_op = S_DEV__PRBS_EXECUTE__INIT;
    SDev__PrbsResult prbs_get_res = S_DEV__PRBS_RESULT__INIT;
    prbs_op.index = &if_index;
    prbs_get_res.index = &if_index;

    /* 模块信息相关对象初始化 */
    SIntf__TaskFiber trans_info = S_INTF__TASK_FIBER__INIT;
    trans_info.index = &keyindex;

    size_t field_array[8] = {6, 7, 8, 9, 10, 11, 12, 13};
    vsd_unit_thread_info_t *unit_info_attr_arr[8]={unit_t_info, unit_t_info, unit_t_info, unit_t_info, unit_t_info, unit_t_info, unit_t_info, unit_t_info};
    size_t bc_array[2] = {5, 6};
    vsd_unit_thread_info_t *unit_info_bc_arr[2]={unit_t_info, unit_t_info};
    size_t lb_array[2] = {5, 6};
    vsd_unit_thread_info_t *unit_info_lb_arr[2]={unit_t_info, unit_t_info};
    size_t prbs_op_array[1] = {6};
    vsd_unit_thread_info_t *unit_info_prbs_op_arr[1]={unit_t_info};
    size_t prbs_get_res_array[1] = {6};
    vsd_unit_thread_info_t *unit_info_prbs_get_res_arr[1]={unit_t_info};
printf("%s %d.\n", __FUNCTION__, __LINE__); 
    int count = 8;
    int ret;
    /* 订阅cfg attr 8个域 */
    ret = rg_mom_subscribe_field(global, RG_MOM_ASIC_DB, (const rg_obj *)&cfg_attr, 0, field_array, ptd_mom_attr_set_cb_arr, (void **)unit_info_attr_arr, count);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field fail\n");
    }
printf("%s %d.\n", __FUNCTION__, __LINE__); 
    /* reg vsl-intf change callback */
    ret = intf_frm_serv_ptchg_reg(global, ptd_port_event_args, PTD_ARRAY_SIZE(ptd_port_event_args));
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD intf_frm_serv_ptchg_reg fail[%d]", ret);
    }

    /* 订阅 clr mib */
    ret = rg_mom_subscribe(global, RG_MOM_ASIC_DB, (const rg_obj *)&mib_clr, 0, ptd_mom_clr_mib_msg_handle, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field fail\n");
    }

    count = 2;
    /* 订阅 生测的key 广播测试 */
    ret = rg_mom_subscribe_field(global, RG_MOM_ASIC_DB, (const rg_obj *)&bc_test, 0, bc_array, ptd_mom_attr_bc_cb_arr, (void **)unit_info_bc_arr, count);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field fail\n");
    }
    count = 2;
    /******订阅生测的key 设置回环 ******/
    ret = rg_mom_subscribe_field(global, RG_MOM_ASIC_DB, (const rg_obj *)&lb_test, 0, lb_array, ptd_mom_attr_lb_cb_arr, (void **)unit_info_lb_arr, count);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field fail\n");
    }

    /* subscribe the key for prbs operations */
    count = 1;
    ret = rg_mom_subscribe_field(global, RG_MOM_ASIC_DB, (const rg_obj *)&prbs_op, 0, prbs_op_array, ptd_mom_prbs_op_cb_arr,(void **)unit_info_prbs_op_arr, count);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field fail\n");
    }

    /* subscribe the key for request prbs result */
    count = 1;
    ret = rg_mom_subscribe_field(global, RG_MOM_ASIC_DB, (const rg_obj *)&prbs_get_res, 0, prbs_get_res_array, ptd_mom_prbs_get_res_cb_arr,(void **)unit_info_prbs_get_res_arr, count);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field fail\n");
    }

    /* 订阅 dfd中断的key */
    ret = rg_mom_subscribe(global, RG_MOM_LOCAL_DB, (const rg_obj *)&sfp_intr, 0, ptd_mom_sfp_irq_msg_handle, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field dfd_irq fail\n");
    }

    /* 订阅 dfd中phy中断的key */
    if (ssa_port_cfg_get_copper_fastlink_type() == TYPE_PHY) {
        ret = rg_mom_subscribe(global, RG_MOM_LOCAL_DB, (const rg_obj *)&phy_intr, 0, ptd_mom_phy_irq_msg_handle, unit_t_info);
        if (ret) {
            SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field dfd_irq fail\n");
        }
    }

    /* 订阅 模块信息相关的key */
    ret = rg_mom_subscribe(global, RG_MOM_ASIC_DB, (const rg_obj *)&trans_info, 0, ptd_mom_trans_info_get_handle, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field tans_info fail\n");
    }

    /* 订阅 loopback相关的key */
    ret = rg_mom_subscribe(global, RG_MOM_ASIC_DB, (const rg_obj *)&loopback, 0, ptd_mom_loopback_set_handle, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field tans_info fail\n");
    }

    /* 订阅 intf-port-end相关的key */
    ret = rg_mom_subscribe_field(global, RG_MOM_ASIC_DB, (const rg_obj *)&intf_port_end, 0, intf_port_end_array,
        ptd_mom_intf_port_end_arr, (void **)intf_port_end_arr_info, 1);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field intf_port_end fail\n");
    }

    /* 订阅 system-enable相关的key */
    ret = rg_mom_subscribe(global, RG_MOM_ASIC_DB, (const rg_obj *)&unit_enable_key, 0, ptd_mom_system_enable_handler, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field system-enable fail\n");
    }

    /* 订阅 system-enable相关的key */
    ret = rg_mom_subscribe(global, RG_MOM_IBC_DB, (const rg_obj *)&dad_shut_exception, 0, ptd_mom_dad_shut_exception_handler, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe_field system-enable fail\n");
    }

    /* 订阅 clr mib_ex */
    ret = rg_mom_subscribe(global, RG_MOM_ASIC_DB, (const rg_obj *)&mib_ex_clr, 0, ptd_mom_clr_mib_ex_msg_handle, unit_t_info);
    if (ret) {
        SSA_PTD_ZLOG_ERROR("PTD mom rg_mom_subscribe mib_ex_clr fail\n");
    }

    //mib统计 写数据库
    ptd_mom_mib_thread(global, unit, unit_t_info);

    return 0;
}

void ptd_dump_enable_flag(void)
{
    int i;

    SSA_PTD_ZLOG_FATAL("dump g_ptd_enable_flag:\n");
    for (i = 0; i < MAX_LOCAL_UNIT; i++) {
        SSA_PTD_ZLOG_FATAL("g_ptd_enable_flag: unit[%d], flag[%d]\n", i, g_ptd_enable_flag[i]);
    }
}

int ssa_intf_port_end_notify_reg(rg_global_t *mom_handle)
{
    return ssa_key_module_register(KEY_MODULE_INTF_PORT);
}

