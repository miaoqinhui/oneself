/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * ptd_nps.c
 * Original Author:  pengcheng@ruijie.com.cn, 2019-3-5
 *
 * port驱动NPS400芯片小系统功能
 *
 * History 编码中
 */
#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#include "../include/ptd_type.h"
#include <libpub/rg_mom/rg_mom_sync.h>
#if 0
#include <EZapiStruct.h>
#include <EZagtRPC.h>
#include <EZagtCPMain.h>
#include <EZsocket.h>
#include <EZenv.h>
#include <EZdev.h>
#include <EZtype.h>
#include <EZrc.h>
#include <EZosIO.h>
#include <stdio.h>
#include <EZapiChannel.h>
#include <EZapiStruct.h>
#include <EZapiICU.h>
#include <EZapiStat.h>
#include <EZapiIF.h>
#include <EZapiTCAM.h>
#include <EZapiTM.h>
#include <EZosMem.h>
#include <EZkbp.h>
#include <EZkbpRC.h>
#endif
int g_ssa_port_debug = 0;                           /* 调试开关，用于打开所有的调试开关 */

static struct list_head g_link_notify_list_head[MAX_LOCAL_UNIT];
static sem_t g_link_notify_mutex[MAX_LOCAL_UNIT];

/* THESE bit offsets determine which conf goes to SDK */
#define FILTER_SDK_SPEED     0  /* is speed conf be filtered 1:filter 0:conf  */
#define FILTER_SDK_DUPLEX    1  /* is duplex conf be filtered 1:filter 0:conf  */

    /* flowctrl config */
#define FILTER_SDK_PAUSE_T   2  /* is pause_t conf be filtered 1:filter 0:conf  */
#define FILTER_SDK_PAUSE_R   3  /* is pause_r conf be filtered 1:filter 0:conf  */

    /* an ability */
#define FILTER_SDK_ADV_MASK  4  /* is adv_mask conf be filtered 1:filter 0:conf  */
#define FILTER_SDK_AN        5  /* is an conf be filtered 1:filter 0:conf  */

#define FILTER_SDK_ADMIN     6  /* is admin conf be filtered 1:filter 0:conf  */
#define FILTER_SDK_LOOPBACK  7  /* is loopback conf be filtered 1:filter 0:conf  */

#define FILTER_SDK_FEC       8  /* is fec conf be filtered 1:filter 0:conf  */

#define SSA_LINK_NOTIFY_LOCK_INIT(_m)          (sem_init(&(_m), 0, 1))
#define SSA_LINK_NOTIFY_LOCK(_m)               (sem_wait(&(_m)))
#define SSA_LINK_NOTIFY_UNLOCK(_m)             (sem_post(&(_m)))

#define BCM_PORT_DUPLEX_HALF  0
#define BCM_PORT_DUPLEX_FULL  1
#define BCM_PORT_MEDIUM_COPPER   0
#define BCM_PORT_MEDIUM_FIBER    1

extern int ptd_clear_mib(int unit, int port);
extern int ptd_mib_init(int unit);
extern int out_ssa_port_enable_sfp(void);
extern int32_t libddm_get_lport_by_unit_port(int32_t unit, int32_t port, int32_t *lport);

#if 0
typedef struct ptd_nps_port_info_s {
    EZapiCP_Version eVersion;
    EZui32 uiSide;
    EZui32 uiIFEngine;
    EZapiChannel_EthIFType eEthIFType;
    EZui32 uiIFNumber;
    EZui32 uiLogicalID; 
    EZui32 port;
} ptd_nps_port_info_t;

ptd_nps_port_info_t g_nps_port_info[] = {
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 10, 0, 0},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 11, 1, 1},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 8, 2, 2},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 9, 3, 3},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 6, 4, 4},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 7, 5, 5},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 5, 6, 6},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 4, 7, 7},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 2, 8, 8},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 3, 9, 9},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 0, 10, 10},
    {0, 0, 1, EZapiChannel_EthIFType_10GE, 1, 11, 11},
    {0, 0, 0, EZapiChannel_EthIFType_100GE, 0, 12, 12},
};
#else
typedef struct ptd_nps_port_info_s {
    uint32_t eVersion;
    uint32_t uiSide;
    uint32_t uiIFEngine;
    uint32_t eEthIFType;
    uint32_t uiIFNumber;
    uint32_t uiLogicalID; 
    uint32_t port;
} ptd_nps_port_info_t;
ptd_nps_port_info_t g_nps_port_info[] = {
    {0, 0, 1, 0, 10, 0, 0},
    {0, 0, 1, 0, 11, 1, 1},
    {0, 0, 1, 0, 8, 2, 2},
    {0, 0, 1, 0, 9, 3, 3},
    {0, 0, 1, 0, 6, 4, 4},
    {0, 0, 1, 0, 7, 5, 5},
    {0, 0, 1, 0, 5, 6, 6},
    {0, 0, 1, 0, 4, 7, 7},
    {0, 0, 1, 0, 2, 8, 8},
    {0, 0, 1, 0, 3, 9, 9},
    {0, 0, 1, 0, 0, 10, 10},
    {0, 0, 1, 0, 1, 11, 11},
    {0, 0, 0, 0, 0, 12, 12},
};
#endif
static ptd_nps_port_info_t *nps_trans_port_ssp_to_nps(unsigned int port)
{
    return &g_nps_port_info[port];
}

/****************************************************************************************************************/
ptd_ops_t  ptd_nps_ops;                          /* 架构驱动接口 */

static int ptd_flowctrl_init(int unit)
{
#if 0
    int rv, port;
    bcm_pbmp_t pbmp;

    rv = SSA_PORT_E_NONE;
    SSTEST_DBG_ERR("ptd_flowctrl_init enter\n");

    pbmp = CUST_PBMP_E_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        printf("ptd_flowctrl_init unit[%d] port[%d] start\n", unit, port);
        rv = bcm_port_pause_set(unit, port, 0, 0);
        if (rv != 0) {
                SSTEST_DBG_ERR("bcm_port_pause_set failed, unit %d , port %d rv %d\n", unit, port, rv);
                continue;
        }

        printf("ptd_flowctrl_init unit[%d] port[%d] over\n", unit, port);
        /* 开启 */
        if (ssa_port_cfg_get_pause_init()) {
            cust_ssa_port_pause_init(unit);
        }
    }

    SSTEST_DBG_ERR("init flowctrl off success unit %d rv %d!\n", unit, rv);
#else
#if 0
    int rv, port;
    bcm_pbmp_t pbmp;

    rv = SSA_PORT_E_NONE;
    SSTEST_DBG_ERR("ptd_flowctrl_init enter\n");

    pbmp = CUST_PBMP_E_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        printf("ptd_flowctrl_init unit[%d] port[%d] start\n", unit, port);
        rv = bcm_port_pause_set(unit, port, 0, 0);
        if (rv != 0) {
                SSTEST_DBG_ERR("bcm_port_pause_set failed, unit %d , port %d rv %d\n", unit, port, rv);
                continue;
        }

        printf("ptd_flowctrl_init unit[%d] port[%d] over\n", unit, port);
        /* 开启 */
        if (ssa_port_cfg_get_pause_init()) {
            cust_ssa_port_pause_init(unit);
        }
    }
    SSTEST_DBG_ERR("init flowctrl off success unit %d rv %d!\n", unit, rv);
#endif
#endif

    return 0;
}


/* 端口MTU初始化 通用 初始化 需要使用到  本文件使用到 */
static int ptd_set_mtu_def(int unit)
{
#if 0
	int lport = 1, rv, port;
    bcm_pbmp_t pbmp;

    pbmp = CUST_PBMP_E_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        rv = ptd_get_lport_from_unit_port(unit, port, &lport);
        if (rv != 0) {
            SSA_PTD_ZLOG_ERROR("get lport fail unit %d port %d\n", unit, port);
            continue;
        }
        //SSA_PORT_INTF_ERRFNC_RET(bcm_port_frame_max_set(unit, port, ssa_port_cfg_get_default_mtu() + ssa_port_cfg_get_mtu_add_len(lport)));

        //SSA_PORT_INTF_ERRFNC_RET(bcm_port_control_set(unit, port, bcmPortControlStatOversize, DEFAULT_CNT_MAX_SIZE)); //CB卡需要更换其他接口
    }

    SSTEST_DBG_ERR("mtu init success unit %d\n", unit);
#else
				/* NPS to do */
#endif

    return SSA_PORT_E_NONE;
}

static int duplex_ptm_to_ptd(int duplex)
{
    switch (duplex) {
    case S_INTF__DUPLEX_TYPE_E__HALF:
        return BCM_PORT_DUPLEX_HALF;
    case S_INTF__DUPLEX_TYPE_E__DUPLEX_AUTO:
    case S_INTF__DUPLEX_TYPE_E__FULL:
    default:
        return BCM_PORT_DUPLEX_FULL;
    }
}

static void pause_ptm_to_ptd(int pause, int *tx, int *rx)
{
    switch (pause) {
    case S_INTF__FLOWCTRL_TYPE_E__ON:
        *tx = 1;
        *rx = 1;
        break;
    /*case SS_PT__FLOWCTRL_TYPE_E__RX_ON_TX_OFF:
        *rx = 1;
        *tx = 0;
        break;
    case SS_PT__FLOWCTRL_TYPE_E__RX_OFF_TX_ON:
        *rx = 0;
        *tx = 1;
        break;*/
    case S_INTF__FLOWCTRL_TYPE_E__OFF:
    case S_INTF__FLOWCTRL_TYPE_E__FLOWCTRL_AUTO:
    default:
        *tx = 0;
        *rx = 0;
        break;
    }

    return;
}



/****************************对外封装使用服务******************************************/
extern int medium_ptd_to_ptm(int medium);
extern int nps_del_attr_cache(ptd_info_t *ptd);
extern void ptd_write_port_link_inter(ptd_info_t *ptd);

int nps_get_medium(int unit, int port, int *drv_medium)
{
#if 0
    SSA_PORT_INIT_FUNC_ENTER;
    SSA_PORT_NULL_PARAM_CHECK_RETURN(drv_medium);
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_medium_get(unit, port, (bcm_port_medium_t *)drv_medium));
    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
#else
	//目前NPS线卡只有光中
    *drv_medium = BCM_PORT_MEDIUM_FIBER;
    return SSA_PORT_E_NONE;
#endif

}

int nps_set_admin_common(ptd_info_t *ptd, int port_stat)
{
#if 0
	int rv;
    int old_stat;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PTD_ZLOG_NOTICE("set admin [%d][%d] [%d] start.", ptd->unit, ptd->port, port_stat);

    old_stat = -1;
    rv = bcm_port_enable_get(ptd->unit, ptd->port, &old_stat);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("bcm_port_enable_get[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);
         return -1;
    }
    SSA_PTD_ZLOG_NOTICE("bcm_port_enable_get [%d][%d] [%d] over.", ptd->unit, ptd->port, port_stat);

    if (old_stat == port_stat) {
        SSA_PTD_ZLOG_ERROR("old_stat[%d] is the same as new_stat[%d] unit[%d] port[%d]",
            old_stat, port_stat, ptd->unit, ptd->port);
        return 0;
    }

    rv = bcm_port_enable_set(ptd->unit, ptd->port, port_stat);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("bcm_port_enable_set[%d][%d] error, rv %d", ptd->unit, ptd->port, rv);
         return -1;
    }

    rv = out_ssa_port_open_transceiver(ptd->lport, !port_stat);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("transceiver operate error, lport 0x%x, rv %d", ptd->lport, rv);
        return -1;
    }

    SSA_PTD_ZLOG_NOTICE("set admin [%d][%d] [%d] over.", ptd->unit, ptd->port, port_stat);
#else
#if 0
    int rv;
    ptd_nps_port_info_t *port_info = NULL;
    EZui32 uiChannel;
    EZapiIF_EthMACControl   sParams;
    int old_stat;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PTD_ZLOG_NOTICE("set admin [%d][%d][%d] [%d] start.", ptd->phyid, ptd->unit, ptd->port, port_stat);

    port_info =  nps_trans_port_ssp_to_nps(ptd->port);
    if (port_info == NULL) {
         SSA_PTD_ZLOG_ERROR("nps_trans_port_ssp_to_nps[%d][%d][%d] error\n", ptd->phyid, ptd->unit, ptd->port);		
         return -1;
    }

    uiChannel = 0;
#if 0
    EZosMem_memset(&sParams, 0, sizeof(sParams));
    sParams.uiSide = port_info->uiSide;
    sParams.uiIFEngine = port_info->uiIFEngine;
    sParams.uiIFNumber = port_info->uiIFNumber;

    rv = EZapiIF_Status(uiChannel, EZapiIF_StatCmd_GetEthMACControl, &sParams);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("EZapiIF_StatCmd_GetEthMACStatus[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);		
         return -1;
    }
    old_stat = sParams.bPowerUp;

    if (old_stat == port_stat) {
        SSA_PTD_ZLOG_ERROR("old_stat[%d] is the same as new_stat[%d] phyid[%d] unit[%d] port[%d]",
            old_stat, port_stat, ptd->phyid, ptd->unit, ptd->port);
        return 0;
    }

    sParams.bPowerUp = port_stat;
    rv = EZapiIF_Config(uiChannel, EZapiIF_ConfigCmd_SetEthMACControl, &sParams);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("EZapiIF_StatCmd_SetEthMACControl[%d][%d] error, rv %d\n", ptd->phyid, ptd->unit, ptd->port, rv);		
         return -1;
    }
#endif
    rv = out_ssa_port_open_transceiver(ptd->lport, port_stat);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("transceiver operate error, lport 0x%x, rv %d", ptd->lport, rv);
        return -1;
    }

    SSA_PTD_ZLOG_NOTICE("set admin [%d][%d] [%d] over.", ptd->unit, ptd->port, port_stat);
#endif
#endif

    return 0;
}

int nps_set_admin_mac_loopback(ptd_info_t *ptd, int port_stat)
{
#if 0
	int rv;
    int linkscan_type;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PTD_ZLOG_DEBUG("set admin [%d][%d] [%d] start.", ptd->unit, ptd->port, port_stat);
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_get(ptd->unit, ptd->port, &linkscan_type));

    SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd->unit, ptd->port, BCM_LINKSCAN_MODE_NONE));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_loopback_set(ptd->unit, ptd->port, BCM_PORT_LOOPBACK_NONE));
    rv = nps_set_admin_common(ptd, port_stat);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("nps_set_admin_common[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);
        return SSA_PORT_E_RETURN;
    }

    SSA_PORT_INTF_ERRFNC_RET(bcm_port_loopback_set(ptd->unit, ptd->port, BCM_PORT_LOOPBACK_MAC));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd->unit, ptd->port, linkscan_type));
#else
				/* NPS to do */
#endif

    return SSA_PORT_E_NONE;
}

int nps_set_admin(ptd_info_t *ptd, int port_stat)
{
#if 0
    int loop_back;
    int rv;

    /* bug469891 now set admin logic becomes quite different between loopback-port and none loopback port
     * so we make it 2 api for common port and loopback port to do enable operation
     * so we need to judge loopback state first
     */
    loop_back = BCM_PORT_LOOPBACK_NONE;
    rv = bcm_port_loopback_get(ptd->unit, ptd->port, &loop_back);
    if (rv != BCM_E_NONE) {
        SSA_PTD_ZLOG_ERROR("get port loopback[%d][%d] status fail", ptd->unit, ptd->port);
        /* if loopback get fail we may want the port be shutdown,
         * so just proceed and set a common shutdown
         */
    }

    return (loop_back == BCM_PORT_LOOPBACK_MAC && port_stat == 0)
        ? nps_set_admin_mac_loopback(ptd, port_stat):nps_set_admin_common(ptd, port_stat);
#else
    int loop_back;
    int rv;
/*
    loop_back = BCM_PORT_LOOPBACK_NONE;

    return (loop_back == BCM_PORT_LOOPBACK_MAC && port_stat == 0)
        ? nps_set_admin_mac_loopback(ptd, port_stat):nps_set_admin_common(ptd, port_stat);
*/
    return nps_set_admin_common(ptd, port_stat);
#endif
}

int nps_get_admin(ptd_info_t *ptd, int *port_stat)
{
#if 0
	int rv;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(port_stat);
    SSA_PTD_ZLOG_NOTICE("get admin [%d][%d] start.", ptd->unit, ptd->port);

    rv = bcm_port_enable_get(ptd->unit, ptd->port, port_stat);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("bcm_port_enable_get[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);
         return -1;
    }
    SSA_PTD_ZLOG_NOTICE("get admin [%d][%d] [%d] over.", ptd->unit, ptd->port, *port_stat);

    return 0;
#else
#if 0
    int rv;
    ptd_nps_port_info_t *port_info = NULL;
    EZui32 uiChannel = 0;
    EZapiIF_EthMACControl sParams;
   
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(port_stat);
    SSA_PTD_ZLOG_NOTICE("get admin [%d][%d][%d] start.", ptd->phyid, ptd->unit, ptd->port);

    port_info =  nps_trans_port_ssp_to_nps(ptd->port);
    if (port_info == NULL) {
         SSA_PTD_ZLOG_ERROR("nps_trans_port_ssp_to_nps[%d][%d][%d] error\n", ptd->phyid, ptd->unit, ptd->port);		
         return -1;
    }
#if 0
    EZosMem_memset(&sParams, 0, sizeof(sParams));
    
    sParams.uiSide = port_info->uiSide;
    sParams.uiIFEngine = port_info->uiIFEngine;
    sParams.uiIFNumber = port_info->uiIFNumber;

    rv = EZapiIF_Status(uiChannel, EZapiIF_StatCmd_GetEthMACControl, &sParams);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("EZapiIF_StatCmd_GetEthMACStatus[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);		
         return -1;
    }
    *port_stat = sParams.bPowerUp;
 #endif   
    SSA_PTD_ZLOG_NOTICE("get admin [%d][%d] [%d] over.", ptd->unit, ptd->port, *port_stat);
#endif
    return 0;
#endif

}

/****************setadmin 特殊操作 芯片适配层属于特殊芯片驱动层 ********************/
int ptd_set_admin_spec(int unit, int port, int port_stat)
{
    return 0;
}
#define BCM_PORT_LINK_STATUS_UP 1
static void ptd_link_info_copy(ptd_link_notify_info_t *port_info, ptd_link_notify_info_t *info)
{
	port_info->speed = info->speed;
    port_info->pause_tx = info->pause_tx; /* COV:XMB wrong value, but has no problem for now. cause pause_tx alway equal to pause_rx */
    port_info->pause_rx = info->pause_rx;
    port_info->linkstatus = (info->linkstatus == BCM_PORT_LINK_STATUS_UP) ? 1 : 0;
    port_info->autoneg = info->autoneg;
    port_info->drv_medium = info->drv_medium;
}

static void ptd_link_notify_info_add(int unit, int port, ptd_link_notify_info_t *info, struct list_head *head)
{
    link_notify_port_info_t *body;

    body = (link_notify_port_info_t *)malloc(sizeof(link_notify_port_info_t));
    if (body == NULL) {
        SSTEST_DBG_TEST("ptd_link_notify_info_add malloc failed\n");
        return;
    }

    body->unit = unit;
    body->port = port;

    memcpy(&body->port_info, info, sizeof(ptd_link_notify_info_t));

    list_add_tail(&body->node, head);

    return;
}

/**
 * out_ssa_port_link_notify - 普通link通告处理函数
 * @unit:    芯片号
 * @port:    端口号
 * @info:    端口的信息
 *
 * return: 无
 */
void ssa_port_bcm_linkscan_callback(int unit, int port, ptd_link_notify_info_t *info)
{
    link_notify_port_info_t *body, *body_find;
    ptd_link_notify_info_t port_info;
    int found_flag;

    SSA_PTD_ZLOG_NOTICE("enter unit[%d]port[%d].", unit, port);

    memset(&port_info, 0, sizeof(ptd_link_notify_info_t));
    found_flag = 0;
    SSA_LINK_NOTIFY_LOCK(g_link_notify_mutex[unit]);
    list_for_each_entry_safe(body_find, body, &g_link_notify_list_head[unit], node) {
        if (port == body_find->port) {
            ptd_link_info_copy(&(body_find->port_info), info);
            found_flag = 1;
            break;
        }
    }

    if (found_flag == 0) {
        ptd_link_info_copy(&port_info, info);
        ptd_link_notify_info_add(unit, port, &port_info, &g_link_notify_list_head[unit]);
    }
    SSA_LINK_NOTIFY_UNLOCK(g_link_notify_mutex[unit]);

    SSA_PTD_ZLOG_NOTICE("before send unit[%d]port[%d].", unit, port);
    //发送到主线程写host数据库
    if (found_flag == 0) {
        ptd_client_socket_send(unit);
    }
    SSA_PTD_ZLOG_NOTICE("done.");

    return;
}

/* this api is for ptd_link_notify_msg_process in rg_thread  */
int ptd_link_msg_to_local_list(int unit, struct list_head *link_notify_list_head_local)
{
    link_notify_port_info_t *body, *body_del;

    if ((unit >= MAX_LOCAL_UNIT) || (unit < 0)) {  /* COV:XMB g_link_notify_mutex is a size 8 array, max index is 7 */
        SSA_PTD_ZLOG_ERROR("unit[%d] is invalid", unit);
        return SSA_PORT_E_RETURN;
    }
    SSA_PORT_NULL_PARAM_CHECK_RETURN(link_notify_list_head_local);

    /* copy the msg to local list */
    SSA_LINK_NOTIFY_LOCK(g_link_notify_mutex[unit]);
    list_for_each_entry_safe(body_del, body, &g_link_notify_list_head[unit], node) {
        ptd_link_notify_info_add(body_del->unit, body_del->port, &(body_del->port_info), link_notify_list_head_local);
        list_del(&body_del->node);
        free(body_del);
    }
    SSA_LINK_NOTIFY_UNLOCK(g_link_notify_mutex[unit]);

    return SSA_PORT_E_NONE;
}

int ptd_register_linkscan(int unit)
{
#if 0
	int rv;
    INIT_LIST_HEAD(&g_link_notify_list_head[unit]);
    SSA_LINK_NOTIFY_LOCK_INIT(g_link_notify_mutex[unit]);
     rv = bcm_linkscan_register(unit, (bcm_linkscan_handler_t)ssa_port_bcm_linkscan_callback);
     if (rv != 0) {
            printf("bcm_linkscan_register failed, rv %d, unit %d\n", rv, unit);
            fflush(stdout);
            return rv;
     }
     printf("bcm_linkscan_register success, rv %d, unit %d\n", rv, unit);
     fflush(stdout);
#else
				 /* NPS to do */
#endif

    return SSA_PORT_E_NONE;
}

/**
 * ssa_port_set_mtu - 设置端口的MTU值
 * @uint32_t phyid： 指定端口
 * @int32_t mtu：     MTU值
 *
 * return: 成功返回0，否则返回负值
 */
int nps_set_mtu(ptd_info_t *ptd, int mtu)
{
#if 0
    int  mtu_oversize;

    SSA_PORT_INIT_FUNC_ENTER;
    SSA_PTD_ZLOG_NOTICE("unit %d, port %d lport %d, mtu %d!\n", ptd->unit, ptd->port, ptd->lport, mtu);

    /* the adding of mtu_len is to adapter the SDK's adding 4 to conf mtu in mac_max_frame_set api which varies from diff chip.
     * some mac will add 4 while some will not, so use conf to control this.
     */
    mtu += ssa_port_cfg_get_mtu_add_len(ptd->lport);

    /* it is the very first instinct to conf mtu_oversize ths same as MTU
     * but there is a problem that prevent us to just make mtu_oversize = mtu.
     * sometimes bcm_port_frame_max_set will autoly add 4 to mtu while
     * bcm_port_control_set(bcmPortControlStatOversize) will not, which make mtu is not equal to mtu_oversize.
     * becaus of lacking means to control the SDK behavior,
     * just add conf-file to seperately select whether MTU or mtu_oversize will be add extra len
     */
    mtu_oversize = mtu + ssa_port_cfg_get_oversize_frm_add_len(ptd->lport);

    if (mtu == (ssa_port_cfg_get_default_mtu() + ssa_port_cfg_get_mtu_add_len(ptd->lport))) {
        /* MTU设置为默认值时，恢复Oversize packets统计水线值 */
        mtu_oversize = DEFAULT_CNT_MAX_SIZE;
    }
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d]mtu_oversize %d,  mtu %d!\n", ptd->unit, ptd->port, mtu_oversize, mtu);

    //SSA_PORT_INTF_ERRFNC_RET(bcm_port_frame_max_set(ptd->unit, ptd->port, mtu));
    //SSA_PORT_INTF_ERRFNC_RET(bcm_port_control_set(ptd->unit, ptd->port, bcmPortControlStatOversize, mtu_oversize));

    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
#else
#if 0
	/* NPS to do */
    int rv;
    ptd_nps_port_info_t *port_info = NULL;
    EZui32 uiChannel = 0;
    EZapiIF_EthMACParams sParams;
    int old_mtu;
   
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PTD_ZLOG_NOTICE("unit %d, port %d lport %d, mtu %d!\n", ptd->unit, ptd->port, ptd->lport, mtu);

    port_info =  nps_trans_port_ssp_to_nps(ptd->port);
    if (port_info == NULL) {
         SSA_PTD_ZLOG_ERROR("nps_trans_port_ssp_to_nps[%d][%d][%d] error\n", ptd->phyid, ptd->unit, ptd->port);		
         return -1;
    }

    EZosMem_memset(&sParams, 0, sizeof(sParams));
    
    sParams.uiSide = port_info->uiSide;
    sParams.uiIFEngine = port_info->uiIFEngine;
    sParams.uiIFNumber = port_info->uiIFNumber;    
    rv = EZapiIF_Status(uiChannel, EZapiIF_StatCmd_GetEthMACParams, &sParams);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("EZapiIF_StatCmd_GetEthMACStatus[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);		
         return -1;
    }

    old_mtu = sParams.uiMaxFrameLength;
    if (old_mtu == mtu) {
        SSA_PTD_ZLOG_ERROR("old_mtu[%d] is the same as mtu[%d] phyid[%d] unit[%d] port[%d]",
            old_mtu, mtu, ptd->phyid, ptd->unit, ptd->port);
        return 0;
    }

    sParams.uiMaxFrameLength = mtu;
    rv = EZapiIF_Config(uiChannel, EZapiIF_ConfigCmd_SetEthMACParams, &sParams);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR("EZapiIF_StatCmd_SetEthMACControl[%d][%d] error, rv %d\n", ptd->phyid, ptd->unit, ptd->port, rv);		
         return -1;
    }
#endif
    return SSA_PORT_E_NONE;
#endif

}


static int medium_ptm_to_ptd(int medium)
{
    switch (medium) {
    case S_INTF__MEDIUM_TYPE_E__COPPER:
    case S_INTF__MEDIUM_TYPE_E__AUTO_PRE_COPPER:                /* 电口为1 */
        return BCM_PORT_MEDIUM_COPPER;
    case S_INTF__MEDIUM_TYPE_E__FIBER:
    case S_INTF__MEDIUM_TYPE_E__AUTO_PRE_FIBER:                 /* 光口为2 */
        return BCM_PORT_MEDIUM_FIBER;
    default:
        return SSA_PORT_E_IVPARAM;
    }
}

int ptd_set_medium(unsigned int phyid, int medium)
{
#if 0
    int   unit, port, rv, lport, is_copper;
    bcm_port_medium_t used_medium, cur_medium;
    soc_phy_config_t cfg;
    int medium_type;
    ptd_info_t ptd;
    int port_stat;
    uint32_t isolate_val;
    int linkscan_type;

    SSA_PORT_INIT_FUNC_ENTER;
    SSTEST_DBG_TEST("phyid 0x%x, medium %d\n", phyid, medium);

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_phyid(phyid, &ptd);
    if (rv) {
        SSTEST_DBG_ERR("phyid 0x%x, get portinfo fail\n", phyid);
        return rv;
    }

    unit = ptd.unit;
    port = ptd.port;
    lport = ptd.lport;
    medium_type = ptd.dev_medium;

    if (medium_type == PORT_MEDIUM_FIBER || medium_type == PORT_MEDIUM_COPPER) {
        SSTEST_DBG_TEST("medium is not combo return lport %d \n", lport);
        return 0;
    }
    used_medium = medium_ptm_to_ptd(medium);
    /* 获取当前介质 */
    cur_medium = medium_ptm_to_ptd(ptd.ptm_medium);
    if ((int)used_medium == SSA_PORT_E_IVPARAM || (int)cur_medium == SSA_PORT_E_IVPARAM) {
        SSTEST_DBG_ERR("medium invalid, ss medium %d, sdk medium %d, current medium %d\n", medium, used_medium, cur_medium);
        return SSA_PORT_E_IVPARAM;
    }
    is_copper = (used_medium == BCM_PORT_MEDIUM_COPPER) ? 1 : 0;
    if (cur_medium == used_medium) {
        out_ssa_port_led_fiber_copper_set(unit, lport, is_copper);
        SSA_PTD_ZLOG_FATAL("unit[%d] port[%d] current medium[%d] same as use medium[%d]\n", unit, port, cur_medium, used_medium);
        return 0;
    }
    SSTEST_DBG_TEST("Set: ss medium type %d, sdk medium type %d\n", medium, used_medium);
    /* 转成电介质前，首先将光模块关闭 */
    if (used_medium == BCM_PORT_MEDIUM_COPPER) {
        if (out_ssa_port_open_transceiver(lport, TRANS_DISABLE) != SSA_PORT_E_NONE) {
            SSTEST_DBG_ERR("out_ssa_port_enable_sfp SFP_DISABLE error phyid 0x%x\n", phyid);
            return SSA_PORT_E_RETURN;
        }
    }
    (void)memset(&cfg, 0, sizeof(soc_phy_config_t));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_medium_config_get(unit, port, used_medium, &cfg));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_medium_config_set(unit, port, used_medium, &cfg));

    /* set fiber or copper led */
    out_ssa_port_led_fiber_copper_set(unit, lport, is_copper);
    usleep(100000);

    rv = bcm_port_enable_get(unit, port, &port_stat);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("bcm_port_enable_get failed rv %d\n", rv);
        return rv;
    }

    /* 切换成光口后且光口使能打开，打开光模块 */
    if (used_medium == BCM_PORT_MEDIUM_FIBER && port_stat) {
        if (out_ssa_port_open_transceiver(lport, TRANS_NOT_DISABLE) != SSA_PORT_E_NONE) {
            SSTEST_DBG_ERR("out_ssa_port_enable_sfp SFP_ENABLE error phyid 0x%x\n", phyid);
            return SSA_PORT_E_RETURN;
        }
    }

    /* phy542xx默认Isolate是隔离，sdk在生效电介质且enable下才会关闭隔离，若生效的是光介质使能开启下
        去切换电介质不会关掉隔离(关闭隔离在enable接口下做)，因此需要加关闭隔离操作，必须在电介质下设置 */
    isolate_val = 0;
    if (used_medium == BCM_PORT_MEDIUM_COPPER && port_stat) {
        bcm_port_phy_control_get(unit, port, BCM_PORT_PHY_CONTROL_SUPER_ISOLATE, &isolate_val);
        if (isolate_val) {
            /* 关闭隔离 */
            bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_SUPER_ISOLATE, 0);
        }
    }

    /* 1.不同的介质能力保存在不同的寄存器中，在介质切换时寄存器能力值不会更新，若再切回原来的介质，由于ptd
         会做cache过滤，导致生效的属性能力为原来寄存器中属性，与上层配置不符，因此需要清除cache。
       2.ptm保证时序，必须是先切介质，再下发属性配置。此次不关心返回值 */
    nps_del_attr_cache(&ptd);

    /* 防止 MAC 与 PHY 状态不一致,需要将端口up/down一次 */
    rv = customer_ssa_port_set_link_chg(unit, port);
    if (rv) {
        SSTEST_DBG_ERR("bcm link change failed rv %d\n", rv);
        return rv;
    }

    linkscan_type = BCM_LINKSCAN_MODE_SW;
    if (ssa_port_cfg_get_phy_scan(lport)) {
        SSA_PTD_ZLOG_FATAL("in the setting range\n");
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_get(ptd.unit, ptd.port, &linkscan_type));
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd.unit, ptd.port, BCM_LINKSCAN_MODE_NONE));
        ptd_write_port_link_inter(&ptd);
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd.unit, ptd.port, linkscan_type));
    }
    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
#else
    /*NPS线卡目前只提供光口*/
	if ((S_INTF__MEDIUM_TYPE_E__FIBER == medium) || (S_INTF__MEDIUM_TYPE_E__FIBER == medium)) {
        return SSA_PORT_E_NONE;
    } else {
        return  SSA_PORT_E_NONE;
    }
#endif
}

int ptd_cpld_enable_sfp(int unit)
{
    int rv;

    printf("[%s %d]enter!!!!\n", __FUNCTION__, __LINE__);
    rv = out_ssa_port_enable_sfp();
    if (rv) {
        printf("out_ssa_port_enable_sfp failed, rv %d\n", rv);
        return rv;
    }

    return SSA_PORT_E_NONE;
}

extern int out_ssa_port_set_qsfp_power(void);

int ptd_enable_system(int unit)
{
    int rv;
    //out_ssa_port_led_40g_data_ram_init();
   // out_ssa_port_set_dataram();
    rv = out_ssa_port_set_qsfp_power();
    if (rv) {
        printf("out_ssa_port_set_qsfp_power failed, rv %d\n", rv);
        return rv;
    }

    return rv;
}


int ptd_spec_driver_reg(ptd_spec_ops_t *spec_port_driver, int unit)
{
    if (spec_port_driver != NULL) {
        g_spec_ptd[unit] = spec_port_driver;
    }

    return 0;
}

static ptd_spec_ops_t  ptd_spec_ops = {
    .set_admin          = NULL,
    .set_attr           = NULL,
    .set_vsl            = NULL,
    .link_noitify_spec  = NULL,
};

int ptd_nps_init_port(int unit)
{
#if 0
	int  rv;

    SSA_PORT_INIT_FUNC_ENTER;

    ptd_spec_driver_reg(&ptd_spec_ops, unit);
    rv = in_ssa_port_data_init(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_data_init failed, rv %d\n", rv);
        return rv;
    }

    /* 初始化时，需要将端口的流控关闭 */
    (void)ptd_flowctrl_init(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_set_flowctrl_off failed, rv %d\n", rv);
        return rv;
    }

    /* 初始化时，需要将MTU的值设置成1526 */
    rv = ptd_set_mtu_def(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_set_mtu_def failed, rv %d\n", rv);
        return rv;
    }

    rv = ptd_set_linkscan(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_set_linkscan set failed, rv %d\n", rv);
        return rv;
    }


    rv = ptd_register_linkscan(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_register_linkscan set failed, rv %d\n", rv);
        return rv;
    }

    /* 点灯初始化 */
    rv = ptd_led_init(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_led_init, continue\n");
    }

    rv = ptd_mib_init(unit);
    if (rv != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_mib_init, continue\n");
    }

    (void)ptd_enable_system(unit);
    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
#else
    //RDA目前涉及的NPS芯片初始化流程比较特殊，与NPS数据面商定由他们进行初始化。但调用的代码是没有做检测，所以空函数；
	return SSA_PORT_E_NONE;
#endif

}

static int nps_set_attr_fiber_dsf(ptd_info_t *ptd, ptd_attr_info_t *port_att, ptd_attr_eff_info_t *ptd_attr_eff_info)
{
#if 0
	int rv;
    /* for cache conf judge */
    unit_port_conf_eff_t new_ptd_sdk_nps_attr_eff;
    unit_port_conf_eff_t *old_ptd_sdk_nps_attr_eff = NULL;
    /* bit flags of whitch SDK conf will be filtered */
    int nps_sdk_attr_conf_fbmp, all_filter_fbmp;
    ptd_sdk_fiber_conf_info_t ptd_sdk_fiber_conf_info; /* old fiber related conf from cache */
    ptd_sdk_fiber_conf_info_t ptd_sdk_fiber_conf_info_new; /* new fiber related conf from config */
    /* ENABLE cache */
    int is_enable, ret;

    SSA_PTD_ZLOG_NOTICE("\n enter!");
    SSA_PTD_ZLOG_NOTICE("nps_set_attr_dsf [%d].[%d] lport[%d] dev_medium[%d] lport_max_rate[%d] fec[%d] start!",
        ptd->unit, ptd->port, ptd->lport, ptd->dev_medium, ptd->lport_max_rate, port_att->fec);

    if (ptd_attr_eff_info == NULL) {
        SSA_PTD_ZLOG_ERROR("ptd_attr_eff_info null unit %d port %d", ptd->unit, ptd->port);
        /* nothing has been done here, surely nothing goes to cache */
        return SSA_PORT_E_RETURN;
    }

    /* malloc new_ptd_sdk_nps_attr_eff. in anycase this cache will goto list  */
    memset(&new_ptd_sdk_nps_attr_eff, 0, sizeof(unit_port_conf_eff_t));
    /* init cache val as -1, incase some conf is really 0 */
    nps_init_new_sdk_conf_cache(&new_ptd_sdk_nps_attr_eff);

    /* get the new SDK conf from PTM conf */
    new_ptd_sdk_nps_attr_eff.unit = ptd->unit;
    new_ptd_sdk_nps_attr_eff.port = ptd->port;

    /* here we update fec cache only for fiber */
    new_ptd_sdk_nps_attr_eff.fec = port_att->fec;
    SSA_PTD_ZLOG_NOTICE("unit[%d]port[%d] port_att->fec[%d] new-fec[%d]", ptd->unit, ptd->port, port_att->fec, new_ptd_sdk_nps_attr_eff.fec);
    rv = in_ptd_get_attr_sdk_conf(ptd->lport, ptd->unit, ptd->port, ptd->lport_max_rate, port_att, &new_ptd_sdk_nps_attr_eff);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("set port dsf fail unit %d port %d", ptd->unit, ptd->port);
        /* nothing has been done here, surely nothing goes to cache */
        return SSA_PORT_E_RETURN;
    }
    /* here directly get fec config no auto version */
    if (port_att->fec == S_INTF__FEC_MODE_E__FEC_MODE_AUTO) {
        /* now we define AUTO as RS cl91 */
        new_ptd_sdk_nps_attr_eff.fec = S_INTF__FEC_MODE_E__FEC_MODE_RS;
    }
    SSA_PTD_ZLOG_FATAL("unit[%d]port[%d] port_att->fec[%d] new-fec[%d]", ptd->unit, ptd->port, port_att->fec, new_ptd_sdk_nps_attr_eff.fec);

    /* here we get the conf really going into SDK in ptd_sdk_nps_attr_eff
     * now we must find the sdk_conf in cache to determine whether to conf or not
     */
    /* first we find if this unit-port-conf is in cache
     */
    old_ptd_sdk_nps_attr_eff = (unit_port_conf_eff_t *)ptd_nps_dnx_info_cache_find_from_unit_port(&nps_conf_eff_cache_head[ptd->unit], ptd->port);
    /* now just compare the old and new ptd_sdk_nps_attr_eff
     * note that old_ptd_sdk_nps_attr_eff could be NULL.
     * but this is legal for nps_attr_sdk_conf_filter
     * NULL means that this unit-port is not cached and all conf will goto SDK
     * if not NULL means that this unit-port is cached
     * all conf must be compared with the new one
     */
    nps_sdk_attr_conf_fbmp = nps_attr_sdk_conf_filter(old_ptd_sdk_nps_attr_eff, &new_ptd_sdk_nps_attr_eff);
    SSA_PTD_ZLOG_NOTICE("unit[%d]port[%d] conf is filtered 0x%x", ptd->unit, ptd->port, nps_sdk_attr_conf_fbmp);

    /* for fec is only for fiber so we filter here seperately
     * here we first see if FEC is unknown, if is unknown means
     * 1. we dont need to set fec
     * 2. we dont want to update cache
     * so if the fec is unknown, we just update the new-cache with old value
     * to ensure FEC will not be set later and the cache update wont change the old value
     */
    if (old_ptd_sdk_nps_attr_eff != NULL) {
        if (new_ptd_sdk_nps_attr_eff.fec == S_INTF__FEC_MODE_E__FEC_MODE_UNKNOWN) {
            /* if we did have some old conf and the new-conf is fec_unknown
             * we just keep the old conf and not conf this time
             */
            new_ptd_sdk_nps_attr_eff.fec = old_ptd_sdk_nps_attr_eff->fec;
            SSA_PTD_ZLOG_NOTICE("FEC UNKNOWN sdk_fec_old[%d] sdk_fec_new[%d]",
                old_ptd_sdk_nps_attr_eff->fec, new_ptd_sdk_nps_attr_eff.fec);
        }
        /* with old-conf exists, we must compare to decide whether to conf */
        if (new_ptd_sdk_nps_attr_eff.fec == old_ptd_sdk_nps_attr_eff->fec) {
            nps_sdk_attr_conf_fbmp = PTD_BIT_SET(nps_sdk_attr_conf_fbmp, FILTER_SDK_FEC);
        }
    } else {
        if (new_ptd_sdk_nps_attr_eff.fec == S_INTF__FEC_MODE_E__FEC_MODE_UNKNOWN) {
            /* if we dont have old conf and new-conf is fec_unknown
             * just make sure the new-conf is init-val and dont conf this time
             */
            nps_sdk_attr_conf_fbmp = PTD_BIT_SET(nps_sdk_attr_conf_fbmp, FILTER_SDK_FEC);
        }
    }
    SSA_PTD_ZLOG_NOTICE("nps_sdk_attr_conf_fbmp[0x%x] after fec", nps_sdk_attr_conf_fbmp);

    /* now we want to disable the port before conf
     * NOTE THAT ONLY IF WE REALLY HAVE SOMETHING TO CONF, CAN WE SHUT THE PORT
     */
    all_filter_fbmp = ((1 << FILTER_SDK_SPEED) | (1 << FILTER_SDK_DUPLEX) |
                       (1 << FILTER_SDK_PAUSE_T) | (1 << FILTER_SDK_PAUSE_R) |
                       (1 << FILTER_SDK_ADV_MASK) | (1 << FILTER_SDK_AN) | (1 << FILTER_SDK_FEC));

    /* bugid:512415 For chip BCM56770/56771, while we change the speed of ports, the Tx_pause
       and Rx_pause will be open automatically, so when we set speed without the flow control,
       meanwhile the old flowctrl configuration is off, we should not filter the flowtcrl configuration */
    if (ssa_port_cfg_get_speed_change_flow_ctrl()) {
        if ((old_ptd_sdk_nps_attr_eff == NULL) || ((old_ptd_sdk_nps_attr_eff->sdk_pause_t == 0)
                && (old_ptd_sdk_nps_attr_eff->sdk_pause_r == 0))) {
            nps_sdk_attr_conf_fbmp &= ~(1 << FILTER_SDK_PAUSE_T);
            nps_sdk_attr_conf_fbmp &= ~(1 << FILTER_SDK_PAUSE_R);
            SSA_PTD_ZLOG_NOTICE("Defined speed_change_flow_ctrl, no filter flowctrl, fbmp[0x%x]", nps_sdk_attr_conf_fbmp);
        }
    }

    SSA_PTD_ZLOG_NOTICE("unit[%d]port[%d] all_filter_fbmp[0x%x]", ptd->unit, ptd->port, all_filter_fbmp);
    if (nps_sdk_attr_conf_fbmp != all_filter_fbmp) {
        /* if nps_sdk_attr_conf_fbmp is not equels to all_filter_fbmp
         * this means we have to really conf something, so just shut the port
         * and for safety, we dont care if shut is OK, we must conf SDK ANYWAY!
         * BUT WE MUST CACHE THE ORIGIN STATE OF THIS PORT before shut to determine
         * whether the port will be enabled after conf
         */
        is_enable = 0; /* default as disable */
        (void)bcm_port_enable_get(ptd->unit, ptd->port, &is_enable);
        (void)nps_set_admin(ptd, 0);
    }

    /* now we know which conf will go to SDK now do real staff */
    rv = nps_attr_sdk_fiber_conf_distribute(ptd->unit, ptd->port, nps_sdk_attr_conf_fbmp, &new_ptd_sdk_nps_attr_eff);
    if (rv != 0) {
        /* conf fail we don't know what is in effect, so nothing goes to cache also */
        SSA_PTD_ZLOG_ERROR("nps_attr_sdk_conf_distribute fail,unit[%d]port[%d] rv[%d]", ptd->unit, ptd->port, rv);
        return SSA_PORT_E_RETURN;
    }

    /* in_ssa_port_set_attr_dsf_spec must place into
     * nps_attr_sdk_conf_distribute later put here for now
     */
    in_ssa_port_set_attr_dsf_spec(ptd, port_att);

    /* get trans info */
    ptd_get_trans_info_by_lport(ptd->lport, ptd);

    if (ptd->present == 0) {
        SSA_PTD_ZLOG_NOTICE("trans no exist lport[%d] just save sp:dp:fl:an in cache\n", ptd->lport);
        /* if the trans is not present, we don't add the conf to cache
         * because when the trans plugin next time, it's better to do a
         * full conf
         * due to bug469657, this logic is about to be fixed.
         * it should be considered that a port without a trans might be up, such as a loopback port.
         * when conf comes to a loopback port, the link status would be shocked also.
         * so we about save the speed\duplex\flowctl\an in cache regardless of the present of the trans.
         * the property related to trans and port form such as firmode/iftype/etc will not be saved still
         * in this case, as when a trans has been inserted these properties should be confed also.
         */
        /* here we must notice that if the trans is absent, we must override the fec conf to init val
         * cause fec only conf when trans is present
         */
        new_ptd_sdk_nps_attr_eff.fec = S_INTF__FEC_MODE_E__FEC_MODE_UNKNOWN;
        goto update_cache;
    }

    /* here we set the old conf to ptd_sdk_fiber_conf_info, if there any
     * first we init ptd_sdk_fiber_conf_info with SDK_CONF_CACHE_INIT_INVALID_VAL
     * then we see if there is any old_ptd_sdk_nps_attr_eff, if have
     * we update ptd_sdk_fiber_conf_info with old_ptd_sdk_nps_attr_eff
     * then ptd_sdk_fiber_conf_info goes to set_func
     * set_func will return the effective conf to new_ptd_sdk_nps_attr_eff
     */
    /* below are fiber specific conf
     * first just init ptd_sdk_fiber_conf_info
     */
    nps_init_new_fiber_info(&ptd_sdk_fiber_conf_info);
    if (old_ptd_sdk_nps_attr_eff != NULL) {
        /* now we must compare the fec cache */
        ptd_sdk_fiber_conf_info.fec = old_ptd_sdk_nps_attr_eff->fec;
        ptd_sdk_fiber_conf_info.firmode = old_ptd_sdk_nps_attr_eff->firmode;
        ptd_sdk_fiber_conf_info.iftype =  (new_ptd_sdk_nps_attr_eff.sdk_speed < 10000 ||
            new_ptd_sdk_nps_attr_eff.sdk_an) ? SDK_CONF_CACHE_INIT_INVALID_VAL : old_ptd_sdk_nps_attr_eff->iftype;
    }

    /* update fec info from attr-cache to fiber tmp cache
     * currently only fec has new conf
     */
    nps_init_new_fiber_info(&ptd_sdk_fiber_conf_info_new);
    ptd_sdk_fiber_conf_info_new.fec = new_ptd_sdk_nps_attr_eff.fec;

    SSA_PTD_ZLOG_NOTICE("fec_old[%d] fec_new[%d] firmode_old[%d] iftype_old[%d]",
        ptd_sdk_fiber_conf_info.fec, ptd_sdk_fiber_conf_info_new.fec, ptd_sdk_fiber_conf_info.firmode, ptd_sdk_fiber_conf_info.iftype);

    if (g_ptd && g_ptd->set_interface) {
        rv = g_ptd->set_interface(ptd, &ptd_sdk_fiber_conf_info, NULL);
        if (rv == SSA_PORT_E_NONE) {
            new_ptd_sdk_nps_attr_eff.iftype = ptd_sdk_fiber_conf_info.iftype;
        }
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] new effective iftype[%d] rv[%d]",
            new_ptd_sdk_nps_attr_eff.unit, new_ptd_sdk_nps_attr_eff.port, new_ptd_sdk_nps_attr_eff.iftype, rv);
    }

    if (g_ptd && g_ptd->set_firemode) {
        rv = g_ptd->set_firemode(ptd, &ptd_sdk_fiber_conf_info, NULL);
        if (rv == SSA_PORT_E_NONE) {
            new_ptd_sdk_nps_attr_eff.firmode= ptd_sdk_fiber_conf_info.firmode;
        }
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] effective firmode_old[%d] rv[%d]",
            new_ptd_sdk_nps_attr_eff.unit, new_ptd_sdk_nps_attr_eff.port, new_ptd_sdk_nps_attr_eff.firmode, rv);
    }

    if (g_ptd && g_ptd->set_preemphasis) {
        rv = g_ptd->set_preemphasis(ptd, &ptd_sdk_fiber_conf_info, NULL);
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] set_preemphasis rval[%d]",
            new_ptd_sdk_nps_attr_eff.unit, new_ptd_sdk_nps_attr_eff.port, rv);
    }

    if (!PTD_BIT_IS_SET(nps_sdk_attr_conf_fbmp, FILTER_SDK_FEC)) {
        /* FEC is now in attr set bitmap
         * this bitmap filter has already filtered the FEC_unknown situation,
         * which means when in here fec must be a valid value and must be diff from old_val
         */
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] effective fec[%d] need set",
            new_ptd_sdk_nps_attr_eff.unit, new_ptd_sdk_nps_attr_eff.port, new_ptd_sdk_nps_attr_eff.fec);
        if (g_ptd && g_ptd->set_fec) {
            rv = g_ptd->set_fec(ptd, &ptd_sdk_fiber_conf_info, &ptd_sdk_fiber_conf_info_new);
            if (rv == SSA_PORT_E_NONE) { /* if fec update success update cache with new fec configed, otherwise restore the cache to old value */
                new_ptd_sdk_nps_attr_eff.fec = ptd_sdk_fiber_conf_info_new.fec;
            } else {
                new_ptd_sdk_nps_attr_eff.fec = ptd_sdk_fiber_conf_info.fec;
            }
            SSA_PTD_ZLOG_FATAL("unit[%d] port[%d] effective fec[%d] rv[%d]",
                new_ptd_sdk_nps_attr_eff.unit, new_ptd_sdk_nps_attr_eff.port, new_ptd_sdk_nps_attr_eff.fec, rv);
        }
    }

update_cache:
    /* when getting here we are to update the SDK-conf to cache */
    /* notify to mom-layer after cache is certain
     * currently only fec need to be notified
     */
    ptd_attr_eff_info->fec = new_ptd_sdk_nps_attr_eff.fec;
    SSA_PTD_ZLOG_NOTICE("new_ptd_sdk_nps_attr_eff.fec[%d]", ptd_attr_eff_info->fec);
    if (old_ptd_sdk_nps_attr_eff != NULL) {
        /* if old_ptd_sdk_nps_attr_eff is not NULL, we just copy the new cache-info into old one */
        memcpy(old_ptd_sdk_nps_attr_eff, &new_ptd_sdk_nps_attr_eff, sizeof(unit_port_conf_eff_t));
        SSA_PTD_ZLOG_NOTICE("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] update OK", ptd->unit, ptd->port);
    } else {
        /* getting here means no old-node find we must alloc a new node so just ADD
         * only machine start up the first time will come here
         */
        rv = ptd_nps_dnx_info_cache_add_from_eff_conf(&nps_conf_eff_cache_head[ptd->unit], ptd->port, &new_ptd_sdk_nps_attr_eff, sizeof(unit_port_conf_eff_t));
        if (rv != 0) {
            /* just print to notify, DNOT return, cause nothing we can do */
            SSA_PTD_ZLOG_ERROR("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] add FAIL", ptd->unit, ptd->port);
        }
        SSA_PTD_ZLOG_NOTICE("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] add OK", ptd->unit, ptd->port);
    }
    SSA_PTD_ZLOG_FATAL("nps_set_attr_dsf [%d].[%d] lport[%d] medium[%d] port_type[%d] over!",
        ptd->unit, ptd->port, ptd->lport, ptd->ptm_medium, ptd->lport_max_rate);

    /* when all is done we just SEE if we need to ENABLE this port  */
    if (nps_sdk_attr_conf_fbmp != all_filter_fbmp) {
        /* if nps_sdk_attr_conf_fbmp is not equels to all_filter_fbmp
         * this means we formerly disable this port for conf, so we
         * depend on is_enable to decide whether we enable this port again
         */
        ret = nps_set_admin(ptd, is_enable);
        if (ret != 0) {
            /* if this enable fail we want to know */
            SSA_PTD_ZLOG_FATAL("nps_set_admin unit[%d]port[%d] stat[%d] FAIL", ptd->unit, ptd->port, is_enable);
        }
    }

    SSA_PTD_ZLOG_FATAL("leaver!\n");
#else
			/* NPS to do */
#endif

    return SSA_PORT_E_NONE;
}

static int nps_set_attr_copper_dsf(ptd_info_t *ptd, ptd_attr_info_t *port_att, ptd_attr_eff_info_t *ptd_attr_eff_info)
{
#if 0
	int rv;
    /* for cache conf judge */
    unit_port_conf_eff_t new_ptd_sdk_nps_attr_eff;
    unit_port_conf_eff_t *old_ptd_sdk_nps_attr_eff = NULL;
    /* bit flags of whitch SDK conf will be filtered */
    int nps_sdk_attr_conf_fbmp;

    SSA_PTD_ZLOG_NOTICE("\n enter!");
    SSA_PTD_ZLOG_NOTICE("nps_set_attr_dsf [%d].[%d] lport[%d] dev_medium[%d] lport_max_rate[%d] start!",
        ptd->unit, ptd->port, ptd->lport, ptd->dev_medium, ptd->lport_max_rate);

    /* malloc new_ptd_sdk_nps_attr_eff. in anycase this cache will goto list  */
    memset(&new_ptd_sdk_nps_attr_eff, 0, sizeof(unit_port_conf_eff_t));
    /* init cache val as -1, incase some conf is really 0 */
    nps_init_new_sdk_conf_cache(&new_ptd_sdk_nps_attr_eff);

    /* get the new SDK conf from PTM conf */
    new_ptd_sdk_nps_attr_eff.unit = ptd->unit;
    new_ptd_sdk_nps_attr_eff.port = ptd->port;
    rv = in_ptd_get_attr_sdk_conf(ptd->lport, ptd->unit, ptd->port, ptd->lport_max_rate, port_att, &new_ptd_sdk_nps_attr_eff);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("set port dsf fail unit %d port %d", ptd->unit, ptd->port);
        /* nothing has been done here, surely nothing goes to cache */
        return SSA_PORT_E_RETURN;
    }

    /* here we get the conf really going into SDK in ptd_sdk_nps_attr_eff
     * now we must find the sdk_conf in cache to determine whether to conf or not
     */
    /* first we find if this unit-port-conf is in cache
     */
    old_ptd_sdk_nps_attr_eff = (unit_port_conf_eff_t *)ptd_nps_dnx_info_cache_find_from_unit_port(&nps_conf_eff_cache_head[ptd->unit], ptd->port);
    /* now just compare the old and new ptd_sdk_nps_attr_eff
     * note that old_ptd_sdk_nps_attr_eff could be NULL.
     * but this is legal for nps_attr_sdk_conf_filter
     * NULL means that this unit-port is not cached and all conf will goto SDK
     * if not NULL means that this unit-port is cached
     * all conf must be compared with the new one
     */
    nps_sdk_attr_conf_fbmp = nps_attr_sdk_conf_filter(old_ptd_sdk_nps_attr_eff, &new_ptd_sdk_nps_attr_eff);
    SSA_PTD_ZLOG_NOTICE("unit[%d]port[%d] conf is filtered 0x%x", ptd->unit, ptd->port, nps_sdk_attr_conf_fbmp);
    /* now we know which conf will go to SDK now do real staff */
    rv = nps_attr_sdk_copper_conf_distribute(ptd->unit, ptd->port, nps_sdk_attr_conf_fbmp, &new_ptd_sdk_nps_attr_eff);
    if (rv != 0) {
        /* conf fail we don't know what is in effect, so nothing goes to cache also */
        SSA_PTD_ZLOG_ERROR("nps_attr_sdk_conf_distribute fail,unit[%d]port[%d] rv[%d]", ptd->unit, ptd->port, rv);
        return SSA_PORT_E_RETURN;
    }

    /* in_ssa_port_set_attr_dsf_spec must place into
     * nps_attr_sdk_conf_distribute later put here for now
     */
    in_ssa_port_set_attr_dsf_spec(ptd, port_att);

    /* when getting here we are to update the SDK-conf to cache */
    if (old_ptd_sdk_nps_attr_eff != NULL) {
        /* if old_ptd_sdk_nps_attr_eff is not NULL, we just copy the new cache-info into old one */
        memcpy(old_ptd_sdk_nps_attr_eff, &new_ptd_sdk_nps_attr_eff, sizeof(unit_port_conf_eff_t));
        SSA_PTD_ZLOG_ERROR("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] update OK", ptd->unit, ptd->port);
    } else {
        /* getting here means no old-node find we must alloc a new node so just ADD
         * only machine start up the first time will come here
         */
        rv = ptd_nps_dnx_info_cache_add_from_eff_conf(&nps_conf_eff_cache_head[ptd->unit], ptd->port, &new_ptd_sdk_nps_attr_eff, sizeof(unit_port_conf_eff_t));
        if (rv != 0) {
            /* just print to notify, DNOT return, cause nothing we can do */
            SSA_PTD_ZLOG_ERROR("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] add FAIL", ptd->unit, ptd->port);
        }
        SSA_PTD_ZLOG_NOTICE("bcm_conf_eff_cache_update_from_eff_conf unit[%d]port[%d] add OK", ptd->unit, ptd->port);
    }

    SSA_PTD_ZLOG_NOTICE("nps_set_attr_dsf [%d].[%d] lport[%d] medium[%d] port_type[%d] over!",
        ptd->unit, ptd->port, ptd->lport, ptd->ptm_medium, ptd->lport_max_rate);

    SSA_PTD_ZLOG_NOTICE("leaver!\n");
#else
			/* NPS to do */
#endif

    return SSA_PORT_E_NONE;
}

/* considering of copper-port and fiber-port is different in many ways of conf,
 * so we just seperate the conf logic to two api
 */
int nps_set_attr_dsf(ptd_info_t *ptd, ptd_attr_info_t *port_att, ptd_attr_eff_info_t *ptd_attr_eff_info)
{
#if 0
    int rv;
    
    rv = SSA_PORT_E_NONE;        
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] lport[%d] ptm_medium[%d]",ptd->unit, ptd->port, ptd->lport, ptd->ptm_medium);
    if(ptd->ptm_medium != S_INTF__MEDIUM_TYPE_E__FIBER) {
        SSA_PTD_ZLOG_NOTICE("not fiber lport %d\n", ptd->lport);
        rv = xgs_set_attr_copper_dsf(ptd, port_att, ptd_attr_eff_info);
    } else {
        SSA_PTD_ZLOG_NOTICE("fiber lport %d\n", ptd->lport);
        rv = xgs_set_attr_fiber_dsf(ptd, port_att, ptd_attr_eff_info);
    }

    if (port_att->an && cust_soc_is_trident2plus(ptd->unit)) {
        char buf[128] = {0};

        sprintf(buf, "phy %d AN_X4_ENSr CL37_SGMII_ENABLE=0;phy %d AN_X4_ENSr CL37_AN_RESTART=1;sleep 0 300;phy %d AN_X4_ENSr CL37_AN_RESTART=0", 
            ptd->port, ptd->port, ptd->port);
        /* bugid 494634 for GT */
        SSA_PTD_ZLOG_NOTICE("[unit %d][port:%d] to open GT\n", ptd->unit, ptd->port);

        sh_process_command(ptd->unit, buf);
    }
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] lport[%d] ptm_medium[%d] rv[%d]",ptd->unit, ptd->port, ptd->lport, ptd->ptm_medium, rv);

    return rv;
#else
		/* NPS to do */
#endif

}

/* when trans is pulled out, this api will do some post config
 * 1. restore the node-port cache_info to default
 * 2. some post config for SDK fiber setings like firmode iftype etc.
 */
int nps_del_attr_cache(ptd_info_t *ptd)
{
#if 0
    unit_port_conf_eff_t *cur_ptd_sdk_nps_attr_eff = NULL;

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], attr_cache set to default start", ptd->unit, ptd->port);

    cur_ptd_sdk_nps_attr_eff = (unit_port_conf_eff_t *)ptd_nps_dnx_info_cache_find_from_unit_port(&nps_conf_eff_cache_head[ptd->unit], ptd->port);
    if (cur_ptd_sdk_nps_attr_eff == NULL) {
        /* NULL means no cache find do nothing, but not normal */
        SSA_PTD_ZLOG_WARN("unit[%d] port[%d], no cache find", ptd->unit, ptd->port);
        return SSA_PORT_E_IVPARAM;
    }

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], attr_cache found", ptd->unit, ptd->port);
    /* node found restore it to default settings */

    nps_init_new_sdk_conf_cache(cur_ptd_sdk_nps_attr_eff);
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], attr_cache set to default over", ptd->unit, ptd->port);

    /* then some post config for the fiber related to do... */

    return SSA_PORT_E_NONE;
#else
		/* NPS to do */
#endif

}

int nps_set_loopback(ptd_info_t *ptd, int lb)
{
#if 0
	int loop;
    int old_loop;
    int linkscan_type;

    SSA_PORT_INIT_FUNC_ENTER;
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], macloopback %d\n", ptd->unit, ptd->port, lb);


    if (ssa_port_cfg_get_lb_type() == TYPE_PHYLB_RE_MACLB) {
        loop = lb ? BCM_PORT_LOOPBACK_PHY : BCM_PORT_LOOPBACK_NONE;
    } else {
        loop = lb ? BCM_PORT_LOOPBACK_MAC : BCM_PORT_LOOPBACK_NONE;
    }

    old_loop = BCM_PORT_LOOPBACK_NONE;
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_loopback_get(ptd->unit, ptd->port, &old_loop));
    if (loop == old_loop) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], loopback[%d] the same as loopback_pre[%d] skip", ptd->unit, ptd->port, loop, old_loop);
        return SSA_PORT_E_NONE;
    }

    SSA_PORT_INTF_ERRFNC_RET(bcm_port_loopback_set(ptd->unit, ptd->port, loop));

    linkscan_type = BCM_LINKSCAN_MODE_SW;
    if (ssa_port_cfg_get_phy_scan(ptd->lport)) {
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_get(ptd->unit, ptd->port, &linkscan_type));
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd->unit, ptd->port, BCM_LINKSCAN_MODE_NONE));
        ptd_write_port_link_inter(ptd);
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_linkscan_set(ptd->unit, ptd->port, linkscan_type));
    }

    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
#else
			/* NPS to do */
#endif

}

int nps_get_loopback(ptd_info_t *ptd, int *loop)
{
#if 0
	SSA_PORT_INIT_FUNC_ENTER;
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(loop);

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d], macloopback get\n", ptd->unit, ptd->port);

    SSA_PORT_INTF_ERRFNC_RET(bcm_port_loopback_get(ptd->unit, ptd->port, loop));

    SSA_PORT_INIT_FUNC_LEAVER;

    return SSA_PORT_E_NONE;
#else
			/* NPS to do */
#endif

}

int ptd_get_state(int unit, int port, ptd_attr_info_t *port_att)
{
#if 0
	int speed, duplex, autoneg, up, medium;

    SSA_PORT_INTF_ERRFNC_RET(bcm_port_speed_get(unit, port, &speed));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_autoneg_get(unit, port, &autoneg));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_duplex_get(unit, port, &duplex));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_link_status_get(unit, port, &up));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_medium_get(unit, port, (bcm_port_medium_t *)&medium));

    port_att->speed = speed;
    port_att->an =autoneg;
    port_att->duplex =duplex;
    port_att->link = up;
    port_att->medium = medium;
    port_att->flow = 0;

    return 0;
#else
    int speed, duplex, autoneg, up, medium;

    speed = 10000;
    autoneg = 1;
    duplex = BCM_PORT_DUPLEX_FULL;
    up = BCM_PORT_LINK_STATUS_UP;
    medium = BCM_PORT_MEDIUM_FIBER;

    port_att->speed = speed;
    port_att->an =autoneg;
    port_att->duplex =duplex;
    port_att->link = up;
    port_att->medium = medium;
    port_att->flow = 0;

    return 0;
#endif

}

/* this func will change when upper layer changes
 * must return a value when fail return a unknow-medium-type
 */
static int nps_drv_medium_to_ptm(int drv_medium)
{
    switch (drv_medium) {
    case BCM_PORT_MEDIUM_COPPER:
        return S_INTF__MEDIUM_TYPE_E__COPPER;
    case BCM_PORT_MEDIUM_FIBER:
        return S_INTF__MEDIUM_TYPE_E__FIBER;
    default:
        return S_INTF__MEDIUM_TYPE_E__MEDIUM_UNKNOWN;
    }
}

ptd_ops_t  ptd_nps_ops = {
    .set_admin            = nps_set_admin,
    .get_admin            = nps_get_admin,
    .set_attr             = NULL, //nps_set_attr_dsf,
    .del_attr             = NULL, //nps_del_attr_cache,
    .set_mtu              = nps_set_mtu,
    .set_medium           = NULL, //ptd_set_medium,  NPS线卡目前只提供光口
    .set_loopback         = NULL, //nps_set_loopback,
    .get_loopback         = NULL, //nps_get_loopback,
    .set_vsl              = NULL,  //xgs_set_vsl，暂不涉及
    .clear_mib            = ptd_clear_mib,
    .clear_mib_ex         = ptd_clear_mib_ex,
    .get_mib              = NULL,
    .get_medium           = nps_get_medium, //获取medium属性
    .set_interface        = ptd_set_interface,
    .set_firemode         = NULL, //ptd_set_firmode,   目前只有10G模式
    .set_preemphasis      = NULL, //ptd_set_preemphasis,   目前只有10G模式
    .set_fec              = NULL, //ptd_set_fec,   目前只有10G模式
    .init_port            = ptd_nps_init_port, //基于UNIT的初始化，RDA目前涉及的NPS芯片初始化流程比较特殊，与NPS数据面商定由他们进行初始化。
    .get_attr             = ptd_get_state,//获取speed,duple,au,up,medium属性
    .drv_medium_to_ptm    = nps_drv_medium_to_ptm,//BCM的MEDIUM转换成SSP medium，纯软件
};

ptd_arch_t  ptd_nps_driver = {
.type = PTD_NPS,
.ptd_ops = &ptd_nps_ops,
};

/* below are only for fac */
/* 获取fcs报文个数 */
int ptd_fac_get_fcs_count(int unit, int port, uint64_t *fcs_count)
{
#if 0
	int rv;

    rv = bcm_stat_get(unit, port, snmpDot3StatsFCSErrors, fcs_count);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_stat_get fail unit=%d, port=%d\n", unit, port);
        return PORT_FAC_ERROR;
    }
#else
				/* NPS to do */
#endif

    return PORT_FAC_NONE;
}

/* 开始广播测试 */
int ptd_fac_begin_bc_test(int unit)
{
#if 0
	int rv;
    int port;
    bcm_pbmp_t pbmp;


    pbmp = CUST_PBMP_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        /* 清除报文统计 */
        rv = bcm_stat_clear(unit, port);
        if (rv != 0) {
            return PORT_FAC_ERROR;
        }
    }
#else
				/* NPS to do */
#endif

    return PORT_FAC_NONE;
}


/* 开始回环测试 */
int ptd_fac_begin_lb_test(int unit)
{
#if 0
	int rv, port;
    bcm_pbmp_t pbmp;
    bcm_port_info_t info;

    bcm_port_info_t_init(&info);
    info.enable = 1;
    info.action_mask |= BCM_PORT_ATTR_ENABLE_MASK;
    info.loopback = BCM_PORT_LOOPBACK_PHY;
    info.action_mask |= BCM_PORT_ATTR_LOOPBACK_MASK;

    pbmp = CUST_PBMP_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        rv = bcm_port_selective_set(unit, port, &info);
        if (rv != 0) {
            return PORT_FAC_ERROR;
        }
    }
    SSA_PTD_ZLOG_NOTICE("lb test begin\n");
#else
				/* NPS to do */
#endif

    return PORT_FAC_NONE;
}

/* 停止回环测试 */
int ptd_fac_stop_lb_test(int unit)
{
#if 0
	int rv;
    int port;
    bcm_pbmp_t pbmp;

    pbmp = CUST_PBMP_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        rv = bcm_port_loopback_set(unit, port, BCM_PORT_LOOPBACK_NONE);
        if (rv != 0) {
            return PORT_FAC_ERROR;
        }
    }

    SSA_PTD_ZLOG_NOTICE("lb test stop\n");
#else
				/* NPS to do */
#endif
    return PORT_FAC_NONE;
}

static int ptd_fac_stop_bc_test_part1(int unit)
{
#if 0
	int port;
    bcm_pbmp_t pbmp;

    pbmp = CUST_PBMP_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        SSA_PORT_FAC_BCM_ERR_RET(bcm_port_discard_set(unit, port, BCM_PORT_DISCARD_ALL));
        SSA_PTD_ZLOG_NOTICE("unit %d port %d discard\n", unit, port);
    }
#else
				/* NPS to do */
#endif

    return PORT_FAC_NONE;
}

static int ptd_fac_stop_bc_test_part2(int unit)
{
#if 0
	int port;
    bcm_pbmp_t pbmp;

    pbmp = CUST_PBMP_ALL(unit);
    BCM_PBMP_REMOVE(pbmp, PBMP_CMIC(unit));
    CUST_PBMP_ITER(pbmp, port) {
        SSA_PORT_FAC_BCM_ERR_RET(bcm_port_discard_set(unit, port, BCM_PORT_DISCARD_NONE));
        SSA_PTD_ZLOG_NOTICE("unit %d port %d none\n", unit, port);
    }
#else
				/* NPS to do */
#endif

    return PORT_FAC_NONE;
}

/* 停止广播测试 */
int ptd_fac_stop_bc_test(int unit)
{
#if 0
	(void)ptd_fac_stop_bc_test_part1(unit);

    usleep(1000000);

    (void)ptd_fac_stop_bc_test_part2(unit);
#else
	return PORT_FAC_NONE; 
#endif

    return PORT_FAC_NONE;
}

/* for mom.c to judge port type */
int ptd_unit_port_is_e_port(int unit, int port)
{
#if 0
	return cust_soc_is_e_port(unit, port);
#else
	return PORT_FAC_NONE; 
#endif

}

void ptd_write_port_link_inter(ptd_info_t *ptd)
{
#if 0
	int32_t phyid;
    int32_t phy_type;

    phyid = ssa_port_cfg_get_phy_scan(ptd->lport);
    phy_type = ssa_port_cfg_get_ext_phy_type(phyid);
	// 根据路由器线卡的phy，或者交换芯片需要重新实现    ---pengcheng

    if (phy_type == EXTERNAL_PHY_542XXX) {
        if (ptd->dev_medium == PORT_MEDIUM_COPPER) {
            cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_COPPER_INTERRUPT_MASK,
                ssa_port_cfg_get_copper_interrupt_value());
            SSA_PTD_ZLOG_NOTICE("ptd_fastlink_init copper lport:%d unit %d port %d, value %x\n", ptd->lport, ptd->unit, ptd->port, ssa_port_cfg_get_copper_interrupt_value());
        } else if (ptd->dev_medium == PORT_MEDIUM_FIBER) {
            cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_FIBER_INTERRUPT_MASK,
                ssa_port_cfg_get_fiber_interrupt_value());
            SSA_PTD_ZLOG_NOTICE("ptd_fastlink_init fiber lport:%d unit %d port %d, value %x\n", ptd->lport, ptd->unit, ptd->port, ssa_port_cfg_get_fiber_interrupt_value());
        } else {
            cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_COPPER_INTERRUPT_MASK,
                ssa_port_cfg_get_copper_interrupt_value());
            cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_FIBER_INTERRUPT_MASK,
                ssa_port_cfg_get_fiber_interrupt_value());
        }
    } else if (phy_type == EXTERNAL_PHY_84844){
        SSA_PTD_ZLOG_NOTICE("unsupoort phy type 84844\n");
    } else {
        SSA_PTD_ZLOG_NOTICE("invalid phy type\n");
    }
#else
	return PORT_FAC_NONE; 
#endif

    return;
}

void ptd_read_port_link_inter(ptd_info_t *ptd, uint16_t *p_cdata, uint16_t *p_fdata)
{
    int32_t phyid;
    uint16_t copper_data;
    uint16_t fiber_data;
    int32_t phy_type;

    phyid = ssa_port_cfg_get_phy_scan(ptd->lport);
    phy_type = ssa_port_cfg_get_ext_phy_type(phyid);

    copper_data = 0;
    fiber_data = 0;
	// 根据路由器线卡的phy，或者交换芯片需要重新实现    ---pengcheng
#if 0
    if (phy_type == EXTERNAL_PHY_542XXX) {
        if (ptd->dev_medium == PORT_MEDIUM_COPPER) {
            cust_ssa_port_read_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_COPPER_INTERRUPT_STATUS, &copper_data);
            SSA_PTD_ZLOG_NOTICE("copper interuppt unit %d port %d value %x\n",ptd->unit, ptd->port, copper_data);
        } else if (ptd->dev_medium == PORT_MEDIUM_FIBER) {
            cust_ssa_port_read_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_FIBER_INTERRUPT_STATUS, &fiber_data);
            SSA_PTD_ZLOG_NOTICE("fiber interuppt unit %d port %d value %x\n",ptd->unit, ptd->port, fiber_data);
        } else {
            cust_ssa_port_read_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_COPPER_INTERRUPT_STATUS, &copper_data);
            SSA_PTD_ZLOG_NOTICE("fiber-copper interuppt unit %d port %d copper value %x\n",ptd->unit, ptd->port, copper_data);
            cust_ssa_port_read_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_FIBER_INTERRUPT_STATUS, &fiber_data);
            SSA_PTD_ZLOG_NOTICE("fiber-copper interuppt unit %d port %d fiber value %x\n",ptd->unit, ptd->port, fiber_data);
        }
    } else if (phy_type == EXTERNAL_PHY_84844){
        SSA_PTD_ZLOG_NOTICE("unsupoort phy type 84844\n");
    } else {
        SSA_PTD_ZLOG_NOTICE("invalid phy type\n");
    }
#endif
    *p_cdata = copper_data;
    *p_fdata = fiber_data;

    return;
}

void ptd_write_phy_link_inter(ptd_info_t *ptd)
{
    int32_t phyid;
    int32_t phy_type;

    phyid = ssa_port_cfg_get_phy_scan(ptd->lport);
    phy_type = ssa_port_cfg_get_ext_phy_type(phyid);

	// 根据路由器线卡的phy，或者交换芯片需要重新实现    ---pengcheng
#if 0
    if (phy_type == EXTERNAL_PHY_542XXX) {
        cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_TOP_INTERRUPT_MASK,
            PHY_BCM542XX_REG_TOP_INTERRUPT_ALL_PORT_ENABLE);
    } else if (phy_type == EXTERNAL_PHY_84844){
        SSA_PTD_ZLOG_NOTICE("unsupoort phy type 84844\n");
    } else {
        SSA_PTD_ZLOG_NOTICE("invalid phy type\n");
    }
#endif
    return;
}

/**
 * ptd_get_phy_recvstatus - 获取phy端link状态
 * @unit:  芯片号
 * @port:  端口号
 * @stat(out): 千兆电口的link状态
 *
 * return: 成功返回0，失败-1
 */
int32_t ptd_get_phy_recvstatus(ptd_info_t *ptd, int32_t *recv_stus, int32_t speed)
{
    int32_t rv;
    int32_t phyid;
    uint16_t phy_data16;
    uint16_t mode_ctrl_data;
    int32_t phy_type;

    rv = SSA_PORT_E_NONE;
    if (recv_stus == NULL) {
        SSA_PTD_ZLOG_ERROR("stat is null,in file[%s], fun[%s], line[%d]\n", __FILE__, __FUNCTION__, __LINE__);
        return SSA_PORT_E_IVPARAM;
    }

    *recv_stus = 0;
    phyid = ssa_port_cfg_get_phy_scan(ptd->lport);
    phy_type = ssa_port_cfg_get_ext_phy_type(phyid);
	// 根据路由器线卡的phy，或者交换芯片需要重新实现    ---pengcheng
#if 0
    if (phy_type == EXTERNAL_PHY_542XXX) {
        if (ptd->ptm_medium == S_INTF__MEDIUM_TYPE_E__COPPER) {
            cust_ssa_port_read_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_MODE_CONTROL, &mode_ctrl_data);
            SSA_PTD_ZLOG_NOTICE("unit %d, port %d mode_ctrl_data %x\n", ptd->unit, ptd->port, mode_ctrl_data);
            rv = soc_miim_read(ptd->unit, PORT_TO_PHY_ADDR(ptd->unit, ptd->port), MII_STAT_REG, &phy_data16);
            if (rv != SSA_PORT_E_NONE) {
                SSA_PTD_ZLOG_ERROR("failed to red miim, rv=%d", rv);
                return SSA_PORT_E_RETURN;
            }
            SSA_PTD_ZLOG_NOTICE("copper unit %d, port %d phy_data16 %x\n", ptd->unit, ptd->port, phy_data16);
        } else {
            /* 切成光口的标准寄存器 */
            cust_ssa_port_read_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_MODE_CONTROL, &mode_ctrl_data);
            cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_MODE_CONTROL, (mode_ctrl_data | 0x1));
            SSA_PTD_ZLOG_NOTICE("unit %d, port %d mode_ctrl_data %x\n", ptd->unit, ptd->port, mode_ctrl_data);
            rv = soc_miim_read(ptd->unit, PORT_TO_PHY_ADDR(ptd->unit, ptd->port), MII_STAT_REG, &phy_data16);
            if (rv != SSA_PORT_E_NONE) {
                SSA_PTD_ZLOG_ERROR("failed to red miim, rv=%d", rv);
                cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_MODE_CONTROL, mode_ctrl_data);
                return SSA_PORT_E_RETURN;
            }
            cust_ssa_port_write_phy542xx_reg(ptd->unit, ptd->port, PHY_BCM542XX_REG_MODE_CONTROL, mode_ctrl_data);
            SSA_PTD_ZLOG_NOTICE("fiber unit %d, port %d phy_data16 %x\n", ptd->unit, ptd->port, phy_data16);
        }
        *recv_stus = phy_data16 & MII_STAT_LA;
        SSA_PTD_ZLOG_NOTICE("soc_miim_read unit %d, port %d recv_stus %x\n", ptd->unit, ptd->port, *recv_stus);
    } else if (phy_type == EXTERNAL_PHY_84844) {
        SSA_PTD_ZLOG_NOTICE("unsupoort phy type 84844\n");
    } else {
        SSA_PTD_ZLOG_NOTICE("invalid phy type\n");
    }
#endif
    return 0;
}
