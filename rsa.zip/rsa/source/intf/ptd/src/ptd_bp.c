
#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

//#include "../include/ptd_sdk.h"    pengcheng
#include "../include/ptd_type.h"
#include "../include/ptd_bp.h"


/**** backplane ports administration ****/
int bp_set_port_admin(ptd_info_t *ptd, int port_stat)
{
#if 0
	int rv;
    int old_stat;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);

    printf("set admin [%d][%d] [%d] start.\n", ptd->unit, ptd->port, port_stat);

    old_stat = -1;
    rv = bcm_port_enable_get(ptd->unit, ptd->port, &old_stat);
    if (rv != 0) {
        printf("bcm_port_enable_get[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);
         return SSA_PORT_E_RETURN;
    }
    printf("bcm_port_enable_get [%d][%d] [%d] over.\n", ptd->unit, ptd->port, port_stat);

    if (old_stat == port_stat) {
        printf("old_stat[%d] is the same as new_stat[%d] unit[%d] port[%d]\n",
            old_stat, port_stat, ptd->unit, ptd->port);
        return SSA_PORT_E_NONE;
    }

    rv = bcm_port_enable_set(ptd->unit, ptd->port, port_stat);
    if (rv != 0) {
        printf("bcm_port_enable_set[%d][%d] error, rv %d\n", ptd->unit, ptd->port, rv);
         return SSA_PORT_E_RETURN;
    }

    printf("set admin [%d][%d] [%d] over.\n", ptd->unit, ptd->port, port_stat);
#else
	// 路由器set port attr需要重新实现   pengcheng
#endif

    return SSA_PORT_E_NONE;
}

int bp_set_port_attr(ptd_info_t *ptd_bp, ptd_bp_attr_info_t *port_bp_attr)
{
#if 0
	int ret;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd_bp);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(port_bp_attr);

    /* for cache conf judge */
    bp_unit_port_conf_eff_t new_ptd_bp_sdk_cm_attr_eff;
    bp_unit_port_conf_eff_t *old_ptd_bp_sdk_cm_attr_eff = NULL;

    new_ptd_bp_sdk_cm_attr_eff.unit = ptd_bp->unit;
    new_ptd_bp_sdk_cm_attr_eff.port = ptd_bp->port;
    new_ptd_bp_sdk_cm_attr_eff.speed = port_bp_attr->speed;
    new_ptd_bp_sdk_cm_attr_eff.hg2_code = port_bp_attr->hg2_code;
    new_ptd_bp_sdk_cm_attr_eff.ifg = port_bp_attr->ifg;
    new_ptd_bp_sdk_cm_attr_eff.if_type = port_bp_attr->if_type;
    new_ptd_bp_sdk_cm_attr_eff.cl72 = port_bp_attr->cl72;

    printf("bp_port_attr_set, unit[%d] port[%d]\n", ptd_bp->unit, ptd_bp->port);
    printf("bp_port_attr_set, speed[%d] hg2_code[%d] ifg[%d] if_type[%d] cl72[%d]\n",
            port_bp_attr->speed, port_bp_attr->hg2_code,
            port_bp_attr->ifg, port_bp_attr->if_type, port_bp_attr->cl72);

    old_ptd_bp_sdk_cm_attr_eff = (bp_unit_port_conf_eff_t *)ptd_xgs_dnx_info_cache_find_from_unit_port(&bp_conf_eff_cache_head, ptd_bp->port);

    if (old_ptd_bp_sdk_cm_attr_eff == NULL) {
        printf("No old configuration, new_ptd_bp_sdk_cm_attr_eff distribute\n");
    } else {
        ret = memcmp(old_ptd_bp_sdk_cm_attr_eff, &new_ptd_bp_sdk_cm_attr_eff, sizeof(bp_unit_port_conf_eff_t));
        if (ret == 0) {
            printf("old & new configuration are equal, unit[%d] port[%d]\n", ptd_bp->unit, ptd_bp->port);
            return SSA_PORT_E_NONE;
        } else {
            printf("old & new configuration not be equal, new_ptd_bp_sdk_cm_attr_eff distribute\n");
        }
    }

    ret = bp_attr_conf_distribute(ptd_bp->unit, ptd_bp->port, &new_ptd_bp_sdk_cm_attr_eff);
    if (ret != 0) {
        printf("bp_attr_conf_distribute fail,unit[%d] port[%d] rv[%d]\n", ptd_bp->unit, ptd_bp->port, ret);
        return SSA_PORT_E_RETURN;
    } else {
        ptd_xgs_dnx_info_cache_update_from_eff_conf(&bp_conf_eff_cache_head, ptd_bp->port, &new_ptd_bp_sdk_cm_attr_eff, sizeof(bp_unit_port_conf_eff_t));
        printf("bp_attr_conf_distribute success, update cache\n");
    }
#else
	// 路由器set port attr需要重新实现   pengcheng
#endif
    return SSA_PORT_E_NONE;
}

int bp_port_init(int unit)
{
    int rv, port;

    // bp初始化交换机主要是初始化linkscan，路由器应该是初始化bp port的一些基本参数，具体实现to be done， pengcheng

	return SSA_PORT_E_NONE;
}

ptd_bp_ops_t lc_ptd_bp_ops = {
    .set_bp_admin       = bp_set_port_admin,
    .get_bp_admin       = NULL,
    .set_bp_attr        = bp_set_port_attr,
    .get_bp_attr        = NULL,
    .del_bp_attr        = NULL,
    .clear_bp_mib       = NULL,
    .get_bp_mib         = NULL,
    .init_port          = bp_port_init,
};

ptd_bp_ops_t fe_ptd_bp_ops = {
    .set_bp_admin       = bp_set_port_admin,
    .get_bp_admin       = NULL,
    .set_bp_attr        = bp_set_port_attr,
    .get_bp_attr        = NULL,
    .del_bp_attr        = NULL,
    .clear_bp_mib       = NULL,
    .get_bp_mib         = NULL,
    .init_port          = bp_port_init,
};

ptd_bp_ops_t cm_ptd_bp_ops = {
    .set_bp_admin       = bp_set_port_admin,
    .get_bp_admin       = NULL,
    .set_bp_attr        = bp_set_port_attr,
    .get_bp_attr        = NULL,
    .del_bp_attr        = NULL,
    .clear_bp_mib       = NULL,
    .get_bp_mib         = NULL,
    .init_port          = bp_port_init,
};

ptd_bp_arch_t ptd_lc_bp_driver = {
    .type = BP_TYPE_LC,
    .ptd_bp_ops = &lc_ptd_bp_ops,
};

ptd_bp_arch_t ptd_fe_bp_driver = {
    .type = BP_TYPE_FE,
    .ptd_bp_ops = &fe_ptd_bp_ops,
};

ptd_bp_arch_t ptd_cm_bp_driver = {
    .type = BP_TYPE_CM,
    .ptd_bp_ops = &cm_ptd_bp_ops,
};
