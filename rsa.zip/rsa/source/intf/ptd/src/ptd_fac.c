/*
 * Copyright(C) 2012 Ruijie Network. All rights reserved.
 */
/*
 * ptd_fac.c
 * Original Author:  xudongxu@ruijie.com.cn, 2018-10-8
 *
 * 12.x port����ģ��
 *
 * History
 */

#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#include "../include/ptd_mom.h"

#define PORT_FAC_DBG_CFG_FILE_PATH              "/data/.port_dbg_cfg"
#define FAC_LED_CTRL_CMIC_NUM                   (2)
#define FAC_LED_CODE_LENTH                      (1000)

#define HWTEST_PRBS_PHY_MODE                    (0x0)
#define HWTEST_PRBS_0_POLY                      (6)
#define FAC_PORT_PRBS_BIT                       (57)
#define FALSE_PRBS                              (0)
#define TRUE_PRBS                               (1)

int port_fac_debug_level = 0x3;
int port_fac_test_mode = 0x1;

/* ��ȡfcs���ĸ��� */
extern int ptd_fac_get_fcs_count(int unit, int port, uint64_t *fcs_count);
/* ��ʼ�㲥���� */
extern int ptd_fac_begin_bc_test(int unit);
/* ��ʼ�ػ����� */
extern int ptd_fac_begin_lb_test(int unit);
/* ֹͣ�ػ����� */
extern int ptd_fac_stop_lb_test(int unit);
/* ֹͣ�㲥���� */
extern int ptd_fac_stop_bc_test(int unit);
extern void ptd_fac_set_test_mode(int unit);

int ptd_fac_get_led_num(void)
{
    return FAC_LED_CTRL_CMIC_NUM;
}

int ptd_fac_get_led_code_len(void)
{
    return FAC_LED_CODE_LENTH;
}

/* debug�����ļ����� */
static void ptd_fac_dbg_file_load(void)
{
    FILE *fp;
    char buf[100];
    static int inited;


    if (inited) {
        return;
    } else {
        inited = 1;
    }

    memset(buf, 0, sizeof(buf));
    fp = fopen(PORT_FAC_DBG_CFG_FILE_PATH, "r");
    if (fp == NULL) {
        return;
    }

    if (fgets(buf, sizeof(buf), fp) != NULL) {
        if (strstr(buf, "print") != NULL) {
            port_fac_debug_level |= 0x1;
        }

        if (strstr(buf, "error") != NULL) {
            port_fac_debug_level |= 0x2;
        }
    }

    fclose(fp);

    return;
}

/*
 *  ������������ģʽ
 *  ��ssa_port_init�е����ж�
 *  ����:��
 *
 */
void ptd_set_test_mode(void)
{
    static int init = 0;
    if (init) {
        return;
    } else {
        init = 1;
    }

    if (access("/tmp/.factory_disabale_cli_tty", F_OK) != -1) {
        PORT_FAC_INFO("enter fac mod!\n");
        port_fac_test_mode = 1;
    }  else {
        port_fac_test_mode = 0;
    }
}

/*
 *  ��ȡ��������ģʽ
 *
 *  ����:��
 *  ����ֵ: 1--��������ģʽ������������
 *
 */
int ptd_fac_is_test_mode(void)
{
    return port_fac_test_mode;
}

int ptd_fac_set_port_prbs(int lphyid)
{
	//NPS需要重新实现，pengcheng

    return 0;
}

int ptd_fac_cancel_port_prbs(int lphyid)
{
	//NPS需要重新实现，pengcheng

    return 0;
}

int ptd_fac_get_prbs_result(int lphyid, int* result)
{
	//NPS需要重新实现，pengcheng

    return PORT_FAC_NONE;
}

/* ��ȡ�㲥���Խ�� */
static int ut_ssa_port_fac_get_fcs_count(int lport)
{
    uint64_t fcs_count;
    int rv, unit = 0, port = 2;

    rv = libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        PORT_FAC_ERR("libddm_get_unit_port_by_lport fail lport=%d\n", lport);
        return rv;

    }

    PORT_FAC_ERR("unit = %d port=%d\n", unit, port);

    rv = ptd_fac_get_fcs_count(unit, port, &fcs_count);
    if (rv != 0) {
        return rv;
    }

   printf("lport:%d fcs_count:%llu\n", lport, (long long unsigned int)fcs_count);

    return rv;
}

static int ut_ssa_port_fac_stop_bc_test(int unit)
{
    return ptd_fac_stop_bc_test(unit);
}

static int ut_ssa_port_fac_begin_bc_test(int unit)
{
    return ptd_fac_begin_bc_test(unit);
}

static int ut_ptd_fac_stop_lb_test(int unit)
{
    return ptd_fac_stop_lb_test(unit);
}

static int ut_ptd_fac_begin_lb_test(int unit)
{
    return ptd_fac_begin_lb_test(unit);
}

extern int ptd_get_state(int unit, int port, ptd_attr_info_t *port_att);

int ptd_fac_get_state(int slot, unsigned int phyid, ptd_attr_info_t *port_att)
{
    int unit, port, rv;
    rv = libddm_get_unit_port_by_lphyid(phyid, &unit, &port);
    if (rv != 0) {
        SSTEST_DBG_ERR("get unit port fail phyid %u\n", phyid);
        return -1;

    }
    rv = ptd_get_state(unit, port, port_att);
    if (rv != 0) {
        SSTEST_DBG_ERR("ptd_get_state fail phyid %u\n", phyid);
    }

    return 0;
}

static int ut_ptd_fac_get_attr(int lport)
{
    ptd_attr_info_t ptd_attr_info;
    unsigned int phyid = 0;
    int rv;
    int unit, port;

    memset(&ptd_attr_info, 0, sizeof(ptd_attr_info_t));
    //��ȡ���ض˿ں�
    rv = libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        SSTEST_DBG_ERR("get unit port by lport fail lport %d\n", lport);
        return -1;
    }

    rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
    if (rv != 0) {
        SSTEST_DBG_ERR("libddm_get_lphyid_by_unit_port fail unit %d port %d\n", unit, port);
        return -1;
    }

    ptd_fac_get_state(0, phyid, &ptd_attr_info);
    printf("lport %d link %d\n", lport, ptd_attr_info.link);
    printf("lport %d speed %d\n", lport, ptd_attr_info.speed);
    printf("lport %d duplex %d\n", lport, ptd_attr_info.duplex);
    printf("lport %d an %d\n", lport, ptd_attr_info.an);
    printf("lport %d flow %d\n", lport, ptd_attr_info.flow);
    printf("lport %d medium %d\n", lport, ptd_attr_info.medium);

    return 0;
}


static int ut_ssa_port_fac_set_prbs(int unit, int port)
{
    int rv;
    unsigned int lphyid;

    PORT_FAC_INFO("ut_ssa_port_fac_set_prbs, unit %d, port %d\n", unit, port);

    lphyid = -1;
    rv = libddm_get_lphyid_by_unit_port(unit, port, &lphyid);
    if (rv != 0) {
        PORT_FAC_ERR("get lphyid by lport fail, unit %d, port %d\n", unit, port);
        return PORT_FAC_ERROR;
    }

    PORT_FAC_INFO("ut_ssa_port_fac_set_prbs lphyid:%d\n", lphyid);

    rv = ptd_fac_set_port_prbs(lphyid);
    if (rv != 0) {
        PORT_FAC_ERR("ptd_fac_set_port_prbs fail, lphyid:%d\n", lphyid);
        return PORT_FAC_ERROR;
    }

    return 0;
}

static int ut_ssa_port_fac_cancel_prbs(int unit, int port)
{
    int rv;
    unsigned int lphyid;

    PORT_FAC_INFO("ut_ssa_port_fac_cancel_prbs, unit %d, port %d\n", unit, port);

    lphyid = -1;
    rv = libddm_get_lphyid_by_unit_port(unit, port, &lphyid);
    if (rv != 0) {
        PORT_FAC_ERR("get lphyid by lport fail, unit %d, port %d\n", unit, port);
        return PORT_FAC_ERROR;
    }

    PORT_FAC_INFO("ut_ssa_port_fac_cancel_prbs lphyid:%d\n", lphyid);

    rv = ptd_fac_cancel_port_prbs(lphyid);
    if (rv != 0) {
        PORT_FAC_ERR("ptd_fac_cancel_port_prbs fail, lphyid:%d\n", lphyid);
        return PORT_FAC_ERROR;
    }

    return 0;
}

static int ut_ssa_port_fac_result_prbs(int unit, int port)
{
    int rv, result;
    unsigned int lphyid;

    PORT_FAC_INFO("ut_ssa_port_fac_result_prbs, unit %d, port %d\n", unit, port);

    lphyid = -1;
    rv = libddm_get_lphyid_by_unit_port(unit, port, &lphyid);
    if (rv != 0) {
        PORT_FAC_ERR("get lphyid by lport fail, unit %d, port %d\n", unit, port);
        return PORT_FAC_ERROR;
    }

    PORT_FAC_INFO("ptd_fac_get_prbs_result lphyid:%d\n", lphyid);

    rv = ptd_fac_get_prbs_result(lphyid, &result);
    if (rv != 0) {
        PORT_FAC_ERR("ptd_fac_get_prbs_result fail, lphyid:%d\n", lphyid);
        return PORT_FAC_ERROR;
    }

    return 0;
}

int ptd_fac_mom_init(rg_global_t *global, int unit)
{
    at_ctrl_info_t *pos = NULL;
    static int init;
    int ret;
    SSA_PORT_INIT_FUNC_ENTER;

    if (init) {
        return 0;
    }
    init = 1;

    pos = (at_ctrl_info_t *)malloc(sizeof(at_ctrl_info_t));
    if (pos == NULL) {
        printf("name[%s] malloc mem fail\r\n", "ptd_fac_test");
        return -2;
    }
    memset(pos, 0, sizeof(at_ctrl_info_t));
    ret = ssat_multi_thread_init(global, "ptd_fac_test", pos);
    if (ret) {
        printf("name[%s] ssat_multi_thread_init fail\r\n", "ptd_fac_test");
        free(pos);
        return ret;
    }

    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ssa_port_fac_begin_bc_test", "unit=%d", ut_ssa_port_fac_begin_bc_test);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ssa_port_fac_stop_bc_test", "unit=%d", ut_ssa_port_fac_stop_bc_test);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ssa_port_fac_get_fcs_count", "lport=%d", ut_ssa_port_fac_get_fcs_count);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ptd_fac_begin_lb_test", "unit=%d", ut_ptd_fac_begin_lb_test);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ptd_fac_stop_lb_test", "unit=%d", ut_ptd_fac_stop_lb_test);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ptd_fac_get_attr", "lport=%d", ut_ptd_fac_get_attr);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ssa_port_fac_set_prbs", "unit=%d port=%d", ut_ssa_port_fac_set_prbs);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ssa_port_fac_cancel_prbs", "unit=%d port=%d", ut_ssa_port_fac_cancel_prbs);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_fac_test", "ut_ssa_port_fac_result_prbs", "unit=%d port=%d", ut_ssa_port_fac_result_prbs);

    SSA_PORT_INIT_FUNC_LEAVER;

    return 0;
}


int ptd_fac_hw_init(int unit)
{
    ptd_fac_dbg_file_load();
    //��������ģʽ
    ptd_set_test_mode();
    if (ptd_fac_is_test_mode()) {
        ptd_fac_set_test_mode(unit);
    }
    printf("factory mode:%d\n", port_fac_test_mode);

    return 0;
}



