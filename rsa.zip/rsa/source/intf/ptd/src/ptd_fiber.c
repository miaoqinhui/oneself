/*
  * Copyright(C) 2001-2012 Ruijie Network. All rights reserved.
  */
/*
  * ssa_port_sfp.c
  * Original Author: xudongxu@ruijie.com.cn 2018-12-14
  *
  * ��������ӿ�
  *
  * History
  */

#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

//#include "../include/ptd_mom.h"
#include "../include/ptd_trans.h"
#include "../include/ptd_com.h"
#include "../include/ptd_type.h"

/* bug507226����ǰ�����ǣ�����S57H��EB����ʹ��WC��phyоƬ������Ԥ���صı�־λ������������������ */
#define PTD_PREEMPHASIS_PHY_WC      1
#define PTD_PREEMPHASIS_PHY_TSCE    2
#define PTD_PREEMPHASIS_DRV_SIZE        sizeof(ptd_set_pre_drv)/sizeof(ptd_set_pre_drv[0])

extern int32_t    g_ssa_port_arry_speed[MAX_LPORT_NUM];       /* ȡ���˿�Ϊ48�� */
int32_t    g_ssa_port_sfp_type[MAX_LPORT_NUM]; /* ����ģ������ */
#if 0
/* ���� TXB_TX_DRIVER ��idiver �ֶ�*/
static int32_t control_driver_lane[4] = {
    BCM_PORT_PHY_CONTROL_DRIVER_CURRENT_LANE0,
    BCM_PORT_PHY_CONTROL_DRIVER_CURRENT_LANE1,
    BCM_PORT_PHY_CONTROL_DRIVER_CURRENT_LANE2,
    BCM_PORT_PHY_CONTROL_DRIVER_CURRENT_LANE3
};

/* ���� TXB_TX_DRIVER ��ipredriver �ֶ�*/
static int32_t control_pre_driver_lane[4] = {
    BCM_PORT_PHY_CONTROL_PRE_DRIVER_CURRENT_LANE0,
    BCM_PORT_PHY_CONTROL_PRE_DRIVER_CURRENT_LANE1,
    BCM_PORT_PHY_CONTROL_PRE_DRIVER_CURRENT_LANE2,
    BCM_PORT_PHY_CONTROL_PRE_DRIVER_CURRENT_LANE3
};

/* ���� TXB_TX_DRIVER ��post2_coeff �ֶ�, ��ǰ��sdk�޷�����lane���ø��ֶ� */
static int32_t control_driver_post2_lane[4] = {
    BCM_PORT_PHY_CONTROL_DRIVER_POST2_CURRENT,
    BCM_PORT_PHY_CONTROL_DRIVER_POST2_CURRENT,
    BCM_PORT_PHY_CONTROL_DRIVER_POST2_CURRENT,
    BCM_PORT_PHY_CONTROL_DRIVER_POST2_CURRENT
};

/* ���� �Ĵ���CL72_USER_B0_CL72_TX_FIR_TAP_REGISTER�ĺ� */
static int32_t control_preemphasis_lane[4] = {
    BCM_PORT_PHY_CONTROL_PREEMPHASIS_LANE0,
    BCM_PORT_PHY_CONTROL_PREEMPHASIS_LANE1,
    BCM_PORT_PHY_CONTROL_PREEMPHASIS_LANE2,
    BCM_PORT_PHY_CONTROL_PREEMPHASIS_LANE3
};

static int32_t ssa_port_if_type[] = {
    BCM_PORT_IF_SFI,    /* index 0 */      /* #define   SSA_PORT_IF_SFI   BCM_PORT_IF_SFI */
    BCM_PORT_IF_CR,     /* index 1 */
    BCM_PORT_IF_KR4,    /* index 2 */
    BCM_PORT_IF_CR4,    /* index 3 */
    BCM_PORT_IF_SR4,    /* index 4 */
    BCM_PORT_IF_SR,     /* index 5 */
};

static int in_ptd_phy_wc_set_preemphasis(int unit, int port, ptd_preemphasis_entry_t *entry);
static int in_ptd_phy_tsce_set_preemphasis(int unit, int port, ptd_preemphasis_entry_t *entry);
static ptd_set_preemphasis_driver_func ptd_set_pre_drv[] = {
    in_ptd_phy_wc_set_preemphasis,
    in_ptd_phy_tsce_set_preemphasis,
};

/* SOC_PHY_CONTROL_FORWARD_ERROR_CORRECTION_CL91 is cl91-RS-FEC
 * SOC_PHY_CONTROL_FORWARD_ERROR_CORRECTION is cl74 base-R-FEC or FC-FEC
 * currently cl74 base-R-FEC is not effective in 56170
 */
static int ptd_set_fec_real(int unit, int port, int fec_old, int fec_new, int *fec_eff)
{
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec_old[%d] fec_new[%d]",
        unit, port, fec_old, fec_new);

    /* next according to new fec we set it */
    if (fec_new == S_INTF__FEC_MODE_E__FEC_MODE_RS) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec_old[%d] fec_new[%d] set RS AUTO",
            unit, port, fec_old, fec_new);
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FORWARD_ERROR_CORRECTION_CL91, BCM_PORT_PHY_CONTROL_FEC_ON));
        *fec_eff = S_INTF__FEC_MODE_E__FEC_MODE_RS;
    } else if (fec_new == S_INTF__FEC_MODE_E__FEC_MODE_BASE_R) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec_old[%d] fec_new[%d] set BASE_R",
            unit, port, fec_old, fec_new);
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FORWARD_ERROR_CORRECTION, BCM_PORT_PHY_CONTROL_FEC_ON));
        *fec_eff = S_INTF__FEC_MODE_E__FEC_MODE_BASE_R;
    } else if (fec_new == S_INTF__FEC_MODE_E__FEC_MODE_BASE_R_WITH_RS) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec_old[%d] fec_new[%d] set R WITH RS",
            unit, port, fec_old, fec_new);
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FORWARD_ERROR_CORRECTION_CL91, BCM_PORT_PHY_CONTROL_FEC_ON));
        SSA_PORT_INTF_ERRFNC_RET(bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FORWARD_ERROR_CORRECTION, BCM_PORT_PHY_CONTROL_FEC_ON));
        *fec_eff = S_INTF__FEC_MODE_E__FEC_MODE_BASE_R_WITH_RS;
    } else if (fec_new == S_INTF__FEC_MODE_E__FEC_MODE_NONE) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec_old[%d] fec_new[%d] set NONE",
            unit, port, fec_old, fec_new);
        *fec_eff = S_INTF__FEC_MODE_E__FEC_MODE_NONE;
    }

    return SSA_PORT_E_NONE;
}
static int ptd_set_fec_force_none(int unit, int port)
{
    /* if we get here means we force the fec to none and update cache as none */
    /* so we just trun off all type of fec */
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec all none", unit, port);
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FORWARD_ERROR_CORRECTION_CL91, BCM_PORT_PHY_CONTROL_FEC_OFF));
    SSA_PORT_INTF_ERRFNC_RET(bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FORWARD_ERROR_CORRECTION, BCM_PORT_PHY_CONTROL_FEC_OFF));

    return SSA_PORT_E_NONE;
}

int ptd_set_fec(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new)
{
    int unit, port, bcm_speed;
    int new_value, old_value;
    int is_need_set_fec;
    int ret;
    int fec_set_flag;
    int fec_eff;

    is_need_set_fec = 0;
    fec_set_flag = 0;
    unit = ptd->unit;
    port = ptd->port;
    new_value = ptd_sdk_fiber_conf_info_new->fec;
    old_value = ptd_sdk_fiber_conf_info->fec;
    bcm_speed = 0;

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] fec_new[%d] fec_old[%d]", ptd->unit, ptd->port, new_value, old_value);
    ret = SSA_PORT_E_NONE;

    /* here for defensive check is fec_unknown leak here we do nothing and update cache to fec_unknown */
    if (new_value == S_INTF__FEC_MODE_E__FEC_MODE_UNKNOWN) {
        SSA_PTD_ZLOG_FATAL("unit[%d] port[%d] fec_value is unknown[%d]", ptd->unit, ptd->port, new_value);
        return SSA_PORT_E_RETURN;
    }

    /* for now not 25G and 100G port will not set fec */
    if ((ptd->lport_max_rate != PORT_TFIGABIT_ETHERNET)
            && (ptd->lport_max_rate != PORT_HUGIGABIT_ETHERNET)) {
        SSA_PTD_ZLOG_FATAL("unit[%d] port[%d] lport_max_rate[%d] invalid", ptd->unit, ptd->port, ptd->lport_max_rate);
        return SSA_PORT_E_RETURN;
    }

    SSA_PORT_INTF_ERRFNC_RET(bcm_port_speed_get(unit, port, &bcm_speed));
    is_need_set_fec = in_ssa_port_sfp_is_need_set_fec((ssa_port_sfp_module_capability_t)ptd->trans_cap_detail);

    if ((bcm_speed == 25000) && ((ptd->trans_rate == 25000) || (ptd->trans_rate == 100000))) {
        /* normal 25G port with 25G speed conf or 100G split with 25G speed conf need set FEC */
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] need to set fec bcm_speed[%d] trans_rate[%d]",
            ptd->unit, ptd->port, bcm_speed, ptd->trans_rate);
        fec_set_flag = 1;
    } else if ((bcm_speed == 100000) && (ptd->trans_rate == 100000) && is_need_set_fec) {
        /* 100G trans with 100G speed conf and certain trans type */
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] need to set fec bcm_speed[%d] trans_rate[%d] is_need_set_fec[%d]",
            ptd->unit, ptd->port, bcm_speed, ptd->trans_rate, is_need_set_fec);
        fec_set_flag = 1;
    } else {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] no need to set fec bcm_speed[%d] trans_rate[%d] is_need_set_fec[%d]",
            ptd->unit, ptd->port, bcm_speed, ptd->trans_rate, is_need_set_fec);
    }

    /* when comes to here FEC is force to none and update cache as fec_none */
    /* because when going to here the speed is already confed, so the cache must be update to fec_none anyway
     * to ensure next time FEC set.
     * we put the fore none before because all conf will turn off former FEC firstly
     */
    ret = ptd_set_fec_force_none(unit, port);
    if (ret != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] ptd_set_fec_force_none fail[%d] trans_rate[%d] fec_new[%d] in effect",
            ptd->unit, ptd->port, ptd->trans_rate, ptd_sdk_fiber_conf_info_new->fec);
    }
    /* new fiber info is used to override callers SDK-cache when fex set OK */
    ptd_sdk_fiber_conf_info_new->fec = S_INTF__FEC_MODE_E__FEC_MODE_NONE;
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] nfec bcm_speed[%d] trans_rate[%d] fec_new[%d] in effect",
        ptd->unit, ptd->port, bcm_speed, ptd->trans_rate, ptd_sdk_fiber_conf_info_new->fec);

    /* first we init fec_eff as old-val incase of fec set fial */
    fec_eff = old_value;
    if (fec_set_flag) {
        ret = ptd_set_fec_real(unit, port, old_value, new_value, &fec_eff);
        if (ret != SSA_PORT_E_NONE) {
            SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] ptd_set_fec_real fail[%d] trans_rate[%d] fec_new[%d] in effect",
                ptd->unit, ptd->port, ret , ptd->trans_rate, ptd_sdk_fiber_conf_info_new->fec);
        }
        /* we set success set fiber-info-fec to new_value */
        new_value = fec_eff;
        ptd_sdk_fiber_conf_info_new->fec = new_value;
    }

    return ret;
}
static int in_ptd_phy_wc_set_preemphasis(int unit, int port, ptd_preemphasis_entry_t *entry)
{
    int rv;
    int pre_value, drv_value;
    int pre_type, drv_type, drv_pre_type, drv_post2_type;

    if (!entry) {
        SSA_PTD_ZLOG_ERROR("entry is NULL");
        return SSA_PORT_E_IVPARAM;
    }

    pre_type = entry->pre_type;
    pre_value = entry->pre_value;
    drv_type = entry->drv_type;
    drv_value = entry->drv_value;
    drv_pre_type = entry->drv_pre_type;
    drv_post2_type = entry->drv_post2_type;
    SSA_PTD_ZLOG_NOTICE("unit %d port %d pre_type %d pre_value %d drv_type %d drv_value %d "
        "drv_pre_type %d drv_post2_type %d", unit, port, pre_type, pre_value, drv_type, drv_value, drv_pre_type, drv_post2_type);
    rv = bcm_port_phy_control_set(unit, port, pre_type, pre_value);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pre, rv %d \n", unit, port, rv);
    }

    rv = bcm_port_phy_control_set(unit, port, drv_type, ((drv_value >> 8) & 0xf));
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, drv_current, rv %d \n", unit, port, rv);
    }

    rv = bcm_port_phy_control_set(unit, port, drv_pre_type, ((drv_value >> 4) & 0xf));
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pre_drv, rv %d \n",
        unit, port, rv);
    }

    rv = bcm_port_phy_control_set(unit, port, drv_post2_type, ((drv_value >> 12) & 0x7));
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pos2, rv %d \n",
        unit, port, rv);
    }

    usleep(10000);
    rv = bcm_port_phy_control_set(unit, port, pre_type, pre_value);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pre, rv %d \n",
            unit, port, rv);
    }

    rv = bcm_port_phy_control_set(unit, port, drv_type, ((drv_value >> 8) & 0xf));
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, drv_current, rv %d \n",
            unit, port, rv);
    }
    rv = bcm_port_phy_control_set(unit, port, drv_pre_type, ((drv_value >> 4) & 0xf));
    if (rv != 0) {
    SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pre_drv, rv %d \n",
        unit, port, rv);
    }

    rv = bcm_port_phy_control_set(unit, port, drv_post2_type, ((drv_value >> 12) & 0x7));
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pos2, rv %d \n",
            unit, port, rv);
    }

    return SSA_PORT_E_NONE;
}

static int in_ptd_phy_tsce_set_preemphasis(int unit, int port, ptd_preemphasis_entry_t *entry)
{
    int rv;
    int pre_type, pre_value, drv_type, drv_value;

    if (!entry) {
        SSA_PTD_ZLOG_ERROR("entry is NULL");
        return SSA_PORT_E_IVPARAM;
    }

    pre_type = entry->pre_type;
    pre_value = entry->pre_value;
    drv_type = entry->drv_type;
    drv_value = entry->drv_value;
    SSA_PTD_ZLOG_NOTICE("unit %d port %d pre_type %d pre_value %d drv_type %d drv_value %d ",
        unit, port, pre_type, pre_value, drv_type, drv_value);
    rv = bcm_port_phy_control_set(unit, port, pre_type, pre_value);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, pre, rv %d \n", unit, port, rv);
    }

    rv = bcm_port_phy_control_set(unit, port, drv_type, drv_value);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set failed unit %d port %d, drv_type %d, drv_value %d, rv %d\n",
            unit, port, drv_type, drv_value, rv);
    }

    return SSA_PORT_E_NONE;
}

int ptd_set_preemphasis(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new)
{
    int unit, port, lport_max_rate, lane_num, trans_model, i, lane, lport, rv;
    int pre_mode;
    ptd_preemphasis_entry_t pre_entry;

    pre_mode = ssa_port_cfg_get_set_preemphasis();
    if (pre_mode <= 0 || pre_mode > PTD_PREEMPHASIS_DRV_SIZE) {
        return SSA_PORT_E_NONE;
    }

    if (!ptd_set_pre_drv[pre_mode -1]) {
        SSA_PTD_ZLOG_WARN("set_preemphasis[%d] is no driver to handle\n", pre_mode);
        return SSA_PORT_E_NONE;
    }

    lport_max_rate = ptd->lport_max_rate;
    unit = ptd->unit;
    port = ptd->port;
    trans_model = ptd->trans_model;
    lport = ptd->lport;

    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] lport[%d] trans_model[%d] lport_max_rate[%d]\n",
        unit, port, lport, trans_model, lport_max_rate);

    /* coverity fix */
    if (lport_max_rate == PORT_TGIGABIT_ETHERNET || lport_max_rate == PORT_TFIGABIT_ETHERNET) {
        lane_num = 1;
    } else if (lport_max_rate == PORT_FOGIGABIT_ETHERNET || lport_max_rate == PORT_HUGIGABIT_ETHERNET)  {
        lane_num = 4;
    } else {
        SSA_PTD_ZLOG_WARN("no need to set pre port_type %d\n", lport_max_rate);
        return SSA_PORT_E_NONE;
    }

    for (i = 0; i < lane_num; i++) {
        memset(&pre_entry, 0, sizeof(pre_entry));
        if (lane_num == 1) {
            lane = ssa_port_cfg_get_port_to_lane(lport);
            pre_entry.pre_type = BCM_PORT_PHY_CONTROL_PREEMPHASIS;
            pre_entry.drv_type = BCM_PORT_PHY_CONTROL_DRIVER_CURRENT;
        } else {
            lane = i;
            pre_entry.pre_type = control_preemphasis_lane[lane];
            pre_entry.drv_type = control_driver_lane[lane];
            SSA_PTD_ZLOG_NOTICE(" lport:%d i:%d lane_num:%d\n", lport , i, lane_num);
        }

        if (trans_model == I2C_SFP_TYPE_COPPER) {
            pre_entry.pre_value = ssa_port_cfg_get_copper_pre(lport, lane);
            pre_entry.drv_value = ssa_port_cfg_get_copper_drv(lport, lane);
        } else {
            pre_entry.pre_value = ssa_port_cfg_get_fiber_pre(lport, lane);
            pre_entry.drv_value = ssa_port_cfg_get_fiber_drv(lport, lane);
        }

        if (pre_entry.pre_value == 0 && pre_entry.drv_value == 0) {
            SSA_PTD_ZLOG_NOTICE("pre and drv is zero, just continue\r\n");
            continue;
        }

        /* ��Ӧԭ����s57h�豸��EB������Ҫ����drv_pre��drv_post2 */
        if (pre_mode == PTD_PREEMPHASIS_PHY_WC) {
            pre_entry.drv_pre_type = control_pre_driver_lane[lane];
            pre_entry.drv_post2_type = control_driver_post2_lane[lane];
        }
        rv = (ptd_set_pre_drv[pre_mode - 1])(unit, port, &pre_entry);
        if (rv) {
            SSA_PTD_ZLOG_ERROR("preemphasis_set failed, unit[%d] port[%d] rv[%d]", unit, port, rv);
        }
    }

    return SSA_PORT_E_NONE;
}
#endif

extern int32_t ssa_port_cfg_get_if_type_copper_hundredgi(void);
extern int32_t ssa_port_cfg_get_if_type_fiber_hundredgi(void);

/* returns the new_iftype in effect */
int ptd_set_interface(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new)
{
#if 0    
    int  lport_max_rate, unit, port, trans_model, new_iftype, rv, trans_rate;
    int is_vsl, bcm_speed;
    int old_iftype;
    int unreliable_los;
	rv = SSA_PORT_E_NONE;
    if (!ssa_port_cfg_get_serdes_if_type()) {
        SSA_PTD_ZLOG_ERROR("no need to serdes_if_type \n");
        return SSA_PORT_E_NONE;
    }

    lport_max_rate = ptd->lport_max_rate;
    unit = ptd->unit;
    port = ptd->port;
    trans_model = ptd->trans_model;
    trans_rate = ptd->trans_rate;
    is_vsl = ptd->is_vsl;

    if (lport_max_rate == PORT_TGIGABIT_ETHERNET || lport_max_rate == PORT_TFIGABIT_ETHERNET) {
        if (trans_model == I2C_SFP_TYPE_COPPER) {
            new_iftype = ssa_port_cfg_get_if_type_copper_tengi();
        } else {
            new_iftype = ssa_port_cfg_get_if_type_fiber_tengi();
        }

        if (trans_rate == 1000) {
           SSA_PTD_ZLOG_NOTICE("speed 1000 no need to set serdes if type, just return\n");
           return SSA_PORT_E_NONE;
        }
    } else if (lport_max_rate == PORT_FOGIGABIT_ETHERNET) {
        if (trans_model == I2C_SFP_TYPE_COPPER) {
            new_iftype = ssa_port_cfg_get_if_type_copper_fortygi();
        } else {
            new_iftype = ssa_port_cfg_get_if_type_fiber_fortygi();
        }
        if (is_vsl) {
             new_iftype = 2;
        }
    } else if (lport_max_rate == PORT_HUGIGABIT_ETHERNET) {

        if (trans_model == I2C_SFP_TYPE_COPPER) {
            new_iftype = ssa_port_cfg_get_if_type_copper_hundredgi();
        } else {
            new_iftype = ssa_port_cfg_get_if_type_fiber_hundredgi();
        }
        if (is_vsl) {
           new_iftype = 2;
        }
    } else {
        return SSA_PORT_E_RETURN;
    }

    old_iftype = ptd_sdk_fiber_conf_info->iftype;
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] new if_type[%d] old if_type[%d]",
        unit, port, new_iftype, old_iftype);

    /* here we judge the if_type maybe the same */
    if (new_iftype == old_iftype) {
        SSA_PTD_ZLOG_ERROR("old iftype and new iftype the same! unit %d, port %d skip", unit, port);
        return SSA_PORT_E_NONE;
    }
	// NPS��Ҫ����ʵ��interface set���� ��pengcheng
    //rv = bcm_port_interface_set(unit, port, ssa_port_if_type[new_iftype]);
    //if (rv != SSA_PORT_E_NONE) {
    //    SSA_PTD_ZLOG_ERROR("bcm_port_interface_set failed! unit %d, port %d, if_type %d, rv %d\n"
	//
    //        , unit, port, ssa_port_if_type[new_iftype], rv);
    //    return SSA_PORT_E_RETURN;
    //}

    /* if if-type changes link will change, so we can set speed again */
	// NPS��Ҫ����ʵ��speed get���� ��pengcheng
    //rv = bcm_port_speed_get(unit, port, &bcm_speed);
    if (rv != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("bcm_port_speed_get failed! unit %d, port %d speed %d rv %d\n"
            , unit, port, bcm_speed, rv);
        return SSA_PORT_E_RETURN;
    }
	// NPS��Ҫ����ʵ��speed set���� ��pengcheng

    //rv = bcm_port_speed_set(unit, port, bcm_speed);
    if (rv != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("bcm_port_speed_set failed! unit %d, port %d speed %d rv %d\n"
            , unit, port, bcm_speed, rv);
        return SSA_PORT_E_RETURN;
    }

    /* update the iftype value to caller when all is success */
    ptd_sdk_fiber_conf_info->iftype = new_iftype;

    /* see if this port should set unreliable_los, now tscf-phy is recommand to set this only the medium is optical
     * so if trans_model is optical we set 1, if non-optical set 0
     */
    unreliable_los = 0;
    if (ssa_port_cfg_get_need_unreliable_los(ptd->lport)) {
        if (trans_model == I2C_SFP_TYPE_COPPER
                || g_ssa_port_sfp_type[ptd->lport - 1] == SSA_PORT_GT) {
            unreliable_los = 0;
        } else {
            unreliable_los = 1;
        }
        SSA_PTD_ZLOG_NOTICE("ssa_port_cfg_get_need_unreliable_los unit[%d] port[%d] trans_model[%d] unreliable_los[%d]",
            unit, port, trans_model, unreliable_los);
		// NPS��Ҫ����ʵ��speed get���� ��pengcheng
        //rv = bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS, unreliable_los);
        if (rv != SSA_PORT_E_NONE) {
            /* here return new if_type to update cache anyway, case in here iftype already set OK */
            SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set unreliable_los error, unit[%d] port[%d], rv[%d]\n",
                unit, port, rv);
            return SSA_PORT_E_RETURN;
        }
    }
#endif
    return SSA_PORT_E_NONE;
}

int ptd_set_firmode(ptd_info_t *ptd, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info, ptd_sdk_fiber_conf_info_t *ptd_sdk_fiber_conf_info_new)
{
#if 0    
    int unit, port, trans_model, trans_rate, lport_max_rate;
    int rv;
    int dfe_enable;
    unsigned int old_value, new_value;
    int link_status;

    if (!ssa_port_cfg_get_fir_mode()) {
        SSA_PTD_ZLOG_ERROR("no need to set fir mode \n");
        return SSA_PORT_E_NONE;
    }

    unit = ptd->unit;
    port = ptd->port;
    trans_model = ptd->trans_model;
    trans_rate = ptd->trans_rate;
    lport_max_rate = ptd->lport_max_rate;

    link_status = 0;//BCM_PORT_LINK_STATUS_DOWN;
	// NPS��Ҫ����ʵ��speed get���� ��pengcheng
    //rv = bcm_port_link_status_get(unit, port, &link_status);
    if (rv != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("unit[%d] port[%d] bcm_port_link_status_get fail[%d]", unit, port, rv);
        return SSA_PORT_E_RETURN;
    }
    if (link_status != 0) {
        SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] not linkdown skip[%d]", unit, port, link_status);
        return SSA_PORT_E_NONE;
    }

    if (trans_rate == 1000) {
       SSTEST_DBG_TEST("speed 1000 no need to set serdes if type, just return\n");
       return SSA_PORT_E_NONE;
    }

    switch (lport_max_rate) {
        case PORT_GIGABIT_ETHERNET:
            SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] 1000m port no need set firmode!", unit, port);
            return SSA_PORT_E_NONE;
        case PORT_TGIGABIT_ETHERNET:
        case PORT_TFIGABIT_ETHERNET:
        case PORT_FOGIGABIT_ETHERNET:
        case PORT_HUGIGABIT_ETHERNET:
            new_value = (trans_model == I2C_SFP_TYPE_COPPER) ? FIBER_FIRMODE_COPPER_WIRE : FIBER_FIRMODE_FIBER_OPTICAL;
            SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] firmode[%d] lport_max_rate[%d]!", unit, port, new_value, lport_max_rate);
            break;
        default:
            new_value = FIBER_FIRMODE_COPPER_WIRE;
            SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] firmode in default!", unit, port);
            break;
    }

    /* here we must see if the old value is the same */
    old_value = ptd_sdk_fiber_conf_info->firmode;
    SSA_PTD_ZLOG_NOTICE("firmode_old[%d] firmode_new[%d]", old_value, new_value);

    /* we do not care enable state here, on condition that PTM notifies firmode config
     * when port is disable. this is an imply condition
     */
    rv = SSA_PORT_E_NONE;
    if (old_value == new_value) {
        SSA_PTD_ZLOG_NOTICE("firmode_old[%d] firmode_new[%d] the same!", old_value, new_value);
        return SSA_PORT_E_NONE;
    }
	// NPS��Ҫ����ʵ��speed get���� ��pengcheng
    //rv = bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FIRMWARE_MODE, new_value);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set error, unit %d port %d, rv %d\n",
                unit, port, rv);
    }

    if (ssa_port_cfg_get_firmware_dfe_enable()) {
        dfe_enable = trans_model == I2C_SFP_TYPE_COPPER ? 1 : 0;
		// NPS��Ҫ����ʵ��speed get���� ��pengcheng
        //rv = bcm_port_phy_control_set(unit, port, BCM_PORT_PHY_CONTROL_FIRMWARE_DFE_ENABLE, dfe_enable);
        if (rv != 0) {
            SSA_PTD_ZLOG_ERROR("bcm_port_phy_control_set dfe on error, unit %d port %d, rv %d\n",
                unit, port, rv);
        }
    }

    /* update the fimode value to caller when all is success */
    ptd_sdk_fiber_conf_info->firmode = new_value;
#endif
    return SSA_PORT_E_NONE;
}

