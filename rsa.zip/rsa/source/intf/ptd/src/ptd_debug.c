/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * ptd_debug.c
 * Original Author:  xudongxu@ruijie.com.cn, 2018-12-7
 *
 * PTD模块调试
 *
 * History
 */
#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"

#include "../include/ptd_mom.h"

int g_ssa_port_debug_error = 1;
int g_ssa_port_debug_test = 0;
int record_open = 0;
rgdf_zlog_level_t g_ssa_ptd_zlog_level = RGDF_ZLOG_LV_FATAL;
zlog_category_t * g_ssa_ptd_zlog_category;

#define PTD_ZLOG_DBG_FILE           "/data/dbg/ssa_ptd_zlog.txt"
#define PTD_DBG_FIEL_BUF_LEN                (64)

extern void ptd_dump_enable_flag(void);
extern void ptd_write_port_link_inter(ptd_info_t *ptd);
extern void ptd_read_port_link_inter(ptd_info_t *ptd, uint16_t *p_cdata, uint16_t *p_fdata);

/******************************************************************************/
static void ptd_debug_cpld(int addr, int val, int flag)
{
    char cpld_dev[32] = "/dev/cpld0";
    int rv;
    /* flag 1 表示写 0 表示读 */
    int value;

    value = val;

    if (flag) {
        rv = ptd_write_cpld(cpld_dev, addr, (unsigned char *)&value, 1);
        if (rv < 0) {
            printf("ptd write cpld fail\n");
        } else {
            printf("ptd write cpld success\n");
    }

    } else {

        rv = ptd_read_cpld(cpld_dev, addr, (unsigned char *)&value, 1);
        if (rv < 0) {
            printf("ptd read cpld fail\n");
        } else {
            printf("ptd read cpld success val %d\n", value);
        }
    }
}

static void ptd_debug_i2c(int lport, int addr, int val, int flag)
{
    char *i2c_dev;
    int rv, dev_addr = 0x50;

    i2c_dev = ssa_port_cfg_get_sfp_i2c_dev_name(lport);
    if (i2c_dev == NULL) {
        SSTEST_DBG_TEST("pca9548_channel_name is NULL\n");
        return ;
    }

    printf("i2c name %s\n", i2c_dev);

    /* flag 1 表示写 0 表示读 */
    if (flag) {
        rv = ptd_write_i2c(i2c_dev, dev_addr, addr, (unsigned char *)&val, 1, 0);
        if (rv < 0) {
            printf("ptd write i2c fail\n");
        } else {
            printf("ptd write i2c success\n");
        }
    } else {
        rv = ptd_read_i2c(i2c_dev, dev_addr, addr, (unsigned char *)&val, 1, 0);
        if (rv < 0) {
            printf("ptd read i2c fail\n");
        } else {
            printf("ptd read i2c success val %d\n", val);
        }
    }
}

static void ptd_debug_on_off(int enable)
{
    if (enable) {
        printf("g_ssa_port_debug == 1\n");
            g_ssa_port_debug = 1;

    } else {
        printf("g_ssa_port_debug == 0\n");
            g_ssa_port_debug = 0;
    }

    return;
}

static void ptd_debug_time_record(int enable)
{
    if (enable) {
        printf("record_open == 1\n");
        record_open  = 1;
    } else {
        printf("record_open == 0\n");
        record_open = 0;
    }

    return;
}

static void ptd_debug_read_config(void)
{
    uint32_t time;

    ssa_port_read_cfg();
    time = ssa_port_cfg_get_read_cfgfile_time();
    printf("read config file need time %u\n", time);
    return;
}

static void ptd_debug_getmedium(int lport)
{
    unsigned int phyid = 0x80006;
    int medium;
    int rv;
    int unit = 0, port = 2;
    g_ssa_port_debug = 1;
    rv  = libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        SSTEST_DBG_TEST("get gphyid by lport fail lport %d\n", lport);
        return;

    }

    rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
    return;

    }

    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);
    medium = PORT_PTM_MEDIUM_FIBER;
    //get medium fix me
    //(void)ptd_get_medium(phyid, &medium);

    if (medium == PORT_PTM_MEDIUM_FIBER) {
        printf("lport %d, medium fiber\n", lport);
    } else if (medium == PORT_PTM_MEDIUM_COPPER) {
        printf("lport %d, medium copper\n", lport);
    }
    g_ssa_port_debug = 0;
    return;
}

static void ptd_debug_setmedium(int lport, int medium)
{
    unsigned int phyid =0x800006;
    int unit = 0, port = 2;
    int rv;

    g_ssa_port_debug = 1;
    rv  = libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        SSTEST_DBG_TEST("get gphyid by lport fail lport %d\n", lport);
        return;
    }

    rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;
    }

    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);
    (void)ptd_set_medium(phyid, medium);

    g_ssa_port_debug = 0;
    return;
}

static void ptd_debug_admin(int32_t lport, int enable)
{

    unsigned int phyid = 0x80006;
    int unit = 0, port = 2;
    ptd_info_t ptd;
    int rv;

    g_ssa_port_debug = 1;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;
    }

    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);

    if (enable) {
       nps_set_admin(&ptd, 1);
    } else {
       nps_set_admin(&ptd, 0);
    }

    g_ssa_port_debug = 0;

}

static void ptd_debug_loop(int lport, int loop)
{
    unsigned int phyid = 0x80006;
    int unit = 0, port = 2;
    int rv;
    ptd_info_t ptd;

    g_ssa_port_debug = 1;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;
    }

    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);
    if (loop == 1) {
        (void)nps_set_loopback(&ptd, 1);

    }  else {
        (void)nps_set_loopback(&ptd, 0);
    }
    g_ssa_port_debug = 0;
}


static void ptd_debug_open_trans(int lport, int enable)
{
    /* enable 0 表示打开光模块 1 表示关闭 */
    g_ssa_port_debug = 1;
    (void)out_ssa_port_open_transceiver(lport, enable);
    g_ssa_port_debug = 0;
}

//获取模块速率
static void ptd_debug_get_trans_speed(int lport)
{
    int speed = 0;
    g_ssa_port_debug = 1;
    //(void)in_ssa_port_get_trans_max_support_rate(lport, &speed);
    g_ssa_port_debug = 0;
    printf("get trans speed %d\n", speed);
}

//判断模块是否在位
static void ptd_debug_check_trans_exist(int lport)
{
    int rv = 0;
    g_ssa_port_debug = 1;
    rv = ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_SYNC);
    g_ssa_port_debug = 0;
    printf("trans exist %d\n", rv);
}

//获取模块介质类型
static void ptd_debug_get_trans_plug(unsigned int phyid)
{
    unsigned char plg_mode = 0;
    g_ssa_port_debug = 1;
    //(void)in_ssa_port_get_sfp_plug_mode(phyid, &plg_mode);
    g_ssa_port_debug = 0;
    printf("trans plug %d\n", plg_mode);
}

//光模块上电
extern int out_ssa_port_set_qsfp_power(void);

static void ptd_debug_set_trans_power(void)
{
    g_ssa_port_debug = 1;
    (void)out_ssa_port_set_qsfp_power();
    g_ssa_port_debug = 0;

}

static void ptd_debug_ddev(void)
{
#if 0
	int i, unit, port, mmu_port, phy_port, rv;

    soc_info_t *si;

    for (i = 1; i <= 120; i++) {
        rv = libddm_get_unit_port_by_lport(i, &unit, &port);
        if (rv != 0) {
            SSA_PTD_ZLOG_FATAL("get gphyid by lport fail lport %d\n", i);
            continue;
        }
        si = &SOC_INFO(unit);
        phy_port = si->port_l2p_mapping[port];
        mmu_port = si->port_p2m_mapping[phy_port];

        SSA_PTD_ZLOG_FATAL("\r\n  lport %3d,  unit %d, port %3d,  %5s  mmu_port %3d, phy_port %3d",
                i, unit, port, SOC_PORT_NAME(unit, port), mmu_port, phy_port);
    }

    SSA_PTD_ZLOG_FATAL("\n");
#else
// NPS需要重新实现        pengcheng
#endif
}

/* debug set mtu */
static void ptd_debug_mtu(int32_t lport, int mtu)
{
    unsigned int phyid = 0x80006;
    int unit = 0, port = 2;
    int rv;
    ptd_info_t ptd;

    g_ssa_port_debug = 1;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;
    }

    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);

    (void)nps_set_mtu(&ptd, mtu);

    g_ssa_port_debug = 0;

}

static void ptd_debug_set_attr(int lport, int speed, int an, int flow, int duplex, int fec)
{
    unsigned int phyid = 0x80006;
    ptd_attr_info_t ptd_attr_info;
    int unit = 0, port = 2;
    int rv;
    ptd_info_t ptd;
    ptd_attr_eff_info_t ptd_attr_eff_info;

    memset(&ptd_attr_info, 0, sizeof(ptd_attr_info_t));
    ptd_attr_info.speed = speed;
    ptd_attr_info.an = an;
    ptd_attr_info.duplex = duplex;
    ptd_attr_info.flow = flow;
    ptd_attr_info.fec = fec;
    memset(&ptd_attr_eff_info, 0, sizeof(ptd_attr_eff_info_t));

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;
    }

    g_ssa_port_debug = 1;
    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);

    (void)nps_set_attr_dsf(&ptd, &ptd_attr_info, &ptd_attr_eff_info);

    g_ssa_port_debug = 0;

}

extern int ptd_clear_mib(int unit, int port);
static void ptd_debug_clear_mib(int32_t lport)
{
    int unit = 0, port = 2;
    int rv;
    unsigned int phyid = 0x80006;

    g_ssa_port_debug = 1;
    rv = libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        SSTEST_DBG_TEST("get gphyid by lport fail lport %d\n", lport);
        return;
    }

    rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;
    }

    SSTEST_DBG_TEST("get unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);

    (void)ptd_clear_mib(unit, port);

    g_ssa_port_debug = 0;

}

/* this func will be realized in specitic driver C file
 * because drv_medium types vary from SDK
 */
int ptd_rgos_medium_drv_to_ptm(int drv_medium)
{
    int ptm_medium;

    ptm_medium = S_INTF__MEDIUM_TYPE_E__MEDIUM_UNKNOWN;
    if ((g_ptd != NULL) && g_ptd->drv_medium_to_ptm) {
        ptm_medium = g_ptd->drv_medium_to_ptm(drv_medium);
        SSA_PTD_ZLOG_NOTICE("ptm_medium[%d] rv[%d]\n", drv_medium, ptm_medium);
    }

    return ptm_medium;
}

/* unified func of get medium in rgos-adapter layer
 * ptd must be init and filled by caller
 */
int ptd_rgos_get_medium(ptd_info_t *ptd, int *ptm_medium)
{
    int rv;
    /* medium type from SDK drv */
    int drv_medium;
    /* medium type from NDM */
    int dev_medium;

    SSA_PORT_INIT_FUNC_ENTER;
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptm_medium);
    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);

    rv = SSA_PORT_E_NONE;
    dev_medium = ptd->dev_medium;
    SSA_PTD_ZLOG_NOTICE("dev_medium[%d]", dev_medium);

    if (dev_medium == PORT_MEDIUM_FIBER) {
        SSA_PTD_ZLOG_NOTICE("dev_medium is fiber!");
        *ptm_medium = S_INTF__MEDIUM_TYPE_E__FIBER;
    } else if (dev_medium == PORT_MEDIUM_COPPER) {
        SSA_PTD_ZLOG_NOTICE("dev_medium is copper!");
        *ptm_medium = S_INTF__MEDIUM_TYPE_E__COPPER;
    } else {
        SSA_PTD_ZLOG_NOTICE("dev_medium is fiber-copper!");
        /* fiber & copper combo port medium get, must use SDK func */
#if 1   /* this the right logic */
        drv_medium = 0;
        if ((g_ptd != NULL) && g_ptd->get_medium) {
            rv = g_ptd->get_medium(ptd->unit, ptd->port, &drv_medium);
            SSA_PTD_ZLOG_NOTICE("drv_medium[%d] rv[%d]", drv_medium, rv);
        }
        *ptm_medium = ptd_rgos_medium_drv_to_ptm(drv_medium);
#else
        /* get medium of fiber & copper combo port will fail in SDK
         * so just evade this problem now. support only the copper port
         */
        *ptm_medium = S_INTF__MEDIUM_TYPE_E__COPPER;
        SSA_PTD_ZLOG_NOTICE("ptm_medium[%d]", *ptm_medium);
#endif
    }
    SSA_PORT_INIT_FUNC_LEAVER;

    return rv;
}

/* only fill trans related ptd_infos
 * should be called after ptd_get_port_info_by_lport or ptd_get_port_info_by_lport
 */
void ptd_get_trans_info_by_lport(int lport, ptd_info_t *ptd)
{
    /* update the whole present states of all port from CPLD */

    if(ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC)) {
        ptd->present = 0;
        SSA_PTD_ZLOG_NOTICE("trans no exist lport %d\n", lport);
        return;
    }
    ptd->present = 1;

    (void)in_ssa_port_get_sfp_capability(lport, (ssa_port_sfp_module_capability_t *)&(ptd->trans_cap_detail));

    /* get the trans supported max rate */
    (void)in_ssa_port_get_trans_max_support_rate(lport, ptd->lport_max_rate, &(ptd->trans_rate), ptd->split_port_type, ptd->trans_cap_detail);

    /* get the trans module just want to know whether trans is copper-wire fiber-optical or AOC */
    (void)in_ssa_port_get_sfp_plug_mode(lport, ptd->lport_max_rate, &(ptd->trans_model), ptd->split_port_type, ptd->trans_cap_detail);

    SSA_PTD_ZLOG_NOTICE("trans_cap_detail[%d] trans_rate[%d] trans_model[%d]", ptd->trans_cap_detail, ptd->trans_rate, ptd->trans_model);
}

/* fill the content of ptd_info */
static int ptd_rgos_fill_ptd_info(ptd_info_t *ptd, int unit, int port, int lport, unsigned int phyid)
{
    PDev__UnitCportInfo *local;
    int ptm_medium;
    int rv;
    int dev_unit, dev_port;

    /* there is a special case where unit port is a split port
     * input args is the reak SDK unit port acquired from DDM.
     * but if we are to use NDM func to get dev-medium & dev-port-type
     * we must use fake dev-unit-port
     * so when using NDM func, use ddm-macro to get fake unit port
     */
    dev_unit = DDM_GET_UNIT(phyid);
    dev_port = DDM_GET_PORT(phyid);
    SSA_PTD_ZLOG_NOTICE("get dev-unit[%d] dev-port[%d]", dev_unit, dev_port);
    rv = ndm_get_local_port_by_unit_cport(dev_unit, dev_port, &local);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("get local port by unit port fail, ret = %d. unit %d port %d", rv, dev_unit, dev_port);
        return rv;
    }

    SSA_PTD_ZLOG_DEBUG("ptd_get_port_info_by_lport unit = %d, port = %d, lport = %d. port_type %d medium %d",
        unit, port, lport, local->static_info->type, local->static_info->pd_medium_type);
    ptd->unit = unit;
    ptd->port = port;
    ptd->dev_medium = local->static_info->pd_medium_type;
    rv = ptd_rgos_get_medium(ptd, &ptm_medium);
    if (rv != 0) {
        ndm_port_obj_free(local);
        SSA_PTD_ZLOG_ERROR("ptd_rgos_get_medium fail, ret = %d. unit %d port %d", rv, unit, port);
        return rv;
    }
    ptd->ptm_medium = ptm_medium;
    ptd->lport_max_rate = local->static_info->type;
    ptd->lport = lport;
    ptd->phyid = phyid;
    ndm_port_obj_free(local);

    /* here get the vsl info */

    /* here get the split info */
    /* split port judge considering using lport trans_lane config, here only need to determine whether is a split port */
    if (ssa_port_cfg_get_split_lport_lane_info(ptd->lport) != 0) {
        /* if this config not 0 means this is a split offspring port */
        ptd->split_port_type = 1;
    }

    SSA_PTD_ZLOG_NOTICE("ssa_port_cfg_get_split_lport_lane_info, lport = %d is_split[%d]",
        ptd->lport, ssa_port_cfg_get_split_lport_lane_info(ptd->lport));
    return 0;
}

int ptd_get_bp_port_info_by_phyid(unsigned int phyid, ptd_info_t *ptd)
{
    int unit, port, rv;

    SSA_PORT_NULL_PARAM_CHECK_RETURN(ptd);

    SSA_PTD_ZLOG_DEBUG("ptd_get_bp_port_info_by_phyid phyid[0x%x] start\n", phyid);

    rv = libddm_get_unit_port_by_lphyid(phyid, &unit, &port);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("get unit port by lphyid fail phyid %u rv %d\n", phyid, rv);
        return rv;

    }
    SSA_PTD_ZLOG_DEBUG("libddm_get_unit_port_by_lphyid unit[%d] port[%d] end\n", unit, port);

    ptd->unit = unit;
    ptd->port = port;
    ptd->phyid = phyid;

    return 0;

}

int ptd_get_port_info_by_lport(int lport, ptd_info_t *ptd)
{
    int unit, port, rv;
    unsigned int phyid;

    rv = libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("get unit port by lport fail lport %d rv %d\n", lport, rv);
        return rv;
    }

    rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("get phyid fail unit %d port %d rv %d\n", unit, port, rv);
        return rv;
    }

    rv = ptd_rgos_fill_ptd_info(ptd, unit, port, lport, phyid);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("ptd_rgos_get_ptd_info_mediums fail unit %d port %d rv %d\n", unit, port, rv);
        return rv;
    }

    return 0;

}

static void ptd_debug_bp_set_attr(int unit, int port)
{
    ptd_bp_attr_info_t ptd_attr_info;
    ptd_info_t ptd;

    /* 静态工具检查错误 */
    memset(&ptd_attr_info, 0, sizeof(ptd_bp_attr_info_t));
    ptd_attr_info.speed = 21000;
    ptd_attr_info.hg2_code = 1;
    ptd_attr_info.ifg = 1;
    ptd_attr_info.if_type = 0;//BCM_PORT_IF_XGMII;  NPS会重新定义 ，pengcheng

    memset(&ptd, 0, sizeof(ptd_info_t));
    ptd.unit = unit;
    ptd.port = port;
    g_ssa_port_debug = 1;

    SSA_PTD_ZLOG_DEBUG("bp_set_port_attr unit[%d] port[%d]", ptd.unit, ptd.port);
    (void)bp_set_port_attr(&ptd, &ptd_attr_info);
    SSA_PTD_ZLOG_DEBUG("speed %d hg2_code %d ifg %d if_type %d\n", ptd_attr_info.speed, ptd_attr_info.hg2_code, ptd_attr_info.ifg, ptd_attr_info.if_type);
    g_ssa_port_debug = 0;

    return;
}

int ptd_get_port_info_by_phyid(unsigned int phyid, ptd_info_t *ptd)
{
    int unit, port, rv;
    int lport, slot;

    rv = libddm_get_unit_port_by_lphyid(phyid, &unit, &port);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("get unit port by lport fail phyid %u rv %d\n", phyid, rv);
        return rv;

    }

    rv = libddm_get_slot_lport_by_unit_port(unit, port, &slot, &lport);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("get lport by unit port fail unit %d port %d rv %d\n", unit, port, rv);
        return rv;
    }

    rv = ptd_rgos_fill_ptd_info(ptd, unit, port, lport, phyid);
   if (rv != 0) {
       SSA_PTD_ZLOG_ERROR("ptd_rgos_get_ptd_info_mediums fail unit %d port %d rv %d\n", unit, port, rv);
       return rv;
   }

    return 0;

}

int ptd_get_lport_from_unit_port(int unit, int port, int *lport)
{
    int rv;
    int slot; /*we dont care about this */

    SSA_PORT_NULL_PARAM_CHECK_RETURN(lport);
    rv = libddm_get_slot_lport_by_unit_port(unit, port, &slot, lport);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("get lport fail unit[%d] port[%d]", unit, port);
        return SSA_PORT_E_RETURN;
    }

    return SSA_PORT_E_NONE;
}

static void ptd_debug_interface(int lport)
{
    ptd_info_t ptd;
    int rv;
    ptd_sdk_fiber_conf_info_t ptd_sdk_fiber_conf_info;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv) {
        printf("get port info by lport fail lport %d\n", lport);
        return ;
    }

    (void)ptd_get_trans_info_by_lport(lport, &ptd);
    g_ssa_port_debug = 1;
    SSTEST_DBG_TEST("get unit %d port %d lport %d lport_max_rate %d trans_rate %d trans_model %d present %d\n",
        ptd.unit, ptd.port, lport, ptd.lport_max_rate, ptd.trans_rate, ptd.trans_model, ptd.present);
    (void)ptd_set_interface(&ptd, &ptd_sdk_fiber_conf_info, NULL);

    g_ssa_port_debug = 0;

}

static void ptd_debug_firmod(int lport)
{
    ptd_info_t ptd;
    int rv;
    ptd_sdk_fiber_conf_info_t ptd_sdk_fiber_conf_info;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv) {
        printf("get port info by lport fail lport %d\n", lport);
        return ;
    }

    (void)ptd_get_trans_info_by_lport(lport, &ptd);


    g_ssa_port_debug = 1;
    SSTEST_DBG_TEST("get unit %d port %d lport %d lport_max_rate %d trans_rate %d trans_model %d present %d\n",
    ptd.unit, ptd.port, lport, ptd.lport_max_rate, ptd.trans_rate, ptd.trans_model, ptd.present);
    (void)ptd_set_firmode(&ptd, &ptd_sdk_fiber_conf_info, NULL);

    g_ssa_port_debug = 0;

}

static void ptd_debug_preemphasis(int lport)
{
    ptd_info_t ptd;
    int rv;
    ptd_sdk_fiber_conf_info_t ptd_sdk_fiber_conf_info;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv) {
        printf("get port info by lport fail lport %d\n", lport);
        return ;
    }

    (void)ptd_get_trans_info_by_lport(lport, &ptd);

    g_ssa_port_debug = 1;
    SSTEST_DBG_TEST("get unit %d port %d lport %d lport_max_rate %d trans_rate %d trans_model %d present %d\n",
        ptd.unit, ptd.port, lport, ptd.lport_max_rate, ptd.trans_rate, ptd.trans_model, ptd.present);
    //(void)ptd_set_preemphasis(&ptd, &ptd_sdk_fiber_conf_info, NULL);

    g_ssa_port_debug = 0;

}

static void ssa_ptd_set_zlog_level(int level)
{
    g_ssa_ptd_zlog_level = level;
}

//extern void ptd_dump_sdk_conf_cache(int unit);
//extern void ptd_print_split_cache_info(int unit);

extern int ptd_unit_port_split_info_get(int unit, int port, split_port_cache_t *split_port_cache);
extern bool ptd_unit_port_split_support(int unit, int port);
extern int ptd_unit_port_split_num_get(int unit, int port);
#if 0 
by pengcheng
static void ptd_test_split_info_get(int unit, int port)
{
    split_port_cache_t split_port_cache;
    int rv, i;
    int count;

    memset(&split_port_cache, 0, sizeof(split_port_cache_t));
    rv = ptd_unit_port_split_info_get(unit, port, &split_port_cache);
    if (rv != 0) {
        return;
    }
    SSA_PTD_ZLOG_NOTICE("unit[%d] port[%d] split_port_sup_type[%d] count[%d]",
        split_port_cache.unit, split_port_cache.port, split_port_cache.split_port_sup_type, split_port_cache.count);
    for (i = 0; i < split_port_cache.count; i++) {
        SSA_PTD_ZLOG_NOTICE("dev_fake_port[%d] sdk_real_port[%d]", split_port_cache.dev_chip_port[i], split_port_cache.real_chip_port[i]);
    }
    count = ptd_unit_port_split_num_get(unit, port);
    SSA_PTD_ZLOG_NOTICE("count:%d", count);

    return;
}
#endif
static void ptd_dump_sfp_present(int sync)
{
    int rv;

    if (sync == 1) {
        rv = ptd_trnas_update_sfp_dect_state();
        SSA_PTD_ZLOG_NOTICE("rv:%d", rv);
    }

    ptd_trans_dump_sfp_present();
}

static void ptd_debug_clear_mib_ex(int32_t lport)
{
    int unit = 0, port = 2;
    int rv;
    unsigned int phyid = 0x80006;

    g_ssa_port_debug = 1;
    rv	= libddm_get_unit_port_by_lport(lport, &unit, &port);
    if (rv != 0) {
        SSTEST_DBG_TEST("get gphyid by lport fail lport %d\n", lport);
        return;
    }

    rv = libddm_get_lphyid_by_unit_port(unit, port, &phyid);
    if (rv != 0) {
        SSTEST_DBG_TEST("get phyid by unit port fail unit %d port %d\n", unit, port);
        return;

    }
    printf("ptd_debug_clear_ex_mib unit %d port %d phyd %d lport %d\n", unit, port, phyid, lport);

    (void)ptd_clear_mib_ex(unit, port);
    g_ssa_port_debug = 0;

    return;
}

static void ptd_debug_bp_set_admin(int unit, int port, int enable)
{
    ptd_info_t ptd;

    g_ssa_port_debug = 1;

    memset(&ptd, 0, sizeof(ptd_info_t));
    ptd.unit = unit;
    ptd.port = port;
    SSA_PTD_ZLOG_DEBUG("bp_set_port_admin unit[%d] port[%d]", ptd.unit, ptd.port);

    if (enable) {
            bp_set_port_admin(&ptd, 1);
    } else {
            bp_set_port_admin(&ptd, 0);
    }

    g_ssa_port_debug = 0;

    return;
}

static void ptd_debug_get_port_interrupt(int unit, int port)
{
#if 0
	int linkscan_type;
    int rv;
    int lport;
    int phyid;
    int phy_type;
    ptd_info_t ptd;
    uint16_t copper_int_val, fiber_int_val;

    rv = libddm_get_lport_by_unit_port(unit, port, &lport);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("libddm_get_lport_by_unit_port err\n");
        return;
    }

    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("ptd_get_port_info_by_lport err\n");
        return;
    }

    if (!ssa_port_cfg_get_phy_scan(lport)) {
        SSA_PTD_ZLOG_FATAL("Not in the setting range\n");
        return;
    }

    phyid = ssa_port_cfg_get_phy_scan(ptd.lport);
    phy_type = ssa_port_cfg_get_ext_phy_type(phyid);
    linkscan_type = 1;
    rv = bcm_port_linkscan_get(unit, port, &linkscan_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_get error rv [%d]\n", rv);
        return;
    }
    rv = bcm_port_linkscan_set(unit, port, 0);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_set error rv [%d]\n", rv);
        return;
    }
    if (phy_type == 1) {
        if (ptd.dev_medium == PORT_MEDIUM_COPPER) {
            cust_ssa_port_read_phy542xx_reg(unit, port, 0xb, &copper_int_val);
        } else if (ptd.dev_medium == PORT_MEDIUM_FIBER) {
            cust_ssa_port_read_phy542xx_reg(unit, port, 0x32, &fiber_int_val);
        } else {
            cust_ssa_port_read_phy542xx_reg(unit, port, 0xb, &copper_int_val);
            cust_ssa_port_read_phy542xx_reg(unit, port, 0x32,&fiber_int_val);
        }
    } else if (phy_type == 2){
        SSA_PTD_ZLOG_FATAL("unsupoort phy type 84844\n");
    } else {
        SSA_PTD_ZLOG_FATAL("invalid phy type\n");
    }
    SSA_PTD_ZLOG_FATAL("unit %d port %d addr:0xb, copper value:%x, fiber value:%x\n", unit, port, copper_int_val, fiber_int_val);
    rv = bcm_port_linkscan_set(unit, port, linkscan_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_set error rv [%d]\n", rv);
        return;
    }
#else
//NPS需要重新实现，pengcheng
#endif
    return;
}

static void ptd_debug_set_port_interrupt(int unit, int port)
{
#if 0
	int linkscan_type;
    int rv;
    int lport;
    ptd_info_t ptd;

    rv = libddm_get_lport_by_unit_port(unit, port, &lport);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("libddm_get_lport_by_unit_port err\n");
        return;
    }

    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("ptd_get_port_info_by_lport err\n");
        return;
    }

    if (!ssa_port_cfg_get_phy_scan(lport)) {
        SSA_PTD_ZLOG_FATAL("Not in the setting range\n");
        return;
    }

    linkscan_type = 1;
    rv = bcm_port_linkscan_get(unit, port, &linkscan_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_get error rv [%d]\n", rv);
        return;
    }
    rv = bcm_port_linkscan_set(unit, port, 0);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_set error rv [%d]\n", rv);
        return;
    }
    ptd_write_port_link_inter(&ptd);
    SSA_PTD_ZLOG_FATAL("unit %d port %d addr:0xb, copper value:%x, fiber value:%x\n", unit, port,
        ssa_port_cfg_get_copper_interrupt_value(), ssa_port_cfg_get_fiber_interrupt_value());
    rv = bcm_port_linkscan_set(unit, port, linkscan_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_set error rv [%d]\n", rv);
        return;
    }
#else
	//NPS需要重新实现，pengcheng
#endif
    return;
}

static void ptd_debug_get_port_interrupt_status(int unit, int port)
{
#if 0
	int linkscan_type;
    int rv;
    int lport;
    ptd_info_t ptd;
    uint16_t copper_data, fiber_data;

    rv = libddm_get_lport_by_unit_port(unit, port, &lport);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("libddm_get_lport_by_unit_port err\n");
        return;
    }

    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSA_PTD_ZLOG_FATAL("ptd_get_port_info_by_lport err\n");
        return;
    }

    if (!ssa_port_cfg_get_phy_scan(lport)) {
        SSA_PTD_ZLOG_FATAL("Not in the setting range\n");
        return;
    }

    linkscan_type = 1;
    rv = bcm_port_linkscan_get(unit, port, &linkscan_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_get error rv [%d]\n", rv);
        return;
    }
    rv = bcm_port_linkscan_set(unit, port, 0);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_set error rv [%d]\n", rv);
        return;
    }
    ptd_read_port_link_inter(&ptd, &copper_data, &fiber_data);
    SSA_PTD_ZLOG_FATAL("unit %d port %d addr:0xb, copper status value:%x, fiber status value:%x\n",
        unit, port, copper_data, copper_data);
    rv = bcm_port_linkscan_set(unit, port, linkscan_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("bcm_port_linkscan_set error rv [%d]\n", rv);
        return;
    }
#else
	//NPS需要重新实现，pengcheng
#endif
    return;
}

void ut_ptd_debug_init(rg_global_t *global)
{
    at_ctrl_info_t *pos = NULL;
    static int init = 0;
    int ret;

    if (init) {
        return;
    }
    init = 1;

    pos = (at_ctrl_info_t *)malloc(sizeof(at_ctrl_info_t));
    if (pos == NULL) {
        printf("name[%s] malloc mem fail\r\n", "ptd_debug_test");
        return;
    }
    memset(pos, 0, sizeof(at_ctrl_info_t));
    ret = ssat_multi_thread_init(global, "ptd_debug_test", pos);
    if (ret != 0) {
        printf("name[%s] ssat_multi_thread_init fail\r\n", "ptd_debug_test");
        free(pos);
        return;
    }

    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_cpld", "addr=%d, val=%d, flag=%d", ptd_debug_cpld);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_i2c", "port=%d, addr=%d, val=%d, flag=%d", ptd_debug_i2c);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_on_off", "enable=%d", ptd_debug_on_off);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_time_record", "enable=%d", ptd_debug_time_record);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_read_config", "void", ptd_debug_read_config);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_getmedium", "lport=%d", ptd_debug_getmedium);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_setmedium", "lport=%d, medium=%d", ptd_debug_setmedium);
    //SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_admin", "lport=%d, enable=%d", ptd_debug_admin);
    //SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_loop", "lport=%d, enable=%d", ptd_debug_loop);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_open_trans", "lport=%d, enable=%d", ptd_debug_open_trans);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_ddev", "void", ptd_debug_ddev);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_mtu", "lport=%d, mtu=%d", ptd_debug_mtu);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_set_attr", "lport=%d, speed=%d, an=%d, flow=%d, duplex=%d fec=%d", ptd_debug_set_attr);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_clear_mib", "lport=%d", ptd_debug_clear_mib);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_interface", "lport=%d", ptd_debug_interface);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_firmod", "lport=%d", ptd_debug_firmod);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_preemphasis", "lport=%d", ptd_debug_preemphasis);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_get_trans_speed", "lport=%d", ptd_debug_get_trans_speed);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_check_trans_exist", "lport=%d", ptd_debug_check_trans_exist);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_get_trans_plug", "phyid=%u", ptd_debug_get_trans_plug);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_set_trans_power", "void", ptd_debug_set_trans_power);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ssa_ptd_set_zlog_level", "level=%d", ssa_ptd_set_zlog_level);
    //SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_dump_sdk_conf_cache", "unit=%d", ptd_dump_sdk_conf_cache);
    //SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_print_split_cache_info", "unit=%d", ptd_print_split_cache_info);
    //SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_unit_port_split_support", "unit=%d port=%d", ptd_unit_port_split_support);
    //SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_test_split_info_get", "unit=%d port=%d", ptd_test_split_info_get);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ssa_port_read_cfg", "void", ssa_port_read_cfg);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_dump_enable_flag", "void", ptd_dump_enable_flag);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_dump_sfp_present", "sync=%d", ptd_dump_sfp_present);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_clear_mib_ex", "lport=%d", ptd_debug_clear_mib_ex);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_bp_set_admin", "unit=%d port=%d enable =%d", ptd_debug_bp_set_admin);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_bp_set_attr", "unit=%d port=%d", ptd_debug_bp_set_attr);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_get_port_interrupt", "unit=%d port=%d", ptd_debug_get_port_interrupt);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_set_port_interrupt", "unit=%d port=%d", ptd_debug_set_port_interrupt);
    SSAT_MULTI_THREAD_CMD_REG(pos, "ptd_debug_test", "ptd_debug_get_port_interrupt_status", "unit=%d port=%d", ptd_debug_get_port_interrupt_status);

    return;
}

static int get_int_by_file(char * path, int def_timeout)
{
    int fd, num, ret;
    char buf[PTD_DBG_FIEL_BUF_LEN];

    fd = open(path, O_RDONLY);
    if (fd < 0) {
        return def_timeout;
    }
    memset(buf, 0, sizeof(buf));
    ret = read(fd, buf, PTD_DBG_FIEL_BUF_LEN);
    if (ret <= 0) {
        close(fd);
        return def_timeout;
    }
    num = atoi(buf);
    close(fd);

    return num;
}

void ptd_zlog_debug_init(void)
{
    int dbg_level;

    dbg_level = get_int_by_file(PTD_ZLOG_DBG_FILE, RGDF_ZLOG_LV_DEBUG);
    ssa_ptd_set_zlog_level(dbg_level);

    g_ssa_ptd_zlog_category = rg_zlog_init("ssa_ptd");
    if (g_ssa_ptd_zlog_category == NULL) {
        SSA_PTD_ZLOG_WARN("zlog debug init fail.");
    }
    return;
}

void ptd_debug_init(rg_global_t *global, int unit)
{
    ut_ptd_debug_init(global);

    return;
}

