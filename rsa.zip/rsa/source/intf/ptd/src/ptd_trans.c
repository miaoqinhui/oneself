/*
  * Copyright(C) 2001-2012 Ruijie Network. All rights reserved.
  */
/*
  * ssa_port_trans.c
  * Original Author: xudongxu@ruijie.com.cn 2017-08-22
  *
  * port模块光模块操作
  *
  * History 2017-08-22
  * 先把模块相关的全放着
  * 光模块搞成驱动 采用代码静态分离的方案
  */

#include "../include/ptd_init.h"
#include "../include/ptd_debug.h"
#include "../include/ptd_mom.h"
#include "../include/ptd_type.h"

/* not containing bsl debug log */

#define SPLIT_NUM 4

int    g_ssa_port_arry_speed[MAX_LPORT_NUM];       /* 取最多端口为48个 */
static unsigned char g_ssa_port_sfp_off[MAX_LPORT_GROUP];     /* 存储光模块是否打开关闭的状态 */
static unsigned char sfp_dect_cpld_reg_val[MAX_CPLD_DECT_REG_NUM];  /* array that keep read val off cpld val */
//static bcm_pbmp_t g_ssa_port_exit_sfp;

extern int    g_ssa_port_sfp_type[MAX_LPORT_NUM];
extern int ptd_mom_fiber_notify(ptd_info_t *ptd, rg_global_t *global);
extern int32_t ssa_port_cfg_get_cpld_enable_sfp_addr(int32_t lport);
extern int ptd_cpld_enable_sfp(int unit);

void ptd_trans_dump_sfp_present(void)
{
    int i;

    for (i = 0; i < MAX_CPLD_DECT_REG_NUM; i++) {
        SSA_PTD_ZLOG_FATAL("sfp_dect_cpld_reg_val[%d]:0x%x\n", i, sfp_dect_cpld_reg_val[i]);
    }
}

/* this func updates hw-state into cache */
int ptd_trnas_update_sfp_dect_state(void)
{
    char *cpld_name = NULL;
    char cpld_dev_name[MAX_NAME_LEN] = {0};
    int cpld_addr, i, rv;
    unsigned char value;

    /* fix cpld_name dev name in the future! may have multiple CPLD dev
     * to do...
     */
    cpld_name = ptd_cfg_get_sfp_cpld_dev_name(1);
    if (cpld_name == NULL || cpld_name[0] == 0) {
        snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", CPLD_DEV_PATH);
    } else {
        snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", cpld_name);
    }

    cpld_addr = 0;
    for (i = 0; i < MAX_CPLD_DECT_REG_NUM; i++) {
        cpld_addr = ssa_port_cfg_get_sfp_present_cache(i+1);
        /* COV:XMB cpld_addr may be negetive value, if the i+1 is invalid. this situation must be seen as err */
        if (cpld_addr <= 0) {
            continue;
        }
        SSA_PTD_ZLOG_NOTICE("cpld_dev_name[%s] cpld_addr[%d]:0x%x", cpld_dev_name, i, cpld_addr);
        rv = ptd_read_cpld(cpld_dev_name, cpld_addr, &value, 1);
        if (rv < 0) {
            SSA_PTD_ZLOG_ERROR("Read cpld failed, rv %d", rv);
            return SSA_PORT_E_RETURN;
        }
        sfp_dect_cpld_reg_val[i] = value;
        SSA_PTD_ZLOG_NOTICE("sfp_dect_cpld_reg_val[%d]:0x%x", i, sfp_dect_cpld_reg_val[i]);
    }

    return SSA_PORT_E_NONE;
}

static int ptd_get_trans_info(int lport, ptd_info_t *ptd, int unit)
{
    ptd_get_trans_info_by_lport(lport, ptd);

    if (g_ssa_port_sfp_type[lport - 1] == SSA_PORT_GT) {
        ptd->trans_model = S_INTF__PLUG_TYPE_E__PLUG_TYPE_FIBER_GT;
        SSA_PTD_ZLOG_DEBUG("SSA_PORT_GT unit[%d] port[%d] trans_model[%d]!", ptd->unit, ptd->port, ptd->trans_model);
    } else if (ptd->trans_model == I2C_SFP_TYPE_COPPER) {
        ptd->trans_model = S_INTF__PLUG_TYPE_E__PLUG_TYPE_COPPER;
        SSA_PTD_ZLOG_DEBUG("I2C_SFP_TYPE_COPPER unit[%d] port[%d] trans_model[%d]!", ptd->unit, ptd->port, ptd->trans_model);
    } else {
        if (ptd->trans_rate == 0) {
            SSA_PTD_ZLOG_DEBUG("unkown sfp speed lport %d\n", lport);
            ptd->trans_model = S_INTF__PLUG_TYPE_E__PLUG_TYPE_UNKNOW;
        } else {
            ptd->trans_model = S_INTF__PLUG_TYPE_E__PLUG_TYPE_FIBER;
            SSA_PTD_ZLOG_DEBUG("else else unit[%d] port[%d] trans_model[%d]!", ptd->unit, ptd->port, ptd->trans_model);
        }
    }

    return SSA_PORT_E_NONE;
}

/* this func is only for update the initial trans present situation to PTM
 * MAKE SURE this api is called after the ptd_trnas_update_sfp_dect_state()
 * cause we need to know the real present info from hardware
 * and this api is only called once in the init phase
 */
static int ptd_sfp_preset_init_notify(rg_global_t *global, int unit)
{
    int lport_min, lport_max, lport;
    ptd_info_t ptd;
    int rv;

    lport_min = ssa_port_cfg_get_adjust_lport_min();
    lport_max = ssa_port_cfg_get_adjust_lport_max();

    /* 只有电口的线卡 */
    if ((lport_min == 0) && (lport_max == 0)) {
        return SSA_PORT_E_NONE;
    }

    if ((lport_max > MAX_LPORT_NUM) || (lport_max < 1) || (lport_min < 1)
            || (lport_min > lport_max)) {
        SSA_PTD_ZLOG_ERROR("lport invalid, lport_min, %u, lport_max %u", lport_min, lport_max);
        return -1;
    }

    for (lport = lport_min; lport <= lport_max; lport++) {
        memset(&ptd, 0, sizeof(ptd_info_t));
        rv = ptd_get_port_info_by_lport(lport, &ptd);
        if (rv != 0) {
            SSA_PTD_ZLOG_ERROR("get port info by lport fail lport %d\n", lport);
            continue;
        }

        if (ptd.unit != unit) {
            SSA_PTD_ZLOG_WARN("no same unit, current unit %d, get unit %d lport %d\n", unit, ptd.unit, lport);
            continue;
        }

        /* copper port need not trans present info */
        if (ptd.ptm_medium == S_INTF__MEDIUM_TYPE_E__COPPER) {
            SSA_PTD_ZLOG_INFO("port is copper just return lport %d", lport);
            continue;
        }

        /* get the present info of this lport */
        if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC)) {
            ptd.present = 0;
            SSA_PTD_ZLOG_NOTICE("trans no exist lport[%d]\n", lport);
        } else {
            ptd.present = 1;
            SSA_PTD_ZLOG_NOTICE("trans    exist lport[%d]\n", lport);
        }

        /* in this api we dont use handle_type, we just want to tell PTM the init trans present situation */
        if (ptd.present == 1) {
            rv = ptd_get_trans_info(lport, &ptd, unit);
            if (rv < 0) {
                SSA_PTD_ZLOG_INFO("ptd_get_info fail, lport %d\n", lport);
                continue;
            }
        }

        /* here notify directly */
        SSA_PTD_ZLOG_NOTICE("lport[%d] init notify, present 0x%x\n", lport, ptd.present);
        if (ptd_mom_fiber_notify(&ptd, global) != SSA_PORT_E_NONE) {
            SSA_PTD_ZLOG_DEBUG("in_ssa_port_fiber_notify fail, lport %d\n", lport);
            continue;
        }
    }

    return SSA_PORT_E_NONE;
}

/* trans related init */
int ptd_trans_init(rg_global_t *global, int unit)
{
    int i, ret;
    /* now we only have one thing here
     * to ini sfp_dect_cpld_reg_val array. by default, we see all trans are not present
     */

    for (i = 0; i < MAX_CPLD_DECT_REG_NUM; i++) {
        sfp_dect_cpld_reg_val[i] = 0xff;
    }

    ret = ptd_cpld_enable_sfp(unit);
    if (ret != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("in_ssa_port_cpld_enable_sfp set failed, rv %d\n", ret);
        return ret;
    }

    /* FOR  BUG472142 we update cache from HW imediatly we init the1 cache
     * in case the sfp-irq comes later than PTM-config, which will cause problem 1
     * in bug472142
     */

    ret = ptd_trnas_update_sfp_dect_state();
    if (ret != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("ptd_trnas_update_sfp_dect_state failed, ret %d", ret);
        return ret;
    }

    ret = ptd_sfp_preset_init_notify(global, unit);
    if (ret != SSA_PORT_E_NONE) {
        SSA_PTD_ZLOG_ERROR("ptd_sfp_preset_init_notify failed, ret %d", ret);
        return ret;
    }

    return SSA_PORT_E_NONE;
}

static int in_ssa_port_sfp_get_qsfp_speed(ssa_port_sfp_module_capability_t capability)
{
    switch (capability) {
    case SSA_PORT_SFP_UNKNOW:
        return 0;
    case SSA_PORT_QSFP_40G_AOC:
    case SSA_PORT_QSFP_40GBASE_LR4:
    case SSA_PORT_QSFP_40GBASE_SR4:
    case SSA_PORT_QSFP_40GBASE_ER4:
    case SSA_PORT_QSFP_40GBASE_ZR4:
    case SSA_PORT_QSFP_40G_COPPER:
        return 40000;
    case SSA_PORT_QSFP28_100G_AOC:
    case SSA_PORT_QSFP28_100GBASE_LR4:
    case SSA_PORT_QSFP28_100GBASE_PSM4:
    case SSA_PORT_QSFP28_100GBASE_SR4:
    case SSA_PORT_QSFP28_100GBASE_ER4:
    case SSA_PORT_QSFP28_100GBASE_ZR4:
    case SSA_PORT_QSFP28_100G_COPPER:
        return 100000;
    default:
        return 0;
    }

    return 0;
}

int in_ssa_port_sfp_is_need_set_fec(ssa_port_sfp_module_capability_t capability)
{
    switch (capability) {
    case SSA_PORT_QSFP28_100GBASE_SR4:
    case SSA_PORT_QSFP28_100G_COPPER:
    case SSA_PORT_QSFP28_100G_AOC:
    case SSA_PORT_QSFP28_100GBASE_PSM4:
        return 1;
    default:
        return 0;
    }

    return 0;
}

/* 获取光模块中某一个寄存器的值 */
static int in_ssa_port_get_ts_reg_value(int lport, unsigned char *i2c_val, unsigned short offset)
{
    ssa_port_pca9548_info_t dev_info;
    int i, rv;

    if (offset > 0xff) {
        SSTEST_DBG_ERR("too large offset: 0x%x\n", offset);
        return SSA_PORT_E_IVPARAM;
    }

    rv = out_ssa_port_get_9548info_by_lport(lport, &dev_info, 0);
    if (rv) {
        SSTEST_DBG_ERR("Get 9548 info failed, rv %d\n", rv);
        return rv;
    }
    for (i = 0; i <= 5; i ++) {
        /* 读取光模块中偏移值为offset的寄存器的值 */
        rv = ptd_read_i2c(dev_info.pca9548_channel_name, dev_info.addr_sfp, offset, i2c_val, 1, 0);
        if (rv < 0) {
            SSTEST_DBG_TEST("open qsfp failed, channel_name %s dev_addr 0x%x offset_addr 0x%x rv%d\n",
                dev_info.pca9548_channel_name, dev_info.addr_sfp, offset, rv);
            usleep(100000);
            rv = SSA_PORT_E_RETURN;
        } else {
            rv = SSA_PORT_E_NONE;
            break;
        }
    }
    SSTEST_DBG_TEST("open qsfp, channel_name %s dev_addr 0x%x offset_addr 0x%x rv%d\n",
        dev_info.pca9548_channel_name, dev_info.addr_sfp, offset, rv);

    return rv;
}


/* 判断千兆或者万兆光模块是否存在，返回0表示存在，1表示不存在 */
int32_t ptd_trans_get_ts_exist(int lport, int sync_type)
{
    int rv;
    int reg_index, lport_tmp, exchange;
    unsigned char sfp_stat;

    if (sync_type == PTD_SFP_DECT_SYNC) {
        rv = ptd_trnas_update_sfp_dect_state();
        if (rv != SSA_PORT_E_NONE) {
            /* notify sync hw state fail, we just proceed, using cache state */
            SSA_PTD_ZLOG_ERROR("ptd_trnas_update_sfp_dect_state failp[%d], lport[%d]\n", rv, lport);
        }
    }

    /* get state from cache */
    lport_tmp = ssa_port_cfg_get_cpld_offset_reg(lport);
    reg_index = ssa_port_cfg_get_sfp_present_cache_dect(lport);
    exchange = ssa_port_cfg_get_cpld_exchange(lport);
    sfp_stat = 0xff;
    /* 静态工具检查，当获取到的reg_index小于1时，会导致越界，当lport_tmp小于1时会出现未知的移位 */
    if (reg_index <= 0 || lport_tmp <= 0) {
        SSA_PTD_ZLOG_ERROR("get cpld_offset_reg[%d] reg_index[%d] error!\n", lport_tmp, reg_index);
        return SSA_PORT_E_IVPARAM;
    }
    sfp_stat = sfp_dect_cpld_reg_val[reg_index - 1];
    lport_tmp -= 1;
    if (exchange > 0) {
        if (lport_tmp % 2) {
            lport_tmp -= 1;
        } else {
            lport_tmp += 1;
        }
    }
    sfp_stat = sfp_stat & (1 << lport_tmp);
    SSA_PTD_ZLOG_WARN("sfp_stat:0x%x, lport[%d]", sfp_stat, lport);

    return sfp_stat;
}

/* 光模块识别规范
  40G-Active Cable-QSFP+      "寄存器第128字节的值为0x0d代表QSFP+,寄存器的140字节值在0x5a与0x78之间[5a-78,即9000M—12000M速率带宽]，代表40G；((byte130==0x21)&&(byte131 bit3!=1))==1代表AOC;或者：byte130==0x23也代表AOC.           "
  40GBASE-LR4-QSFP+       "寄存器第128字节的值为0x0d代表QSFP+,寄存器的140字节值在0x5a与0x78之间[5a-78,即9000M—12000M速率带宽]，代表40G；{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 bit1==1)}==1代表LR4."
  40GBASE-SR4-QSFP+       "寄存器第128字节的值为0x0d代表QSFP+,寄存器的140字节值在0x5a与0x78之间[5a-78,即9000M—12000M速率带宽]，代表40G；{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 bit2==1)}==1代表SR4."
  40GBASE-ER4-QSFP+       "寄存器第128字节的值为0x0d代表QSFP+,寄存器的140字节值在0x5a与0x78之间[5a-78,即9000M—12000M速率带宽]，代表40G；{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 ==0X80)}&&{byte142的值在0x0F与0x32之间（代表传输距离为15Km~50km）}==1代表ER4."
  40GBASE-ZR4-QSFP+       "寄存器第128字节的值为0x0d代表QSFP+,寄存器的140字节值在0x5a与0x78之间[5a-78,即9000M—12000M速率带宽]，代表40G；{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 ==0X80)}&&{byte142的值在0x33与0x5a之间（代表传输距离为51Km~90km）}==1代表ZR4."
  40G-Copper-QSFP+        "寄存器第128字节的值为0x0d代表QSFP+,""寄存器的140字节值在0x5a与0x78之间[5a-78,即9000M—12000M速率带宽]""(140字节不再作判断)，代表40G；((byte130==0x21)&&(byte131 bit3==1)&&(byte131 bit7!=1))==1代表CR4"
  100G-Active Cable-QSFP28        "byte128的值为0x11或0x0d,{(byte131 bit7==1)&&(byte192==0x01||byte192==0x18)}==1,则代表QSFP28 AOC。Connector Type显示为：No sparable connector"
  100GBASE-SR4-QSFP28     "byte128的值为0x11或0x0d,代表QSFP28,{(byte131 bit7==1)&&(byte192==0x02)}==1,则代表QSFP28 SR4;其它显示字段解析方式同40G QSFP+。"
  100GBASE-LR4-QSFP28     "byte128的值为0x11或0x0d,{(byte131 bit7==1)&&【(byte192==0x03)||(byte192==0x06)||(byte192==0x07)||(byte192==0x09)】}==1，代表QSFP28 LR4。其它显示字段解析方式同40G QSFP+。"
  100GBASE-ER4-QSFP28     "byte128的值为0x11或0x0d，{(byte131 bit7==1)&&【(byte192==0x03)||(byte192==0x06)||(byte192==0x07)||(byte192==0x09)】&&{byte142的值在0x0F与0x32之间（代表传输距离为15Km~50km）}==1，代表QSFP28 ER4。其它显示字段解析方式同40G QSFP+。"
  100GBASE-ZR4-QSFP28     "byte128的值为0x11或0x0d,{(byte131 bit7==1)&&【(byte192==0x03)||(byte192==0x06)||(byte192==0x07)||(byte192==0x09)】&&{byte142的值在0x33与0x5A之间（代表传输距离为51Km~90km）}==1，代表QSFP28 ZR4。其它显示字段解析方式同40G QSFP+。"
  100GBASE-Copper-QSFP28      "byte128的值为0x11或0x0d，{(byte131 bit7==1)&&(byte192==0x08||byte192==0x0b)}==1,则代表QSFP28 copper;Connector Type显示为：No sparable connector"
  */
int in_ssa_port_get_sfp_capability(int lport, ssa_port_sfp_module_capability_t *capability)
{
    int rv;
    unsigned short addr_sfp;
    char *i2c_name;
    unsigned char recv_buf[256];
    int read_time;
    ssa_port_sfp_module_capability_t tmp_capability;

    rv = SSA_PORT_E_NONE;
    tmp_capability = SSA_PORT_SFP_UNKNOW;

    if (lport <= 0 || lport > MAX_LPORT_NUM) {/* wm mod */
        SSA_PTD_ZLOG_ERROR("lport invalid, lport %d\n", lport);
        return SSA_PORT_E_RETURN;
    }

    memset(recv_buf, 0, 3 * sizeof(uint8_t));
    if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC) == 0) {
        SSA_PTD_ZLOG_INFO("lport:%d sfp existed\n", lport);
        memset(recv_buf, 0, sizeof(recv_buf));
        i2c_name = ssa_port_cfg_get_sfp_i2c_dev_name(lport);
        addr_sfp = (uint16_t)ssa_port_cfg_get_sfp_on_i2c_addr();
        for (read_time = 0; read_time < 6; read_time++) {
            rv = ptd_read_i2c(i2c_name, addr_sfp, 128, recv_buf + 128, 100, 0);
            if (rv < 0) {
                 SSA_PTD_ZLOG_INFO("time %d get speed failed, i2c %s, add_sfp %d, offset 128\n"
                                    , read_time, i2c_name, addr_sfp);
                usleep(80000);  /* 有的模块插入会失败，sleep 下重新读 */
                continue;
            } else {
                rv = SSA_PORT_E_NONE;
            }

            break;
        }

        if (rv < 0) {
            SSA_PTD_ZLOG_ERROR("get sfp e2prom fail! lport %d i2c_name %s\n", lport, i2c_name);
            rv = SSA_PORT_E_RETURN;
            goto exit;
        }
     }

     SSTEST_DBG_TEST("ID: [128 : 0x%x],[130 : 0x%x] [131 : 0x%x] [132 : 0x%x] [140 : 0x%x], [142 : 0x%x] [192 : 0x%x] \n"
                        , recv_buf[128], recv_buf[130], recv_buf[131], recv_buf[132], recv_buf[140], recv_buf[142], recv_buf[192]);

     //((byte130==0x21)&&(byte131 bit3==1)&&(byte131 bit7!=1))==1代表CR4 COPPER
     if ((recv_buf[128] == 0xd || recv_buf[128] == 0xc) && recv_buf[130] == 0x21
            && (recv_buf[131] & 0x8) && ((recv_buf[131] & 0x80) == 0)) {
        tmp_capability = SSA_PORT_QSFP_40G_COPPER;
     } else if ((recv_buf[128] == 0xd || recv_buf[128] == 0xc) && recv_buf[140] >= 0x5a && recv_buf[140] <= 0x78) {
        //((byte130==0x21)&&(byte131 bit3!=1))==1代表AOC;或者：byte130==0x23也代表AOC.
        if ((recv_buf[130] == 0x21 && ((recv_buf[131] & 0x8) == 0)) || (recv_buf[130] == 0x23)) {
            tmp_capability = SSA_PORT_QSFP_40G_AOC;
        //{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 bit1==1)}==1代表LR4.
        } else if ((recv_buf[130] != 0x21 && recv_buf[130] != 0x23) && (recv_buf[131] & 0x2)) {
            tmp_capability = SSA_PORT_QSFP_40GBASE_LR4;
        //{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 bit2==1)}==1代表SR4
        } else if ((recv_buf[130] != 0x21 && recv_buf[130] != 0x23) && (recv_buf[131] & 0x4)) {
            tmp_capability = SSA_PORT_QSFP_40GBASE_SR4;
        //{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 ==0X80)}&&{byte142的值在0x0F与0x32之间（代表传输距离为15Km~50km）}==1代表ER4
        } else if (recv_buf[130] != 0x21 && recv_buf[130] != 0x23 && recv_buf[131] == 0x80
                && recv_buf[142] >= 0xf && recv_buf[142] <= 0x32) {
            tmp_capability = SSA_PORT_QSFP_40GBASE_ER4;
        //{((byte130!=0x21)&&(byte130!=0x23))&&(byte131 ==0X80)}&&{byte142的值在0x33与0x5a之间（代表传输距离为51Km~90km）}==1代表ZR4
        } else if (recv_buf[130] != 0x21 && recv_buf[130] != 0x23 && recv_buf[131] == 0x80
                && recv_buf[142] >= 0x33 && recv_buf[142] <= 0x5a) {
            tmp_capability = SSA_PORT_QSFP_40GBASE_ZR4;
        } else if (recv_buf[130] != 0x21 && recv_buf[130] != 0x23) {
            /* 增加容错处理，通过媒介类型确定，当前插入的光模块,默认是SR4 */
            tmp_capability = SSA_PORT_QSFP_40GBASE_SR4;
        } else {
            /* 否则就是铜榄*/
            tmp_capability = SSA_PORT_QSFP_40G_COPPER;
        }
     } else if (recv_buf[128] == 0xd || recv_buf[128] == 0x11) {
        //{(byte131 bit7==1)&&(byte192==0x01||byte192==0x18)}==1,则代表QSFP28 AOC。Connector Type显示为：No sparable connector"
        if ((recv_buf[131] & 0x80)&& (recv_buf[192] == 0x1 || recv_buf[192] == 0x18)) {
            tmp_capability = SSA_PORT_QSFP28_100G_AOC;
        // {(byte131 bit7==1)&&(byte192==0x02)}==1,则代表QSFP28 SR4;
        } else if ((recv_buf[131] & 0x80)&& (recv_buf[192] == 0x2)) {
            tmp_capability = SSA_PORT_QSFP28_100GBASE_SR4;
        // {(byte131 bit7==1)&&【(byte192==0x03)||(byte192==0x06)||(byte192==0x07)||(byte192==0x09)】}==1，代表QSFP28 LR4
        } else if ((recv_buf[131] & 0x80) && (recv_buf[192] == 0x3 || recv_buf[192] == 0x6
                || recv_buf[192] == 0x7 || recv_buf[192] == 0x9)) {
                /* PSM4会被识别成lr4，如果byte 192为0x7，表示psm4 */
            tmp_capability = (recv_buf[192] == 0x7) ? SSA_PORT_QSFP28_100GBASE_PSM4 : SSA_PORT_QSFP28_100GBASE_LR4;
        //{(byte131 bit7==1)&&【(byte192==0x03)||(byte192==0x06)||(byte192==0x07)||(byte192==0x09)】&&{byte142的值在0x0F与0x32之间（代表传输距离为15Km~50km）}==1，代表QSFP28 ER4
        } else if ((recv_buf[131] & 0x80) && (recv_buf[192] == 0x3 || recv_buf[192] == 0x6
                || recv_buf[192] == 0x7 || recv_buf[192] == 0x9) && recv_buf[142] >= 0xf
                && recv_buf[142] <= 0x32) {
            tmp_capability = SSA_PORT_QSFP28_100GBASE_ER4;
        //{(byte131 bit7==1)&&【(byte192==0x03)||(byte192==0x06)||(byte192==0x07)||(byte192==0x09)】&&{byte142的值在0x33与0x5A之间（代表传输距离为51Km~90km)==1，代表QSFP28 ZR4
        } else if ((recv_buf[131] & 0x80) && (recv_buf[192] == 0x3 || recv_buf[192] == 0x6
                || recv_buf[192] == 0x7 || recv_buf[192] == 0x9) && recv_buf[142] >= 0x33
                && recv_buf[142] <= 0x5a) {
            tmp_capability = SSA_PORT_QSFP28_100GBASE_ZR4;
        //{(byte131 bit7==1)&&(byte192==0x08||byte192==0x0b)}==1,则代表QSFP28 copper;
        } else if ((recv_buf[131] & 0x80) && (recv_buf[192] == 0x8 || recv_buf[192] == 0xb)) {
            tmp_capability = SSA_PORT_QSFP28_100G_COPPER;
        } else if (recv_buf[130] != 0x21 && recv_buf[130] != 0x23) {
            /* 增加容错处理，通过媒介类型确定，当前插入的光模块,默认是sr4*/
            tmp_capability = SSA_PORT_QSFP28_100GBASE_SR4;
        } else {
            /* 否则就是铜榄*/
            tmp_capability = SSA_PORT_QSFP28_100G_COPPER;
        }
    }

exit:
    SSA_PTD_ZLOG_INFO("Last, lport %d tmp_capability %d\n", lport, tmp_capability);
    *capability = tmp_capability;

    return rv;
}

/* 打开40G光模块 */
static int in_ssa_port_open_qfp(int lport, int disable, int split_flag)
{
    int slport_lane;
    ssa_port_ts_info_t fp_ts;
    ssa_port_pca9548_info_t pca9548;
    unsigned char   i2c_val[1], value;
    int rv;

    fp_ts.ret = 0;
    fp_ts.table_id = 0;
    fp_ts.type = 0;
    fp_ts.dep_ready = 0;
    fp_ts.data_len = 1;
    fp_ts.addr = I2C_SFP_40G_TYPE_ADDR;

    if (in_ssa_port_get_ts_reg_value(lport, i2c_val, fp_ts.addr) != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("ssa_port_get_qfp_info failed\n");
        return SSA_PORT_E_RETURN;
    }

    /* 铜缆直接返回 */
    if (i2c_val[0] == I2C_SFP_TYPE_COPPER) {
        SSTEST_DBG_TEST("copper can not open tx_disable\n");
        return SSA_PORT_E_NONE;
    }

    /* 40G光模块控制发光(tx_disable)地址 */
    fp_ts.addr = I2C_QSFP_TX_DISABLE_ADDR;
    if (in_ssa_port_get_ts_reg_value(lport, i2c_val, fp_ts.addr) != SSA_PORT_E_NONE) {
        SSTEST_DBG_ERR("ssa_port_get_qfp_info failed\n");
        return SSA_PORT_E_RETURN;
    }

    value = i2c_val[0];
    if (disable > 0) {
        if (split_flag) {
            /* 静态工具检查，如果ssa_port_cfg_get_split_lport_lane_info返回的值小于0，则直接返回，不移位 */
            slport_lane = ssa_port_cfg_get_split_lport_lane_info(lport);
            if (slport_lane <= 0) {
                SSA_PTD_ZLOG_ERROR("get slport_lane[%d] error\n", slport_lane);
                return SSA_PORT_E_IVPARAM;
            }
            /* 86寄存器的0 ~ 3位，0开启，1关闭 */
            value |= 0x1 << (slport_lane - 1);
            SSA_PTD_ZLOG_ERROR(" lport[%d] lane[%d] tx close\n", lport, slport_lane - 1);
        } else {
            /* 86寄存器的0 ~ 3位，0开启，1关闭 */
            value = 0xf;
        }
    } else {
        if (split_flag) {
            /* 静态工具检查，如果ssa_port_cfg_get_split_lport_lane_info返回的值小于0，则直接返回，不移位 */
            slport_lane = ssa_port_cfg_get_split_lport_lane_info(lport);
            if (slport_lane <= 0) {
                SSA_PTD_ZLOG_ERROR("get slport_lane[%d] error\n", slport_lane);
                return SSA_PORT_E_IVPARAM;
            }
            /* 必须要4个口打开，40光模块才能打开 */
            value &= ~(0x1 << (slport_lane - 1));
            SSA_PTD_ZLOG_ERROR(" lport[%d] lane[%d] tx open\n", lport, slport_lane - 1);
        } else {
            /* 必须要4个口打开，40光模块才能打开  这个需要区分是否是拆分口 */
            value = 0;
        }
    }

    (void)memset(&pca9548, 0, sizeof(ssa_port_pca9548_info_t));
    pca9548.pca9548_channel_name = ssa_port_cfg_get_sfp_i2c_dev_name(lport);
    if (pca9548.pca9548_channel_name == NULL) {
        SSTEST_DBG_ERR("pca9548_channel_name is NULL\n");
        return SSA_PORT_E_IVPARAM;
    }
    pca9548.addr_sfp = ssa_port_cfg_get_sfp_on_i2c_addr();

    rv = ptd_write_i2c(pca9548.pca9548_channel_name, pca9548.addr_sfp,
            fp_ts.addr, (unsigned char *)&value, sizeof(uint8_t), 0);
    if (rv < 0) {
        SSA_PTD_ZLOG_ERROR("dfd_write_port_i2c failed, channel_name %s dev_addr 0x%x offset_addr 0x%x rv%d,value0x%x\n",
            pca9548.pca9548_channel_name, pca9548.addr_sfp, fp_ts.addr, rv, value);
        return rv;
    } else {
        rv = SSA_PORT_E_NONE;
        SSA_PTD_ZLOG_ERROR("dfd_write_port_i2c OK, channel_name %s dev_addr 0x%x offset_addr 0x%x rv%d,value0x%x\n",
            pca9548.pca9548_channel_name, pca9548.addr_sfp, fp_ts.addr, rv, value);
    }

    return rv;
}

int out_ssa_port_enable_sfp(void)
{
    int rv;
    char *cpld_name;
    int32_t cpld_addr;
    unsigned char data = 0xff;
    int32_t lport;
    uint32_t min_lport, max_lport;
    char cpld_dev_name[MAX_NAME_LEN] = {0};

    min_lport = ssa_port_cfg_get_adjust_lport_min();
    max_lport = ssa_port_cfg_get_adjust_lport_max();

    /* 只有电口的线卡 */
    if ((min_lport == 0) && (min_lport == 0)) {
        return SSA_PORT_E_NONE;
    }

    printf("[%s %d]min_lport %u, max_lport %u\n", __FUNCTION__, __LINE__, min_lport, max_lport);
    if ((max_lport > MAX_LPORT_NUM) || (max_lport < 1) || (min_lport < 1)
            || (min_lport > max_lport)) {
        SSA_PTD_ZLOG_ERROR("lport invalid, min_lport %u, max_lport %u", min_lport, max_lport);
        return SSA_PORT_E_IVPARAM;
    }

    for (lport = min_lport; lport <= max_lport; lport++) {
        cpld_addr = ssa_port_cfg_get_cpld_enable_sfp_addr(lport);
        if (cpld_addr <= 0) {
            printf("data invalid, cpld_addr 0x%x, lport %d\n", cpld_addr, lport);
            //SSTEST_DBG_ERR("data invalid, cpld_addr 0x%x, lport %d\n", cpld_addr, lport);
            continue;
        }

        cpld_name = ptd_cfg_get_sfp_cpld_dev_name(lport);
        if (cpld_name == NULL || cpld_name[0] == 0) {
            snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", CPLD_DEV_PATH);
        } else {
            snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", cpld_name);
        }
        //SSA_PTD_ZLOG_DEBUG("cpld_dev_name %s, lport %d", cpld_dev_name, lport);
        printf("cpld_dev_name %s, lport %d\n", cpld_dev_name, lport);
        rv = ptd_write_cpld(cpld_dev_name, cpld_addr, &data, sizeof(unsigned char));
        if (rv < 0) {
            SSTEST_DBG_TEST("dfd_cpld_write failed, rv %d\n", rv);
            return SSA_PORT_E_RETURN;
        }
    }

    return SSA_PORT_E_NONE;
}

/* 打开百兆/千兆和万兆光模块 */
static int in_ssa_port_open_sfp(int lport, int disable)
{
    int offset, cpld_addr;
    unsigned char org_data;
    int exchange, i, first_fiber_num, pgroup_num, rv, index;
    static int inited;
    char *cpld_name = NULL;
    char cpld_dev_name[MAX_NAME_LEN] = {0};

    if (!inited) {
        for (i = 0; i < MAX_LPORT_GROUP; i++) {
            g_ssa_port_sfp_off[i] = 0xff;
        }

        inited = 1;
    }
    /* 8个端口一组，访问不同的CPLD地址 */
    offset = lport;
    exchange = 1;
    cpld_addr = ssa_port_cfg_get_cpld_open_sfp_addr(lport);
    offset = ssa_port_cfg_get_cpld_offset_reg(lport);
    exchange = ssa_port_cfg_get_cpld_exchange(lport);
    if ((cpld_addr <= 0) || (offset <= 0) || (exchange < 0)) {
        SSTEST_DBG_ERR("data invalid, cpld_addr 0x%x, offset %d, exchange %d lport %d\n",
            cpld_addr, offset, exchange, lport);
        return SSA_PORT_E_NONE;
    }
    SSA_PTD_ZLOG_DEBUG("cpld_addr 0x%x, offset %d, exchange %d", cpld_addr, offset, exchange);

    offset -= 1;
    if (exchange > 0) {
        if (offset % 2) {
            offset -= 1;
        } else {
            offset += 1;
        }
    }

    first_fiber_num = ssa_port_cfg_get_first_fiber_port_offset();
    pgroup_num = ssa_port_cfg_get_cpld_pnum_group();
    if (pgroup_num == 0) {
        SSTEST_DBG_ERR("pgroup_num is zero\n");
        return SSA_PORT_E_IVPARAM;
    }
    SSTEST_DBG_TEST("first_fiber_num %d, pgroup_num %d\n", first_fiber_num, pgroup_num);

    index = (lport - first_fiber_num) / pgroup_num;
    if (index < 0 || index >= MAX_LPORT_GROUP) {
        SSTEST_DBG_ERR("index invalid %d\n", index);
        return SSA_PORT_E_IVPARAM;
    }

    org_data = g_ssa_port_sfp_off[index];
    SSA_PTD_ZLOG_DEBUG("before set sfp data 0x%x", org_data);
    if (disable) {
        org_data |= (1 << offset);
    } else {
        org_data &= (~(1 << offset));
    }
    /* 操作光模块发光有时序要求，2次操作必须间隔2ms */
    usleep(2000);
    // fix me cpld
    cpld_name = ptd_cfg_get_sfp_cpld_dev_name(lport);
    if (cpld_name == NULL || cpld_name[0] == 0) {
        snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", CPLD_DEV_PATH);	//商业代码检查有问题

    } else {
        snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", cpld_name);

    }
    SSA_PTD_ZLOG_DEBUG("cpld dev name %s, lport %d", cpld_dev_name, lport);
    rv = ptd_write_cpld(cpld_dev_name, cpld_addr, &org_data, sizeof(unsigned char));
    if (rv < 0) {
        SSTEST_DBG_TEST("dfd_cpld_write failed, rv %d\n", rv);
        return SSA_PORT_E_RETURN;
    }
    SSA_PTD_ZLOG_DEBUG("then set sfp data 0x%x,cpld_addr 0x%x,lport %d", org_data, cpld_addr, lport);
    g_ssa_port_sfp_off[index] = org_data;

    SSTEST_DBG_TEST("operate sfp SUCCESS!\n");

    return SSA_PORT_E_NONE;
}

#define CPLD_DEV_PATH2  "/dev/cpld2"
/* 打开百兆/千兆和万兆光模块 */
static int in_rsa_port_open_sfp(int lport, int enable)
{
    int offset, cpld_addr;
    unsigned char org_data;
    char cpld_dev_name[MAX_NAME_LEN] = {0};
    int rv;

    snprintf(cpld_dev_name, MAX_NAME_LEN, "%s", CPLD_DEV_PATH2);
    if (lport < 8) {
        cpld_addr = 0x26;
        offset = lport;
    } else {
        cpld_addr = 0x27;
        offset = (lport - 8);
    }

    SSA_PTD_ZLOG_DEBUG("cpld_dev_name:%s, cpld_addr 0x%x, offset %d.\n", cpld_dev_name, cpld_addr, offset);
 
    /* 操作光模块发光有时序要求，2次操作必须间隔2ms */
    usleep(2000);
    rv = ptd_read_cpld(cpld_dev_name, cpld_addr, &org_data, sizeof(unsigned char));
    if (rv < 0) {
        SSTEST_DBG_TEST("ptd_read_cpld failed, rv %d\n", rv);
        return SSA_PORT_E_RETURN;
    }
    
    if (enable) {
        org_data |= (1 << offset);
    } else {
        org_data &= (~(1 << offset));
    }
    SSA_PTD_ZLOG_DEBUG("before set sfp data 0x%x", org_data);

    usleep(2000);
    rv = ptd_write_cpld(cpld_dev_name, cpld_addr, &org_data, sizeof(unsigned char));
    if (rv < 0) {
        SSTEST_DBG_TEST("dfd_cpld_write failed, rv %d\n", rv);
        return SSA_PORT_E_RETURN;
    }

    SSTEST_DBG_TEST("operate sfp SUCCESS!\n");

    return SSA_PORT_E_NONE;
}

int out_ssa_port_open_transceiver(int lport, int enable)
{
#if 0        
    int lport_max_rate = PORT_TGIGABIT_ETHERNET;
    int rv, ptm_medium;
    ptd_info_t ptd;

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_lport(lport, &ptd);
    if (rv != 0) {
        SSTEST_DBG_ERR(" lport %d  getport info fail\n", lport);
        return -1;
    }

    /* when getting here means that dev tells us the lport is optical, we must judge medium */
    rv = ptd_rgos_get_medium(&ptd, &ptm_medium);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR("ptd_rgos_get_medium fail, lport %d, rv %d\n", ptd.lport, rv);
    }

    if (ptm_medium != S_INTF__MEDIUM_TYPE_E__FIBER) {
        SSA_PTD_ZLOG_ERROR("medium not fiber, lport %d\n", ptd.lport);
        return 0;
    }

    /* judge if split-port here only for test now */
#if 0
    ptd.split_port_type = 0;
    if (/* judge vsl port */0){
        SSA_PTD_ZLOG_ERROR("is split, lport[%d] unit[%d] port[%d]\n", ptd.lport, ptd.unit, ptd.port);
        ptd.split_port_type = 1;
    }
#endif
    SSA_PORT_DEBUG("split_port_type[%d], lport[%d] unit[%d] port[%d]\n", ptd.split_port_type, ptd.lport, ptd.unit, ptd.port);

    lport_max_rate = ptd.lport_max_rate;
    if (lport_max_rate == PORT_FOGIGABIT_ETHERNET || lport_max_rate == PORT_HUGIGABIT_ETHERNET) {
        /* 光模块在位才需要 操作 40口的i2c */
        if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC) == 0) {
            SSA_PTD_ZLOG_DEBUG(" lport %d  qsfp exist \n", lport);
            return in_ssa_port_open_qfp(lport, disable, 0);
        }
    } else if ((lport_max_rate == PORT_TGIGABIT_ETHERNET) && (ptd.split_port_type == 1)) {//拆分的10G口
        if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC) == 0) {
            SSA_PTD_ZLOG_DEBUG(" lport %d  qsfp exist and is split!\n", lport);
            //因为10G的lport需要单独打开tx_disable，所以这里不传parent
            return in_ssa_port_open_qfp(lport, disable, 1);
        }
    }  else if (lport_max_rate == PORT_GIGABIT_ETHERNET || lport_max_rate == PORT_TGIGABIT_ETHERNET
            || lport_max_rate == PORT_FAST_ETHERNET || lport_max_rate == PORT_TFIGABIT_ETHERNET) {
        return in_ssa_port_open_sfp(lport, disable);
    } else {
        SSA_PTD_ZLOG_ERROR("port type invalid, port_type %d\n", lport_max_rate);
        return SSA_PORT_E_IVPARAM;
    }
    return SSA_PORT_E_NONE;
#else
    //先考虑只支持10 SFP
    return in_rsa_port_open_sfp(lport, enable);
#endif    
}

/* 获取光模块的速率 */
int in_ssa_port_get_trans_max_support_rate(int32_t lport, int32_t lport_max_rate, int32_t *trans_rate, int32_t is_split, int trans_cap)
{
    int tmp_trans_rate, rv;
    unsigned short addr_sfp, offset;
    char *i2c_name;
    unsigned char recv_buf[70];
    int read_time;

    rv = SSA_PORT_E_NONE;
    if (lport <= 0 || lport > MAX_LPORT_NUM) {/* wm mod */
        SSA_PTD_ZLOG_ERROR("lport invalid, lport %d", lport);
        return SSA_PORT_E_RETURN;
    }

    SSA_PTD_ZLOG_NOTICE(" lport[%d] lport_max_rate[%d] split[%d] trans_cap[%d]", lport, lport_max_rate, is_split, trans_cap);
    offset = (lport_max_rate == PORT_FOGIGABIT_ETHERNET || lport_max_rate == PORT_HUGIGABIT_ETHERNET) ? TRANS_I2C_INFO_OFFSET_QSFP : TRANS_I2C_INFO_OFFSET_SFP;
    /* if this lport is a split port, then override the offset to  PORT_FOGIGABIT_ETHERNET & PORT_HUGIGABIT_ETHERNET*/
    if (is_split == 1) {
        offset = TRANS_I2C_INFO_OFFSET_QSFP;
        SSA_PTD_ZLOG_NOTICE(" lport[%d] split[%d] offset[%d]", lport, is_split, offset);
    }

    if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC) == 0) {
        SSA_PTD_ZLOG_INFO("lport:%d sfp existed", lport);
        memset(recv_buf, 0, sizeof(recv_buf));
        i2c_name = ssa_port_cfg_get_sfp_i2c_dev_name(lport);
        addr_sfp = (uint16_t)ssa_port_cfg_get_sfp_on_i2c_addr();
        for (read_time = 0; read_time < 6; read_time++) {
            rv = ptd_read_i2c(i2c_name, addr_sfp, offset, recv_buf, 70, 0);
            if (rv < 0) {
                SSA_PTD_ZLOG_INFO("time %d get speed failed, i2c %s, add_sfp %d, offset %d"
                                , read_time, i2c_name, addr_sfp, offset);
                tmp_trans_rate = 0;
                usleep(80000);  /* 有的模块插入会失败，sleep 下重新读 */
                continue;
            } else {
                rv = SSA_PORT_E_NONE;
            }
            break;
        }

        SSA_PTD_ZLOG_INFO("ID: [0 : 0x%x],  [6 : 0x%x]   [12 : 0x%x] [66 : 0x%x]"
                        , recv_buf[0], recv_buf[6], recv_buf[12], recv_buf[66]);

        /* 以下判断逻辑要整改，offset的选取和速率的判断混在一起 */
        if ((recv_buf[6] == 0x8)) {  /* gt 模块*/
            tmp_trans_rate = 1000;
            g_ssa_port_sfp_type[lport - 1] = SSA_PORT_GT;
            offset = I2C_SFP_CHEK_SPEED_ADDR;
        } else if (recv_buf[0] == SSA_PORT_FIBER_ID_XFP || recv_buf[0] == SSA_PORT_FIBER_ID_XFP_E) {
            tmp_trans_rate = 10000;
            goto exit;
        } else if (recv_buf[0] == SSA_PORT_FIBER_ID_SFP) {
            offset = I2C_SFP_CHEK_SPEED_ADDR;
        } else if (recv_buf[0] == SSA_PORT_FIBER_ID_QSFP || recv_buf[0] == SSA_PORT_FIBER_ID_QSFP_PLUS
                || recv_buf[0] == SSA_PORT_FIBER_ID_QSFP28) {
            tmp_trans_rate = in_ssa_port_sfp_get_qsfp_speed(trans_cap);
            if (tmp_trans_rate == 0) {
                /* when splitoffspring-port and tmp_trans_rate get fail then speed is 40000 */
                tmp_trans_rate = (lport_max_rate == PORT_HUGIGABIT_ETHERNET) ? 100000 : 40000;
            }
            goto exit;
        } else {
            tmp_trans_rate = 0;   //不认识的模块 认为速率为0
            SSA_PTD_ZLOG_ERROR("unknow Transceiver ID Invalid, ID 0x%x", recv_buf[0]);
            rv = SSA_PORT_E_IVPARAM;
            goto exit;
        }

        if ((recv_buf[offset] >= I2C_SFP_PLUS_RANGE_MIN) && (recv_buf[offset] <= I2C_SFP_PLUS_RANGE_MAX)) {
            tmp_trans_rate = 10000;
            SSA_PTD_ZLOG_INFO("speedsfp+: %d", tmp_trans_rate);
        } else if ((recv_buf[offset] >= I2C_SFP_RANGE_MIN) && (recv_buf[offset] <= I2C_SFP_RANGE_MAX)) {
            tmp_trans_rate = 1000;
            SSA_PTD_ZLOG_INFO("speedsfp1000: %d", tmp_trans_rate);
        } else if (recv_buf[offset] <= I2C_SFP_HUND_RANGE_MAX) {
            tmp_trans_rate = 100;
            SSA_PTD_ZLOG_INFO("speedsfp100: %d", tmp_trans_rate);
        } else if (recv_buf[offset] == 0xff) {
            /* {byte12==0xff&&[byte66==0x00||(0x5a<byte66<0x78)]}代表25G */
            offset = I2C_SFP_CHEK_25G_ADDR;
            if ((recv_buf[offset] == 0x0) || (recv_buf[offset] > 0x5a && recv_buf[offset] < 0x78)) {
                tmp_trans_rate = 25 * 1000;
                SSA_PTD_ZLOG_INFO("speedsfp25g: %d", tmp_trans_rate);
            } else {
                tmp_trans_rate = 0;
                rv = SSA_PORT_E_IVPARAM;
                SSA_PTD_ZLOG_INFO("speed unknown: %d", tmp_trans_rate);
            }
        } else {
            tmp_trans_rate = 0;     /* 缺省为0，即无效值  是否增加容错 千兆跟10G */
            rv = SSA_PORT_E_IVPARAM;
            SSA_PTD_ZLOG_INFO("speed unknown: %d", tmp_trans_rate);
        }
    } else {
        tmp_trans_rate = 0;
        rv = SSA_PORT_E_IVPARAM;
        SSA_PTD_ZLOG_INFO("speed not exist: %d", tmp_trans_rate);
    } /* End if (out_ssa_port_get_ts_exist(lport) == 0) */

exit:
    SSA_PTD_ZLOG_INFO("Last, tmp_speed %d", tmp_trans_rate);
    g_ssa_port_arry_speed[lport - 1] = tmp_trans_rate;
    *trans_rate = tmp_trans_rate;

    return rv;
}

/* 获取端口的光模块的类型 */
int in_ssa_port_get_sfp_plug_mode(int32_t lport, int32_t lport_max_rate, int32_t *trans_model, int is_split, int trans_cap)
{
    unsigned char        i2c_val;
    int              rv;
    uint16_t             offset;
    uint8_t              cable_tec;
    ssa_port_sfp_module_capability_t capability;

    if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC)) {
        /* not present */
        return SSA_PORT_E_NONE;
    }

    /* pick up the i2c-offset depending on the lport_max_rate */
    switch(lport_max_rate) {
        case PORT_GIGABIT_ETHERNET:
        case PORT_FAST_ETHERNET:
            SSA_PTD_ZLOG_INFO("transceiver is sfp!\n");
            offset = I2C_SFP_TYPE_ADDR;
            break;
        case PORT_TGIGABIT_ETHERNET:
        case PORT_TFIGABIT_ETHERNET:
            if (is_split) {
                SSA_PTD_ZLOG_INFO("transceiver is qsfp!\n");
                offset = I2C_SFP_40G_TYPE_ADDR;
            } else {
                SSA_PTD_ZLOG_INFO("transceiver is sfp!\n");
                offset = I2C_SFP_TYPE_ADDR;

            }
            break;
        case PORT_FOGIGABIT_ETHERNET:
        case PORT_HUGIGABIT_ETHERNET:
            SSA_PTD_ZLOG_INFO("transceiver is qsfp!\n");
            offset = I2C_SFP_40G_TYPE_ADDR;
        break;

        default:
            SSA_PTD_ZLOG_ERROR("port type invalid, lport_max_rate %d\n", lport_max_rate);
            return SSA_PORT_E_IVPARAM;
    }

    rv = in_ssa_port_get_ts_reg_value(lport, &i2c_val, offset);
    if (rv) {
        SSA_PTD_ZLOG_ERROR("ssa_port_get_sfp_info failed, rv %d\n", rv);
        return SSA_PORT_E_IVPARAM;
    }
    SSTEST_DBG_TEST("ssa_port_get_sfp_info: i2c_val 0x%x\n", i2c_val);

    /* finally determin the trans-model */
    if ((lport_max_rate == PORT_TGIGABIT_ETHERNET || lport_max_rate == PORT_TFIGABIT_ETHERNET) && (i2c_val == 0x21 || i2c_val == 0x23)) {
        rv = in_ssa_port_get_ts_reg_value(lport, &cable_tec, 8);
        if (rv) {
            SSA_PTD_ZLOG_ERROR("ssa_port_get_sfp_info failed, rv %d\n", rv);
            return SSA_PORT_E_RETURN;
        }

        if (cable_tec == 0x8) {
            /* 只有0x21表示铜榄，byte8 == 0x8表示aoc ，改为0x23，都按照光模块处理*/
            i2c_val = I2C_SFP_TYPE_AOC;
        } else if (cable_tec == 0x4) {
            i2c_val = I2C_SFP_TYPE_COPPER;
        }
    }

    if (lport_max_rate == PORT_FOGIGABIT_ETHERNET || lport_max_rate == PORT_HUGIGABIT_ETHERNET) {
        capability = trans_cap;
        if (capability == SSA_PORT_QSFP_40G_AOC || capability == SSA_PORT_QSFP28_100G_AOC) {
            i2c_val = I2C_SFP_TYPE_AOC;
        } else if (capability == SSA_PORT_QSFP_40G_COPPER || capability == SSA_PORT_QSFP28_100G_COPPER) {
            i2c_val = I2C_SFP_TYPE_COPPER;
        } else {
            /* here means fiber-optical */
            i2c_val = 0;
        }
    }

    if (i2c_val == 0x21) {
        *trans_model = I2C_SFP_TYPE_COPPER;
    } else if (i2c_val == 0x23) {
        *trans_model = I2C_SFP_TYPE_AOC;
    } else {
        *trans_model = i2c_val;
    }
    SSA_PTD_ZLOG_NOTICE("lport[%d]: *plg_mode 0x%x", lport, *trans_model);
    return SSA_PORT_E_NONE;
}

/**
 * out_ssa_port_get_9548info_by_lport - 根据面板口和table_id获取9548信息
 * @lport: 面板口
 * @dev_info: 光模块在i2c总线上的信息
 * @table_id: 页面号
 *
 * return: 成功0,失败负值
 */
int out_ssa_port_get_9548info_by_lport(int lport, ssa_port_pca9548_info_t *dev_info,
            int32_t table_id)
{
    if (dev_info == NULL) {
        SSTEST_DBG_TEST("dev_info is NULL\n");
        return SSA_PORT_E_MEMORY;
    }

    (void)memset(dev_info, 0, sizeof(ssa_port_pca9548_info_t));
    dev_info->pca9548_channel_name = ssa_port_cfg_get_sfp_i2c_dev_name(lport);
    if (dev_info->pca9548_channel_name == NULL) {
        SSTEST_DBG_TEST("pca9548_channel_name is NULL\n");
        return SSA_PORT_E_IVPARAM;
    }

    dev_info->addr_sfp = (uint16_t)ssa_port_cfg_get_sfp_on_i2c_addr();
    if (!dev_info->addr_sfp) {
        SSTEST_DBG_TEST("transceiver on i2c bus's address is Zero\n");
        return SSA_PORT_E_IVPARAM;
    }

    if (table_id == 1) {
        dev_info->addr_sfp = 81;
    }

    return SSA_PORT_E_NONE;
}

int out_ssa_port_set_qsfp_power(void)
{
    int cpld_addr;
    unsigned char cpld_value;
    int qsfp_reset_val[MAX_LPORT_NUM];
    int i;
    int qsfp_reset_addr[MAX_LPORT_NUM];
    int rv;
    static bool power_set = FALSE;
    char cpld_dev[16] = "/dev/cpld0";

    if (power_set) {
        return 0;
    }

    rv = SSA_PORT_E_NONE;
    /* 当板卡中存在40G光模块时，需要开启供电电源 */
    cpld_addr = ssa_port_cfg_get_qsfp_power_en_addr();
    if ((ssa_port_cfg_get_qsfp_open_method_i2c()) && cpld_addr) {
        cpld_value = 0;
        rv = ptd_read_cpld(cpld_dev, cpld_addr, &cpld_value, 1);
        if (rv < 0) {
            SSTEST_DBG_TEST("dfd_cpld_read failed, rv %d\n", rv);
            return rv;
        }
        SSTEST_DBG_TEST("read register 0x%x, value %d\n", cpld_addr, cpld_value);
        cpld_value |= ssa_port_cfg_get_qsfp_power_en_value();
        SSTEST_DBG_TEST("cpld_value 0x%x\n", cpld_value);
        rv = ptd_write_cpld(cpld_dev, cpld_addr, &cpld_value, 1);
        if (rv) {
            SSTEST_DBG_TEST("dfd_cpld_write failed, rv %d\n", rv);
            return rv;
        }
    }

    /* reset qsfp */
    (void)memset(qsfp_reset_addr, 0, MAX_LPORT_NUM * sizeof(int32_t));
    (void)memset(qsfp_reset_val, 0, MAX_LPORT_NUM * sizeof(int32_t));
    ssa_port_cfg_get_qsfp_reset_addr(qsfp_reset_addr);
    ssa_port_cfg_get_qsfp_reset_val(qsfp_reset_val);
    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!qsfp_reset_addr[i]) {
            break;
        }

        rv = ptd_write_cpld(cpld_dev, qsfp_reset_addr[i], (unsigned char *)&qsfp_reset_val[i], 1);
        if (rv < 0) {
            SSTEST_DBG_TEST("dfd_cpld_write failed, rv %d\n", rv);
            return rv;
        }
    }
    usleep(2000000);
    power_set = TRUE;

    return 0;
}

/* 这个测试用的后续用zlog实现 */
static void dump_trans_info(unsigned char *trans_buf, int size)
{
    int i;
    char print_buf[TRANS_INFO_DUMP_LEN];
    char tmp_buf[TRANS_INFO_DUMP_LEN];
    /* 需要tmp中专下,因为snprintf自身的话依赖gcc版本才能成功，有些gcc版本这种
     *　snprintf(print_buf, TRANS_INFO_DUMP_LEN, "%s 0x%02x", print_buf, trans_buf[i]);
     * 会返回无效值
     */

    SSA_PTD_ZLOG_DEBUG("dump_trans_info:\n");
    memset(print_buf, 0, TRANS_INFO_DUMP_LEN);
    memset(tmp_buf, 0, TRANS_INFO_DUMP_LEN);
    for (i = 0; i < size; i++) {
        /* 不用偏移是因为snprintf的偏移不安全,可以截断会返回比实际填充长的数量,此时表示出现截断 */
        snprintf(tmp_buf, TRANS_INFO_DUMP_LEN, "%s0x%02x ", print_buf, trans_buf[i]);
        snprintf(print_buf, TRANS_INFO_DUMP_LEN, "%s", tmp_buf);
        if ((i + 1)%16 == 0 ) {
            SSA_PTD_ZLOG_DEBUG("%s\n", print_buf);
            memset(print_buf, 0, TRANS_INFO_DUMP_LEN);
            memset(tmp_buf, 0, TRANS_INFO_DUMP_LEN);
        }
    }

    SSA_PTD_ZLOG_DEBUG("\n");
}

static int get_i2c_offest_and_page_from_port_type(int port_type, int *page_addr, int *offset, int flag, int is_split)
{
    int rv = 0;

    /* 先给个初始值 */
    *page_addr = -1;
    *offset = -1;

    /* 这里根据模块类型和访问的flag来确定page */
    if (flag == TRANS_GET_NORMAL_INFO) {
        /* 希望读取模块的normal信息
         * 40G和100G的QSFP的normal信息在offset为128处开始, sfp为offset为0处开始
         * QSFP和SFP的normal信息都是0x50地址获取,即page0
         */
        *offset = (port_type == PORT_FOGIGABIT_ETHERNET || port_type == PORT_HUGIGABIT_ETHERNET) ? TRANS_I2C_INFO_OFFSET_QSFP : TRANS_I2C_INFO_OFFSET_SFP;
        *page_addr = 0x50;
        /* override the result according to is_split */
        if (is_split == 1) {
            *offset = TRANS_I2C_INFO_OFFSET_QSFP;
            SSA_PTD_ZLOG_DEBUG("flag[%d] offset[%d]", flag, *offset);
        }
    } else if (flag == TRANS_GET_DDM_INFO) {
        /* 希望读取模块的ddm信息
         * 40G和100G的QSFP的诊断信息在page0的offset为0的起始处
         * SFP的诊断信息在page1的offset为0处
         */
        *offset = 0;
        *page_addr = (port_type == PORT_FOGIGABIT_ETHERNET || port_type == PORT_HUGIGABIT_ETHERNET) ? 0x50 : 0x51;
        /* override the result according to is_split */
        if (is_split == 1) {
            *page_addr = 0x50;
            SSA_PTD_ZLOG_DEBUG("flag[%d] page_addr[%d]", flag, *page_addr);
        }
    } else if (flag == TRANS_GET_ANTIFAKE_INFO) {
        /* 希望读取模块的antifake信息 */

    } else {
        SSA_PTD_ZLOG_DEBUG("flag[%d] port_type[%d] unspported\n", flag, port_type);
        rv = S_INTF__FIBER_TYPE_E__FIBER_SUPPORTLESS;
    }

    SSA_PTD_ZLOG_DEBUG("flag[%d] port_type[%d] page_addr[0x%x] offset[0x%x] is_split[%d]\n",
        flag, port_type, *page_addr, *offset, is_split);

    return rv;
}

char trans_fail_reason[][TRANS_INFO_GET_FAIL_LOG] = {
    "success",
    "channel open fail!",
    "EPROM read fail!\n",
    "unsupported trans!\n"
    "no trans is present!\n"
    };

/* 信息读取错误打印获取 */
int in_ssa_port_trans_fail_msg(int rv, char *fail_reason)
{
    if ((fail_reason == NULL) || (rv < 0) || (rv > S_INTF__FIBER_RES_E__FIBER_ABSENT)) {
        SSA_PTD_ZLOG_DEBUG("fail_msg copy fail[%d][%p]\n", rv, fail_reason);
        return -1;
    }

    snprintf(fail_reason, TRANS_INFO_GET_FAIL_LOG, "%s", trans_fail_reason[rv]);

    return 0;
}

/* PTD的模块类型和PTM的模块类型转换 */
int in_ssa_ptd_port_type_to_ptm_type(int ptd_port_type, int is_split)
{
    int ptm_port_type;

    switch (ptd_port_type) {
    case PORT_FAST_ETHERNET:
    case PORT_GIGABIT_ETHERNET:
        ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_SFP;
        break;
    case PORT_TGIGABIT_ETHERNET:
    case PORT_TFIGABIT_ETHERNET:
        ptm_port_type = ssa_port_cfg_get_use_xfp() ? S_INTF__FIBER_TYPE_E__FIBER_XFP : S_INTF__FIBER_TYPE_E__FIBER_SFP;
        if (is_split) {
            ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_QSFP;
        }
        break;
    case PORT_FOGIGABIT_ETHERNET:
        ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_QSFP;
        break;
    case PORT_HUGIGABIT_ETHERNET:
        /* xxx: 08CQ使用QSFP28 ，目前没有板卡使用CFP，但未来可能会修改逻辑*/
        ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_QSFP;
        break;
    default:
        ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_SUPPORTLESS;
        break;
    }

    return ptm_port_type;
}

/* 获取光模块信息
 * 根据flag判断是获取normal还是ddm信息
 */
static int in_ssa_port_get_trans_info(ptd_info_t *ptd, int lphyid, unsigned char *trans_buf, int size, int flag)
{
    int rv;
    int page_addr, offset;
    char *i2c_name;
    int read_time;

    rv = S_INTF__FIBER_RES_E__READ_OK;
    /* coverity fix */
    if (ptd== NULL) {
        SSA_PTD_ZLOG_ERROR("phyid[%u] ptd NULL\n", lphyid);
        return S_INTF__FIBER_RES_E__OPEN_CHANNEL_FAIL;
    }

    /* 不在位啥也不用读了 */
    if (ptd_trans_get_ts_exist(ptd->lport, PTD_SFP_DECT_ASYNC)) {
        SSA_PTD_ZLOG_ERROR("phyid[%u][%d][%d] trans not present\n", lphyid, ptd->unit, ptd->port);
        return S_INTF__FIBER_RES_E__FIBER_ABSENT;
    }

    SSA_PTD_ZLOG_DEBUG("phyid[%u][%d][%d] get trans info size[%d] flag[%d]\n",
        lphyid, ptd->unit, ptd->port, size, flag);
    /* 获取模块信息读取的i2c偏移和page */
    rv = get_i2c_offest_and_page_from_port_type(ptd->lport_max_rate, &page_addr, &offset, flag, ptd->split_port_type);
    if (rv != 0) {
        SSA_PTD_ZLOG_ERROR(" phyid %u  getport info fail\n", lphyid);
        return S_INTF__FIBER_RES_E__READ_EEPROM_FAIL;
    }

    /* 开始访问i2c */
    i2c_name = ssa_port_cfg_get_sfp_i2c_dev_name(ptd->lport);
    for (read_time = 0; read_time < 6; read_time++) {
        rv = ptd_read_i2c(i2c_name, page_addr, offset, trans_buf, size, 0);
        if (rv < 0) {
            SSA_PTD_ZLOG_ERROR("time %d trans info, i2c %s, add_sfp %d, offset %d rv %d\n"
                            , read_time, i2c_name, page_addr, offset, rv);
            rv = S_INTF__FIBER_RES_E__READ_EEPROM_FAIL;
            usleep(80000);  /* 有的模块插入会失败，sleep下重新读 */
            continue;
        } else {
            rv = S_INTF__FIBER_RES_E__READ_OK;
        }
        break;
    }


    /* 这里要把读的信息dump出来,作为debug手段 */
    dump_trans_info(trans_buf,size);

    return rv;
}

/* 获取光模块防伪信息 */
static int in_ssa_port_get_trans_antifake_info(ptd_info_t *ptd, int lphyid, unsigned char *antifake_buf, int size)
{
    int rv;
    unsigned char id;
    unsigned char code[I2C_SFP_ANTIFAKE_CODE_LEN] = {0x47, 0x6d, 0x46, 0x72};
    unsigned char antifake_info[I2C_SFP_ANTIFAKE_INFO_LEN];

    char *i2c_name;

    if ((antifake_buf == NULL) || (ptd == NULL)) {
        SSA_PTD_ZLOG_ERROR("invalid input[0x%x][0x%x], lphyid:%d\n", ptd, antifake_buf, lphyid);
        return S_INTF__FIBER_RES_E__OPEN_CHANNEL_FAIL;
    }

    /* 下面是防伪逻辑 */
    memset(antifake_info, 0, I2C_SFP_ANTIFAKE_INFO_LEN);
    i2c_name = ssa_port_cfg_get_sfp_i2c_dev_name(ptd->lport);
    /* 首先向0x51的 offset 123写入 固定的4字节数据 */
    rv = ptd_write_i2c(i2c_name, 0x51, I2C_SFP_ANTIFAKE_CODE_ADDR, code, I2C_SFP_ANTIFAKE_CODE_LEN, 0);
    if (rv < 0) {
        SSA_PTD_ZLOG_ERROR("trans antifake[%d], i2c %s, add_sfp %d, offset %d fail[%d]\n",
            ptd->lport, i2c_name, 0x51, I2C_SFP_ANTIFAKE_CODE_ADDR, rv);
        return S_INTF__FIBER_RES_E__READ_EEPROM_FAIL;
    }

    /* 从0x50的offset 0读出一个字节判断是不是xfp
     * 如果是需要修改code[0], 然后再对0x51的offset 128写一次 4字节数据
     */
    rv = ptd_read_i2c(i2c_name, 0x50, 0, &id, 1, 0);
    if (rv < 0) {
        SSA_PTD_ZLOG_ERROR("Read transceiver eeprom failed, lport:%d rv:%d\n", ptd->lport, rv);
        return S_INTF__FIBER_RES_E__READ_EEPROM_FAIL;
    }
    if ((id == SSA_PORT_FIBER_ID_XFP) || (id == SSA_PORT_FIBER_ID_XFP_E)) {
        code[0] = 0x3;
        rv = ptd_write_i2c(i2c_name, 0x51, I2C_SFP_ANTIFAKE_CODE_1_ADDR, code, I2C_SFP_ANTIFAKE_CODE_LEN, 0);
        if (rv) {
            SSA_PTD_ZLOG_ERROR("Write transceiver eeprom failed, lport:%d rv:%d\n", ptd->lport, rv);
            return S_INTF__FIBER_RES_E__READ_EEPROM_FAIL;
        }
    }
    /* 从0x51的offset 128中读取128字节数据,这个就是防伪信息, 最终只想上传16字节 */
    rv = ptd_read_i2c(i2c_name, 0x51, I2C_SFP_ANTIFAKE_INFO_ADDR,
        antifake_info, I2C_SFP_ANTIFAKE_INFO_LEN, 0);
    if (rv < 0) {
        SSA_PTD_ZLOG_ERROR("Read transceiver eeprom failed, lport:%d rv:%d\n", ptd->lport, rv);
        return S_INTF__FIBER_RES_E__READ_EEPROM_FAIL;
    }

    /* 这里要把读的信息dump出来,作为debug手段 */
    SSA_PTD_ZLOG_DEBUG("antifake dump:\n");
    dump_trans_info(antifake_info, I2C_SFP_ANTIFAKE_INFO_LEN);

    /* 最后再把code全改成0x66, 写入0x51的 offset 123处 */
    memset(code, 0x66, I2C_SFP_ANTIFAKE_CODE_LEN);
    rv = ptd_write_i2c(i2c_name, 0x51, I2C_SFP_ANTIFAKE_CODE_ADDR,
        code, I2C_SFP_ANTIFAKE_CODE_LEN, 0);
    if (rv < 0) {
        SSA_PTD_ZLOG_ERROR("Write transceiver eeprom failed, lport:%d rv:%d\n", ptd->lport, rv);
        return SSA_PORT_E_RETURN;
    }
    /* 这里重最终的info中拷贝前16字节给上层 */
    memcpy(antifake_buf, antifake_info, TRANS_ANTIFAKE_LEN); /* 只传16字节 */
    SSA_PTD_ZLOG_DEBUG("final antifake dump:\n");
    dump_trans_info(antifake_buf, TRANS_ANTIFAKE_LEN);

    return S_INTF__FIBER_RES_E__READ_OK;
}

int in_ssa_ptd_trans_info_collect(unsigned int phyid, trans_info_t *info_from_trans)
{
    int rv;
    ptd_info_t ptd;
    int is_all_ok;

    /* 模块处理与芯片无关, 不放到驱动实现 */
    /* 这里分两部分,模块ddm信息获取和防伪信息获取
     * 1. 获取模块基本信息
     * 2. 获取模块ddm信息
     * 3. 获取模块的防伪信息
     * 4. 确定返回值
     */
    if (info_from_trans == NULL) {
        SSA_PTD_ZLOG_ERROR(" phyid %u info_from_trans is NULL", phyid);
        return S_INTF__FIBER_RES_E__OPEN_CHANNEL_FAIL;
    }
    /* 由于随时可能跳到错误逻辑,因此这里统一按照本接口内的逻辑初始化
     * info_from_trans内的buf需要在外层初始化好
     */
    rv = S_INTF__FIBER_RES_E__FIBER_ABSENT;
    is_all_ok = 0;
    info_from_trans->is_trans_online = 1; /* 默认初始化为在位 */
    info_from_trans->ptm_port_type = S_INTF__FIBER_TYPE_E__FIBER_SUPPORTLESS; /* 默认初始化为不支持的端口类型 */
    info_from_trans->antifake_support = 0; /* 默认初始化不支持 */

    memset(&ptd, 0, sizeof(ptd_info_t));
    rv = ptd_get_port_info_by_phyid(phyid, &ptd);
    if (rv != 0) {
         SSA_PTD_ZLOG_ERROR(" phyid %u getport info fail", phyid);
         rv = S_INTF__FIBER_RES_E__OPEN_CHANNEL_FAIL;
         goto err_log_dump;
    }

    /* 不在位啥也不用读了 */
    if (ptd_trans_get_ts_exist(ptd.lport, PTD_SFP_DECT_ASYNC)) {
        info_from_trans->is_trans_online = 0;
        SSA_PTD_ZLOG_ERROR("phyid[%u][%d][%d] trans not present[%d]",
            phyid, ptd.unit, ptd.port, info_from_trans->is_trans_online);
        rv = S_INTF__FIBER_RES_E__FIBER_ABSENT;
        goto err_log_dump;
    }

    SSA_PTD_ZLOG_NOTICE(" phyid %u lport_max_rate[0x%x] is_split[%d]", phyid, ptd.lport_max_rate, ptd.split_port_type);
    info_from_trans->ptm_port_type = in_ssa_ptd_port_type_to_ptm_type(ptd.lport_max_rate, ptd.split_port_type);
    if (info_from_trans->ptm_port_type <= 0) {
         SSA_PTD_ZLOG_ERROR(" phyid %u unspported trans type[%d]\n", phyid,
            info_from_trans->ptm_port_type);
         rv = S_INTF__FIBER_RES_E__FIBER_ABSENT;
         goto err_log_dump;
    }
    SSA_PTD_ZLOG_DEBUG(" phyid %u trans type[0x%x]", phyid, info_from_trans->ptm_port_type);

    /* 这里具体写得到的数据 基础信息必须读取成功 基础信息不成功后面都不要读了 */
    rv = in_ssa_port_get_trans_info(&ptd, phyid, info_from_trans->normal_buf, TRANS_NOR_INFO_LEN, TRANS_GET_NORMAL_INFO);
    if (rv != S_INTF__FIBER_RES_E__READ_OK) {
        SSA_PTD_ZLOG_ERROR("[%d]normal trans info get fail[%d] [0x%x]!", phyid, rv, is_all_ok);
        goto err_log_dump;
    }
    /* 基础信息读取成功则bit0置位 */
    is_all_ok = PTD_BIT_SET(is_all_ok, PTD_TRAN_NOR_INFO_OK_OFFSET);
    SSA_PTD_ZLOG_DEBUG("[%d]normal trans info get OK[%d] [0x%x]!", phyid, rv, is_all_ok);

    /* DDM信息可以不成功  但是下面的防伪还是要获取下 */
    rv = in_ssa_port_get_trans_info(&ptd, phyid, info_from_trans->ddm_buf, TRANS_NOR_INFO_LEN, TRANS_GET_DDM_INFO);
    if (rv == S_INTF__FIBER_RES_E__READ_OK) {
        SSA_PTD_ZLOG_ERROR("[%d]ddm trans info get OK[%d] [0x%x]!", phyid, rv, is_all_ok);
        /* ddm信息读取成功则bit0置位 */
        is_all_ok = PTD_BIT_SET(is_all_ok, PTD_TRAN_DDM_INFO_OK_OFFSET);
    }
    SSA_PTD_ZLOG_DEBUG("[%d]ddm trans info get rv [%d] [0x%x]!", phyid, rv, is_all_ok);

    /* 先判断是否支持 */
    info_from_trans->antifake_support = ssa_port_cfg_get_sfp_do_antifake();
    if (info_from_trans->antifake_support != 0) {
        /* 为1表示支持防伪 */
        rv = in_ssa_port_get_trans_antifake_info(&ptd, phyid, info_from_trans->antifake_buf, TRANS_ANTIFAKE_LEN);
        if (rv != S_INTF__FIBER_RES_E__READ_OK) {
            SSA_PTD_ZLOG_ERROR("[%d]antifake trans info get fail[%d] [0x%x]!", phyid, rv, is_all_ok);
            goto err_log_dump;
        }
        /* 防伪信息读取成功则bit0置位 */
        is_all_ok = PTD_BIT_SET(is_all_ok, PTD_TRAN_ANTIFAKE_INFO_OK_OFFSET);
        SSA_PTD_ZLOG_DEBUG("[%d]antifake trans info get OK[%d] [0x%x]!", phyid, rv, is_all_ok);
    }

    SSA_PTD_ZLOG_DEBUG("trans into collect OK");

err_log_dump:
    /* 这里需要判断下,只要normal信息获取OK就可以返回成功 */
    SSA_PTD_ZLOG_DEBUG("trans judge rv[0x%x]!", is_all_ok);
    if (PTD_BIT_IS_SET(is_all_ok, PTD_TRAN_NOR_INFO_OK_OFFSET) != 0) {
        /* 不管之前rv为何值, 只要基础信息读取OK都返回成功 */
        rv = S_INTF__FIBER_RES_E__READ_OK;
    }
    SSA_PTD_ZLOG_DEBUG("final rv [%d]", rv);

    return rv;
}

/**
 * 当前前光模块       原来光模块    配置速率       处理方式
 *  0                     0             0           return
 *  0                     1             0           del_sfp, fiber_notif,
 *  1                     0             1           add_sfp, fiber_notif
 *  1                     1             0           return
 *
 */
int ptd_get_trans_handle_type(int lport, ptd_info_t *ptd, int unit)
{
    int handle_type;

    ptd->handle_type = 0;
    /* 当前端口上不存在光模块 */
    if (ptd->present == 0) {
        //if (!BCM_PBMP_MEMBER(g_ssa_port_exit_sfp, lport - 1)) {  /* 当前不存在，原来不存在 */
        //    SSA_PTD_ZLOG_NOTICE("lport[%d] not in pbmp", lport);
       //     return SSA_PORT_E_NONE;
       // }   pengcheng

        handle_type = (SSA_PORT_DEL_SFP_EXIST_MASK | SSA_PORT_FIBER_NOTIFY_MASK);
        ptd->handle_type = handle_type;
        /* clear GT module info */
        g_ssa_port_sfp_type[lport - 1] = 0;
        SSA_PTD_ZLOG_DEBUG("in_ssa_port_get_handle_thread_type1 lport %d, handle_type 0x%x\n", lport, handle_type);
        return SSA_PORT_E_NONE;
    }

    SSA_PTD_ZLOG_DEBUG("trans exist[%d] lport[%d]\n", ptd->present, lport);
    /* 当前端口上存在光模块 */
    if (0) { //(!BCM_PBMP_MEMBER(g_ssa_port_exit_sfp, lport - 1)) {  pengcheng/* 当前存在，原来不存在 */
        handle_type = (SSA_PORT_ADD_SFP_EXIST_MASK | SSA_PORT_FIBER_NOTIFY_MASK);
        SSA_PTD_ZLOG_NOTICE("in_ssa_port_get_handle_thread_type2 lport %d, handle_type 0x%04x\n", lport, handle_type);
    } else {
        handle_type = SSA_PORT_E_NONE;
        SSA_PTD_ZLOG_DEBUG("lport[%d] still pbmp", lport);
    }

    ptd->handle_type = handle_type;

    return SSA_PORT_E_NONE;
}

int ptd_sfp_irq_handle(rg_global_t *global, int unit)
{
    int lport_min, lport_max, lport;
    ptd_info_t ptd;
    int rv;
    int loop;
    int port_stat;

    lport_min = ssa_port_cfg_get_adjust_lport_min();
    lport_max = ssa_port_cfg_get_adjust_lport_max();
    if ((lport_max > MAX_LPORT_NUM) || (lport_max < 1) || (lport_min < 1)
            || (lport_min > lport_max)) {
        SSA_PTD_ZLOG_ERROR("lport invalid, lport_min, %u, lport_max %u", lport_min, lport_max);
        return -1;
    }

    rv = ptd_trnas_update_sfp_dect_state();
    if (rv != SSA_PORT_E_NONE) {
        /* notify sync hw state fail, we just proceed, using cache state */
        SSA_PTD_ZLOG_ERROR("ptd_trnas_update_sfp_dect_state failp[%d]\n", rv);
    }

    for (lport = lport_min; lport <= lport_max; lport++) {
        memset(&ptd, 0, sizeof(ptd_info_t));
        rv = ptd_get_port_info_by_lport(lport, &ptd);
        if (rv != 0) {
            SSA_PTD_ZLOG_ERROR("get port info by lport fail lport %d\n", lport);
            continue;
        }

        if (ptd.unit != unit) {
            SSA_PTD_ZLOG_WARN("no same unit, current unit %d, get unit %d lport %d\n", unit, ptd.unit, lport);
            continue;
        }

#if 0   /* 光电复用口当前可能是电介质 */
        /* copper port need not trans present info */
        if (ptd.ptm_medium == S_INTF__MEDIUM_TYPE_E__COPPER) {
            SSA_PTD_ZLOG_INFO("port is copper just return lport %d", lport);
            continue;
        }
#endif
        /* get the present info of this lport */
        if (ptd_trans_get_ts_exist(lport, PTD_SFP_DECT_ASYNC)) {
            ptd.present = 0;
            SSA_PTD_ZLOG_NOTICE("trans no exist lport[%d]\n", lport);
        } else {
            ptd.present = 1;
            SSA_PTD_ZLOG_NOTICE("trans    exist lport[%d]\n", lport);
        }

        rv = ptd_get_trans_handle_type(lport, &ptd, unit);
        if (rv < 0) {
            SSA_PTD_ZLOG_INFO("ptd_get_trans_handle_type fail, lport %d", lport);
            continue;
        }

        if ((ptd.handle_type & SSA_PORT_ADD_SFP_EXIST_MASK) > 0) {
           // BCM_PBMP_PORT_ADD(g_ssa_port_exit_sfp, lport - 1);   pengcheng
            /* we get trans info only if this lport is to be notify */
            rv = ptd_get_trans_info(lport, &ptd, unit);
            if (rv < 0) {
                SSA_PTD_ZLOG_INFO("ptd_get_info fail, lport %d\n", lport);
                continue;
            }
        }

        if ((ptd.handle_type & SSA_PORT_DEL_SFP_EXIST_MASK) > 0) {
            //BCM_PBMP_PORT_REMOVE(g_ssa_port_exit_sfp, lport - 1);   pengcheng
            /* here we need to del this port cache node
             * since the trans plug irq is also pub from hostDB
             * so in the same connection with hostDB no need to use lock
             * to protect the cache link
             */
            SSA_PTD_ZLOG_NOTICE("lport[%d] need del_attr, handle_type 0x%x\n", lport, ptd.handle_type);
            if (g_ptd != NULL && g_ptd->del_attr) {
                /* 1.光电复用口若生效为电介质，拔插光模块不应该删除电介质配置信息，会导致端口震荡，
                   2.保留非光电复用口时删除cache,因为可能要设置firmode操作，而光电复用口为千兆。无需配firmode，可不删除 */
                if (ptd.dev_medium != PORT_MEDIUM_COPPER_FIBER) {
                    SSA_PTD_ZLOG_NOTICE("clean cache unit[%d] port[%d], dev_medium[%d], ptm_medium[%d]", ptd.unit, ptd.port, ptd.dev_medium, ptd.ptm_medium);
                    rv = g_ptd->del_attr(&ptd);
                }
                /* 此处不需要关心del_attr的返回值，只要记一条错误日志 */
                SSA_PTD_ZLOG_ERROR("[%d]del_attr fail [%d]", ptd.lport, rv);
                /* disable the port when tran is plugged out.
                 * we cannot wait for PTM to send disable cmd,
                 * in case the trans is re-plugged in before the PTM-disable-cmd comes.
                 * with this ensurance, situation discribed above will not happen,
                 * only if the re-plugged in action is faster even than the speed of
                 * the intr comes to PTD, bugid
                 */
                /* here we consider the PTM behaviour of loopback-port
                 * PTM wont conf disable to a loopback port even when a trans is unplugged
                 * so we here do the same
                 */
                loop = 0;// pengcheng BCM_PORT_LOOPBACK_NONE;
                rv = g_ptd->get_loopback(&ptd, &loop);
                if (rv != SSA_PORT_E_NONE) {
                    SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] lport[%d] loopback get fail\n", ptd.unit, ptd.port, ptd.lport);
                }

                /* 考虑到光电复用口disable掉会有端口震荡，不做处理,但是还是需要关闭发光 */
                if (loop == 0 && ptd.dev_medium != PORT_MEDIUM_COPPER_FIBER) {
                    rv = g_ptd->set_admin(&ptd, 0);
                    PTD_CHK_RET_RETURN_VAL(rv, "[%d]del_attr fail [%d]", ptd.lport, rv);
                }

                port_stat = 0;
                rv = g_ptd->get_admin(&ptd, &port_stat);
                if (rv != SSA_PORT_E_NONE) {
                    SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] lport[%d] admin get fail\n", ptd.unit, ptd.port, ptd.lport);
                }

                /* 光电复用口enable=0时才关闭发光 */
                if (ptd.dev_medium == PORT_MEDIUM_COPPER_FIBER && !port_stat) {
                    rv = out_ssa_port_open_transceiver(ptd.lport, TRANS_DISABLE);
                    if (rv) {
                        SSA_PTD_ZLOG_ERROR("transceiver operate error, lport 0x%x, rv %d", ptd.lport, rv);
                    }
                }
                SSA_PTD_ZLOG_DEBUG("unit[%d] port[%d] lport[%d] cache is del\n", ptd.unit, ptd.port, ptd.lport);
            }
        }

        if ((ptd.handle_type & SSA_PORT_FIBER_NOTIFY_MASK) > 0) {
            SSA_PTD_ZLOG_NOTICE("lport[%d] need notify, handle_type 0x%x\n", lport, ptd.handle_type);
            if (ptd_mom_fiber_notify(&ptd, global) != SSA_PORT_E_NONE) {
                SSA_PTD_ZLOG_DEBUG("in_ssa_port_fiber_notify fail, lport %d\n", lport);
                continue;
            }
        }
    }

    return 0;
}
