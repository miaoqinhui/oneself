/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
  * ssa_port_config.c
  * Original Author: xudongxu@ruijie.com.cn 2018-3-12
  *
  * port模块读取配置文件以及获取配置文件中参数的信息
  *
  * History 移植11.x 支持sdk式 查找配置
  * 异同:增加遍历链表查找有无当前配置。只需要调用ptd_config_get("mtu_reset", 1);
  */

#include "../include/ptd_init.h"
#include <rg_sys/list.h>
#include "../include/ptd_debug.h"


//#include "../include/ptd_mom.h"
#include "../include/ptd_sdk.h"

#define DEBUG_SSA                  "debug_ssa"          /* debug标志 */
#define CPLD_DECT_SFP_PREFIX       "cpld_dect_sfp_"     /* 检测光模块在位cpld地址 */

#define SFP_PRESENT_CACHE_DECT     "sfp_present_cache_dect_"   /* sfp present cache index */
#define SFP_PRESENT_CACHE          "sfp_present_cache_"        /* sfp present cache cpld reg */

#define CPLD_ENABLE_SFP_PREFIX     "cpld_enable_sfp_"       /* 打开光模块之前需要先使能 */
#define CPLD_OPEN_SFP_PREFIX       "cpld_open_sfp_"     /* 打开/关闭光模块cpld地址 */
#define CPLD_OFFSET_REG            "cpld_offset_reg_"   /* 每个端口在cpld寄存器上的相对偏移 */
#define CPLD_STATE0_PREFIX         "cpld_state0_"       /* 设置端口管脚cpld地址，第一组 */
#define CPLD_STATE1_PREFIX         "cpld_state1_"       /* 设置端口管脚cpld地址，第二组 */
#define CPLD_EXCHANGE_PREFIX       "cpld_exchange_"     /* 端口是否需要exchange */
#define FIRST_FIBER_PORT_OFFSET    "first_fiber_port_offset"  /* 光口偏移*/
#define CPLD_GROUP_PORT_NUM        "cpld_pnum_pgroup"   /* cpld寄存器对应的端口数量 */
#define ADJUST_LPORT_MIN           "adjust_lport_min"   /* 光模块自适应时起始的面板口号 */
#define ADJUST_LPORT_MAX           "adjust_lport_max"   /* 光模块自适应时结束的面板口号 */
#define SFP_I2C_DEV                "sfp_i2c_dev_"       /* 每个端口对应的字符设备名 */
#define SFP_CPLD_DEV               "sfp_cpld_dev_"        /* 每个端口对应的CPLD设备文件 */
#define QSFP_OPEN_METHOD_I2C       "qsfp_open_method_i2c"   /* 40G光模块开启需要写CPLD */
#define QSFP_POWER_EN_ADDR         "qsfp_power_en_addr"     /* 开启QFP开关的CPLD地址 */
#define QSFP_POWER_EN_VALUE        "qsfp_power_en_value"    /* 开启QFP开关的CPLD值 */
#define SFP_TYPE_OFFSET_ADDR       "sfp_type_offset_addr"   /* 光模块中读取光模块的类型的偏移值,扩展出10G/20G的东西 */
#define SFP_ON_I2C_ADDR            "sfp_on_i2c_addr"        /* 光模块在9458上的偏移地址 */
#define SFP_ADJUST_TIME            "sfp_adjust_time"        /* 自适应线程的间隔时间 */
#define LINKSCAM_TIME              "linkscan_time"          /* linkscan的时间间隔 */
#define LINKSCAM_TYPE              "linkscan_type"          /* linkscan的方式 */
#define GIGA_COPPER_THREAD         "giga_copper_thread" /* 是否创建千兆电口线程 */
#define FAST_LINKSCAN_TIME         "fast_linkscan_time" /* 快速link检测时间间隔 */
#define FAST_LINKSCAN_ADJUST_TIME  "fast_linkscan_adjust_time" /* 端口数目增加后快速检测时间间隔 */
#define FAST_LINKSCAN_ADJUST_PNUM  "fast_linkscan_adjust_pnum" /* 调整时间间隔的端口数 */
#define IRQ_ADUST_THEARD           "irq_adjust_thread"         /* 是否创建中断及自适应线程 */
#define SET_EDC                    "set_edc"                   /* 是否设置edc */
#define SET_PREEMS                 "set_preemphasis"           /* 是否设置预加重 */
#define COPPER_PRE_LANE0_          "copper_pre_lane0_"
#define COPPER_PRE_LANE1_          "copper_pre_lane1_"
#define COPPER_PRE_LANE2_          "copper_pre_lane2_"
#define COPPER_PRE_LANE3_          "copper_pre_lane3_"
#define COPPER_DRV_LANE0_           "copper_drv_lane0_"
#define COPPER_DRV_LANE1_           "copper_drv_lane1_"
#define COPPER_DRV_LANE2_           "copper_drv_lane2_"
#define COPPER_DRV_LANE3_           "copper_drv_lane3_"
#define FIBER_PRE_LANE0_           "fiber_pre_lane0_"
#define FIBER_PRE_LANE1_           "fiber_pre_lane1_"
#define FIBER_PRE_LANE2_           "fiber_pre_lane2_"
#define FIBER_PRE_LANE3_           "fiber_pre_lane3_"
#define FIBER_DRV_LANE0_            "fiber_drv_lane0_"
#define FIBER_DRV_LANE1_            "fiber_drv_lane1_"
#define FIBER_DRV_LANE2_            "fiber_drv_lane2_"
#define FIBER_DRV_LANE3_            "fiber_drv_lane3_"
#define COPPER_EQ_LANE0_            "copper_eq_lane0_"
#define FIBER_EQ_LANE0_             "fiber_eq_lane0_"
#define DEF_PRE                     "def_pre"
#define DEF_DRV                     "def_drv"
#define PORT_TO_LANE               "port_to_lane_"     /* 端口对应的lane */
#define NO_SUP_PROTECT             "no_sup_protect"    /* 是否设置保护口 */
#define PROTECT_TRUNK              "protect_trunk"     /* 保护口是否需要设置trunk */
#define SET_JAM                    "set_jam"           /* 是否半双工 */
#define EVADE_MAC_AND_PHY          "evade_mac_and_phy" /* 是否要规避MAC和PHY不能协商的问题 */
#define RDBGC8_OVER_SIZE           "rdbgc8_over_size"  /* 是否处理rdbgc8溢出 */
#define RDBGC8_SET64_BIT           "rdbgc8_set64_bit"  /* 统计RDBGC8时需要使用64位 */
#define GIGA_FIBER_AUTO_TO_MAX     "giga_fiber_auto_to_max"   /* 千兆光口speed auto 需设置成1G */
#define GIGA_COPPER_1000_AN_EN     "giga_copper_1000_an_en"   /*千兆电口speed 1000 需开启自协商*/
#define TENGIGA_COPPER_10G_AN_EN   "tengiga_copper_10g_an_en" /* 万兆电口speed 10g 需开启自协商 */
#define TENGIGA_COPPER_1000_AN_EN  "tengiga_copper_1000_an_en"/* 万完兆电口speed 10g 需开启自协商 */
#define ADMIN_SLEEP_TIME           "admin_sleep_time"         /* shut/noshut后的时间间隔 */
#define ATT_SLEEP_TIME             "att_sleep_time"           /* 设置速率/双工/流控后的时间间隔 */
#define MTU_RESET                  "mtu_reset"                /* 设置mtu时是否使用自定义函数 */
#define LED_REG_ADDR               "led_reg_addr"             /* 点灯寄存器 */
#define LED_REG_SET_VALUE          "led_reg_set_value"        /* 设置点灯寄存器的值 */
#define INTERRUPT_T0_CPU_ADDR      "interrupt_to_cpu_en_reg"  /* 允许中断到CPU的寄存器地址 */
#define INTERRUPT_TO_CPU_SET_VALUE "interrupt_to_cpu_value"   /* 允许中断到CPU的寄存器的值 */
#define SPLIT_PORT_TO_MERGE        "split_port_to_merge_"     /* 拆分口对应的聚合口（lport） */
#define FASTLINK_TYPE              "fastlink_type"            /* 快速中断方式 */
#define PHY_SCAN                   "phy_scan_"            /* 快速中断方式 */
#define LED_CTRL_CODE              "led_ctrl_code_"           /* led码流 */
#define FAC_LED_CTRL_CODE          "fac_led_ctrl_code_"           /* led码流 */
#define POE_LED_CTRL_CODE          "poe_led_ctrl_code_"       /* POE led码流 */
#define LED_PORT_MAX               "led_port_max"             /* 每个led支持的最大端口数 */
#define LED_40g_DATA_RAM           "led_40g_data_ram_"        /* 40G要写的特殊寄存器 */
#define LED_CALLBACK_TYPE          "led_callback_type"        /* led link的回调方式 */
#define LED_FIBER_COPPER_ADDR      "led_fiber_copper_addr_"     /* fiber copper地址 */
#define ADVER_TYPE                 "adver_type"               /* 自协商方式 */
#define COPPER_PORT_ABILITY_       "copper_port_ability_"     /* 端口能力，生测下使用*/
#define FIBER_PORT_ABILITY_        "fiber_port_ability_"      /* 端口能力，生测下使用*/
#define WC_MODE                    "wc_mode"
#define MDIX_MODE_CFG                  "mdix_mode"
#define MTU_ADD_LEN                "mtu_add_len_"
#define LB_TYPE                    "lb_type"
#define GT_ALWAYS_AN               "gt_always_an"
#define FIRMWARE_DFE_ENABLE        "firmware_dfe_enable"
#define FIR_MODE                   "fir_mode"
#define SET_PREAMBLE               "set_preamble"
#define SET_PCIE                   "set_pcie"
#define FLOW_EXTERN                "flow_extern"
#define PAUSE_INIT                 "pause_init"
#define DEFAULT_MTU                "default_mtu"
#define COUNTER_DOWN_UPDATE        "counter_down_update"      /* 端口down时，计数是否更新 */
#define PORT_IF_CHANGE             "port_if_change_"
#define NO_SUP_LINEDET             "no_sup_linedet"
#define GT_FAKE_LINK               "gt_fake_link"             /* gt模块是否会发生假link现象 */
#define SERDES_IF_TYPE             "serdes_if_type"
#define IF_TYPE_COPPER_TENGI       "if_type_copper_tengi"
#define IF_TYPE_FIBER_TENGI        "if_type_fiber_tengi"
#define IF_TYPE_COPPER_FORTYGI     "if_type_copper_fortygi"
#define IF_TYPE_FIBER_FORTYGI      "if_type_fiber_fortygi"
#define IF_TYPE_COPPER_HUNDREDGI     "if_type_copper_hundredgi"
#define IF_TYPE_FIBER_HUNDREDGI      "if_type_fiber_hundredgi"
#define INERROR_EXCLUDE_RMTU       "inerror_exclude_rmtu"     /* IfInError中的统计是否包括RMTU的统计 */
#define MAC_LB_FORCE_LINK          "mac_lb_force_link"        /* 配置为mac回环时，是否需要force link up */
#define APD_TYPE                   "apd_type"                 /* apd type */
#define USE_XFP                    "use_xfp"                 /* apd type */
#define MODULE_READY_TIME          "module_ready_time"        /* 模块从检测到插入到i2c可读需要的时间 */
#define FORCED_100M_ON_XT          "forced_100m_on_xt"        /* XT口上100M只能强制，不能协商成100M */
#define SPLIT_40G_MAXPORT          "split_40g_maxport"        /* XT口上100M只能强制，不能协商成100M */
#define LINKSCAN_STATE             "linkscan_state_"            /* 起机需要关闭linkscan的端口 */
#define MAC_CPLD_ROV_TYPE          "mac_cpld_rov_type"             /* 通过CPLD调整ROV供给电压 */
#define MAC_CPLD_ROV_ADDR          "mac_cpld_rov_addr"             /* 通过CPLD调整ROV供给电压 */
#define EXT_PHY_PREEMPHASIS        "ext_phy_preemphasis_"            /* 该lport是否配置外部PHY预加重 */
/* QSFP_PORT_RESET_ADDR 和 QSFP_PORT_RESET_VALUE 是以组来赋值，每8个端口一组 */
#define QSFP_PORT_RESET_ADDR       "qsfp_port_reset_addr_"    /* qsfp复位设置cpld地址 */
#define QSFP_PORT_RESET_VALUE      "qsfp_port_reset_val_"     /* qsfp复位的cpld */
#define FEATURE_VSL_NO_SPEED_SET   "feature_vsl_no_speed_set"            /* VSL口不需要设置speed */
#define FEATURE_SFP_DO_ANTIFAKE    "feature_sfp_do_antifake"   /* 是否进行光模块防伪 */
#define SPLIT_LPORT_LANE_INFO      "split_lport_lane_info_"     /* array that label the split port lane of trans,
                                                                * used when determining which lane to open tx_disable.
                                                                * NON-ZERO for SPLIT LPORT, others are ZERO
                                                                */
#define OVERSIZE_FRM_ADD_LEN       "oversize_frm_add_len_"      /* per-port conf of PORT_CNTMAXSIZE reg
                                                                 * in order to match with the actual MTU goes into reg
                                                                 */
#define NEED_UNRELIABLE_LOS        "nead_unreliable_los_"       /* per-port conf of unreliable_los
                                                                 * tsce & tecf is recommand to conf this.
                                                                 * to prrevent single-link problem
                                                                 */
#define OVERRIDE_AN_CONF_IN_CACHE  "override_an_conf_in_cache_"  /* 该配置会导致新的bug494093，由全局配置修改为基于端口的配置 */
                                                                /* here we need to override the an-conf as required.
                                                                 * this action is controlled by conf in config_bcm.port
                                                                 * reason of this is bug467540. some chip may have this problem that
                                                                 * when using bcm_port_speed_set api to set speed other than 1000m,
                                                                 * the an will be turned off automatically, which will cause the ptd_sdk_cache
                                                                 * doesn't correspound to the real sdk_conf. for example when a GT is plug in, PTM will
                                                                 * conf an=on sp=1000. when cli conf this port with speed 10G while the GT is plugged, PTM will
                                                                 * conf only sp=10000, the an in ptd_sdk_cache is still on, but the sdk-real-an-conf-after-speed-10G-is-set is off.
                                                                 * so when cli conf no speed, PTM will conf an=on sp=1000 due to GT still plugged in. but when conf comes to PTD,
                                                                 * PTD will set sp=1000, but an will not be conf as the an in ptd_sdk_cache is still on.
                                                                 */
#define PORT_MIN_SUPP_VSL_SPEED    "port_min_supp_vsl_speed_"     /* the minimum speed of a port can support when this port is in vsl mode */
#define MIB_NOTIFY_LINGER_CNT      "mib_notify_linger_cnt"  /* bug472187 set a mib notify linger cnt for all port */
#define FIBER_INTERRUPT_VAL        "fiber_interrupt_val"
#define COPPER_INTERRUPT_VAL       "copper_interrupt_val"
#define EXTERNEL_PHY_TYPE          "externel_phy_type_"           /* 外部phy类型 */
#define LS_TYPE_LPORT              "ls_type_lport_"               /* 扫描方式范围 */
#define AN_ENSURE_PORT_ENABLED     "an_ensure_port_enabled"      /* bug499053, Because on the M7900-48SFP-EA, the ports
                                                                  * will shock while port open auto negotiation without enable, so we must ensure
                                                                  * only while the port is enabled, auto negotiation is allowed to open. */
#define BACKPLANE_PORT_SPEC        "backplane_port_spec_"         /* bug506567 Disorderly backplanes should be specified */
#define AN_UNSUPPORTED             "an_unsupported"              /* bugid:505268 For Falcon SerDes, the ports don't support auto negotiation */
#define SPEED_CHANGE_FLOW_CTRL     "speed_change_flow_ctrl"      /* bugid:512415 For chip BCM56770/56771, while we change the speed of ports, the Tx_pause
                                                                    and Rx_pause will be open automatically, so when we set speed without the flow control,
                                                                    we must close the flow control by force  */

/* SOME default value of the config */
#define DEF_MIB_NOTI_LINGER_CNT  (10)
#define LED_CTRL_NUM    2
#define LED_CODE_LENTH  1000

#define LPORT_RANGE_CHECK(lport)                        \
    if (((lport) <= 0) || ((lport) > MAX_LPORT_NUM)) {  \
        return SSA_PORT_E_IVPARAM;                      \
    }
#define CPLD_RANGE_CHECK(num)                        \
        if (((num) <= 0) || ((num) > MAX_CPLD_DECT_REG_NUM)) {  \
            return SSA_PORT_E_IVPARAM;                      \
        }
#define EXTPHY_RANGE_CHECK(phyid)                        \
    if (((phyid) <= 0) || ((phyid) > MAX_EXTERNAL_PHY_NUM)) {  \
        return SSA_PORT_E_IVPARAM;                      \
    }

/* 基于线卡配置项的结构体 */
typedef struct ssa_port_lc_config_s {
    int32_t debug_ssa;
    int32_t cpld_dect_sfp[MAX_LPORT_NUM];   /* 每个端口一个检测sfp在位cpld地址 */
    int32_t cpld_enable_sfp[MAX_LPORT_NUM]; /* 每个端口一个使能sfp的cpld地址 */
    int32_t cpld_open_sfp[MAX_LPORT_NUM];   /* 每个端口一个打开sfp cpld地址 */
    int32_t cpld_offset_reg[MAX_LPORT_NUM]; /* 每个端口在cpld寄存器上的相对偏移 */
    int32_t cpld_state0[MAX_LPORT_NUM];     /* 每个端口一个设置cpld state0 */
    int32_t cpld_state1[MAX_LPORT_NUM];     /* 每个端口一个设置cpld state1 */
    int32_t cpld_exchange[MAX_LPORT_NUM];
    int32_t cpld_pnum_pgroup;
    uint32_t adjust_lport_min;
    uint32_t adjust_lport_max;
    int32_t first_fiber_port;               /* 首个光口的前一个端口 */
    int32_t split_lport_lane_info[MAX_LPORT_NUM];  /* array that label the split port lane of trans,
                                                    * used when determining which lane to open tx_disable.
                                                    * NON-ZERO for SPLIT LPORT, others are ZERO
                                                    */
    char    sfp_i2c_dev[MAX_LPORT_NUM][MAX_NAME_LEN];
    char    sfp_cpld_dev[MAX_LPORT_NUM][MAX_NAME_LEN];
    int32_t sfp_type_offset_addr;
    int32_t sfp_on_i2c_addr;
    int32_t qsfp_open_method_i2c;           /* 40G光模块开启需要写CPLD */
    int32_t qsfp_power_en_addr;
    unsigned char qsfp_power_en_value;
    int32_t sfp_adj_thread_time;            /* 自适应线程的间隔时间 */
    int32_t linkscan_time;
    int32_t linkscan_type;
    int32_t giga_copper_thread;
    int32_t fast_linkscan_time;
    int32_t fast_linkscan_adjust_time;
    int32_t fast_linkscan_adjust_pnum;
    int32_t irq_adjust_thread;
    int32_t set_edc;
    int32_t evade_mac_and_phy;              /* MAC和PHY不能协商 */
    int32_t set_preemphasis;
    int32_t ext_phy_preemphasis[MAX_LPORT_NUM];
    int32_t port_to_lane[MAX_LPORT_NUM];
    int32_t copper_pre_lane0[MAX_LPORT_NUM];
    int32_t copper_pre_lane1[MAX_LPORT_NUM];
    int32_t copper_pre_lane2[MAX_LPORT_NUM];
    int32_t copper_pre_lane3[MAX_LPORT_NUM];
    int32_t copper_drv_lane0[MAX_LPORT_NUM];
    int32_t copper_drv_lane1[MAX_LPORT_NUM];
    int32_t copper_drv_lane2[MAX_LPORT_NUM];
    int32_t copper_drv_lane3[MAX_LPORT_NUM];
    int32_t copper_eq_lane0[MAX_LPORT_NUM];
    int32_t fiber_pre_lane0[MAX_LPORT_NUM];
    int32_t fiber_pre_lane1[MAX_LPORT_NUM];
    int32_t fiber_pre_lane2[MAX_LPORT_NUM];
    int32_t fiber_pre_lane3[MAX_LPORT_NUM];
    int32_t fiber_drv_lane0[MAX_LPORT_NUM];
    int32_t fiber_drv_lane1[MAX_LPORT_NUM];
    int32_t fiber_drv_lane2[MAX_LPORT_NUM];
    int32_t fiber_drv_lane3[MAX_LPORT_NUM];
    int32_t fiber_eq_lane0[MAX_LPORT_NUM];
    long unsigned int copper_port_ability[MAX_LPORT_NUM];
    long unsigned int fiber_port_ability[MAX_LPORT_NUM];
    int32_t def_pre;
    int32_t def_drv;
    int32_t no_sup_protect;
    int32_t protect_trunk;
    int32_t set_jam;
    int32_t rdbgc8_over_size;
    int32_t rdbgc8_set64_bit;
    int32_t giga_fiber_auto_to_max;
    int32_t giga_copper_1000_an_en;
    int32_t tengiga_copper_10g_an_en;
    int32_t tengiga_copper_1000_an_en;
    int32_t admin_sleep_time;
    int32_t att_sleep_time;
    int32_t mtu_reset;
    int32_t led_reg_addr;
    int32_t led_reg_set_value;
    int32_t interrupt_to_cpu_en_reg;
    int32_t interrupt_to_cpu_value;
    int32_t split_port_to_merge[MAX_LPORT_NUM];
    int32_t fastlink_type;                  /* 快速中断类型 */
    int32_t phy_scan[MAX_LPORT_NUM];
    uint16_t fiber_interrupt_val;
    uint16_t copper_interrupt_val;
    int32_t qsfp_reset_addr[MAX_LPORT_NUM];
    int32_t qsfp_reset_val[MAX_LPORT_NUM];
    char led_ctrl_code[MAX_LOCAL_UNIT][LED_CTRL_NUM][LED_CODE_LENTH];
    char fac_led_ctrl_code[MAX_LOCAL_UNIT][LED_CTRL_NUM][LED_CODE_LENTH];
    char poe_led_ctrl_code[MAX_LOCAL_UNIT][LED_CTRL_NUM][LED_CODE_LENTH];
    int32_t led_port_max;
    int32_t led_40g_data_ram[MAX_LPORT_NUM];
    int32_t led_callback_type;
    int32_t led_fiber_copper_addr[MAX_LPORT_NUM];
    int32_t adver_type;
    int32_t wc_mode;
    int32_t mdix_mode;
    int32_t mtu_add_len[MAX_LPORT_NUM];
    int32_t lb_type;
    int32_t gt_always_an;
    int32_t firmware_dfe_enable;
    int32_t fir_mode;
    int32_t set_preamble;
    int32_t set_pcie;
    int32_t flow_extern;
    int32_t pause_init;
    int32_t default_mtu;
    int32_t counter_down_update;
    int32_t port_if_change[MAX_LPORT_NUM];
    int32_t no_sup_linedet;
    int32_t gt_fake_link;
    int32_t serdes_if_type;
    int32_t if_type_copper_tengi;
    int32_t if_type_fiber_tengi;
    int32_t if_type_copper_fortygi;
    int32_t if_type_fiber_fortygi;
    int32_t if_type_copper_hundredgi;
    int32_t if_type_fiber_hundredgi;
    int32_t inerror_exclude_rmtu;
    int32_t mac_lb_force_link;
    int32_t apd_type;
    int32_t use_xfp;
    int32_t module_ready_time;
    int32_t forced_100m_on_xt;
    int32_t split_40g_maxport;
    int32_t linkscan_state[MAX_LPORT_NUM];
    int32_t mac_cpld_rov_type;
    int32_t mac_cpld_rov_addr;
    int32_t feature_vsl_no_speed_set;
    int32_t feature_sfp_do_antifake;  /* 模块防伪 */
    int32_t oversize_frm_add_len[MAX_LPORT_NUM];
    int32_t need_unreliable_los[MAX_LPORT_NUM];
    int32_t port_min_supp_vsl_speed[MAX_LPORT_NUM];
    int32_t override_an_conf_in_cache[MAX_LPORT_NUM];
    int32_t sfp_present_cache[MAX_CPLD_DECT_REG_NUM];
    int32_t sfp_present_cache_dect[MAX_LPORT_NUM];
    int32_t ls_type_lport[MAX_LPORT_NUM];
    int32_t externel_phy_type[MAX_EXTERNAL_PHY_NUM];
    int32_t mib_notify_linger_cnt;
    int32_t an_ensure_port_enabled;
    int32_t backplane_port_spec[MAX_BP_PORT_NUM];
    int32_t an_unsupported;
    int32_t speed_change_flow_ctrl;
} ssa_port_lc_config_t;

/* 支持sdk类型读取配置文件 */
struct list_head config_var;
typedef struct def_config_s {
    char config_line[32];
    char config_val[32];
    struct list_head lst;
}def_config_t;

static uint32_t time_need;
ssa_port_lc_config_t *port_config;

/* 把字符串转化为 整数 */
static long unsigned int ssa_port_get_value_from_value_char(char *value_char)
{
    long unsigned int value;

    value = 0;
    /* 十六进制 */
    if (strlen(value_char) > 2 && value_char[0] == '0'
            && (value_char[1] == 'x' || value_char[1] == 'X')) {
        value = (long unsigned int)strtol(value_char, NULL, 16);
    /* 十进制 */
    } else {
        value = atoi(value_char);
    }

    return value;
}

/* 获取端口范围 */
static void ssa_port_get_port_range_from_port_char(char *port_char, int *port_begin, int *port_end)
{
    char *port_begin_char;
    char *port_end_char;

    *port_begin = 0;
    *port_end = 0;
    port_begin_char = strtok(port_char, "_");
    *port_begin = ssa_port_get_value_from_value_char(port_begin_char);
    if (port_begin_char != NULL) {
        port_end_char = strtok(NULL, "_");
        if (port_end_char != NULL) {
            *port_end = ssa_port_get_value_from_value_char(port_end_char);
        } else {
            *port_end = *port_begin;
        }
    } else {
        *port_end = *port_begin;
    }
}

/* 获取一定范围内的信息 */
static void ssa_port_get_value_int_64(char *arg_name, char *arg_value, char *prefix, long unsigned int *arr)
{
    int32_t port_begin, port_end, i;
    char *port_char;
    long unsigned int value;

    port_char = arg_name + strlen(prefix);
    ssa_port_get_port_range_from_port_char(port_char, &port_begin, &port_end);
    if (port_begin <= 0 || port_end <= 0 || port_begin > port_end || port_end > MAX_LPORT_NUM) {
        SSTEST_DBG_ERR("port range error, %d to %d\n", port_begin, port_end);
        return;
    }
    value = ssa_port_get_value_from_value_char(arg_value);
    for (i = port_begin; i <= port_end; i++) {
        arr[i - 1] = value;
    }

    return;
}

/* 获取一定范围内的信息 */
static void ssa_port_get_value_int(char *arg_name, char *arg_value, char *prefix, int32_t *arr)
{
    int32_t port_begin, port_end, i, value;
    char *port_char;

    port_char = arg_name + strlen(prefix);
    ssa_port_get_port_range_from_port_char(port_char, &port_begin, &port_end);
    if (port_begin <= 0 || port_end <= 0 || port_begin > port_end || port_end > MAX_LPORT_NUM) {
        SSTEST_DBG_ERR("port range error, %d to %d\n", port_begin, port_end);
        return;
    }
    value = ssa_port_get_value_from_value_char(arg_value);
    for (i = port_begin; i <= port_end; i++) {
        arr[i - 1] = value;
    }

    return;
}

/* 获取一个信息, 如:qsfp_port_reset_addr_1=0x95  */
static void ssa_port_get_value_int_one(char *arg_name, char *arg_value, char *prefix, int32_t *arr)
{
    int32_t value, index;
    char *port_char;

    port_char = arg_name + strlen(prefix);
    index = ssa_port_get_value_from_value_char(port_char);
    if (index <= 0 || index > MAX_LPORT_NUM) {
        SSTEST_DBG_ERR("port range error port %d\n", index);
        return;
    }
    value = ssa_port_get_value_from_value_char(arg_value);

    arr[index - 1] = value;

    return;
}

/* 获取特定值的信息 */
static void ssa_port_get_value_to_str(char *name, char *value, char *prefix, char (*arr)[MAX_NAME_LEN])
{
    int32_t index;
    char *port_char;

    port_char = name + strlen(prefix);
    index = ssa_port_get_value_from_value_char(port_char);
    if (index <= 0 || index > MAX_LPORT_NUM) {
        SSTEST_DBG_ERR("port range error port %d\n", index);
        return;
    }
    (void)memcpy(arr[index - 1], value, strlen(value));

    return;
}

/* 获取一定范围内的信息 */
static void ssa_port_get_led_code_str(char *name, char *value, char *prefix
                                        , char (*arr)[LED_CTRL_NUM][MAX_VALUE_LEN])
{
    char *led_ctrl_char, *unit_char, *led_ctrl_num_char;
    int32_t unit, led_num;

    unit = 0;
    led_num=0;
    /* 拆分 led_ctr_code_x.x */
    led_ctrl_char = strtok(name, ".");
    if (led_ctrl_char != NULL) {
        /* 拆分 led_ctrl_code_X  */
        led_ctrl_num_char = led_ctrl_char + strlen(prefix);
        led_num = ssa_port_get_value_from_value_char(led_ctrl_num_char);

        /* 获取unit号 字符串 */
        unit_char = strtok(NULL, ".");
        if (unit_char != NULL) {
            unit = ssa_port_get_value_from_value_char(unit_char);
        } else {
            unit = 0;
        }
    }

    if (led_num < 0 || led_num >= LED_CTRL_NUM) {
        SSTEST_DBG_ERR("led_num range error led_num %d\n", led_num);
        return;
    }

    if (unit < 0 || unit >= MAX_LOCAL_UNIT) {
        SSTEST_DBG_ERR("UNIT_NUM error unit %d\n", unit);
        return;
    }
    (void)memcpy(arr[unit][led_num], value, strlen(value));

    return;
}

/* 解析每行的配置 */
static void ssa_port_analyse_each_config_line(char *config_line)   //传入一个字符串参数名 进行封装 就可以不用解析文件 封装出api
{
    int32_t line_len, i, j, rv;
    char *equal;
    char arg_name[MAX_NAME_LEN];
    char arg_value[MAX_VALUE_LEN];
#if 0
    def_config_t *config;
#endif
    /* 移除配置行所有的空格 */
    line_len = strlen(config_line);
    for (i = 0; i < line_len; i++) {
        if (config_line[i] == '\r' || config_line[i] == '\n' || config_line[i] == ' ') {
            for (j = i; j < line_len - 1; j++) {
                config_line[j] = config_line[j + 1];
            }
            config_line[j] = '\0';
            line_len--;
        }
    }

    if (config_line == NULL) {
        return;
    }

    if (config_line[0] == '#') {
        SSTEST_DBG_TEST("This line is note line!\n");
        return;
    }

    (void)memset(arg_name, 0, MAX_NAME_LEN);
    (void)memset(arg_value, 0, MAX_VALUE_LEN);
    /* 在该行参数后查找'='字符，并记录其位置 */
    equal = strchr(config_line, '=');
    if (equal == NULL) {
        SSTEST_DBG_ERR("no '=' between name and value!\n");
        return;
    }

    /* 提取'='左边的字符串作为参数名 */
    rv = sscanf(config_line, "%[^ =]", arg_name);
    if (rv <= 0) {
        SSTEST_DBG_ERR("sscanf arg to memory error!\n");
        return;
    }

    /* 把'='右边的字符串当做参数值 */
    rv = sscanf((++equal), "%s", arg_value);
    if (rv <= 0) {
        SSTEST_DBG_ERR("possibly arg has no value, sscanf value to memory error!\n");
        return;
    }

    SSTEST_DBG_TEST("config_line %s\narg_name %s\narg_value %s\n", config_line, arg_name, arg_value);

    /* 解析匹配配置项 */
    //arg_name用链表做缓存 传入一个参数  直接匹配链表里面的字符串。 即不用在新增解析文件了。

    if (!memcmp(DEBUG_SSA, arg_name, strlen(DEBUG_SSA))) {
        port_config->debug_ssa = ssa_port_get_value_from_value_char(arg_value);

    /* get adjust min lport no */
    } else if (!memcmp(ADJUST_LPORT_MIN, arg_name, strlen(ADJUST_LPORT_MIN))) {
        port_config->adjust_lport_min = ssa_port_get_value_from_value_char(arg_value);

    /* get adjust max lport no */
    } else if (!memcmp(ADJUST_LPORT_MAX, arg_name, strlen(ADJUST_LPORT_MAX))) {
        port_config->adjust_lport_max = ssa_port_get_value_from_value_char(arg_value);

    /* get cpld addr to dect cpld */
    } else if (!memcmp(CPLD_DECT_SFP_PREFIX, arg_name, strlen(CPLD_DECT_SFP_PREFIX))) {
        ssa_port_get_value_int(arg_name, arg_value, CPLD_DECT_SFP_PREFIX, port_config->cpld_dect_sfp);

    /* get led fiber copper addr */
    } else if (!memcmp(LED_FIBER_COPPER_ADDR, arg_name, strlen(LED_FIBER_COPPER_ADDR))) {
        ssa_port_get_value_int(arg_name, arg_value, LED_FIBER_COPPER_ADDR, port_config->led_fiber_copper_addr);

    /* get cpld addr to enable sfp */
    } else if (!memcmp(CPLD_ENABLE_SFP_PREFIX, arg_name, strlen(CPLD_ENABLE_SFP_PREFIX))) {
        ssa_port_get_value_int(arg_name, arg_value, CPLD_ENABLE_SFP_PREFIX, port_config->cpld_enable_sfp);

    /* get cpld addr to open cpld */
    } else if (!memcmp(CPLD_OPEN_SFP_PREFIX, arg_name, strlen(CPLD_OPEN_SFP_PREFIX))) {
        ssa_port_get_value_int(arg_name, arg_value, CPLD_OPEN_SFP_PREFIX, port_config->cpld_open_sfp);

    /* get linkscan state */
    } else if (!memcmp(LINKSCAN_STATE, arg_name, strlen(LINKSCAN_STATE))) {
        ssa_port_get_value_int(arg_name, arg_value, LINKSCAN_STATE, port_config->linkscan_state);

    /* get cpld state0 */
    } else if (!memcmp(CPLD_STATE0_PREFIX, arg_name, strlen(CPLD_STATE0_PREFIX))) {
        ssa_port_get_value_int(arg_name, arg_value, CPLD_STATE0_PREFIX, port_config->cpld_state0);

    /* get cpld state1 */
    } else if (!memcmp(CPLD_STATE1_PREFIX, arg_name, strlen(CPLD_STATE1_PREFIX))) {
        ssa_port_get_value_int(arg_name, arg_value, CPLD_STATE1_PREFIX, port_config->cpld_state1);

    /* get cpld exchange */
    } else if (!memcmp(CPLD_EXCHANGE_PREFIX, arg_name, strlen(CPLD_EXCHANGE_PREFIX))) {
        ssa_port_get_value_int(arg_name, arg_value, CPLD_EXCHANGE_PREFIX, port_config->cpld_exchange);

    /* get qsfp reset cpld address */
    } else if (!memcmp(QSFP_PORT_RESET_ADDR, arg_name, strlen(QSFP_PORT_RESET_ADDR))) {
        ssa_port_get_value_int_one(arg_name, arg_value, QSFP_PORT_RESET_ADDR, port_config->qsfp_reset_addr);

    /* get qsfp reset cpld value */
    } else if (!memcmp(QSFP_PORT_RESET_VALUE, arg_name, strlen(QSFP_PORT_RESET_VALUE))) {
        ssa_port_get_value_int_one(arg_name, arg_value, QSFP_PORT_RESET_VALUE, port_config->qsfp_reset_val);

    /* get i2c name */
    } else if (!memcmp(SFP_I2C_DEV, arg_name, strlen(SFP_I2C_DEV))) {
        ssa_port_get_value_to_str(arg_name, arg_value, SFP_I2C_DEV, port_config->sfp_i2c_dev);
    /* get cpld name */
    } else if (!memcmp(SFP_CPLD_DEV, arg_name, strlen(SFP_CPLD_DEV))) {
        ssa_port_get_value_to_str(arg_name, arg_value, SFP_CPLD_DEV, port_config->sfp_cpld_dev);
    /* get read sfp type offset in i2c dev */
    } else if (!memcmp(SFP_TYPE_OFFSET_ADDR, arg_name, strlen(SFP_TYPE_OFFSET_ADDR))) {
        port_config->sfp_type_offset_addr = ssa_port_get_value_from_value_char(arg_value);

    /* get sfp's address in i2c */
    } else if (!memcmp(SFP_ON_I2C_ADDR, arg_name, strlen(SFP_ON_I2C_ADDR))) {
        port_config->sfp_on_i2c_addr = ssa_port_get_value_from_value_char(arg_value);

    /* get sfp adjust thread interval time */
    } else if (!memcmp(SFP_ADJUST_TIME, arg_name, strlen(SFP_ADJUST_TIME))) {
        port_config->sfp_adj_thread_time = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(LINKSCAM_TIME, arg_name, strlen(LINKSCAM_TIME))) {
        port_config->linkscan_time = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(LINKSCAM_TYPE, arg_name, strlen(LINKSCAM_TYPE))) {
        port_config->linkscan_type= ssa_port_get_value_from_value_char(arg_value);

    /* get giga copper thread */
    } else if (!memcmp(GIGA_COPPER_THREAD, arg_name, strlen(GIGA_COPPER_THREAD))) {
        port_config->giga_copper_thread = ssa_port_get_value_from_value_char(arg_value);

    /* get fast link scan time, just be used when giga copper larger FAST_LINKSCAN_ADJUST_PNUM */
    } else if (!memcmp(FAST_LINKSCAN_TIME, arg_name, strlen(FAST_LINKSCAN_TIME))) {
        port_config->fast_linkscan_adjust_time = ssa_port_get_value_from_value_char(arg_value);

    /* get last need fast link scan port */
    } else if (!memcmp(FAST_LINKSCAN_ADJUST_PNUM, arg_name, strlen(FAST_LINKSCAN_ADJUST_PNUM))) {
        port_config->fast_linkscan_adjust_pnum = ssa_port_get_value_from_value_char(arg_value);

    /* get need create adjust thread */
    } else if (!memcmp(IRQ_ADUST_THEARD, arg_name, strlen(IRQ_ADUST_THEARD))) {
        port_config->irq_adjust_thread = ssa_port_get_value_from_value_char(arg_value);

    /* get need set edc */
    } else if (!memcmp(SET_EDC, arg_name, strlen(SET_EDC))) {
        port_config->set_edc = ssa_port_get_value_from_value_char(arg_value);

    /* open qfp need write i2c */
    } else if (!memcmp(QSFP_OPEN_METHOD_I2C, arg_name, strlen(QSFP_OPEN_METHOD_I2C))) {
        port_config->qsfp_open_method_i2c = ssa_port_get_value_from_value_char(arg_value);

    /* open qfp cpld address */
    } else if (!memcmp(QSFP_POWER_EN_ADDR, arg_name, strlen(QSFP_POWER_EN_ADDR))) {
        port_config->qsfp_power_en_addr = ssa_port_get_value_from_value_char(arg_value);

    /* open qfp cpld value */
    } else if (!memcmp(QSFP_POWER_EN_VALUE, arg_name, strlen(QSFP_POWER_EN_VALUE))) {
        port_config->qsfp_power_en_value = ssa_port_get_value_from_value_char(arg_value);

    /* get need first fiber port number */
    } else if (!memcmp(FIRST_FIBER_PORT_OFFSET, arg_name, strlen(FIRST_FIBER_PORT_OFFSET))) {
        port_config->first_fiber_port = ssa_port_get_value_from_value_char(arg_value);

    /* get get port number in a group */
    } else if (!memcmp(CPLD_GROUP_PORT_NUM, arg_name, strlen(CPLD_GROUP_PORT_NUM))) {
        port_config->cpld_pnum_pgroup = ssa_port_get_value_from_value_char(arg_value);

    /* get need set preemphasis */
    } else if (!memcmp(SET_PREEMS, arg_name, strlen(SET_PREEMS))) {
        port_config->set_preemphasis = ssa_port_get_value_from_value_char(arg_value);
    /* get get cpld offset on cpld reg */
    } else if (!memcmp(CPLD_OFFSET_REG, arg_name, strlen(CPLD_OFFSET_REG))) {
        ssa_port_get_value_int_one(arg_name, arg_value, CPLD_OFFSET_REG, port_config->cpld_offset_reg);
    /* get the lane accord to port */
    } else if (!memcmp(PORT_TO_LANE, arg_name, strlen(PORT_TO_LANE))) {
        ssa_port_get_value_int_one(arg_name, arg_value, PORT_TO_LANE, port_config->port_to_lane);

    /* get need set protect port */
    } else if (!memcmp(NO_SUP_PROTECT, arg_name, strlen(NO_SUP_PROTECT))) {
        port_config->no_sup_protect = ssa_port_get_value_from_value_char(arg_value);

    /* get protect port need config trunk */
    } else if (!memcmp(PROTECT_TRUNK, arg_name, strlen(PROTECT_TRUNK))) {
        port_config->protect_trunk = ssa_port_get_value_from_value_char(arg_value);

    /* get port can set jam */
    } else if (!memcmp(SET_JAM, arg_name, strlen(SET_JAM))) {
        port_config->set_jam = ssa_port_get_value_from_value_char(arg_value);

    /* get port mac and phy not autoneg */
    } else if (!memcmp(EVADE_MAC_AND_PHY, arg_name, strlen(EVADE_MAC_AND_PHY))) {
        port_config->evade_mac_and_phy = ssa_port_get_value_from_value_char(arg_value);

    /* get port rdbgc8 over size */
    } else if (!memcmp(RDBGC8_OVER_SIZE, arg_name, strlen(RDBGC8_OVER_SIZE))) {
        port_config->rdbgc8_over_size = ssa_port_get_value_from_value_char(arg_value);

    /* get port rdbgc8 over size */
    } else if (!memcmp(RDBGC8_SET64_BIT, arg_name, strlen(RDBGC8_SET64_BIT))) {
        port_config->rdbgc8_set64_bit = ssa_port_get_value_from_value_char(arg_value);

    /* get giga fiber speed auto set to 1000 */
    } else if (!memcmp(GIGA_FIBER_AUTO_TO_MAX, arg_name, strlen(GIGA_FIBER_AUTO_TO_MAX))) {
        port_config->giga_fiber_auto_to_max = ssa_port_get_value_from_value_char(arg_value);

    /* get giga copper speed 1000 must set an */
    } else if (!memcmp(GIGA_COPPER_1000_AN_EN, arg_name, strlen(GIGA_COPPER_1000_AN_EN))) {
        port_config->giga_copper_1000_an_en = ssa_port_get_value_from_value_char(arg_value);

    /* get tengiga copper speed 1000 must set an */
    } else if (!memcmp(TENGIGA_COPPER_1000_AN_EN, arg_name, strlen(TENGIGA_COPPER_1000_AN_EN))) {
        port_config->tengiga_copper_1000_an_en = ssa_port_get_value_from_value_char(arg_value);

    /* get tengiga copper speed 10000 must set an */
    } else if (!memcmp(TENGIGA_COPPER_10G_AN_EN, arg_name, strlen(TENGIGA_COPPER_10G_AN_EN))) {
        port_config->tengiga_copper_10g_an_en = ssa_port_get_value_from_value_char(arg_value);

    /* get interval time when shutdown and no shutdown */
    } else if (!memcmp(ADMIN_SLEEP_TIME, arg_name, strlen(ADMIN_SLEEP_TIME))) {
        port_config->admin_sleep_time = ssa_port_get_value_from_value_char(arg_value);

    /* get interval time when set speed duple flowctrl */
    } else if (!memcmp(ATT_SLEEP_TIME, arg_name, strlen(ATT_SLEEP_TIME))) {
        port_config->att_sleep_time = ssa_port_get_value_from_value_char(arg_value);

    /* get need user new function to set mtu */
    } else if (!memcmp(MTU_RESET, arg_name, strlen(MTU_RESET))) {
        port_config->mtu_reset = ssa_port_get_value_from_value_char(arg_value);

    /* get led reg address to open led */
    } else if (!memcmp(LED_REG_ADDR, arg_name, strlen(LED_REG_ADDR))) {
        port_config->led_reg_addr = ssa_port_get_value_from_value_char(arg_value);

    /* get led reg value to open led */
    } else if (!memcmp(LED_REG_SET_VALUE, arg_name, strlen(LED_REG_SET_VALUE))) {
        port_config->led_reg_set_value = ssa_port_get_value_from_value_char(arg_value);

    /* get reg address used enale interrupt to cpu */
    } else if (!memcmp(INTERRUPT_T0_CPU_ADDR, arg_name, strlen(INTERRUPT_T0_CPU_ADDR))) {
        port_config->interrupt_to_cpu_en_reg = ssa_port_get_value_from_value_char(arg_value);

    /* get reg value used enale interrupt to cpu */
    } else if (!memcmp(INTERRUPT_TO_CPU_SET_VALUE, arg_name, strlen(INTERRUPT_TO_CPU_SET_VALUE))) {
        port_config->interrupt_to_cpu_value = ssa_port_get_value_from_value_char(arg_value);

    /* get split port to merge */
    } else if (!memcmp(SPLIT_PORT_TO_MERGE, arg_name, strlen(SPLIT_PORT_TO_MERGE))) {
        ssa_port_get_value_int(arg_name, arg_value, SPLIT_PORT_TO_MERGE, port_config->split_port_to_merge);

    /* get fastlink type */
    } else if (!memcmp(FASTLINK_TYPE, arg_name, strlen(FASTLINK_TYPE))) {
        port_config->fastlink_type= ssa_port_get_value_from_value_char(arg_value);

      /* get fastlink type */
    } else if (!memcmp(PHY_SCAN, arg_name, strlen(PHY_SCAN))) {
        ssa_port_get_value_int(arg_name, arg_value, PHY_SCAN, port_config->phy_scan);

    /* get led ctrol code */
    } else if (!memcmp(LED_CTRL_CODE, arg_name, strlen(LED_CTRL_CODE))) {
        ssa_port_get_led_code_str(arg_name, arg_value, LED_CTRL_CODE, port_config->led_ctrl_code);

    } else if (!memcmp(FAC_LED_CTRL_CODE, arg_name, strlen(FAC_LED_CTRL_CODE))) {
       ssa_port_get_led_code_str(arg_name, arg_value, FAC_LED_CTRL_CODE, port_config->fac_led_ctrl_code);
    } else if (!memcmp(POE_LED_CTRL_CODE, arg_name, strlen(POE_LED_CTRL_CODE))) {
        ssa_port_get_led_code_str(arg_name, arg_value, POE_LED_CTRL_CODE, port_config->poe_led_ctrl_code);

    } else if (!memcmp(LED_PORT_MAX, arg_name, strlen(LED_PORT_MAX))) {
        port_config->led_port_max= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(LED_40g_DATA_RAM, arg_name, strlen(LED_40g_DATA_RAM))) {
        ssa_port_get_value_int(arg_name, arg_value, LED_40g_DATA_RAM, port_config->led_40g_data_ram);

    } else if (!memcmp(LED_CALLBACK_TYPE, arg_name, strlen(LED_CALLBACK_TYPE))) {
        port_config->led_callback_type= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(ADVER_TYPE, arg_name, strlen(ADVER_TYPE))) {
        port_config->adver_type = ssa_port_get_value_from_value_char(arg_value);
    }  else if (!memcmp(COPPER_PRE_LANE0_, arg_name, strlen(COPPER_PRE_LANE0_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_PRE_LANE0_, port_config->copper_pre_lane0);

    } else if (!memcmp(COPPER_PRE_LANE1_, arg_name, strlen(COPPER_PRE_LANE1_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_PRE_LANE1_, port_config->copper_pre_lane1);

    } else if (!memcmp(COPPER_PRE_LANE2_, arg_name, strlen(COPPER_PRE_LANE2_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_PRE_LANE2_, port_config->copper_pre_lane2);

    } else if (!memcmp(COPPER_PRE_LANE3_, arg_name, strlen(COPPER_PRE_LANE3_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_PRE_LANE3_, port_config->copper_pre_lane3);

    } else if (!memcmp(COPPER_DRV_LANE0_, arg_name, strlen(COPPER_DRV_LANE0_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_DRV_LANE0_, port_config->copper_drv_lane0);

    } else if (!memcmp(COPPER_DRV_LANE1_, arg_name, strlen(COPPER_DRV_LANE1_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_DRV_LANE1_, port_config->copper_drv_lane1);

    } else if (!memcmp(COPPER_DRV_LANE2_, arg_name, strlen(COPPER_DRV_LANE2_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_DRV_LANE2_, port_config->copper_drv_lane2);

    } else if (!memcmp(COPPER_DRV_LANE3_, arg_name, strlen(COPPER_DRV_LANE3_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_DRV_LANE3_, port_config->copper_drv_lane3);

    } else if (!memcmp(FIBER_PRE_LANE0_, arg_name, strlen(FIBER_PRE_LANE0_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_PRE_LANE0_, port_config->fiber_pre_lane0);

    } else if (!memcmp(FIBER_PRE_LANE1_, arg_name, strlen(FIBER_PRE_LANE1_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_PRE_LANE1_, port_config->fiber_pre_lane1);

    } else if (!memcmp(FIBER_PRE_LANE2_, arg_name, strlen(FIBER_PRE_LANE2_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_PRE_LANE2_, port_config->fiber_pre_lane2);

    } else if (!memcmp(FIBER_PRE_LANE3_, arg_name, strlen(FIBER_PRE_LANE3_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_PRE_LANE3_, port_config->fiber_pre_lane3);

    } else if (!memcmp(FIBER_DRV_LANE0_, arg_name, strlen(FIBER_DRV_LANE0_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_DRV_LANE0_, port_config->fiber_drv_lane0);

    } else if (!memcmp(FIBER_DRV_LANE1_, arg_name, strlen(FIBER_DRV_LANE1_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_DRV_LANE1_, port_config->fiber_drv_lane1);

    } else if (!memcmp(FIBER_DRV_LANE2_, arg_name, strlen(FIBER_DRV_LANE2_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_DRV_LANE2_, port_config->fiber_drv_lane2);

    } else if (!memcmp(FIBER_DRV_LANE3_, arg_name, strlen(FIBER_DRV_LANE3_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_DRV_LANE3_, port_config->fiber_drv_lane3);

    } else if (!memcmp(COPPER_EQ_LANE0_, arg_name, strlen(COPPER_EQ_LANE0_))) {
        ssa_port_get_value_int(arg_name, arg_value, COPPER_EQ_LANE0_, port_config->copper_eq_lane0);

    } else if (!memcmp(FIBER_EQ_LANE0_, arg_name, strlen(FIBER_EQ_LANE0_))) {
        ssa_port_get_value_int(arg_name, arg_value, FIBER_EQ_LANE0_, port_config->fiber_eq_lane0);

    } else if (!memcmp(DEF_PRE, arg_name, strlen(DEF_PRE))) {
        port_config->def_pre = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(DEF_DRV, arg_name, strlen(DEF_DRV))) {
        port_config->def_drv = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(WC_MODE, arg_name, strlen(WC_MODE))) {
        port_config->wc_mode= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(MDIX_MODE_CFG, arg_name, strlen(MDIX_MODE_CFG))) {
        port_config->mdix_mode= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(MTU_ADD_LEN, arg_name, strlen(MTU_ADD_LEN))) {
        ssa_port_get_value_int(arg_name, arg_value, MTU_ADD_LEN, port_config->mtu_add_len);

    } else if (!memcmp(OVERSIZE_FRM_ADD_LEN, arg_name, strlen(OVERSIZE_FRM_ADD_LEN))) {
        ssa_port_get_value_int(arg_name, arg_value, OVERSIZE_FRM_ADD_LEN, port_config->oversize_frm_add_len);

    } else if (!memcmp(NEED_UNRELIABLE_LOS, arg_name, strlen(NEED_UNRELIABLE_LOS))) {
        ssa_port_get_value_int(arg_name, arg_value, NEED_UNRELIABLE_LOS, port_config->need_unreliable_los);

    } else if (!memcmp(LB_TYPE, arg_name, strlen(LB_TYPE))) {
        port_config->lb_type= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(GT_ALWAYS_AN, arg_name, strlen(GT_ALWAYS_AN))) {
        port_config->gt_always_an= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(FIRMWARE_DFE_ENABLE, arg_name, strlen(FIRMWARE_DFE_ENABLE))) {
        port_config->firmware_dfe_enable = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(FIR_MODE, arg_name, strlen(FIR_MODE))) {
        port_config->fir_mode= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(SET_PREAMBLE, arg_name, strlen(SET_PREAMBLE))) {
        port_config->set_preamble= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(SET_PCIE, arg_name, strlen(SET_PCIE))) {
        port_config->set_pcie= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(FLOW_EXTERN, arg_name, strlen(FLOW_EXTERN))) {
        port_config->flow_extern= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(PAUSE_INIT, arg_name, strlen(PAUSE_INIT))) {
        port_config->pause_init= ssa_port_get_value_from_value_char(arg_value);

    }  else if (!memcmp(DEFAULT_MTU, arg_name, strlen(DEFAULT_MTU))) {
        port_config->default_mtu= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(COUNTER_DOWN_UPDATE, arg_name, strlen(COUNTER_DOWN_UPDATE))) {
        port_config->counter_down_update = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(PORT_IF_CHANGE, arg_name, strlen(PORT_IF_CHANGE))) {
        ssa_port_get_value_int(arg_name, arg_value, PORT_IF_CHANGE, port_config->port_if_change);

    } else if (!memcmp(NO_SUP_LINEDET, arg_name, strlen(NO_SUP_LINEDET))) {
        port_config->no_sup_linedet= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(GT_FAKE_LINK, arg_name, strlen(GT_FAKE_LINK))) {
        port_config->gt_fake_link = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(SERDES_IF_TYPE, arg_name, strlen(SERDES_IF_TYPE))) {
        port_config->serdes_if_type= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(IF_TYPE_COPPER_TENGI, arg_name, strlen(IF_TYPE_COPPER_TENGI))) {
        port_config->if_type_copper_tengi= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(IF_TYPE_FIBER_TENGI, arg_name, strlen(IF_TYPE_FIBER_TENGI))) {
        port_config->if_type_fiber_tengi= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(IF_TYPE_COPPER_FORTYGI, arg_name, strlen(IF_TYPE_COPPER_FORTYGI))) {
        port_config->if_type_copper_fortygi= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(IF_TYPE_FIBER_FORTYGI, arg_name, strlen(IF_TYPE_FIBER_FORTYGI))) {
        port_config->if_type_fiber_fortygi= ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(IF_TYPE_COPPER_HUNDREDGI, arg_name, strlen(IF_TYPE_COPPER_HUNDREDGI))) {
        port_config->if_type_copper_hundredgi= ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(IF_TYPE_FIBER_HUNDREDGI, arg_name, strlen(IF_TYPE_FIBER_HUNDREDGI))) {
        port_config->if_type_fiber_hundredgi= ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(INERROR_EXCLUDE_RMTU, arg_name, strlen(INERROR_EXCLUDE_RMTU))) {
        port_config->inerror_exclude_rmtu = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(MAC_LB_FORCE_LINK, arg_name, strlen(MAC_LB_FORCE_LINK))) {
        port_config->mac_lb_force_link = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(APD_TYPE, arg_name, strlen(APD_TYPE))) {
        port_config->apd_type = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(USE_XFP, arg_name, strlen(USE_XFP))) {
        port_config->use_xfp = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(OVERRIDE_AN_CONF_IN_CACHE, arg_name, strlen(OVERRIDE_AN_CONF_IN_CACHE))) {
        ssa_port_get_value_int(arg_name, arg_value, OVERRIDE_AN_CONF_IN_CACHE, port_config->override_an_conf_in_cache);
    } else if (!memcmp(MODULE_READY_TIME, arg_name, strlen(MODULE_READY_TIME))) {
        port_config->module_ready_time = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(FORCED_100M_ON_XT, arg_name, strlen(FORCED_100M_ON_XT))) {
        port_config->forced_100m_on_xt = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(SPLIT_40G_MAXPORT, arg_name, strlen(SPLIT_40G_MAXPORT))) {
        port_config->split_40g_maxport= ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(MAC_CPLD_ROV_TYPE, arg_name, strlen(MAC_CPLD_ROV_TYPE))) {
        port_config->mac_cpld_rov_type = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(MAC_CPLD_ROV_ADDR, arg_name, strlen(MAC_CPLD_ROV_ADDR))) {
        port_config->mac_cpld_rov_addr = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(EXT_PHY_PREEMPHASIS, arg_name, strlen(EXT_PHY_PREEMPHASIS))) {
        ssa_port_get_value_int_one(arg_name, arg_value, EXT_PHY_PREEMPHASIS, port_config->ext_phy_preemphasis);
    } else if (!memcmp(FEATURE_VSL_NO_SPEED_SET, arg_name, strlen(FEATURE_VSL_NO_SPEED_SET))) {
        port_config->feature_vsl_no_speed_set= ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(COPPER_PORT_ABILITY_, arg_name, strlen(COPPER_PORT_ABILITY_))) {
        ssa_port_get_value_int_64(arg_name, arg_value, COPPER_PORT_ABILITY_, port_config->copper_port_ability);
    } else if (!memcmp(FIBER_PORT_ABILITY_, arg_name, strlen(FIBER_PORT_ABILITY_))) {
        ssa_port_get_value_int_64(arg_name, arg_value, FIBER_PORT_ABILITY_, port_config->fiber_port_ability);
    } else if (!memcmp(FEATURE_SFP_DO_ANTIFAKE, arg_name, strlen(FEATURE_SFP_DO_ANTIFAKE))) {
        port_config->feature_sfp_do_antifake = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(SPLIT_LPORT_LANE_INFO, arg_name, strlen(SPLIT_LPORT_LANE_INFO))) {
        ssa_port_get_value_int_one(arg_name, arg_value, SPLIT_LPORT_LANE_INFO, port_config->split_lport_lane_info);
    } else if (!memcmp(PORT_MIN_SUPP_VSL_SPEED, arg_name, strlen(PORT_MIN_SUPP_VSL_SPEED))) {
        ssa_port_get_value_int(arg_name, arg_value, PORT_MIN_SUPP_VSL_SPEED, port_config->port_min_supp_vsl_speed);

    } else if (!memcmp(SFP_PRESENT_CACHE_DECT, arg_name, strlen(SFP_PRESENT_CACHE_DECT))) {
        ssa_port_get_value_int(arg_name, arg_value, SFP_PRESENT_CACHE_DECT, port_config->sfp_present_cache_dect);

    } else if (!memcmp(SFP_PRESENT_CACHE, arg_name, strlen(SFP_PRESENT_CACHE))) {
        ssa_port_get_value_int(arg_name, arg_value, SFP_PRESENT_CACHE, port_config->sfp_present_cache);
    /* bug472187 */
    } else if (!memcmp(MIB_NOTIFY_LINGER_CNT, arg_name, strlen(MIB_NOTIFY_LINGER_CNT))) {
        port_config->mib_notify_linger_cnt = ssa_port_get_value_from_value_char(arg_value);

    } else if (!memcmp(FIBER_INTERRUPT_VAL, arg_name, strlen(FIBER_INTERRUPT_VAL))) {
        port_config->fiber_interrupt_val = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(COPPER_INTERRUPT_VAL, arg_name, strlen(COPPER_INTERRUPT_VAL))) {
        port_config->copper_interrupt_val = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(EXTERNEL_PHY_TYPE, arg_name, strlen(EXTERNEL_PHY_TYPE))) {
        ssa_port_get_value_int(arg_name, arg_value, EXTERNEL_PHY_TYPE, port_config->externel_phy_type);
    } else if (!memcmp(LS_TYPE_LPORT, arg_name, strlen(LS_TYPE_LPORT))) {
        ssa_port_get_value_int(arg_name, arg_value, LS_TYPE_LPORT, port_config->ls_type_lport);
    } else if (!memcmp(AN_ENSURE_PORT_ENABLED, arg_name, strlen(AN_ENSURE_PORT_ENABLED))) {
        port_config->an_ensure_port_enabled = ssa_port_get_value_from_value_char(arg_value);
    }  else if (!memcmp(BACKPLANE_PORT_SPEC, arg_name, strlen(BACKPLANE_PORT_SPEC))) {
        ssa_port_get_value_int(arg_name, arg_value, BACKPLANE_PORT_SPEC, port_config->backplane_port_spec);
    } else if (!memcmp(AN_UNSUPPORTED, arg_name, strlen(AN_UNSUPPORTED))) {
        port_config->an_unsupported = ssa_port_get_value_from_value_char(arg_value);
    } else if (!memcmp(SPEED_CHANGE_FLOW_CTRL, arg_name, strlen(SPEED_CHANGE_FLOW_CTRL))) {
        port_config->speed_change_flow_ctrl = ssa_port_get_value_from_value_char(arg_value);
    }
    else {
#if 0   /* coverity fix */
        //没有找到对应的config line
        //将得到的字符串存储到链表，后面直接链表查询 o(n)，复杂度
        config = (def_config_t *)malloc(sizeof(def_config_t));
        if (config == NULL) {
        printf("malloc fail in confog.c\n");
            //之前存储的链表内容 不用释放，后面可查询
            return ;
        }
        memset(config, 0, sizeof(def_config_t));
        memcpy(config->config_line, arg_name, strlen(arg_name));
        memcpy(config->config_val, arg_value, strlen(arg_value));
        list_add_tail(&(config->lst), &config_var);
#endif
        SSA_PTD_ZLOG_ERROR("no find config end arg_name %s arg_value %s\n ", arg_name, arg_value);
    }

    return;
}

#if 0
/* 支持sdk 配置获取 */
int ptd_config_get(char *config_line, int def)
{
    def_config_t *config;

    list_for_each_entry(config, &config_var, lst) {
        if(!memcmp(config->config_line, config_line, strlen(config_line))) {
            return (int)ssa_port_get_value_from_value_char(config->config_val);
        }
    }

    return def;
}
#endif

/**
 * ssa_port_conf_file_init - 配置文件初始化   端口负责自己初始化起来
 *
 * return: void  需要支持读取指定配置文件 to do by 许东旭
 * 1.读取配置文件解析 2.dm 集成获取类型 端口类型 3.link通告写数据库
 */
int32_t ssa_port_conf_file_init(void)
{
    FILE *fp;
    char file_bcm[100];
    char config_line[1000];
    int32_t i;
    struct timeval t_start,t_end;

    char config_name[32] = "config_port";
    char *name;

    name = config_name;
    gettimeofday(&t_start, NULL);
    SSTEST_DBG_TEST("ssa port config file init!\n");

    /* malloc port config control  */
    port_config = (ssa_port_lc_config_t *)malloc(sizeof(ssa_port_lc_config_t));
    if (port_config == NULL) {
        SSTEST_DBG_ERR("no enough memory\n");
        return SSA_PORT_E_MEMORY;
    }
    (void)memset(port_config, 0, sizeof(ssa_port_lc_config_t));
    SSTEST_DBG_TEST("malloc port config ok\n");

    /* get config file,分配的空间大小为100，足够大，不需要判断是否数组越界 */
    (void)memset(file_bcm, 0, sizeof(file_bcm));
    strcpy((char *)file_bcm, PORT_CONFIG_FILE_DIR);
    strcat((char *)file_bcm, (char *)name);
    strcat((char *)file_bcm, PORT_CONFIG_FILE_BCM);
    SSTEST_DBG_TEST("file_name %s\n", file_bcm);

    if ((fp = fopen((char *)file_bcm, "r")) == NULL) {
        SSTEST_DBG_ERR("read file %s fail!\n", file_bcm);
        free(port_config);
        return SSA_PORT_E_RETURN;
    }

    /* analyse each config line */
    i = 0;
    (void)memset(config_line, 0, sizeof(config_line));
    INIT_LIST_HEAD(&config_var);
    while (fgets(config_line, 1000, fp) != NULL){
        SSTEST_DBG_TEST("line %d\n", i++);
        ssa_port_analyse_each_config_line(config_line);
        (void)memset(config_line, 0, 1000);
    }

    SSTEST_DBG_TEST("ssa port config file init OK!\n");

    fclose(fp);

    gettimeofday(&t_end, NULL);
    time_need = (t_end.tv_sec - t_start.tv_sec) * 1000 + (t_end.tv_usec - t_start.tv_usec) / 1000;
    SSTEST_DBG_TEST("read this file need consume %d s\n", time_need);

    return SSA_PORT_E_NONE;
}

uint32_t ssa_port_cfg_get_read_cfgfile_time(void)
{
    return time_need;
}

int32_t ssa_port_cfg_get_debug_ssa(void)
{
    return port_config->debug_ssa;
}
// sfp在位检测的CPLD地址
int32_t ssa_port_cfg_get_cpld_dect_sfp_addr(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->cpld_dect_sfp[lport - 1];
}
/* 每个端口一个打开sfp cpld地址 */
int32_t ssa_port_cfg_get_cpld_open_sfp_addr(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->cpld_open_sfp[lport - 1];
}
// 未使用
int32_t ssa_port_cfg_get_led_fiber_copper_addr(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->led_fiber_copper_addr[lport - 1];
}
/* 每个端口一个使能sfp的cpld地址 */
int32_t ssa_port_cfg_get_cpld_enable_sfp_addr(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->cpld_enable_sfp[lport - 1];
}

// CPLD offset 的调整参数
int32_t ssa_port_cfg_get_cpld_exchange(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->cpld_exchange[lport - 1];
}

//定义sfp的I2C设备名称
char *ssa_port_cfg_get_sfp_i2c_dev_name(int32_t lport)
{
    if (((lport) <= 0) || ((lport) > MAX_LPORT_NUM)) {
        return NULL;;
    }

    return port_config->sfp_i2c_dev[lport - 1];
}
// enable sfp的cpld寄存器地址
char *ptd_cfg_get_sfp_cpld_dev_name(int32_t lport)
{
    if (((lport) <= 0) || ((lport) > MAX_LPORT_NUM)) {
        return NULL;;
    }

    return port_config->sfp_cpld_dev[lport - 1];
}
// sfp的i2c地址
int32_t ssa_port_cfg_get_sfp_on_i2c_addr(void)
{
    return port_config->sfp_on_i2c_addr;
}


/* 电口speed 1000M 需开启自协商，暂时不需要 */
int32_t ssa_port_cfg_get_giga_copper_1000_an_en(void)
{
    return port_config->giga_copper_1000_an_en;
}

/* 千兆光口speed auto 需设置成1G ，不需要*/
int32_t ssa_port_cfg_get_giga_fiber_speed_auto_to_max(void)
{
    return port_config->giga_fiber_auto_to_max;
}
/* 电口speed 10g 需开启自协商，暂时不需要 */
int32_t ssa_port_cfg_get_tengiga_copper_10g_an_en(void)
{
    return port_config->tengiga_copper_10g_an_en;
}
/* 电口speed 10g 需开启自协商，暂时不需要 */
int32_t ssa_port_cfg_get_tengiga_copper_1000_an_en(void)
{
    return port_config->tengiga_copper_1000_an_en;
}
/* shut/noshut后的时间间隔，但是实际上用在了mib获取的时间间隔 */
int32_t ssa_port_cfg_get_admin_sleep_time(void)
{
    return port_config->admin_sleep_time;
}
/* 设置速率/双工/流控后的时间间隔 ，未使用*/
int32_t ssa_port_cfg_get_att_sleep_time(void)
{
    return port_config->att_sleep_time;
}
// 不需要
int32_t ssa_port_cfg_get_split_port_to_merge(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->split_port_to_merge[lport - 1];
}
// 每个端口在寄存器中的bit位
int32_t ssa_port_cfg_get_cpld_offset_reg(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->cpld_offset_reg[lport - 1];
}
// 未使用
int32_t ssa_port_cfg_get_sfp_type_offset(void)
{
    return port_config->sfp_type_offset_addr;
}
//需要
int32_t ssa_port_cfg_get_first_fiber_port_offset(void)
{
    if (port_config->first_fiber_port) {
        return port_config->first_fiber_port;
    } else {
        return 1;
    }
}
// 需要
int32_t ssa_port_cfg_get_cpld_pnum_group(void)
{
    if (port_config->cpld_pnum_pgroup) {
        return port_config->cpld_pnum_pgroup;
    } else {
        return 8;                        /* 缺省8个端口1组 */
    }
}
// 不需要

int32_t ssa_port_cfg_get_qsfp_open_method_i2c(void)
{
    return port_config->qsfp_open_method_i2c;
}
// 不需要

int32_t ssa_port_cfg_get_mac_and_phy_not_an(void)
{
    return port_config->evade_mac_and_phy;
}
// 不需要
int32_t ssa_port_cfg_get_qsfp_power_en_addr(void)
{
    return port_config->qsfp_power_en_addr;
}
// 不需要
unsigned char ssa_port_cfg_get_qsfp_power_en_value(void)
{
    return port_config->qsfp_power_en_value;
}
// lport的最小值
uint32_t ssa_port_cfg_get_adjust_lport_min(void)
{
    return port_config->adjust_lport_min;
}
// lport的最大值
uint32_t ssa_port_cfg_get_adjust_lport_max(void)
{
    return port_config->adjust_lport_max;
}
// 不需要
int32_t ssa_port_cfg_get_copper_fastlink_type(void)
{
    return port_config->fastlink_type;
}
// 是否需要phy scan
int32_t ssa_port_cfg_get_phy_scan(int32_t lport)
{
    return port_config->phy_scan[lport - 1];
}
//不需要
char * ssa_port_cfg_get_led_code(void)
{
    return (char *)port_config->led_ctrl_code;
}
//不需要
char * ssa_port_cfg_get_poe_led_code(void)
{
    return (char *)port_config->poe_led_ctrl_code;
}
//不需要
int32_t ssa_port_cfg_get_led_port_max(void)
{
    return port_config->led_port_max;
}
//不需要
int32_t ssa_port_cfg_get_led_40g_data_ram(int32_t lport)
{
    return port_config->led_40g_data_ram[lport - 1];
}
// 不需要
int32_t ssa_port_cfg_get_led_callback_type(void)
{
    /* 1表示 arad 方式, 2表示 td2 方式 3表示 tr3 方式 */
    return port_config->led_callback_type;
}
// qsfp的，不需要
void ssa_port_cfg_get_qsfp_reset_addr(int32_t *addr)
{
    (void)memcpy(addr, port_config->qsfp_reset_addr, MAX_LPORT_NUM);
}
// qsfp的，不需要
void ssa_port_cfg_get_qsfp_reset_val(int32_t *val)
{
    (void)memcpy(val, port_config->qsfp_reset_val, MAX_LPORT_NUM);
}
// 不需要
int32_t ssa_port_cfg_get_adver_type(void)
{
    return port_config->adver_type;
}
//未使用
int32_t ssa_port_cfg_get_wcmode(void)
{
    return port_config->wc_mode;
}
//未使用
int32_t ssa_port_cfg_get_mdixmode(void)
{
    return port_config->mdix_mode;
}

// 不需要
int32_t ssa_port_cfg_get_mtu_add_len(int32_t lport)
{
    return port_config->mtu_add_len[lport - 1];
}
// 不需要
int32_t ssa_port_cfg_get_oversize_frm_add_len(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);
    return port_config->oversize_frm_add_len[lport - 1];
}
// 不需要
int32_t ssa_port_cfg_get_need_unreliable_los(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);
    return port_config->need_unreliable_los[lport - 1];
}
// 不需要
int32_t ssa_port_cfg_get_prt_min_supp_vsl_speed(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);
    return port_config->port_min_supp_vsl_speed[lport - 1];
}
// lport和多个CPLD寄存器之间的对应关系
int32_t ssa_port_cfg_get_sfp_present_cache_dect(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);
    return port_config->sfp_present_cache_dect[lport - 1];
}
//sfp_present 的CPLD寄存器地址，可以有多个
int32_t ssa_port_cfg_get_sfp_present_cache(int32_t num)
{
    CPLD_RANGE_CHECK(num);
    return port_config->sfp_present_cache[num - 1];
}
//loopback类型，比如是mac还是phy
int32_t ssa_port_cfg_get_lb_type(void)
{
    return port_config->lb_type;
}
//不需要
int32_t ssa_port_cfg_get_gt_always_an(void)
{
    return port_config->gt_always_an;
}
// 可以不需要，NPS上没有复用或光电转换接口
int32_t ssa_port_cfg_get_firmware_dfe_enable(void)
{
    return port_config->firmware_dfe_enable;
}
// 可以不需要，NPS上没有复用或光电转换接口
int32_t ssa_port_cfg_get_fir_mode(void)
{
    return port_config->fir_mode;
}
//不需要
int32_t ssa_port_cfg_get_set_preamble(void)
{
    return port_config->set_preamble;
}
// 不需要
int32_t ssa_port_cfg_get_set_pcie(void)
{
    return port_config->set_pcie;
}
// 可以不用
int32_t ssa_port_cfg_get_flow_extern(void)
{
    return port_config->flow_extern;
}
// pause初始值
int32_t ssa_port_cfg_get_pause_init(void)
{
    return port_config->pause_init;
}
// 默认MTU值
int32_t ssa_port_cfg_get_default_mtu(void)
{
    if (port_config->default_mtu) {
        return port_config->default_mtu;
    } else {
        return 1526;
    }
}
// 未使用
long unsigned int ssa_port_cfg_get_copper_port_ability(int32_t lport)
{
    return port_config->copper_port_ability[lport - 1];
}
// 未使用
long unsigned int ssa_port_cfg_get_fiber_port_ability(int32_t lport)
{
    return port_config->fiber_port_ability[lport - 1];
}
// 工厂程序LED code
char * ssa_port_cfg_get_fac_led_code(void)
{
    return (char *)port_config->fac_led_ctrl_code;
}
/* 端口down时，计数是否更新 */
int32_t ssa_port_cfg_get_counter_down_update(void)
{
    return port_config->counter_down_update;
}
//未使用
int32_t ssa_port_cfg_get_port_if_change(int32_t lport)
{
    return port_config->port_if_change[lport - 1];
}
// 未使用，可以不用
int32_t ssa_port_cfg_get_nosup_linedet(void)
{
    return port_config->no_sup_linedet;
}
/* 电口是否会发生假link现象 */
int32_t ssa_port_cfg_get_gt_fake_link(void)
{
    return port_config->gt_fake_link;
}
// 不清楚用途
int32_t ssa_port_cfg_get_serdes_if_type(void)
{
    return port_config->serdes_if_type;
}
// 不清楚用途
int32_t ssa_port_cfg_get_if_type_copper_tengi(void)
{
    return port_config->if_type_copper_tengi;
}
// 不清楚用途
int32_t ssa_port_cfg_get_if_type_fiber_tengi(void)
{
    return port_config->if_type_fiber_tengi;
}
// 不清楚用途
int32_t ssa_port_cfg_get_if_type_copper_fortygi(void)
{
    return port_config->if_type_copper_fortygi;
}
// 不清楚用途
int32_t ssa_port_cfg_get_if_type_fiber_fortygi(void)
{
    return port_config->if_type_fiber_fortygi;
}
// 不清楚用途
int32_t ssa_port_cfg_get_if_type_copper_hundredgi(void)
{
    return port_config->if_type_copper_hundredgi;

}
// 不清楚用途
int32_t ssa_port_cfg_get_if_type_fiber_hundredgi(void)
{
    return port_config->if_type_fiber_hundredgi;

}
/* IfInError中的统计是否包括RMTU的统计，不需要 */
int32_t ssa_port_cfg_get_inerror_exclude_rmtu(void)
{
    return port_config->inerror_exclude_rmtu;
}

/* 配置为mac回环时，是否需要force link up */
int32_t ssa_port_cfg_get_mac_lb_force_link(void)
{
    return port_config->mac_lb_force_link;
}
// apd type ，不需要
int32_t ssa_port_cfg_get_apd_type(void)
{
    return port_config->apd_type;
}
// use xpf or sfp
int32_t ssa_port_cfg_get_use_xfp(void)
{
    return port_config->use_xfp;
}
/* 模块从检测到插入到i2c可读需要的时间 */
int32_t ssa_port_cfg_get_module_ready_time(void)
{
    if (port_config->module_ready_time) {
        return port_config->module_ready_time;
    } else {
        return 100;
    }
}
/* XT口上100M只能强制，不能协商成100M 不需要*/
int32_t ssa_port_cfg_get_forced_100m_on_xt(void)
{
    if (port_config->forced_100m_on_xt) {
        return port_config->forced_100m_on_xt;
    } else {
        return 0;
    }
}
// 不需要
int32_t ssa_port_cfg_get_split_40g_maxport(void)
{
    return port_config->split_40g_maxport;
}
/* VSL口不需要设置speed，不需要 */
int32_t ssa_port_cfg_get_feature_vsl_no_speed_set(void)
{
    return port_config->feature_vsl_no_speed_set;
}
// 通过CPLD调整rov电压类型，08-X暂时用不上
int32_t ssa_port_cfg_get_mac_cpld_rov_type(void)
{
    printf("port_config->mac_cpld_rov_type:0x%x\n", port_config->mac_cpld_rov_type);

    return port_config->mac_cpld_rov_type;
}
// 通过CPLD调整rov电压，08-X暂时用不上
int32_t ssa_port_cfg_get_mac_cpld_rov_addr(void)
{
    printf("port_config->mac_cpld_rov_addr:0x%x\n", port_config->mac_cpld_rov_addr);

    return port_config->mac_cpld_rov_addr;
}

/* 新增光模块防伪配置 */
int32_t ssa_port_cfg_get_sfp_do_antifake(void)
{
    //是否进行光模块防伪，全局的
    return port_config->feature_sfp_do_antifake;
}
// split功能不需要
int32_t ssa_port_cfg_get_split_lport_lane_info(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);

    return port_config->split_lport_lane_info[lport - 1];
}
// 没使用
int32_t ssa_port_cfg_get_override_an_conf_in_cache(int32_t lport)
{
    return port_config->override_an_conf_in_cache[lport - 1];
}
// mib相关，没看懂做什么用的
int32_t ssa_port_cfg_get_mib_notify_linger_cnt(void)
{
    if (port_config->mib_notify_linger_cnt) {
        return port_config->mib_notify_linger_cnt;
    } else {
        return DEF_MIB_NOTI_LINGER_CNT;
    }
}
// 不需要
uint16_t ssa_port_cfg_get_fiber_interrupt_value(void)
{
    return port_config->fiber_interrupt_val;
}
// 不需要
uint16_t ssa_port_cfg_get_copper_interrupt_value(void)
{
    return port_config->copper_interrupt_val;
}
//获取外部phy类型，比如EXTERNAL_PHY_542XXX，可以使用
int32_t ssa_port_cfg_get_ext_phy_type(int32_t phyid)
{
    EXTPHY_RANGE_CHECK(phyid);
    return port_config->externel_phy_type[phyid - 1];
}
// no use
int32_t ssa_port_cfg_get_ls_type_lport(int32_t lport)
{
    LPORT_RANGE_CHECK(lport);
    return port_config->ls_type_lport[lport - 1];
}
// no use
int32_t ssa_port_cfg_get_an_ensure_port_enabled(void)
{
    return port_config->an_ensure_port_enabled;
}
/* bugid:505268 For Falcon SerDes, the ports don't support auto negotiation */
int32_t ssa_port_cfg_get_an_unsupported(void)
{
    return port_config->an_unsupported;
}
// 解决一个bug增加的，在修订speed后flow ctrl会变为默认，所以增加这个字段用于
int32_t ssa_port_cfg_get_speed_change_flow_ctrl(void)
{
    return port_config->speed_change_flow_ctrl;
}
// ptd_mom_link_notify中调用，判断端口是否背板端口
int32_t ssa_port_cfg_get_backplane_port_spec(int32_t port)
{
    int i;

    for (i = 0; i < MAX_BP_PORT_NUM; i++) {
        if ( port == port_config->backplane_port_spec[i]) {
            return SSA_PORT_E_NONE;
        }
    }
    return SSA_PORT_E_RETURN;
}

void ssa_port_read_cfg(void)
{
    int32_t i, j;

    printf("#feature\n");
    printf("irq_adjust_thread %s\n", port_config->irq_adjust_thread > 0 ? "yes" : "no");
    printf("set_edc %s\n", port_config->set_edc > 0 ? "yes" : "no");
    printf("set_preemphasis %s\n", port_config->set_preemphasis > 0 ? "yes" : "no");
    printf("set_jam %s\n", port_config->set_jam > 0 ? "yes" : "no");
    printf("no_sup_protect %s\n", port_config->no_sup_protect > 0 ? "yes" : "no");
    printf("protect_trunk %s\n", port_config->protect_trunk > 0 ? "yes" : "no");
    printf("rdbgc8_over_size %s\n", port_config->rdbgc8_over_size > 0 ? "yes" : "no");
    printf("giga_fiber_auto_to_max %s\n", port_config->giga_fiber_auto_to_max > 0 ? "yes" : "no");
    printf("giga_copper_1000_an_en %s\n", port_config->giga_copper_1000_an_en > 0 ? "yes" : "no");
    printf("tengiga_copper_10g_an_en %s\n", port_config->tengiga_copper_10g_an_en > 0 ? "yes" : "no");
    printf("tengiga_copper_1000_an_en %s\n", port_config->tengiga_copper_1000_an_en > 0 ? "yes" : "no");
    printf("admin_sleep_time(ms) %d\n", port_config->admin_sleep_time);
    printf("att_sleep_time(ms) %d\n", port_config->att_sleep_time);
    printf("mtu_reset %s\n", port_config->mtu_reset > 0 ? "yes" : "no");
    printf("evade mac and phy not autoneg %s\n", port_config->evade_mac_and_phy> 0 ? "yes" : "no");
    printf("rdbgc8_set64_bit %s\n", port_config->rdbgc8_set64_bit > 0 ? "yes" : "no");
    printf("qsfp_open_method_i2c %d\n", port_config->qsfp_open_method_i2c);
    printf("qsfp_power_en_addr 0x%x\n", port_config->qsfp_power_en_addr);
    printf("qsfp_power_en_value 0x%x\n", port_config->qsfp_power_en_value);
    printf("led_reg_addr  0x%x\n", port_config->led_reg_addr);
    printf("led_reg_set_value 0x%x\n", port_config->led_reg_set_value);
    printf("interrupt_to_cpu_en_reg  0x%x\n", port_config->interrupt_to_cpu_en_reg);
    printf("interrupt_to_cpu_value 0x%x\n", port_config->interrupt_to_cpu_value);
    printf("feature_vsl_no_speed_set 0x%x\n", port_config->feature_vsl_no_speed_set);

    printf("#data\n");
    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->mtu_add_len[i] != 0) {
            printf("mtu_add_len[%d]  0%d\n", i + 1, port_config->mtu_add_len[i]);
        }

        if (port_config->oversize_frm_add_len[i] != 0) {
            printf("oversize_frm_add_len[%d]  0%d\n", i + 1, port_config->oversize_frm_add_len[i]);
        }

        if (port_config->need_unreliable_los[i] != 0) {
            printf("need_unreliable_los[%d]  0%d\n", i + 1, port_config->need_unreliable_los[i]);
        }

        if (port_config->port_min_supp_vsl_speed[i] != 0) {
            printf("need_unreliable_los[%d]  0%d\n", i + 1, port_config->port_min_supp_vsl_speed[i]);
        }

        if (port_config->sfp_present_cache_dect[i] != 0) {
            printf("sfp_present_cache_dect[%d]  0%d\n", i + 1, port_config->sfp_present_cache_dect[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->sfp_present_cache_dect[i] != 0) {
            printf("sfp_present_cache_dect[%d]  0%d\n", i + 1, port_config->sfp_present_cache_dect[i]);
        }
    }

    printf("sfp present detect cpld reg addr:\n");
    for (i = 0; i < MAX_CPLD_DECT_REG_NUM; i++) {
        if (port_config->sfp_present_cache[i] != 0) {
            printf("sfp_present_cache[%d]  0x%x\n", i + 1, port_config->sfp_present_cache[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->copper_pre_lane0[i]!= 0) {
            printf("copper_pre_lane0[%d]  0x%x\n", i + 1, port_config->copper_pre_lane0[i]);
        }
        if (port_config->copper_pre_lane1[i]!= 0) {
            printf("copper_pre_lane1[%d]  0x%x\n", i + 1, port_config->copper_pre_lane1[i]);
        }
        if (port_config->copper_pre_lane2[i]!= 0) {
            printf("copper_pre_lane2[%d]  0x%x\n", i + 1, port_config->copper_pre_lane2[i]);
        }
        if (port_config->copper_pre_lane3[i]!= 0) {
            printf("copper_pre_lane3[%d]  0x%x\n", i + 1, port_config->copper_pre_lane3[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->copper_drv_lane0[i] != 0) {
            printf("copper_drv_lane0[%d]  0x%x\n", i + 1, port_config->copper_drv_lane0[i]);
        }
        if (port_config->copper_drv_lane1[i] != 0) {
            printf("copper_drv_lane1[%d]  0x%x\n", i + 1, port_config->copper_drv_lane1[i]);
        }
        if (port_config->copper_drv_lane2[i] != 0) {
            printf("copper_drv_lane2[%d]  0x%x\n", i + 1, port_config->copper_drv_lane2[i]);
        }
        if (port_config->copper_drv_lane3[i] != 0) {
            printf("copper_drv_lane3[%d]  0x%x\n", i + 1, port_config->copper_drv_lane3[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->fiber_pre_lane0[i] != 0) {
            printf("fiber_pre_lane0[%d]  0x%x\n", i + 1, port_config->fiber_pre_lane0[i]);
        }
        if (port_config->fiber_pre_lane1[i] != 0) {
            printf("fiber_pre_lane1[%d]  0x%x\n", i + 1, port_config->fiber_pre_lane1[i]);
        }
        if (port_config->fiber_pre_lane2[i] != 0) {
            printf("fiber_pre_lane2[%d]  0x%x\n", i + 1, port_config->fiber_pre_lane2[i]);
        }
        if (port_config->fiber_pre_lane3[i] != 0) {
            printf("fiber_pre_lane3[%d]  0x%x\n", i + 1, port_config->fiber_pre_lane3[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->fiber_drv_lane0[i] != 0) {
            printf("fiber_drv_lane0[%d]  0x%x\n", i + 1, port_config->fiber_drv_lane0[i]);
        }
        if (port_config->fiber_drv_lane1[i] != 0) {
            printf("fiber_drv_lane1[%d]  0x%x\n", i + 1, port_config->fiber_drv_lane1[i]);
        }
        if (port_config->fiber_drv_lane2[i] != 0) {
            printf("fiber_drv_lane2[%d]  0x%x\n", i + 1, port_config->fiber_drv_lane2[i]);
        }
        if (port_config->fiber_drv_lane3[i] != 0) {
            printf("fiber_drv_lane3[%d]  0x%x\n", i + 1, port_config->fiber_drv_lane3[i]);
        }
    }

    printf("def_pre 0x%x\n", port_config->def_pre);
    printf("def_drv 0x%x\n", port_config->def_drv);

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->port_to_lane[i] != 0) {
            printf("port_to_lane[%d]  %d\n", i + 1, port_config->port_to_lane[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->copper_port_ability[i] != 0) {
            printf("copper_port_ability[%d]  0x%lx\n", i + 1, port_config->copper_port_ability[i]);
        }
        if (port_config->fiber_port_ability[i] != 0) {
            printf("fiber_port_ability[%d]  0x%lx\n", i + 1, port_config->fiber_port_ability[i]);
        }
    }

    printf("adjust min lport %u\n", port_config->adjust_lport_min);
    printf("adjust max lport %u\n", port_config->adjust_lport_max);
    printf("first_fiber_port_offset %d\n", port_config->first_fiber_port);
    printf("cpld_pnum_pgroup %d\n", port_config->cpld_pnum_pgroup);

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->cpld_dect_sfp[i] != 0) {
            SSA_PTD_ZLOG_NOTICE("cpld_dect_sfp[%d]  0x%x\n", i + 1, port_config->cpld_dect_sfp[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->cpld_exchange[i] != 0) {
            printf("cpld_exchange[%d]  %d\n", i + 1, port_config->cpld_exchange[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->cpld_open_sfp[i] != 0) {
            printf("cpld_open_sfp[%d] 0x%x\n", i + 1, port_config->cpld_open_sfp[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->led_fiber_copper_addr[i] != 0) {
            printf("led_fiber_copper_addr[%d] 0x%x\n", i + 1, port_config->led_fiber_copper_addr[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (port_config->linkscan_state[i] != 0) {
            printf("linkscan_state[%d] 0x%x\n", i + 1, port_config->linkscan_state[i]);
        }
    }
    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (strlen(port_config->sfp_i2c_dev[i]) != 0) {
            SSA_PTD_ZLOG_NOTICE("sfp_i2c_dev lport[%d] %s\n", i + 1, port_config->sfp_i2c_dev[i]);
        }
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (strlen(port_config->sfp_cpld_dev[i]) != 0) {
            printf("sfp_cpld_dev lport[%d] %s\n", i + 1, port_config->sfp_cpld_dev[i]);
        }
    }

    printf("sfp_on_i2c_addr 0x%x\n", port_config->sfp_on_i2c_addr);
    printf("sfp_adjust_time(s) %d\n", port_config->sfp_adj_thread_time);
    printf("linkscan_time(ms) %d\n", port_config->linkscan_time);
    printf("linkscan_type %d\n", port_config->linkscan_type);
    printf("advert_type %d\n", port_config->adver_type);
    printf("giga_copper_thread %s\n", port_config->giga_copper_thread > 0 ? "yes" : "no");
    printf("fast_linkscan_time(ms) %d\n", port_config->fast_linkscan_time);
    printf("fast_linkscan_adjust_time(ms) %d\n", port_config->fast_linkscan_adjust_time);
    printf("fast_linkscan_adjust_port number %d\n", port_config->fast_linkscan_adjust_pnum);
    printf("fastlink_type %d\n", port_config->fastlink_type);
    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!port_config->phy_scan[i]) {
            continue;
        }
        printf("    lport %2d need phy_scan\n", i + 1);
    }

    printf("led_port_max %d\n", port_config->led_port_max);
    printf("led_callback_type %d\n", port_config->led_callback_type);
    for (j = 0; j < MAX_LOCAL_UNIT; j++) {
        for (i = 0; i < LED_CTRL_NUM; i++) {
            if (port_config->led_ctrl_code[j][i][0] != 0) {
                printf("LED CODE unit %d  ctrl %d,  %s\n", j, i + 1, port_config->led_ctrl_code[j][i]);
            }
            if (port_config->poe_led_ctrl_code[j][i][0] != 0) {
                printf("LED CODE unit %d  ctrl %d,  %s\n", j, i + 1, port_config->poe_led_ctrl_code[j][i]);
            }

            if (port_config->fac_led_ctrl_code[j][i][0] != 0) {
                printf("FAC LED CODE unit %d ctrl %d,  %s\n", j, i + 1, port_config->fac_led_ctrl_code[j][i]);
            }
        }
    }
    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!port_config->led_40g_data_ram[i]) {
            continue;
        }

        printf("led_40g_data_ram[%d] = 0x%x\n", i + 1, port_config->led_40g_data_ram[i]);
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!port_config->qsfp_reset_addr[i]) {
            continue;
        }

        printf("qsfp_reset_addr[%d] = 0x%x\n", i + 1, port_config->qsfp_reset_addr[i]);
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!port_config->qsfp_reset_val[i]) {
            continue;
        }

        printf("qsfp_reset_val[%d] = 0x%x\n", i + 1, port_config->qsfp_reset_val[i]);
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!port_config->port_if_change[i]) {
            continue;
        }

        printf("port_if_change[%d] = 0x%x\n", i + 1, port_config->port_if_change[i]);
    }

    for (i = 0; i < MAX_LPORT_NUM; i++) {
        if (!port_config->split_lport_lane_info[i]) {
            continue;
        }

        SSA_PTD_ZLOG_NOTICE("split_lport_lane_info[%d] = 0x%x\n", i + 1, port_config->split_lport_lane_info[i]);
    }

    printf("wcmode %d\n", port_config->wc_mode);
    printf("mdix_mode %d\n", port_config->mdix_mode);
    printf("lb_type %d\n", port_config->lb_type);
    printf("gt_always_an %d\n", port_config->gt_always_an);
    printf("fir_mode %d\n", port_config->fir_mode);
    printf("flow_extern %d\n", port_config->flow_extern);
    printf("pause_init %d\n", port_config->pause_init);
    printf("default_mtu %d\n", port_config->default_mtu);
    printf("counter_down_update %d\n", port_config->counter_down_update);
    printf("set_pcie %d\n", port_config->set_pcie);
    printf("gt_fake_link %d\n", port_config->gt_fake_link);
    printf("serdes_if_type %d\n", port_config->serdes_if_type);
    if (port_config->serdes_if_type) {
        printf("if_type_copper_tengi %d\n", port_config->if_type_copper_tengi);
        printf("if_type_fiber_tengi %d\n", port_config->if_type_fiber_tengi);
        printf("if_type_copper_fortygi %d\n", port_config->if_type_copper_fortygi);
        printf("if_type_fiber_fortygi %d\n", port_config->if_type_fiber_fortygi);
    }

    printf("inerror_exclude_rmtu %d\n", port_config->inerror_exclude_rmtu);
    printf("mac_lb_force_link %d\n", port_config->mac_lb_force_link);
    printf("apd type %d\n", port_config->apd_type);
    printf("use xfp %d\n", port_config->use_xfp);
    printf("module ready time %d (ms)\n", port_config->module_ready_time);
    printf("100m forced on 10G copper %d\n", port_config->forced_100m_on_xt);
    printf("split_40g_maxport %d\n", port_config->split_40g_maxport);

    return;
}


