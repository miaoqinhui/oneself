/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * ssa_port_common.c
 * Original Author:  xudongxu@ruijie.com.cn, 2018-3-12
 *
 * ��װdfd cpld/i2c��д���ʽӿ�
 *
 * History
 */

#include "../include/ptd_init.h"
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include "../include/ptd_debug.h"

#define DFD_I2C_SHORT_ADDR_TYPE 0
#define DFD_I2C_LONG_ADDR_TYPE  1

/**
 * ptd_device_read - ���豸�ļ�
 * @path: �豸�ļ�·��������cpld0��Ϊ/dev/cpld0
 * @addr: ƫ�Ƶ�ַ
 * @val: ��������
 * @size:  ��buf�Ĵ�С
 * return: �ɹ�����0��������ʧ�ܸ�ֵ
 */
int ptd_read_cpld(char *path, int addr, unsigned char *val, int size)
{
    int fd;
    int rv;

    if (val == NULL || path == NULL) {
        return -1;
    }

    rv = -1;
    fd = open(path, O_RDWR, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        goto fail;
    }

    rv = lseek(fd, addr, 0);
    if (rv < 0) {
        goto exit;
    }

    rv = read(fd, val, size);
    if (rv < 0) {
        goto exit;
    }

    rv = 0;
exit:
    close(fd);
fail:

    return rv;
}

/**
 * sdd_device_write - д�豸�ļ�
 * @path: �豸�ļ�·��������cpld0��Ϊ/dev/cpld0
 * @addr: ƫ�Ƶ�ַ
 * @val: д������
 * @size:  дbuf�Ĵ�С
 * return: �ɹ�����0��������ʧ�ܸ�ֵ
 */
int ptd_write_cpld(char *path, int addr, unsigned char *val, int size)
{
    int fd;
    int rv = -1;

    if (val == NULL || path == NULL) {
        return -1;
    }

    fd = open(path, O_RDWR, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        goto fail;
    }

    rv = lseek(fd, addr, 0);
    if (rv < 0) {
        goto exit;
    }

    rv = write(fd, val, size);
    if (rv < 0) {
        goto exit;
    }

    rv = 0;

exit:
    close(fd);
fail:
    return rv;
}

int ptd_read_i2c(char *i2c_name, unsigned short dev_addr, unsigned short offset_addr,
                                   unsigned char *recv_buf, int size, int addr_type)
{
    int fd, rv;
    struct i2c_rdwr_ioctl_data ioctl_data;
    struct i2c_msg msgs[2];
    unsigned char buf[2];

    if (i2c_name == NULL || recv_buf == NULL) {
        return -1;
    }

    rv = 0;
    fd = open(i2c_name, O_RDWR | O_SYNC);
    if (fd < 0) {
        rv = fd;
        goto fail;
    }
    memset(&ioctl_data, 0, sizeof(ioctl_data));
    memset(msgs, 0, sizeof(msgs));
    memset(buf, 0, sizeof(buf));

    while (1) {
        /* �е�����ֻ֧��1�ֽڵ�ַ����,�е�֧��2�ֽ� */
        if (addr_type != DFD_I2C_SHORT_ADDR_TYPE) {
            buf[0] = (unsigned char)(offset_addr >> 8);
            buf[1] = (unsigned char)(offset_addr);
            msgs[0].len = sizeof(unsigned short);
        } else {
            buf[0] = (unsigned char)(offset_addr);
            msgs[0].len = sizeof(unsigned char);
        }
        msgs[0].buf = buf;
        msgs[0].addr = dev_addr;
        if (addr_type != DFD_I2C_SHORT_ADDR_TYPE) {
            msgs[0].flags = I2C_M_TEN;
        }

        msgs[1].buf = recv_buf;
        msgs[1].len = size;
        msgs[1].addr = dev_addr;
        msgs[1].flags |= I2C_M_RD;
        ioctl_data.msgs = &(msgs[0]);
        ioctl_data.nmsgs = 2;/* ������ʱ��Ҫд������Ϣ�� */

        rv = ioctl(fd, I2C_RDWR, (unsigned long)&ioctl_data);
        if (rv < 0) {
            printf("ioctl fail\n");
        }
        break;
    }

    close(fd);
fail:

    return rv;
}

int ptd_write_i2c(char *i2c_name, unsigned short dev_addr, unsigned short offset_addr,
                                    unsigned char *write_buf, int size, int addr_type)
{
    int fd, rv;
    struct i2c_rdwr_ioctl_data ioctl_data;
    struct i2c_msg msgs[2];
    unsigned char addr_buf[2];
    unsigned char write_buf_tmp[256];

    if (i2c_name == NULL || write_buf == NULL) {
        return -1;
    }

    if (size <= 0) {
        return size;
    }

    memset(&ioctl_data, 0, sizeof(ioctl_data));
    memset(msgs, 0, sizeof(msgs));
    memset(addr_buf, 0, sizeof(addr_buf));
    memset(write_buf_tmp, 0, sizeof(write_buf_tmp));

    rv = 0;
    fd = open(i2c_name, O_RDWR | O_SYNC);
    if (fd < 0) {
        rv = fd;
        goto fail;
    }

    while (1) {
        /* �е�����ֻ֧��1�ֽڵ�ַ����,�е�֧��2�ֽ� */
        if (addr_type != DFD_I2C_SHORT_ADDR_TYPE) {
            addr_buf[0] = (unsigned char)((offset_addr) >> 8);
            addr_buf[1] = (unsigned char)(offset_addr);
            msgs[0].len = sizeof(unsigned short);
        } else {
            addr_buf[0] = (unsigned char)(offset_addr);
            msgs[0].len = sizeof(unsigned char);
        }
        memcpy(write_buf_tmp, write_buf, size);
        msgs[1].len = size;

        msgs[0].buf = addr_buf;
        msgs[0].addr = dev_addr;

        msgs[1].buf = write_buf_tmp;
        msgs[1].addr = dev_addr;
        msgs[1].flags |= 0x4000;
        ioctl_data.msgs = msgs;
        ioctl_data.nmsgs = 2;

        rv= ioctl(fd, I2C_RDWR, (unsigned long)&ioctl_data);
        if (rv < 0) {
            printf("ioctl fail\n");
        }
        break;
    }
    close(fd);

fail:

    return rv;
}





