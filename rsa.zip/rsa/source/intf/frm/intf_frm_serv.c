#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <libpub/rg_mom/rg_mom.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <rg_sys/list.h> 
#include "../comm/intf_comm_zlog_dbg.h"
#include "intf_frm_serv.h"

#define APP_NAME_MAX_LEN    128
#define APP_NAME_UNKONWN    "unknown_app_name" 

typedef struct {
    struct list_head list;
    char             app_name[APP_NAME_MAX_LEN];
    ptchg_cb_reg_t   reg;    
} ptchg_cb_reg_node_t;

typedef struct {
    struct list_head list;
    uint32_t         lphyid;
    pt_type_t        type;
} pttype_node_t;

typedef struct {
    struct list_head head;
    bool         inited;
    rg_global_t *glb;
    int32_t      unit;
} ptchg_head_t;

static ptchg_head_t g_ptchg_cb_reg_head[UNIT_MAX_NUM];
static ptchg_head_t g_pttype_head[UNIT_MAX_NUM];

struct list_head *intf_frm_serv_ptchg_get_pttype_head_by_glb(rg_global_t *glb) 
{
    int32_t unit;

    for (unit = 0; unit < UNIT_MAX_NUM; unit++) {
        if (glb == g_ptchg_cb_reg_head[unit].glb) {
            return &g_ptchg_cb_reg_head[unit].head;
        }
    }
    
    return NULL;
}

int32_t intf_frm_serv_update_pt_type(rg_global_t *glb, uint32_t lphyid, pt_type_t type)
{
    struct list_head *pos;
    pttype_node_t *node, *new_node;
    struct list_head *head;

    head = intf_frm_serv_ptchg_get_pttype_head_by_glb(glb);
    if (head == NULL) {
        INTF_COMM_ZLOG_ERROR("pttype head is NULL");
        return INTF_COMM_E_EXISTS;
    }
    list_for_each(pos, head) {
        node = list_entry(pos, pttype_node_t, list);
        if (node->lphyid== lphyid) {
            node->type = type;
            return INTF_COMM_E_NONE;
        }
    }
    new_node = (pttype_node_t *) malloc (sizeof(pttype_node_t));
    if (!new_node) {
        return INTF_COMM_E_MEMORY;
    }
    memset(new_node, 0, sizeof(pttype_node_t));
    new_node->lphyid = lphyid;
    new_node->type = type;
    list_add_tail(&new_node->list, head);
    
    return INTF_COMM_E_NONE;
}

int32_t intf_frm_serv_get_pt_type_by_lphyid(rg_global_t *glb, uint32_t lphyid, pt_type_t *type)
{
    struct list_head *pos;
    pttype_node_t *node;
    struct list_head *head;
    int32_t ret, unit, port;

    head = intf_frm_serv_ptchg_get_pttype_head_by_glb(glb);
    if (head == NULL) {
        INTF_COMM_ZLOG_ERROR("pttype head is NULL");
        return INTF_COMM_E_EXISTS;
    }
    list_for_each(pos, head) {
        node = list_entry(pos, pttype_node_t, list);
        if (node->lphyid == lphyid) {
            *type = node->type;
            return INTF_COMM_E_NONE;
        }
    }
    
    ret = libddm_get_unit_port_by_lphyid(lphyid, &unit, &port);
    if (ret == 0) {
        *type = PT_TYPE_ETH;
    } else {
        *type = PT_TYPE_UNK;
    }
    
    return INTF_COMM_E_NONE;
}

struct list_head *intf_frm_serv_ptchg_get_cb_reg_head_by_glb(rg_global_t *glb) 
{
    int32_t unit;

    for (unit = 0; unit < UNIT_MAX_NUM; unit++) {
        if (glb == g_pttype_head[unit].glb) {
            return &g_pttype_head[unit].head;
        }
    }
    
    return NULL;
}

int32_t intf_frm_serv_ptchg_real_reg(rg_global_t *glb, char *app_name, ptchg_cb_reg_t *reg_funs, 
            int32_t reg_size)
{
    int32_t i;
    ptchg_cb_reg_node_t *new_node;
    struct list_head *head;

    head = intf_frm_serv_ptchg_get_cb_reg_head_by_glb(glb);
    if (head == NULL) {
        return INTF_COMM_E_EXISTS;
    }
    for (i = 0; i < reg_size; i++) {
        new_node = (ptchg_cb_reg_node_t *) malloc (sizeof(ptchg_cb_reg_node_t));
        if (!new_node) {
            INTF_COMM_ZLOG_ERROR("malloc failed.");
            return INTF_COMM_E_MEMORY;
        }
        memset(new_node, 0, sizeof(ptchg_cb_reg_node_t));
        memcpy(&new_node->reg, &reg_funs[i], sizeof(ptchg_cb_reg_t));
        if (strlen(app_name) >= APP_NAME_MAX_LEN) {
            strcpy(new_node->app_name, APP_NAME_UNKONWN);
        } else {
            strcpy(new_node->app_name, app_name);
        }
        list_add_tail(&new_node->list, head);
    }

    return INTF_COMM_E_NONE;
}

int32_t intf_frm_serv_ptchg_ntfy(rg_global_t *glb, uint32_t lphyid, ptchg_type_t type, ptchg_evt_t evt)
{
    int32_t ret;
    struct list_head *pos;
    ptchg_cb_reg_node_t *node;
    struct list_head *head;
    
    head = intf_frm_serv_ptchg_get_cb_reg_head_by_glb(glb);
    if (head == NULL) {
        INTF_COMM_ZLOG_ERROR("cb reg head is NULL");
        return INTF_COMM_E_EXISTS;
    }
    
    list_for_each(pos, head) {
        node = list_entry(pos, ptchg_cb_reg_node_t, list);
        if (node->reg.type == type) {
            ret = node->reg.cb(lphyid, evt);
            INTF_COMM_CHK_RET_CONTINUE(ret, "lphyid 0x%x trigger type %d evt %d but callback module %s failed ret %d",
                                    lphyid, type, evt, node->app_name, ret);
            INTF_COMM_ZLOG_INFO("lphyid 0x%x trigger type %d evt %d and callback module %s suc.",
                                    lphyid, type, evt, node->app_name);
        }
    }
    
    return INTF_COMM_E_NONE;
}

int32_t intf_frm_serv_ptchg_head_init(ptchg_head_t *ptchg_head, rg_global_t *glb, int unit)
{

    if (ptchg_head->inited) {
        INTF_COMM_ZLOG_WARN("unit %d is inited, return.", unit);
        return INTF_COMM_E_NONE;
    }

    /* �ӿڱ䶯�ص�ע�ắ��ͷָ�� */
    INIT_LIST_HEAD(&ptchg_head->head);
    ptchg_head->inited = true;
    ptchg_head->unit = unit;
    ptchg_head->glb = glb;

    return INTF_COMM_E_NONE;
}

int intf_frm_serv_ptchg_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info)
{
    int32_t ret, unit;

    unit = unit_t_info->unit;
    if (unit < 0 || unit >= UNIT_MAX_NUM) {
        INTF_COMM_ZLOG_ERROR("unit %d is invalid, return.", unit);
        return INTF_COMM_E_PARAM;
    }
    (void)intf_comm_zlog_dbg_init("intf_comm");
    
    ret = intf_frm_serv_ptchg_head_init(&g_ptchg_cb_reg_head[unit], glb, unit);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "intf_frm_serv_ptchg_head_init %d failed.", ret);
    ret = intf_frm_serv_ptchg_head_init(&g_pttype_head[unit], glb, unit);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "intf_frm_serv_ptchg_head_init %d failed.", ret);
    
    return INTF_COMM_E_NONE;
}

