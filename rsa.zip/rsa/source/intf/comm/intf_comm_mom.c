/*
 * ce_ptm.c
 * 
 * ce.port.intf.ss�������ļ�
 *
 */
#include <rg_sys/list.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h> 
#include <libpub/rg_mom/rg_mom.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <sys/types.h>
#include "intf_comm_zlog_dbg.h"
#include "intf_comm_mom.h"
#include "intf_comm_error.h"
#include "intf_comm_types.h"

struct list_head g_mom_tbl_head;
typedef struct {
    struct list_head list;
    char      mod_name[64];
    mom_tbl_t *tbl;
} mom_tbl_node_t;

struct list_head *intf_comm_mom_list_head_get(void)
{
    static int32_t inited = 0;

    if (!inited) {
        INIT_LIST_HEAD(&g_mom_tbl_head);
        inited = 1;
    }
 
    return &g_mom_tbl_head;
}

int32_t intf_comm_mom_sub_reg(rg_global_t *glb, int32_t db, mom_obj_fsub_cb_t *fsub, rg_obj *obj)
{
    int ret;

    INTF_COMM_CHK_NULL_RETURN_VAL(glb,  "glb is NULL");
    INTF_COMM_CHK_NULL_RETURN_VAL(obj,  "obj is NULL");
    INTF_COMM_CHK_NULL_RETURN_VAL(fsub, "fsub is NULL");
    if (fsub->chgs == 0) {
        ret = rg_mom_subscribe(glb, db, obj, 0, fsub->cb[0], NULL);
        INTF_COMM_CHK_RET_RETURN_VAL(ret, "rg_mom_subscribe failed %d..", ret);
    } else {
        ret = rg_mom_subscribe_field(glb, db, obj, 0, fsub->sel, fsub->cb, NULL, fsub->chgs);
        INTF_COMM_CHK_RET_RETURN_VAL(ret, "rg_mom_subscribe_field failed %d..", ret);
    }
    
    return INTF_COMM_E_NONE;
}

int32_t intf_comm_mom_db_tbl_subreg(rg_global_t *glb, char *mod_name, struct list_head* tbl_h) 
{
    int32_t ret;
    struct list_head *pos;
    mom_tbl_node_t *node;

    INTF_COMM_CHK_NULL_RETURN_VAL(glb, "glb is NULL");
   /* �������ݿ�������ע�ᶩ��*/
    list_for_each(pos, tbl_h) {
        node = list_entry(pos, mom_tbl_node_t, list);
        if (!node->tbl->fsub_cb.cb[0] || strcmp(mod_name, node->mod_name)) {
            continue;
        }
        INTF_COMM_ZLOG_INFO("obj %s of db %d subcribe begin", node->tbl->obj_name, node->tbl->db);
        ret  = node->tbl->init(glb, node->tbl->db, 0, &(node->tbl->fsub_cb));
        INTF_COMM_CHK_RET_CONTINUE(ret, "subcribe of %s failed %d.", node->tbl->obj_name, ret);
        INTF_COMM_ZLOG_INFO("obj %s of db %d subcribe end", node->tbl->obj_name, node->tbl->db);
    }
   
    return INTF_COMM_E_NONE;
}

int32_t intf_comm_mom_tbl_init(rg_global_t *glb, char *mod_name)
{
    int32_t ret;
    struct list_head *tbl_head;
    
    INTF_COMM_CHK_NULL_RETURN_VAL(glb, "glb is NULL");
    tbl_head = intf_comm_mom_list_head_get();
    ret = intf_comm_mom_db_tbl_subreg(glb, mod_name, tbl_head);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "intf_comm_mom_db_tbl_subreg failed %d.", ret);
    
    /* ������ɣ����·���ds end*/
    
    return INTF_COMM_E_NONE;
}

int32_t intf_comm_mom_tbl_reg(char *mod_name, mom_tbl_t *tbl, int size)
{
    mom_tbl_node_t *node;
    int32_t i;
    struct list_head *tbl_head;

    INTF_COMM_CHK_NULL_RETURN_VAL(tbl, "tbl is NULL");
    tbl_head = intf_comm_mom_list_head_get();
    for (i = 0; i < size; i++) {
        node = (mom_tbl_node_t*)malloc(sizeof(mom_tbl_node_t));
        INTF_COMM_CHK_NULL_RETURN_VAL(node, "node is NULL");
        memset(node, 0, sizeof(mom_tbl_node_t));
        node->tbl = &tbl[i];
        strcpy(node->mod_name, mod_name);
        list_add_tail(&node->list, tbl_head);
    }

    return INTF_COMM_E_NONE;
}

int32_t intf_comm_mom_init(rg_global_t *glb, char *mod_name)
{
    int32_t ret;

    INTF_COMM_CHK_NULL_RETURN_VAL(glb, "glb is NULL");
    /* mom���ݱ������ʼ������������ע�ᣬ�ϻ����ã�scan�� */
    ret = intf_comm_mom_tbl_init(glb, mod_name);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "intf_comm_mom_tbl_init failed %d..", ret);
    
    return INTF_COMM_E_NONE;
}

