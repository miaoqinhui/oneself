#ifndef __INTF_COMM_ERROR_H__
#define __INTF_COMM_ERROR_H__

typedef enum {
    INTF_COMM_E_NONE       = 0,
    INTF_COMM_E_INTERNAL   = -1,
    INTF_COMM_E_MEMORY     = -2,
    INTF_COMM_E_UNIT       = -3,
    INTF_COMM_E_PARAM      = -4,
    INTF_COMM_E_EMPTY      = -5,
    INTF_COMM_E_FULL       = -6,
    INTF_COMM_E_NOT_FOUND  = -7,
    INTF_COMM_E_EXISTS     = -8,
    INTF_COMM_E_TIMEOUT    = -9,
    INTF_COMM_E_BUSY       = -10,
    INTF_COMM_E_FAIL       = -11,
    INTF_COMM_E_DISABLED   = -12,
    INTF_COMM_E_BADID      = -13,
    INTF_COMM_E_RESOURCE   = -14,
    INTF_COMM_E_CONFIG     = -15,
    INTF_COMM_E_UNAVAIL    = -16,
    INTF_COMM_E_INIT       = -17,
    INTF_COMM_E_PORT       = -18,
    INTF_COMM_E_OFFLINE    = -19,
    INTF_COMM_E_NOT_SUP    = -20,
} ptm_comm_error_t;

#endif /* __INTF_COMM_ERROR_H__ */
