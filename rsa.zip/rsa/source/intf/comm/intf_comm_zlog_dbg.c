 /*
  * Copyright(C) 2018 Ruijie Network. All rights reserved.
  */
 /*
  * intf_comm_dbg.c
  * Original Author:  linchuanyang@ruijie.com.cn, 2018-04-17
  *
  * intf_comm_dbgģ����Դ���
  *
  * History
  *
  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <execinfo.h>
#include <sys/stat.h>
#include <errno.h>
#include <rg_zlog/zct.h>
#include <rg_zlog/rgdf_zlog.h>
#include "intf_comm_zlog_dbg.h"

rgdf_zlog_level_t g_intf_comm_zlog_level = RGDF_ZLOG_LV_ERROR;
zlog_category_t *g_intf_comm_zlog_category = NULL;

static void intf_comm_set_dbg_level_from_file(char *module_name)
{
    int  fd, len;
    char buf[8], dbg_file_path[128];
    
    sprintf(dbg_file_path, "/data/dbg/ptm/%s", module_name);
    fd = open(dbg_file_path, O_RDONLY);
    if (fd < 0) {
        printf("dbg file %s is not exist\n", module_name);
        return;
    }
    memset(buf, 0, sizeof(buf));
    len = read(fd, buf, sizeof(buf));
    if (len >  0) {
        g_intf_comm_zlog_level = atoi(buf);
    }
    close(fd);

    printf("module %s zlog_level = %d\n", module_name, g_intf_comm_zlog_level);

    return;
}

int intf_comm_zlog_dbg_init(char *module_name)
{
    static bool inited;

    if (inited) {
        return 0;
    }
    inited = true;
    g_intf_comm_zlog_category = rg_zlog_init(module_name);
    intf_comm_set_dbg_level_from_file(module_name);
    if (g_intf_comm_zlog_level >= RGDF_ZLOG_LV_MAX) {
        g_intf_comm_zlog_category = NULL;
    }
    return 0;
}

