#ifndef __INTF_COMM_DBG_H__
#define __INTF_COMM_DBG_H__

#include <rg_zlog/zct.h>
#include <rg_zlog/rgdf_zlog.h>

#define INTF_COMM_ZLOG_FATAL(fmt, arg...)   RGDF_ZLOG_FATAL(intf_comm, fmt, ##arg);
#define INTF_COMM_ZLOG_ERROR(fmt, arg...)   RGDF_ZLOG_ERROR(intf_comm, fmt, ##arg);
#define INTF_COMM_ZLOG_WARN(fmt, arg...)    RGDF_ZLOG_WARN(intf_comm, fmt, ##arg);
#define INTF_COMM_ZLOG_NOTICE(fmt, arg...)  RGDF_ZLOG_NOTICE(intf_comm, fmt, ##arg);
#define INTF_COMM_ZLOG_INFO(fmt, arg...)    RGDF_ZLOG_INFO(intf_comm, fmt, ##arg);
#define INTF_COMM_ZLOG_DEBUG(fmt, arg...)   RGDF_ZLOG_DEBUG(intf_comm, fmt, ##arg);

#define INTF_COMM_CHK_RET_RETURN_VAL(ret, fmt, args...)       do { \
    if ((ret) != 0) { \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
        return (ret); \
    } \
} while(0)

#define INTF_COMM_CHK_NULL_RETURN_VAL(pret, fmt, args...)       do { \
    if ((pret) == NULL) { \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
        return (INTF_COMM_E_FULL); \
    } \
} while(0)

#define INTF_COMM_CHK_NULL_RETURN_VOID(pret, fmt, args...)       do { \
    if ((pret) == NULL) { \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
        return; \
    } \
} while(0)
#define INTF_COMM_CHK_RET_ONLY(ret, fmt, args...)       do { \
    if ((ret) != 0) { \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
    } \
} while(0)

#define INTF_COMM_CHK_RET_RETURN_VOID(ret, fmt, args...)      do { \
    if ((ret) != 0) { \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
        return; \
    } \
} while(0)

#define INTF_COMM_CHK_RET_CONTINUE(ret, fmt, args...)  \
    if ((ret) != 0) { \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
        continue; \
    }

#define INTF_COMM_CHK_RET_FREE_RETURN_VAL(ret, pfree, fmt, args...)       do { \
    if ((ret) != 0) { \
        free(pfree);                 \
        INTF_COMM_ZLOG_ERROR(fmt, ##args);\
        return (-2); \
    } \
} while(0)

extern rgdf_zlog_level_t g_intf_comm_zlog_level;
extern zlog_category_t *g_intf_comm_zlog_category;
extern int intf_comm_zlog_dbg_init(char *module_name);

#endif  /* __INTF_COMM_DBG_H__ */

