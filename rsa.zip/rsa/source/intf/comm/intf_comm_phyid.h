#ifndef _INTF_COMM_PHYID_H_
#define _INTF_COMM_PHYID_H_
#include <stdio.h>
#include <sw_intf/ddm/libddm.h>
#include <arch/unit_thread.h>
#include <libpub/rg_protobuf_rt/p/dev/dev_local_port.pb-c.h>
#include "intf_comm_zlog_dbg.h"
#include "intf_comm_types.h"
#include "intf_comm_phyid.h"
#include "intf_comm_error.h"
#include <arch/unit_thread.h>

#define UNIT_MAX_NUM               1

#define GET_VSLPHYID_BY_DEV_INFO(_dev, _slot, _lport) \
    (0x6 << 24 | (_dev) << 16 | (_slot) << 8 | (_lport))
    
typedef struct {
    int32_t  dev;
    int32_t  slot;
    int32_t  lport;
    int32_t  unit;
    int32_t  port;
    uint32_t fe_phyid;
    uint32_t vsl_phyid;
    bool     is_local_port;
    int32_t  dm_medium;
    int32_t  dm_speed;
} phyid_info_t;

extern int32_t g_local_devid;

static inline int32_t intf_comm_phyid_dm_get_speed_by_port_type(int32_t port_type)
{
    switch (port_type) {
    case P_INTF__INTFTYPE_E__ETH_100M: /* DEV_COMMON__PORT_TYPE__FASE */
        return 100;
    case P_INTF__INTFTYPE_E__ETH_1000M: /* DEV_COMMON__PORT_TYPE__GIGABIT */
        return 1000;
    case P_INTF__INTFTYPE_E__ETH_2500M: /* DEV_COMMON__PORT_TYPE__FOGIGABIT */
        return 2500;
    case P_INTF__INTFTYPE_E__ETH_5G: /* DEV_COMMON__PORT_TYPE__HUGIGABIT */
        return 5000;
    case P_INTF__INTFTYPE_E__ETH_10G: /* DEV_COMMON__PORT_TYPE__TWGIGABIT */
        return 10000;
    case P_INTF__INTFTYPE_E__ETH_20G: /* DEV_COMMON__PORT_TYPE__TFGIGABIT */
        return 20000;
    case P_INTF__INTFTYPE_E__ETH_25G: /* DEV_COMMON__PORT_TYPE__TFGIGABIT */
        return 25000;
    case P_INTF__INTFTYPE_E__ETH_40G:/* DEV_COMMON__PORT_TYPE__TPFGIGABIT */
        return 40000;
    case P_INTF__INTFTYPE_E__ETH_100G:/* DEV_COMMON__PORT_TYPE__TPFGIGABIT */
        return 100000;   
    default:
        return 0;
    }
    return 0;
}

static inline int32_t intf_comm_get_phyid_info_by_dev_port_info(int32_t dev, int32_t slot, int32_t lport, 
                            phyid_info_t *phyid_info)
{
    phyid_info_t tmp_phyid_info;
    int32_t      ret, dev_chip_port;
    PDev__UnitCportInfo *local;

    memset(&tmp_phyid_info, 0, sizeof(phyid_info_t));
    tmp_phyid_info.vsl_phyid = GET_VSLPHYID_BY_DEV_INFO(dev, slot, lport);
    
    ret = libddm_get_unit_port_by_slot_lport(slot, lport, &tmp_phyid_info.unit, &tmp_phyid_info.port);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "libddm_get_unit_port_by_slot_lport failed %d..", ret);
    ret = libddm_get_lphyid_by_unit_port(tmp_phyid_info.unit, tmp_phyid_info.port, &tmp_phyid_info.fe_phyid);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "libddm_get_lphyid_by_unit_port failed %d..", ret);
    tmp_phyid_info.is_local_port = libddm_is_local_port(tmp_phyid_info.fe_phyid);
    NDM_CHACH_LOCK(ndm_mutex);
    dev_chip_port = SS_GET_PORT_BY_LPHYID(tmp_phyid_info.fe_phyid);
    ret = ndm_get_local_port_by_unit_cport(tmp_phyid_info.unit, dev_chip_port, &local);    
    NDM_CHACH_UNLOCK(ndm_mutex);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "ndm_get_local_port_by_unit_cport failed %d..", ret);
    tmp_phyid_info.dm_speed = intf_comm_phyid_dm_get_speed_by_port_type(local->static_info->type);
    tmp_phyid_info.dm_medium = local->static_info->pd_medium_type;
    tmp_phyid_info.dev = dev;
    tmp_phyid_info.lport = lport;
    tmp_phyid_info.slot = slot;
    ndm_port_obj_free(local);
    memcpy(phyid_info, &tmp_phyid_info, sizeof(phyid_info_t));
    #if 0
    INTF_COMM_ZLOG_INFO("dev %d slot %d lport %d unit %d port %d is_local %d vsl_phyid 0x%x fe_phyid 0x%x",
                            dev, slot, lport, tmp_phyid_info.unit, tmp_phyid_info.port, 
                            tmp_phyid_info.is_local_port, tmp_phyid_info.vsl_phyid, 
                            tmp_phyid_info.fe_phyid);
    #endif
    
    return INTF_COMM_E_NONE;
}

static inline int32_t intf_comm_get_phyid_info_by_lphyid(uint32_t fe_phyid, phyid_info_t *phyid_info)
{
    phyid_info_t tmp_phyid_info;
    int32_t      ret;

    memset(&tmp_phyid_info, 0, sizeof(phyid_info_t));
    ret = libddm_get_unit_port_by_lphyid(fe_phyid, &tmp_phyid_info.unit, &tmp_phyid_info.port);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "libddm_get_unit_port_by_lphyid lphyid 0x%x failed %d..", fe_phyid, ret);
    ret = libddm_get_slot_lport_by_unit_port(tmp_phyid_info.unit, tmp_phyid_info.port, &tmp_phyid_info.slot, 
                                                &tmp_phyid_info.lport);
    INTF_COMM_CHK_RET_RETURN_VAL(ret, "libddm_get_slot_lport_by_unit_port unit %d port %d failed %d..", 
                                    tmp_phyid_info.unit, tmp_phyid_info.port, ret);
    tmp_phyid_info.dev = g_local_devid;
    return intf_comm_get_phyid_info_by_dev_port_info(tmp_phyid_info.dev, tmp_phyid_info.slot, 
                tmp_phyid_info.lport, phyid_info);
}

static inline bool intf_comm_is_local_global_unit(rg_global_t *glb, int32_t unit)
{
    vsd_unit_thread_info_t *unit_thread;
    
    unit_thread = get_g_vsd_unit_thread_info(unit);
    return (unit_thread->global == glb) ? true : false;
}

static inline int32_t intf_comm_get_unit_by_global(rg_global_t *glb, int32_t *unit)
{
    vsd_unit_thread_info_t *unit_thread;
    int32_t tmp_unit;
    for (tmp_unit = 0; tmp_unit < UNIT_MAX_NUM; tmp_unit++) {
        unit_thread = get_g_vsd_unit_thread_info(tmp_unit);
        if (unit_thread->global == glb) {
            *unit = tmp_unit;
            return INTF_COMM_E_NONE;
        }
    }

    return INTF_COMM_E_EXISTS;
}
#endif
