#ifndef __INTF_COMM_TYPES__
#define __INTF_COMM_TYPES__
#include <stdio.h>
typedef unsigned int   uint;
typedef unsigned long  ulong;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t ;
typedef unsigned int   uint32_t;
typedef unsigned short ushort;
typedef int int32_t;

#ifndef bool
#define bool unsigned char
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#ifndef PTM_ARRAY_SIZE
#define PTM_ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#endif

#endif