/*
 * sscm_port.h
 * 
 * ce.port.intf.ss����ͷ�ļ�
 *
 */
#ifndef _CE_PTM_MOM_H__
#define _CE_PTM_MOM_H__
#include <rg_sys/rg_types.h>
#include <libpub/rg_mom/rg_global.h>
#include <libpub/rg_mom/rg_mom_common.h>
#include <sys/types.h>
#include "intf_comm_zlog_dbg.h"

#define MAX_SUB_CNT               16
#define MAX_NAME_LEN              64

#define MOM_RES_CHK_NULL_RET(_res, _pmsg) do {\
     _res = (rg_mom_hash_res_t*)_pmsg->value; \
     INTF_COMM_CHK_NULL_RETURN_VAL(_res, "res is NULL");\
     INTF_COMM_CHK_RET_RETURN_VAL(_res->error_code, "error_code %d", _res->error_code);\
} while (0)

#define  ASIC_DB        RG_MOM_ASIC_DB
#define  UDP_DB         RG_MOM_UDP_DB 
#define  APP_DB         RG_MOM_APP_DB 
#define  MONITOR_DB     RG_MOM_MONITOR_DB 
#define  IBC_DB         RG_MOM_IBC_DB

typedef struct {
    int                  chgs;
    size_t               sel[MAX_SUB_CNT];
    rg_mom_response_cb   cb[MAX_SUB_CNT];
} mom_obj_fsub_cb_t; 

typedef int  (*mom_obj_init)(rg_global_t*, int32_t, int32_t, mom_obj_fsub_cb_t*);
typedef struct {
    int32_t            db;
    char               obj_name[64];
    mom_obj_fsub_cb_t  fsub_cb;
    mom_obj_init       init;
} mom_tbl_t;

extern int32_t intf_comm_mom_sub_reg(rg_global_t *glb, int32_t db, mom_obj_fsub_cb_t *obj_cb, rg_obj *obj);
extern int32_t intf_comm_mom_tbl_reg(char *mod_name, mom_tbl_t *tbl, int size);
extern int32_t intf_comm_mom_init(rg_global_t *glb, char *mod_name);

#endif

