#ifndef _ARCH_HA_SDK_THREAD_H_
#define _ARCH_HA_SDK_THREAD_H_


typedef enum {
    SDK_THREAD_L2X = 0,
    SDK_THREAD_COUNTER,
    SDK_THREAD_MEMSCAN,
    SDK_THREAD_L2MOD,
    SDK_THREAD_L2MOD_DMA,
    SDK_THREAD_IPFIX,
    SDK_THREAD_LINKSCAN,
    SDK_THREAD_REGEX_REPORT,
    SDK_THREAD_HWDOS_MONITOR,
    SDK_THREAD_CTR_EVICT_DMA,
    SDK_THREAD_SRAMSCAN,
    SDK_THREAD_L2X_LEARN,
    SDK_THREAD_MAX
} sdk_thread_id_t;

void sdk_thread_event_handle(int unit, uint32_t thread_id, uint32_t line_num, uint32_t error_code);

#endif /* _ARCH_HA_SDK_THREAD_H_ */

