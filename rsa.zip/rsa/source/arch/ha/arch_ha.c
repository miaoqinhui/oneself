#include <stdio.h>
#include <psh/psh.h>
#include "./arch_ha.h"
#include "./arch_ha_ser.h"
#include "./arch_ha_sdk_thread.h"
#include "./arch_ha_dbg.h"

bool libha_dbg_vb  = false;
bool libha_dbg_vvb = false;
bool libha_dbg_err = false;

/* sdk事件处理函数 */
void frame_sdk_event_handle(int unit, int event, int arg1,
        int arg2, int arg3, void* userdata)
{
#if 0
    //SS_HA_DBG_VB("unit:%d, event:%d", unit, event);

    switch (event) {
    case BCM_SWITCH_EVENT_IO_ERROR:
        break;
    case BCM_SWITCH_EVENT_PARITY_ERROR:
        parity_event_handle(unit, arg1, arg2, arg3);
        break;
    case BCM_SWITCH_EVENT_THREAD_ERROR:
        sdk_thread_event_handle(unit, arg1, arg2, arg3);
        break;
    case BCM_SWITCH_EVENT_ACCESS_ERROR:
        break;
    case BCM_SWITCH_EVENT_ASSERT_ERROR:
        break;
    case BCM_SWITCH_EVENT_MODID_CHANGE:
        break;
    case BCM_SWITCH_EVENT_DOS_ATTACK:
        break;
    case BCM_SWITCH_EVENT_STABLE_FULL:
        break;
    case BCM_SWITCH_EVENT_STABLE_ERROR:
        break;
    case BCM_SWITCH_EVENT_UNCONTROLLED_SHUTDOWN:
        break;
    case BCM_SWITCH_EVENT_WARM_BOOT_DOWNGRADE:
        break;
    case BCM_SWITCH_EVENT_TUNE_ERROR:
        break;
    case BCM_SWITCH_EVENT_DEVICE_INTERRUPT:
        break;
    case BCM_SWITCH_EVENT_ALARM:
        break;
    case BCM_SWITCH_EVENT_MMU_BST_TRIGGER:
        break;
    case BCM_SWITCH_EVENT_EPON_ALARM:
        break;
    case BCM_SWITCH_EVENT_RUNT_DETECT:
        break;
    case BCM_SWITCH_EVENT_AUTONEG_SPEED_ERROR:
        break;
    case BCM_SWITCH_EVENT_COUNT:
        break;
    default:
        printf("not support event");
    }
#else
// NPS to be done pengcheng
#endif
    return;
}

/* sdk事件注册 */
int frame_sdk_event_reg(int unit)
{
    int rv;

    rv = true; //bcm_switch_event_register(unit, (bcm_switch_event_cb_t)frame_sdk_event_handle, NULL);
    SS_HA_DBG_VB("unit:%d, rv:%d", unit, rv);

    return rv;
}

/* 全局统计数据在主函数中初始化 */
void sda_ha_init(void)
{
    arch_ha_ser_init();
    return;
}

/* sdk事件注册在unit线程起来后初始化 */
int sda_ha_unit_init(rg_global_t *global, vsd_unit_thread_info_t *unit_info)
{
    int rv;
    int unit;

    arch_ha_dbg_init(global);

    if(unit_info == NULL) {
        return -SS_E_UNIT;
    }

    unit = get_unit_from_unit_thread_info(unit_info);
    rv = frame_sdk_event_reg(unit);
    if (rv != 0) {
        SS_HA_DBG_VB("frame_sdk_event_reg err(ret:%d)!\n", rv);
    }

    return rv;
}

