#include <psh/psh.h>
#include "arch_ha.h"
#include "arch_ha_sdk_thread.h"

char *g_sdk_thread_name[SDK_THREAD_MAX] = {
    [SDK_THREAD_L2X]            = "l2x",
    [SDK_THREAD_COUNTER]        = "counter",
    [SDK_THREAD_MEMSCAN]        = "memscan",
    [SDK_THREAD_L2MOD]          = "l2mod",
    [SDK_THREAD_L2MOD_DMA]      = "l2mod_dma",
    [SDK_THREAD_IPFIX]          = "ipfix",
    [SDK_THREAD_LINKSCAN]       = "linkscan",
    [SDK_THREAD_REGEX_REPORT]   = "regex report",
    [SDK_THREAD_HWDOS_MONITOR]  = "hwdos monitor",
    [SDK_THREAD_CTR_EVICT_DMA]  = "ctr evict dma",
    [SDK_THREAD_SRAMSCAN]       = "sramscan",
    [SDK_THREAD_L2X_LEARN]      = "l2x learn",
};

/* SDK线程异常事件处理函数 */
void sdk_thread_event_handle(int unit, uint32_t thread_id, uint32_t line_num, uint32_t error_code)
{
    int rv;
    char message[PSH_EVT_CAUSE_LEN_MAX];

    if (thread_id >= SDK_THREAD_MAX) {
        SS_HA_DBG_ERR("sdk thread id error");
        return;
    }

    snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "A sdk thread event of %s occurs in unit %d, and error code is %d.",
            g_sdk_thread_name[thread_id], unit, error_code);

    rv = protect_selfhealing_do_action(PSH_INNER_ACT, 0, "SSA-HA", message);
    if (rv != 0) {
        printf("protect_selfhealing_do_action do act err(ret:%d)!\r\n", rv);
    }
    /* 请求马上刷写自愈事件到存储介质中 */
    protect_selfhealing_flush_buf_in_emergency();
    return;
}
