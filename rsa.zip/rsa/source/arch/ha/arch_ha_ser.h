#ifndef _ARCH_HA_SER_H_
#define _ARCH_HA_SER_H_
#include <rg_sys/list.h>

#define HA_EVENT_DETECT_TIMES_MAX       (10)
#define HA_EVENT_DETECT_FILE_MAX_LEN    (200 * 1024)
#define HA_REG_NAME_LEN                 (128)            /* reg module name len */
#define HA_REG_REASON_LEN               (128)           /* reg module reason len */
#define HA_PARITY_REPL_LIMIT            (10)

/* Top level parity error info returned in event callbacks */
typedef enum {
    SER_SUBEVENT_ERROR_PARITY = 0,
    SER_SUBEVENT_ERROR_ECC,
    SER_SUBEVENT_ERROR_UNSPECIFIED,
    SER_SUBEVENT_ERROR_FATAL,
    SER_SUBEVENT_ERROR_CORRECTED,
    SER_SUBEVENT_ERROR_LOG,
    SER_SUBEVENT_ERROR_UNCORRECTABLE,
    SER_SUBEVENT_ERROR_AUTO_CORRECTED,
    SER_SUBEVENT_ERROR_FAILEDTOCORRECT,
    SER_SUBEVENT_ERROR_ECC_1BIT_CORRECTED, /* Single-bit ECC corrected, no traffic loss */
    SER_SUBEVENT_ERROR_ECC_2BIT_CORRECTED, /* Double-bit ECC corrected, potential traffic loss */
    SER_SUBEVENT_ERROR_PARITY_CORRECTED, /* Parity error correction */
    SER_SUBEVENT_ERROR_CFAP_MEM_FAIL,
    SER_SUBEVENT_ERROR_MAX
} ser_subevent_error_t;

/* sdk通告的奇偶校验信息 */
typedef struct ser_info_s {
    int unit;
    int arg1;
    int arg2;
    int arg3;
    bool mem_vaild;
    char mem_name[HA_REG_NAME_LEN];
} ser_info_t;

 /* 奇偶校验存储信息 */
typedef struct parity_data_s {
    int unit;
    int event;
    int subevent;
    int arg2;
    int arg3;
    bool mem_vaild;
    char mem_name[HA_REG_NAME_LEN];
    time_t occur_time;
 } parity_data_t;

/* 错误事件链表，最大10个 */
typedef struct {
    struct list_head lst;
    parity_data_t entry;
} parity_list_t;

/* 成功事件数组成员，10个 */
typedef struct {
    int count;
    parity_data_t entry;
} parity_repl_t;

/* 全局维护数据 */
typedef struct glb_parity_s {
    int fail_count;
    int repl_count;
    long total_count;
    struct list_head parity_head;
    parity_repl_t parity_repl[HA_PARITY_REPL_LIMIT]; /* 只记录10个重复成功事件  */
    int syslog_suppress;
} glb_parity_t;

extern glb_parity_t glb_parity;

void arch_ha_ser_init(void);
void parity_event_handle(int unit, uint32_t subevent, uint32_t arg2, uint32_t arg3);

#endif /* _ARCH_HA_SER_H_ */

