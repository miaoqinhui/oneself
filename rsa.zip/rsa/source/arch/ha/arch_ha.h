#ifndef _ARCH_HA_H_
#define _ARCH_HA_H_

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <rg_sys/rg_types.h>
#include <arch/unit_thread.h>

extern bool libha_dbg_vb;
extern bool libha_dbg_vvb;
extern bool libha_dbg_err;

#define SS_HA_DBG_VB(fmt, args...)   do {                               \
        if (libha_dbg_vb) {                                        \
            printf("[SSA_HA][VB](%s:%d)"fmt"\n", __func__, __LINE__, ##args); \
        }                                                                   \
    } while (0);

#define SS_HA_DBG_VVB(fmt, args...)   do {                                \
        if (libha_dbg_vvb) {                                        \
            printf("[SSA_HA][VVB](%s:%d)"fmt"\n", __func__, __LINE__, ##args); \
        }                                                                   \
    } while (0);
#define SS_HA_DBG_ERR(fmt, args...)   do {                                \
        if (libha_dbg_err) {                                        \
            printf("[SSA_HA][ERR](%s:%d)"fmt"\n", __func__, __LINE__, ##args); \
        }                                                                   \
    } while (0);

typedef enum {
    SS_E_NONE       = 0,
    SS_E_INTERNAL   = 1,
    SS_E_MEMORY     = 2,
    SS_E_UNIT       = 3,
    SS_E_PARAM      = 4,
    SS_E_EMPTY      = 5,
    SS_E_FULL       = 6,
    SS_E_NOT_FOUND  = 7,
    SS_E_EXISTS     = 8,
    SS_E_TIMEOUT    = 9,
    SS_E_BUSY       = 10,
    SS_E_FAIL       = 11,
    SS_E_DISABLED   = 12,
    SS_E_BADID      = 13,
    SS_E_RESOURCE   = 14,
    SS_E_CONFIG     = 15,
    SS_E_UNAVAIL    = 16,
    SS_E_INIT       = 17,
    SS_E_PORT       = 18,
    SS_E_OFFLINE    = 19,
    SS_E_NOT_SUP    = 20,
} ha_error_t;

void sda_ha_init(void);
//void frame_sdk_event_handle(int unit, bcm_switch_event_t event, uint32 arg1,
//        uint32 arg2, uint32 arg3, void* userdata);
int sda_ha_unit_init(rg_global_t *global, vsd_unit_thread_info_t *unit_info);

#endif /* _ARCH_HA_H_ */

