#ifndef _ARCH_HA_DBG_H_
#define _ARCH_HA_DBG_H_

int arch_ha_dbg_init(rg_global_t *global);

#endif /* _ARCH_HA_DBG_H_ */

