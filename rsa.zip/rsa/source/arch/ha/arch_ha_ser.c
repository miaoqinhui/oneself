#include <stdlib.h>
#include <unistd.h>
#include <psh/psh.h>
#include "arch_ha.h"
#include "arch_ha_ser.h"

#define HA_FAIL_AGE_TIME  (24 * 60 * 60)

glb_parity_t glb_parity;

char *g_ser_subevent_name[SER_SUBEVENT_ERROR_MAX] = {
    [SER_SUBEVENT_ERROR_PARITY]              = "parity",
    [SER_SUBEVENT_ERROR_ECC]                 = "ecc",
    [SER_SUBEVENT_ERROR_UNSPECIFIED]         = "unspecified",
    [SER_SUBEVENT_ERROR_FATAL]               = "fatal",
    [SER_SUBEVENT_ERROR_CORRECTED]           = "corrected",
    [SER_SUBEVENT_ERROR_LOG]                 = "log",
    [SER_SUBEVENT_ERROR_UNCORRECTABLE]       = "uncorrectable",
    [SER_SUBEVENT_ERROR_AUTO_CORRECTED]      = "auto corrected",
    [SER_SUBEVENT_ERROR_FAILEDTOCORRECT]     = "fail to correct",
    [SER_SUBEVENT_ERROR_ECC_1BIT_CORRECTED]  = "ecc 1bit corrected",
    [SER_SUBEVENT_ERROR_ECC_2BIT_CORRECTED]  = "ecc 2bit corrected",
    [SER_SUBEVENT_ERROR_PARITY_CORRECTED]    = "parity corrected",
    [SER_SUBEVENT_ERROR_CFAP_MEM_FAIL]       = "cfap mem fail",
};

static void ser_info_t_print(ser_info_t *info)
{
    SS_HA_DBG_VVB("unit %d, ", info->unit);
    SS_HA_DBG_VVB("arg1 %d, ", info->arg1);
    SS_HA_DBG_VVB("arg2 %d, ", info->arg2);
    SS_HA_DBG_VVB("arg3 %d, ", info->arg3);
    SS_HA_DBG_VVB("mem_valid %d, ", info->mem_vaild);
    if (info->mem_vaild) {
        SS_HA_DBG_VVB("mem %s\n", info->mem_name);
    }

    return;
}

/* 判断子事件的合法性 */
static bool parity_event_valid(int subevent)
{
    SS_HA_DBG_VVB("parity subevent %d", subevent);
    if (subevent >= SER_SUBEVENT_ERROR_MAX || subevent < SER_SUBEVENT_ERROR_PARITY) {
        return false;
    } else {
        return true;
    }
}

/* 增加错误统计节点 */
static int parity_entry_add(time_t *now, ser_info_t *info)
{
    parity_list_t *new_entry;

    /* 创建一个新的统计信息 */
    new_entry = (parity_list_t *)malloc(sizeof(new_entry[0]));
    if (new_entry == NULL) {
        return -SS_E_MEMORY;
    }

    memset(new_entry, 0, sizeof(new_entry[0]));
    memcpy(&(new_entry->entry.occur_time), now, sizeof(time_t));
    new_entry->entry.mem_vaild = info->mem_vaild;
    if (info->mem_vaild) {
        memcpy(new_entry->entry.mem_name, info->mem_name, sizeof(info->mem_name));
        new_entry->entry.mem_name[HA_REG_NAME_LEN - 1] = '\0';
    }
    new_entry->entry.unit = info->unit;
    new_entry->entry.arg2 = info->arg2;
    new_entry->entry.arg3 = info->arg3;
    new_entry->entry.subevent = info->arg1;
    list_add(&new_entry->lst, &glb_parity.parity_head);
    glb_parity.fail_count++;

    return SS_E_NONE;
}

static void parity_repl_add(time_t *now, ser_info_t *info)
{
    int i;
    int min_count;
    int index;

    for (i = 0; i < HA_PARITY_REPL_LIMIT; i++) {
        if ((glb_parity.parity_repl[i].entry.arg2 == info->arg2)
            && (glb_parity.parity_repl[i].entry.arg3 == info->arg3)
            && (glb_parity.parity_repl[i].entry.unit == info->unit)) {
            memcpy(&(glb_parity.parity_repl[i].entry.occur_time), now, sizeof(time_t));
            glb_parity.parity_repl[i].count++;
            if (glb_parity.repl_count < glb_parity.parity_repl[i].count) {
                glb_parity.repl_count = glb_parity.parity_repl[i].count;
            }
            return;
        }
    }

    min_count = glb_parity.parity_repl[0].count;
    index = 0;
    for (i = 1; i < HA_PARITY_REPL_LIMIT; i++) {
        if (min_count > glb_parity.parity_repl[i].count) {
            min_count = glb_parity.parity_repl[i].count;
            index = i;
        }
    }

    memset(&glb_parity.parity_repl[index], 0x0, sizeof(parity_repl_t));
    memcpy(&glb_parity.parity_repl[index].entry.occur_time, now, sizeof(time_t));
    glb_parity.parity_repl[index].entry.mem_vaild = info->mem_vaild;
    if (info->mem_vaild) {
        memcpy(glb_parity.parity_repl[index].entry.mem_name, info->mem_name, sizeof(info->mem_name));
        glb_parity.parity_repl[index].entry.mem_name[HA_REG_NAME_LEN - 1] = '\0';
    }
    glb_parity.parity_repl[index].entry.unit = info->unit;
    glb_parity.parity_repl[index].entry.arg2 = info->arg2;
    glb_parity.parity_repl[index].entry.arg3 = info->arg3;
    glb_parity.parity_repl[index].entry.subevent = info->arg1;
    glb_parity.parity_repl[index].count++;
    if (glb_parity.repl_count < glb_parity.parity_repl[index].count) {
        glb_parity.repl_count = glb_parity.parity_repl[index].count;
    }

    return;
}

static void parity_repl_syslog(ser_info_t *info)
{
    int rv;
    char message[PSH_EVT_CAUSE_LEN_MAX];

    if (info->mem_vaild) {
        snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "A ser event of %s occurs in %s index %d, and have been repaired.",
                g_ser_subevent_name[info->arg1], info->mem_name, info->arg3);
    } else {
        snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "A ser event of %s occurs, and have been repaired.", g_ser_subevent_name[info->arg1]);
    }

    rv = protect_selfhealing_do_action(PSH_INNER_ACT, 0, "SSA-HA", message);
    if (rv != 0) {
        printf("protect_selfhealing_do_action do act err(ret:%d)!\n", rv);
    }
    /* 请求马上刷写自愈事件到存储介质中 */
    protect_selfhealing_flush_buf_in_emergency();
    return;
}

static void parity_fatal_syslog(ser_info_t *info)
{
    int rv;
    char message[PSH_EVT_CAUSE_LEN_MAX];

    if (info->mem_vaild) {
        snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "A ser event of %s occurs in %s index %d, and could not be repaired.",
                g_ser_subevent_name[info->arg1], info->mem_name, info->arg3);
    } else {
        snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "A ser event of %s occurs, and could not be repaired.", g_ser_subevent_name[info->arg1]);
    }

    rv = protect_selfhealing_do_action(PSH_INNER_ACT, 0, "SSA-HA", message);
    if (rv != 0) {
        printf("protect_selfhealing_do_action do act err(ret:%d)!\n", rv);
    }
    /* 请求马上刷写自愈事件到存储介质中 */
    protect_selfhealing_flush_buf_in_emergency();
    return;
}

static void parity_reload_device(ser_info_t *info)
{
    int rv;

    rv = protect_selfhealing_do_action(PSH_RELOAD_SELF_ACT, 0, "SSA-HA", "A fatal ser error occurs, the device will reboot.");
    if (rv != 0) {
        printf("protect_selfhealing_do_action do act err(ret:%d)!\n", rv);
    }
    /* 请求马上刷写自愈事件到存储介质中 */
    protect_selfhealing_flush_buf_in_emergency();
    sleep(2);
    return;
}

/* 奇偶校验事件处理函数 */
void parity_event_handle(int unit, uint32_t subevent, uint32_t arg2, uint32_t arg3)
{

    int rv;
    time_t now;
    bool reload = false;
    int i;
    parity_list_t *pos, *n;

    int name_len;
    ser_info_t info;

    if (!parity_event_valid(subevent)) {
        SS_HA_DBG_ERR("the subevent id [%d] is illegal.", subevent);
        return;
    }

    memset(&info, 0, sizeof(info));
    info.arg1 = subevent;
    info.arg2 = arg2;
    info.arg3 = arg3;
#if 0
    if (SOC_MEM_IS_VALID(unit, arg2)) {
        name_len = strlen(SOC_MEM_NAME(unit, arg2));
        memcpy(&(info.mem_name), SOC_MEM_NAME(unit, arg2), name_len);
        info.mem_vaild = true;
    }
#endif
    now = time(NULL);

    ser_info_t_print(&info);

    switch (subevent) {
    case SER_SUBEVENT_ERROR_PARITY:
        /* 仅记录log，不计数 */
        protect_selfhealing_do_action(PSH_INNER_ACT, 0, "SSA-HA", "A parity error occurs");
        break;
    case SER_SUBEVENT_ERROR_ECC:
        /* 仅记录log，不计数 */
        protect_selfhealing_do_action(PSH_INNER_ACT, 0, "SSA-HA", "An ECC error occurs");
        break;
    case SER_SUBEVENT_ERROR_UNSPECIFIED: /* fallthrough */
    case SER_SUBEVENT_ERROR_FATAL: /* fallthrough */
    case SER_SUBEVENT_ERROR_UNCORRECTABLE: /* fallthrough */
    case SER_SUBEVENT_ERROR_FAILEDTOCORRECT: /* fallthrough */
    case SER_SUBEVENT_ERROR_CFAP_MEM_FAIL:
        /* 先判断是否老化 */
        if (!list_empty(&glb_parity.parity_head)) {
            list_for_each_entry_safe(pos, n, &glb_parity.parity_head, lst) {
                printf("difftime is %f\n", difftime(now, pos->entry.occur_time) );
                if( difftime(now, pos->entry.occur_time) > HA_FAIL_AGE_TIME) {
                    list_del(&pos->lst);
                    free(pos);
                    glb_parity.fail_count--;
                    glb_parity.total_count--;
                }
            }
        }

        /* 计数 */
        SS_HA_DBG_VB("fail parity list process %d", subevent);
        rv = parity_entry_add(&now, &info);
        if (rv != SS_E_NONE) {
            SS_HA_DBG_ERR("add parity list fail %d", rv);
            break;
        }
        glb_parity.total_count++;
        if (glb_parity.fail_count >= HA_EVENT_DETECT_TIMES_MAX) {
            reload = true;
            /* 回收内存 */
            if (!list_empty(&glb_parity.parity_head)) {
                list_for_each_entry_safe(pos, n, &glb_parity.parity_head, lst) {
                    list_del(&pos->lst);
                    free(pos);
                }
            }
            glb_parity.fail_count = 0;
        }
        SS_HA_DBG_VB("record critical parity event");

        /* 记录log */
        parity_fatal_syslog(&info);
        break;
    case SER_SUBEVENT_ERROR_AUTO_CORRECTED: /* fallthrough */
    case SER_SUBEVENT_ERROR_CORRECTED: /* fallthrough */
    case SER_SUBEVENT_ERROR_ECC_1BIT_CORRECTED: /* fallthrough */
    case SER_SUBEVENT_ERROR_ECC_2BIT_CORRECTED: /* fallthrough */
    case SER_SUBEVENT_ERROR_PARITY_CORRECTED:
        /* 计数 */
        SS_HA_DBG_VB("repl parity process %d", subevent);

        parity_repl_add(&now, &info);
        glb_parity.total_count++;
        if (glb_parity.repl_count >= HA_EVENT_DETECT_TIMES_MAX) {
            if (glb_parity.syslog_suppress < HA_PARITY_REPL_LIMIT) {
                glb_parity.syslog_suppress++;
            }
            glb_parity.repl_count = 0;
            for (i = 0; i < HA_PARITY_REPL_LIMIT; i++) {
                if ((glb_parity.parity_repl[i].count >= HA_EVENT_DETECT_TIMES_MAX)) {
                    memset(&glb_parity.parity_repl[i], 0x0, sizeof(parity_repl_t));
                    continue;
                }
                if (glb_parity.repl_count < glb_parity.parity_repl[i].count) {
                    glb_parity.repl_count = glb_parity.parity_repl[i].count;
                }
            }
        }

        /* 记录log */
        parity_repl_syslog(&info);
        break;
    case SER_SUBEVENT_ERROR_LOG: /* fallthrough */
    default:
        glb_parity.total_count++;

        break;
    }

    /* 严重SER错误，重启本设备 */
    if (reload) {
        parity_reload_device(&info);
    }

    return;
}

void arch_ha_ser_init(void)
{
    memset(&glb_parity, 0x0, sizeof(glb_parity));
    INIT_LIST_HEAD(&glb_parity.parity_head);

    return;
}
