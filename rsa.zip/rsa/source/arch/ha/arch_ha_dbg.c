#include <stdio.h>
#include <rg_at/ssat_intf.h>
#include "arch_ha.h"
#include "arch_ha_ser.h"
#include "arch_ha_sdk_thread.h"

int sdk_ser_event_simulator(int unit, uint32_t arg2, uint32_t arg3)
{
    int i;
    for (i = 1; i < SER_SUBEVENT_ERROR_MAX; i++) {
        parity_event_handle(unit, i, arg2, arg3);
    }
    return 0;
}

int sdk_ser_event_repl(int unit)
{
    int i;
    for (i = 1; i < SER_SUBEVENT_ERROR_MAX; i++) {
        parity_event_handle(unit, i, 6644, 100);
    }
    return 0;
}

int sdk_thread_event_simulator(int unit, uint32_t arg2, uint32_t arg3)
{
    int i;

    for(i = 1; i < SDK_THREAD_MAX; i++) {
        sdk_thread_event_handle(unit, i, arg2, arg3);
    }

    return 0;
}

int sdk_event_simulator(int unit, uint32_t event, uint32_t arg1, uint32_t arg2, uint32_t arg3)
{
    //frame_sdk_event_handle(unit, event, arg1, arg2, arg3, NULL);

    return 0;
}

static void parity_data_t_print(parity_data_t *info)
{
    struct tm *local_time;
    char time_str[20];

    SS_HA_DBG_VVB("unit %d, ", info->unit);
    SS_HA_DBG_VVB("subevent %d, ", info->subevent);
    SS_HA_DBG_VVB("arg2 %d, ", info->arg2);
    SS_HA_DBG_VVB("arg3 %d, ", info->arg3);
    SS_HA_DBG_VVB("mem_valid %d, ", info->mem_vaild);
    if (info->mem_vaild) {
        SS_HA_DBG_VVB("mem %s", info->mem_name);
    }
    local_time = localtime(&info->occur_time);
    (void)strftime(time_str, sizeof(time_str), "%F %T", local_time);
    SS_HA_DBG_VVB("time %s\n,", time_str);

    return;
}

static int parity_data_print(void)
{
    int i;
    parity_list_t *pos;

    printf("fail_count %d\n", glb_parity.fail_count);
    printf("repl_count %d\n", glb_parity.repl_count);
    printf("total_count %ld\n", glb_parity.total_count);
    printf("syslog_suppress count %d\n", glb_parity.syslog_suppress);

    if (!list_empty(&glb_parity.parity_head)) {
        list_for_each_entry(pos, &glb_parity.parity_head, lst) {
            parity_data_t_print(&pos->entry);
        }
    }

    for (i = 0; i < HA_PARITY_REPL_LIMIT; i++) {
        if (glb_parity.parity_repl[i].count != 0) {
            printf("[%d]count %d\n", i, glb_parity.parity_repl[i].count);
            parity_data_t_print(&glb_parity.parity_repl[i].entry);
        }
    }

    return SS_E_NONE;
}

int arch_ha_dbg_init(rg_global_t *global)
{
    int rv;
    char *name = "ssa_ha";
    at_ctrl_info_t *pos = NULL;

    /* 组件注册 */
    pos = (at_ctrl_info_t *)malloc(sizeof(at_ctrl_info_t));
    if (pos == NULL) {
        printf("name[%s] malloc mem fail\r\n", name);
        return -2;
    }
    memset(pos, 0, sizeof(at_ctrl_info_t));
    rv = ssat_multi_thread_init(global, name, pos);
    /* 组件注册ok后，才开始注册命令 */
    if (!rv) {
        SSAT_MULTI_THREAD_CMD_REG(pos, name, "sdk_ser_event_simulator", "unit=%d, arg2=%d, arg3=%d", sdk_ser_event_simulator);
        SSAT_MULTI_THREAD_CMD_REG(pos, name, "sdk_thread_event_simulator", "unit=%d, arg2=%d, arg3=%d", sdk_thread_event_simulator);
        SSAT_MULTI_THREAD_CMD_REG(pos, name, "sdk_event_simulator", "unit=%d, event=%d, arg1=%d, arg2=%d, arg3=%d", sdk_event_simulator);
        SSAT_MULTI_THREAD_CMD_REG(pos, name, "parity_data_print", "void", parity_data_print);
        SSAT_MULTI_THREAD_CMD_REG(pos, name, "sdk_ser_event_repl", "unit=%d", sdk_ser_event_repl);
    } else {
        printf("name[%s] ssat_multi_thread_init fail\r\n", name);
        free(pos);
    }

    return rv;
}

