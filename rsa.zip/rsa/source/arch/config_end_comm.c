/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * config_end_comm.c
 * Original Author:  shenhanbin@ruijie.com.cn, 2018-8-15
 * 12.x ssa�˿�enable��ʼ�����
 *
 * History
 *
 */

#include <stdbool.h>
#include <rg_zlog/zct.h>
#include <rg_zlog/rgdf_zlog.h>
#include <rg_at/ssat_intf.h>
#include <arch/unit_thread.h>
#include <libpub/rg_protobuf_rt/s/frame/config_end_comm.pb-c.h>
#include <libpub/rg_mom/rg_global.h>
#include <libpub/rg_mom/rg_mom_common.h>
#include <libpub/rg_mom/rg_mom.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <arch/config_end_comm.h>

rgdf_zlog_level_t g_config_end_comm_zlog_level = RGDF_ZLOG_LV_ERROR;
zlog_category_t * g_config_end_comm_zlog_category;

#define CONFIG_END_COMM_ZLOG_FATAL(fmt, arg...)   RGDF_ZLOG_FATAL(config_end_comm, fmt, ##arg)
#define CONFIG_END_COMM_ZLOG_ERROR(fmt, arg...)   RGDF_ZLOG_ERROR(config_end_comm, fmt, ##arg)
#define CONFIG_END_COMM_ZLOG_WARN(fmt, arg...)    RGDF_ZLOG_WARN(config_end_comm, fmt, ##arg)
#define CONFIG_END_COMM_ZLOG_NOTICE(fmt, arg...)  RGDF_ZLOG_NOTICE(config_end_comm, fmt, ##arg)
#define CONFIG_END_COMM_ZLOG_INFO(fmt, arg...)    RGDF_ZLOG_INFO(config_end_comm, fmt, ##arg)
#define CONFIG_END_COMM_ZLOG_DEBUG(fmt, arg...)   RGDF_ZLOG_DEBUG(config_end_comm, fmt, ##arg)

#define MODULE_CFG_OFFSET                0x00000001
#define CONFIG_END_MODULE_NAME           "config_end_comm"

const char* module_config_name[] = {
    "intf_ap",
    "intf_port",
    "bridge_vlan",
    "bridge_stp",
    "bridge_mac",
    "route_mc",
    "route_uc",
    "policy_fp_model",
    "policy_appmng",
    "policy_qos",
    "me_mpls",
    "cluster_cpp_pkc",
    "cluster_cpp_rate",    
    "cluster_dpm",
    "overlay_intf",
    "all_module"
};

/* ҵ��ע��ؼ�ģ��ģ�壬��Ҫ��ssa���̳߳�ʼ����ɣ���оƬ���̳߳�ʼ��֮ǰ */
static int enable_template = 0;
/* count_module��¼��ǰע�����ؼ�ģ�飬����at���� */
static int count_module = 0;

/*****************************************************************************************************/
/*                                            at����                                                   */
/*****************************************************************************************************/

/* ��ȡ�忨���оƬ�� */
static unsigned int at_get_dev_max_units (void) {
	return get_max_switch_unit();
}

/* ��ӡ��ǰδ�����ؼ�ģ�� */
static void at_dump_key_module_not_ready(const int unit, int not_enable)
{
    int i;
	bool state;

    printf("[at]:unit %d not ready module is :\n", unit);
	for (i = 0; i <= count_module; i++) {
        state = (not_enable>>i) & MODULE_CFG_OFFSET;
		if (state) {
            printf("                         %s\n", module_config_name[i]);
		}
	}
	printf("********************\n");
}

/* ��ӡ����оƬ����ģ�弰����״̬ */
static void at_dump_unit_enable_info (void) {
    unsigned int max_unit, i;
	vsd_unit_thread_info_t *unit_info;
	bool state;

    printf("\n********************\n");
    printf("[at]:enable_template= 0x%x\n", enable_template);
	printf("[at]:register key_module is :\n");
	for (i = 0; i <= count_module; i++) {
        state = (enable_template>>i) & MODULE_CFG_OFFSET;
		if (state) {
            printf("                         %s\n", module_config_name[i]);
		}
	}
	
	max_unit = at_get_dev_max_units();
    for (i = 0; i < max_unit; i++) {
        unit_info = get_g_vsd_unit_thread_info(i);
		if (!unit_info) {
            continue;
		}
		printf("[at]:unit %d enable = 0x%x\n", i, unit_info->enable);
	    at_dump_key_module_not_ready(unit_info->unit, unit_info->enable^enable_template);
	}

}

/* ģ��ؼ�ģ��ע�� */
static void at_register_key_module (key_module_type_t key_module)
{
    if (ssa_key_module_register(key_module) != 0) {
        printf("[at]:failed to set key module type %d\n", key_module);
	}
}

/* ģ��ؼ�ģ��������� */
static void at_set_key_module_end (unsigned int unit, key_module_type_t key_module)
{
	vsd_unit_thread_info_t *unit_info;
	unsigned int max_unit;
	
	max_unit = at_get_dev_max_units();
    if (unit >= max_unit) {
        printf("[at]:unit number over max_unit\n");
	}
	unit_info = get_g_vsd_unit_thread_info(unit);
	if (ssa_set_key_module_cfg_end(unit_info, key_module) != 0) {
        printf("[at]:failed to set unit %d key_module %d\n", unit, key_module);
	}
}

#if 0

static int at_subscribe_callback(rg_global_t *global, rg_mom_pubsub_msg_t *msg, void *privdata)
{
	SFrame__UnitEnable* at_unit_enable;
    if (msg->error != RG_MOM_OK) {
        CONFIG_END_COMM_ZLOG_DEBUG("[at]:config end comm subscribe failed");
		return -1;
	} 

	if (msg->cmd == RG_MOM_SUBSCRIBE) {
		CONFIG_END_COMM_ZLOG_DEBUG("[at]:config end comm subscribe success");
        return 0;
	}

    if (msg->cmd == RG_MOM_SET) {
        at_unit_enable = (SFrame__UnitEnable *) msg->value;
	    CONFIG_END_COMM_ZLOG_DEBUG("[at]:unit %d is enable, value is %d", at_unit_enable->index->unit, at_unit_enable->value);
		return 0;
	}

	return -1;
}

static int at_subscribe_unit_enable(rg_global_t *global, vsd_unit_thread_info_t *unit_info) 
{
    SFrame__UnitEnable unit_enable_key = S_FRAME__UNIT_ENABLE__INIT;
    SFrame__KeyIndex key_index = S_FRAME__KEY_INDEX__INIT;

    if (!global || !unit_info) {
        CONFIG_END_COMM_ZLOG_DEBUG("[at]:invalid global or unit_info");
		return -1;
	}
	
    unit_enable_key.index = &key_index;
    rg_mom_subscribe(global, RG_MOM_ASIC_DB, (const rg_obj*) &unit_enable_key, 0, at_subscribe_callback, NULL);
	CONFIG_END_COMM_ZLOG_DEBUG("[at]:unit_enable_subscribed");


	return 0;
}
/*****************************************************************************************************/
#endif

/* zlog��ʼ�� */
static int config_end_comm_zlog_init (void)
{
    g_config_end_comm_zlog_category = rg_zlog_init(CONFIG_END_MODULE_NAME);
    if (!g_config_end_comm_zlog_category) {
        CONFIG_END_COMM_ZLOG_ERROR("%s zlog init fail", CONFIG_END_MODULE_NAME);
        return -1;
    }
    CONFIG_END_COMM_ZLOG_DEBUG("%s zlog init successfully", CONFIG_END_MODULE_NAME);
    return 0;
}

/* at��ʼ�� */
static int config_end_comm_rg_at_init (rg_global_t *global)
{
    at_ctrl_info_t *pos = NULL;

    if (!global) {
        CONFIG_END_COMM_ZLOG_ERROR("%s input global is NULL", CONFIG_END_MODULE_NAME);
        return -1;
	}

    pos = (at_ctrl_info_t *)malloc(sizeof(at_ctrl_info_t));
    if (pos == NULL) {
        printf("name[%s] malloc mem fail\r\n", CONFIG_END_MODULE_NAME);
        return -2;
    }
    memset(pos, 0, sizeof(at_ctrl_info_t));
    if (ssat_multi_thread_init(global, CONFIG_END_MODULE_NAME, pos) != 0) {
        CONFIG_END_COMM_ZLOG_ERROR("%s ssat_multi_thread_init failed", CONFIG_END_MODULE_NAME);
        free(pos);
        return -1;
    }
    CONFIG_END_COMM_ZLOG_DEBUG("%s ssat init successfully", CONFIG_END_MODULE_NAME);
	
    SSAT_MULTI_THREAD_CMD_REG(pos, CONFIG_END_MODULE_NAME, "dump_enable", "void", (void*)at_dump_unit_enable_info);
    SSAT_MULTI_THREAD_CMD_REG(pos, CONFIG_END_MODULE_NAME, "register_key_module", "key_module = %d", (void*)at_register_key_module);
    SSAT_MULTI_THREAD_CMD_REG(pos, CONFIG_END_MODULE_NAME, "set_key_module_end", "unit = %d, key_module = %d", (void*)at_set_key_module_end);

    return 0;
}

/* enable��ܳ�ʼ���ӿ� */
int config_end_comm_init (rg_global_t *global, vsd_unit_thread_info_t *unit_info)
{
    if (config_end_comm_zlog_init() != 0) {
        return -1;
    }
    if (config_end_comm_rg_at_init(global) != 0) {
        return -1;
    }
    /* for at test */
	#if 0
	at_subscribe_unit_enable(global, unit_info);
    #endif
	
    return 0;
}

/* ҵ��ؼ�ģ��ע�� */
int ssa_key_module_register (key_module_type_t key_module)
{
    if (key_module >= MAX_KEY_MODULES || key_module < 0) {
        CONFIG_END_COMM_ZLOG_ERROR("key module type %d register fail", key_module);
		return -1;
	}
		
    enable_template |= MODULE_CFG_OFFSET<<key_module;
	/* count_module ����atδע��ؼ�ģ����� */
	if (key_module > count_module) {
        count_module = key_module;
	}
	
	return 0;
}

/* �ؼ�ģ��������ýӿ� */
int ssa_set_key_module_cfg_end(vsd_unit_thread_info_t* unit_info,\
    key_module_type_t key_module)
{
    SFrame__UnitEnable unit_enable_key = S_FRAME__UNIT_ENABLE__INIT;
    SFrame__KeyIndex key_index = S_FRAME__KEY_INDEX__INIT;

    if (key_module >= MAX_KEY_MODULES || key_module < 0) {
        CONFIG_END_COMM_ZLOG_ERROR("key module type %d register fail", key_module);
		return -1;
	}

	if (!unit_info || !unit_info->global) {
        CONFIG_END_COMM_ZLOG_ERROR("unit_info is invalid");
		return -1;
	}
	
    key_index.unit = unit_info->unit;
    unit_enable_key.index = &key_index;
	/* unit_enable_key.value����ʹ�ÿ�������ֵ���˿�enableģ��ֻ���ע����ͨ�漴�� */
    unit_enable_key.value = 1;
    unit_info->enable |= MODULE_CFG_OFFSET << key_module;
	
	CONFIG_END_COMM_ZLOG_DEBUG("unit %d : %s : ready", unit_info->unit, module_config_name[key_module]);
    if (unit_info->enable == enable_template) {
        if (rg_mom_set_sync(unit_info->global, RG_MOM_ASIC_DB, (const rg_obj*) &unit_enable_key) != 0) {
            CONFIG_END_COMM_ZLOG_FATAL("failed to set unit %d : %s : ready", unit_info->unit, module_config_name[MAX_KEY_MODULES]);
			return -1;
        }
        CONFIG_END_COMM_ZLOG_DEBUG("unit %d : %s : ready", unit_info->unit, module_config_name[MAX_KEY_MODULES]);
		return 0;
    }

	return 0;
}

