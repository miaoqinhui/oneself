/*
 * Copyright(C) 2018 Ruijie Network. All rights reserved.
 */
/*
 * one_proc.c
 * Original Author:  shenhanbin@ruijie.com.cn, 2018-8-20
 * 12.x ssa ע��ham�����̶�ʵ�����
 *
 * History
 *
 */

#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <rg-ham/ham.h>

#define SYS_MAX_PATH_LEN        256
#define SSA_MODULE_NAME         "rsa"
#define SSA_NO_HAM              "/var/tmp/ssa_no_ham"
#define SYS_LOCK_DIR            "/var/run"
#define SYS_LOCK_MODE           (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)

static int sys_lockfile_req(int fd)
{
    struct flock fl;

    fl.l_type = F_WRLCK;
    fl.l_start = 0;
    fl.l_whence = SEEK_SET;
    fl.l_len = 0;

    return(fcntl(fd, F_SETLK, &fl));
}

static int sys_check_running(char *name)
{
    int fd;
    char buf[16] = {0};
	char path[SYS_MAX_PATH_LEN + 1] = {0};
	
	if (name == NULL) {
		return -1;
	}
	snprintf(path, SYS_MAX_PATH_LEN, "%s/%s.pid", SYS_LOCK_DIR, name);
	
    fd = open(path, O_RDWR | O_CREAT | O_TRUNC, SYS_LOCK_MODE);
    if (fd < 0) {
        return -1;
    }

    if (sys_lockfile_req(fd) == -1) {
        if (errno == EACCES || errno == EAGAIN) {
            close(fd);
            return -1;
        }
        return -1;
    }

    (void)ftruncate(fd, 0);
    sprintf(buf, "%ld", (long)getpid());
    write(fd, buf, strlen(buf) + 1);

    return 0;
}

/* ssa���̶�ʵ����� */
int frame_check_ssa_one(void)
{
	if (sys_check_running(SSA_MODULE_NAME) < 0) {
		printf("%s is running\n", SSA_MODULE_NAME);
		exit(0);
	}
	return 1;
}

/* ssa ע��ham */
void ssa_rg_ham_init(void)
{
    int ret, fd;

    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, SIG_IGN); 
    
    fd = open(SSA_NO_HAM, O_RDONLY);
    if (fd < 0) {
        ret = reg_process_exit_action(getpid(), HAM_SHELL_RESTART);
        if (ret) {
            printf(" %s reg_process_exit_action ret %d", SSA_MODULE_NAME, ret);
        }
    } else {
        close(fd);
    }

    return;
}
