#ifndef __FE_BUSS_INIT_H__
#define __FE_BUSS_INIT_H__

extern int ptd_fe_bp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);

#endif  /* __FE_BUSS_INIT_H__ */
