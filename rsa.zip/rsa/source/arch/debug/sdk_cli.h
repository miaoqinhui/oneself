#ifndef __SDK_CLI_H__
#define __SDK_CLI_H__

int sdk_cli_init(void);

int sdk_cli_run(char *prompt);

#endif