#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include "debug_proc.h"
//#include "at_cli.h"
//#include "sd_cli.h"
#include "sdk_cli.h"

/* debug cli数据结构 */
typedef int (*dbg_init_f)(void);
typedef int (*dbg_run_f)(char *prompt);
typedef struct {
	char 		*prompt;	/* 提示�?*/
	int 		en;			/* 是否使能 */
	dbg_init_f 	init;		/* 初始化函�?*/
	dbg_run_f 	run;		/* 运行函数 */
} dbg_info_t;


/* 支持的cli信息 */
static dbg_info_t m_dbg_cli_info[] = {
	{"sdk", 1, sdk_cli_init, sdk_cli_run},
	/* {"ngsa-cli> ", 1, sd_cli_init, sd_cli_run}, */
	/* {"at-cli> ", 1, at_cli_init, at_cli_run}, */
};


/* ����ܷ����豸 */
static int debug_dev_valid(void)
{
    #define STD_BUF_LEN 128
    
    char old_std[STD_BUF_LEN + 1] = {0};
    char dev_pts[] = "/dev/pts/";
    
    ttyname_r(0, old_std, STD_BUF_LEN);
    //printf("dev_pts: %s\r\n", old_std);
    return (strncmp(dev_pts, old_std, strlen(dev_pts)) == 0);
    
}

int debug_proc_main(void *data)
{
	dbg_info_t *mgr = m_dbg_cli_info;
	dbg_info_t *cli = NULL;
	int 	   cnt = sizeof(m_dbg_cli_info) / sizeof(m_dbg_cli_info[0]);
	int 		i = 0;
	
	/* run init*/
            
	for (i = 0; i < cnt; i++) {
		cli = &mgr[i];
		if (cli->init && cli->en) 
			cli->init();
	}
	
	while (1) {
        if (!debug_dev_valid()) {
            sleep(1);
			continue;
        }
		for (i = 0; i < cnt; i++) {
			cli = &mgr[i];
			if (cli->run && cli->en) 
				cli->run(cli->prompt);
		}
	}
	
	return 1;
}




//#ifdef CONFIG_SSA_DEBUG_THREAD_EN
#include <pthread.h>

static void *debug_proc_task_main(void *data)
{
    (void)prctl(PR_SET_NAME, "debug_sdk_thread");
    (void)pthread_detach(pthread_self());
	debug_proc_main(data);
	return NULL;
}


int debug_proc_run_task(void)
{
	int rv;
	pthread_t thread_id;
	
	rv = pthread_create(&thread_id, NULL, debug_proc_task_main, NULL);
	if (rv != 0) {
		return 0;
	}
	
	return 1;
}
//#endif
