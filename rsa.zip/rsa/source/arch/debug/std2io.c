#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <pthread.h>

#define STD_BUF_LEN 128

#define STD_RUN_DIR "/tmp/proxy/stdio"
#define STD_ETC_DIR "/etc/proxy"
#define STD_ETC_CLI "/etc/proxy/shell"

static char m_app_name[STD_BUF_LEN + 1] = {0};
static char m_std_dev[STD_BUF_LEN + 1] = {0};
static char m_std_cli[STD_BUF_LEN + 1] = {0};
static char m_std_etc[STD_BUF_LEN + 1] = {0};
static char m_std_ps[STD_BUF_LEN + 1] = {0};
static int m_std_init = 0;
static int m_std_fd = -1;

int proxy_io_cfg2raw(int fd, int raw)
{
    struct termios termios = {0};
    struct termios *tty = &termios;
    struct termios *termios_p = tty;

    if (!isatty(fd)) {
        return 0;
    }
    
    tcgetattr(fd,tty);
    if (raw) {
        termios_p->c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
        termios_p->c_oflag &= ~OPOST;
        termios_p->c_lflag &= ~(ECHO | ECHONL | IEXTEN | ICANON);
    } else {
        termios_p->c_lflag |= (ECHO | ECHONL | ICANON);
    }

    tcsetattr(fd, TCSANOW, tty);
    tcflush(fd,TCIOFLUSH);
    
    return 1;
}

int io_check_file(char *file)
{
    FILE *fp;

    if (file == NULL) {
        return 0;
    }
    
    fp = fopen(file, "r");
    if (fp == NULL) {
        return 0;
    }
    fclose(fp);

    return 1;
}


char *std_base_name(char *app_full)
{
    char *app_name = NULL;
    
    app_name = strrchr(app_full, '/');
    app_name = (app_name ? app_name +1 : app_full);

    return app_name;
}

static char *std_get_app_name(int pid, char *app_out)
{
    char path[STD_BUF_LEN + 1] = {0};
    char app_full[STD_BUF_LEN + 1] = {0};
    int real = 0;
    char *app_name = NULL;
    
    memset(app_full, 0, sizeof(app_full));

    sprintf(path, "/proc/%d/exe", pid);

    real = readlink(path, app_full, STD_BUF_LEN);
    if (real == -1) {
        perror("readlink: ");
    }
    app_name = strrchr(app_full, '/');
    app_name = (app_name ? app_name +1 : app_full);
    strcpy(app_out, app_name);
    
    return app_out;
}

static int std_io2fd(char *dev)
{
    int new_fd = -1;

    /* ���豸 */
    new_fd = open(dev, O_RDWR);
    if (new_fd < 0) {
        return 0;
    }

    dup2(new_fd, 0);
    dup2(new_fd, 1);
    dup2(new_fd, 2);
    m_std_fd = new_fd;
    
    return 1;
}

static void std_init_config(void)
{
    if (m_std_init) {
        return;
    }

    std_get_app_name(getpid(), m_app_name);
    
    snprintf(m_std_dev, STD_BUF_LEN, "%s/%s", STD_RUN_DIR, m_app_name);
    snprintf(m_std_etc, STD_BUF_LEN, "%s/%s", STD_ETC_DIR, m_app_name);
    snprintf(m_std_cli, STD_BUF_LEN, "%s/%s", STD_ETC_CLI, m_app_name);
    snprintf(m_std_ps, STD_BUF_LEN, "%s> ", m_app_name);
    
    std_io2fd(m_std_dev);
    m_std_init = 1;
    
    return;
}

void *std_2io_task(void *args)
{
    while(1) {
        if (!isatty(0) || (m_std_fd < 0)) {
            std_io2fd(m_std_dev);   /* ���¶����� */
        }
		
		sleep(1);
    }
    
    return NULL;
}

/* ��ʼ������ */
void std_so_init(void)
{
    int rv;
    pthread_t tid = 0;
    
    std_init_config();

    rv = pthread_create(&tid, NULL, std_2io_task, NULL);
	if (rv) {
        printf("rv %d \r\n", rv);
		return;
    }
		
    return;
}

