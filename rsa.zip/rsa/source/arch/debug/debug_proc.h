#ifndef __DEBUG_PROC_H__
#define __DEBUG_PROC_H__


#define CONFIG_SSA_DEBUG_THREAD_EN


int debug_proc_main(void *data);

//#ifdef CONFIG_SSA_DEBUG_THREAD_EN
int debug_proc_run_task(void);
//#endif


#endif