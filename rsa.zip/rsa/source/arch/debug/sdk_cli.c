#include "sdk_cli.h"
//#include "at_cli.h"
//#include "sd_cli.h"

//extern void sh_process(int u, const char *pfx, int eof_exit);
#if 0
static cmd_result_t cmd_at_proc(int unit, args_t *a)
{
	at_cli_run("at-cli> ");

    return CMD_OK;
}

static cmd_result_t cmd_sd_proc(int unit, args_t *a)
{
	sd_cli_run("ngsa-cli> ");

    return CMD_OK;
}

#endif
int sdk_cli_init(void)
{
#if 0
	static char cmd_sd_help[] = "sdebug";
	static char cmd_at_help[] = "AnyTest";
	static char cmd_sd_usage[] = "Enter SDebug mode";
	static char cmd_at_usage[] = "Enter AnyTest mode";
	
	cmd_t at_cmd  = {"AT", cmd_at_proc, cmd_at_help, cmd_at_usage};
	cmd_t sd_cmd  = {"SDebug", cmd_sd_proc, cmd_sd_help, cmd_sd_usage};
	
	//sd_cli_init();
	//at_cli_init();
	
	//cmdlist_add(&at_cmd);
	//cmdlist_add(&sd_cmd);

    #if defined(CONFIG_SDK_MDEBUG_EN)
    {
        extern int mdebug_init(void);

        //mdebug_init();
    }
    #endif
#endif
    return 0;
}


int sdk_cli_run(char *prompt)
{
	//sh_process(-1, prompt, 0);     
	return 0;
}