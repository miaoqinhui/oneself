/*
 * Copyright(C) 2016 Ruijie Network. All rights reserved.
 */
/*
 * unit_thread.c
 * Original Author:  xiamengbing@ruijie.com.cn, 2018-05-26
 *
 * for ssa multi-unit-thread-management
 * support for vsd feature
 * modified by shenhanbin
 *
 * History
 */

#include <arch/unit_thread.h>
#include <arch/config_end_comm.h>
#include <psh/psh.h>
#include "ha/arch_ha.h"

/* 私有全局变量在这里定义 */
int debug_print_err = 1;

static int max_switch_unit;   /* 本卡最大交换unit个数 */

static vsd_unit_thread_info_t *g_vsd_unit_thread_info = NULL; /* 全局线程管理数据结构按照max_switch_unit初始化 */

/* 用于业务访问NDM模块的线程锁 */
pthread_mutex_t ndm_mutex;

/* 专业打印野时间戳 */
uint32_t get_timer_now(void)
{
    struct timespec tv;
    uint32_t recv_time;

    clock_gettime(CLOCK_MONOTONIC, &tv);
    recv_time = tv.tv_sec * 1000 * 1000 + tv.tv_nsec / 1000;

    return recv_time;
}

unsigned int get_max_switch_unit(void) {
    return max_switch_unit;
}

vsd_unit_thread_info_t * get_g_vsd_unit_thread_info(int unit)
{
    if (g_vsd_unit_thread_info == NULL) {
        vsd_unit_err("g_vsd_unit_thread_info is NULL");
        return NULL;
    }
    if (unit >= max_switch_unit) {
        vsd_unit_err("unit[%d] is invalid!\n", unit);
        return NULL;
    }
    
    return &g_vsd_unit_thread_info[unit];
}

int dump_g_vsd_unit_thread_info(int unit)
{
    if ((g_vsd_unit_thread_info == NULL) || (unit >= max_switch_unit)) {
        vsd_unit_err("dump_g_vsd_unit_thread_info fail, unit:%d", unit);
        return -1;
    }

    printf("vsd_unit_thread_info for unit[%d]:\n", g_vsd_unit_thread_info[unit].unit);
    printf("vsd_unit_thread_info cur vsd [%d]:\n", g_vsd_unit_thread_info[unit].cur_vsd);
    printf("vsd_unit_thread_info old vsd [%d]:\n", g_vsd_unit_thread_info[unit].old_vsd);
    printf("vsd_unit_thread_info enable  [%d]:\n", g_vsd_unit_thread_info[unit].enable);
    printf("vsd_unit_thread_info global_ready [%d]:\n", g_vsd_unit_thread_info[unit].global_ready);
    printf("vsd_unit_thread_info running [%d]:\n", g_vsd_unit_thread_info[unit].thread_is_running);
    printf("vsd_unit_thread_info local_card_ok [%d]:\n", g_vsd_unit_thread_info[unit].local_card_ok);
    printf("vsd_unit_thread_info local_chassis_ok [%d]:\n", g_vsd_unit_thread_info[unit].local_chassis_ok);
    printf("vsd_unit_thread_info global_ok [%d]:\n", g_vsd_unit_thread_info[unit].global_all_ok);
    printf("vsd_unit_thread_info cap_ctrl_info [%p]:\n", g_vsd_unit_thread_info[unit].cap_ctrl_info);

    return 0;
}

void vsd_set_debug_print_err(int val)
{
    debug_print_err = val;
}

/* 测试接口 */
int test_module_start_local_chassis(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int ret, unit;
    SFrame__UnitIndex unit_index = S_FRAME__UNIT_INDEX__INIT;
    SFrame__UnitInitOk unit_init_ok = S_FRAME__UNIT_INIT_OK__INIT;
    struct timeval timer1 = {100, 0};

    unit = get_unit_from_unit_thread_info(unit_t_info);
    printf("test_module business local_chassis start unit:%d\n", unit);

    /* expire the key the thread set */
    unit_init_ok.index = &unit_index;
    unit_init_ok.index->unit = unit;
    ret = rg_mom_pexpire_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)(&unit_init_ok), 0, timer1);
    if (ret) {
        /* this set action is intended only to claim a notify for factory.
         * when thread runs here, we can make sure that all the bussiness module init OK.
         * no need to ret fail.
         */
        printf("unit init complete expire fail!\n");
    }

    return 0;
}

int test_module_end_local_chassis(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int ret, unit;
    SFrame__UnitIndex unit_index = S_FRAME__UNIT_INDEX__INIT;
    SFrame__UnitInitOk unit_init_ok = S_FRAME__UNIT_INIT_OK__INIT;

    unit = get_unit_from_unit_thread_info(unit_t_info);
    printf("test_module business local_chassis end unit:%d\n", unit);

    /* set key in host to notify fac that this unit init OK */
    unit_init_ok.index = &unit_index;
    unit_init_ok.index->unit = unit;
    unit_init_ok.value = 1;

    ret = rg_mom_set_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)(&unit_init_ok));
    if (ret) {
        /* this set action is intended only to claim a notify for factory.
         * when thread runs here, we can make sure that all the bussiness module init OK.
         * no need to ret fail.
         */
        printf("unit init complete set fail!\n");
    }

    return 0;
}

int test_module_start_local_card(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int unit;

    unit = get_unit_from_unit_thread_info(unit_t_info);
    printf("local card start init[%d]!\n", unit);

    return 0;
}

int test_module_end_local_card(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int unit;

    unit = get_unit_from_unit_thread_info(unit_t_info);
    printf("local card init over[%d]!\n", unit);

    return 0;
}

int test_module_start_global(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int unit;

    unit = get_unit_from_unit_thread_info(unit_t_info);
    printf("global start init[%d]!\n", unit);

    return 0;
}

int test_module_end_global(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    int unit;

    unit = get_unit_from_unit_thread_info(unit_t_info);
    printf("global init over[%d]!\n", unit);

    return 0;
}

extern int ptd_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int32_t ssa_ap_init_phase_0(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int32_t ssa_ap_init_phase_2(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sda_ebridge_init_phase0(rg_global_t *mom_handle, vsd_unit_thread_info_t *thread_info);
//extern int sda_ebridge_init_phase2(rg_global_t *mom_handle, vsd_unit_thread_info_t *thread_info);
//extern int sda_stp_init(rg_global_t *mom_handle, vsd_unit_thread_info_t *thread_info);
//extern int sda_virvlan_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sda_qinq_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int ssa_fp_module_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sw_route_ssa_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int cluster_dpm_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int mac_temp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int intf_frm_serv_ptchg_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
extern int intf_vsl_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
//extern int intf_vsl_cache_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
//extern int sw_overlay_ssa_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sw_me_ssa_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int ssa_span_init(rg_global_t * global, vsd_unit_thread_info_t * unit_t_info);
//extern int ssa_sflow_init(rg_global_t * global, vsd_unit_thread_info_t * unit_t_info);
extern int intf_fwdctrl_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
extern int fac_mem_test_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int ssa_mmu_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int32_t sda_pktd_at_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
extern int intf_split_pre_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
extern int intf_split_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
//extern int sda_cpp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sw_route_ssa_phase0_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sw_overlay_ssa_phase0_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int cust_qos_gport_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int ssa_qos_module_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sda_ixn_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int32_t sda_mlag_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);

/* 业务模块自行填入自己的初始化接口 */
buss_module_init_fn *buss_module_init_sequence_local_card_ok[] = {
    test_module_start_local_card,
    //ssa_ap_init_phase_0,    /* dpm有依赖ap */
    fac_mem_test_init,
    sda_ha_unit_init,
    //cust_qos_gport_init,
    //intf_frm_serv_ptchg_init,
    //intf_split_pre_init,
    //sda_ebridge_init_phase0,
    //sda_stp_init,
    //sw_overlay_ssa_phase0_init,
    //cluster_dpm_init,
    //sw_route_ssa_phase0_init,
    //intf_vsl_cache_init,
    /* 业务模块在这个之间添加相关的业务模块初始化接口 ptd初始化*/
    config_end_comm_init,
    ptd_init,
    //sda_ixn_init,
    mac_temp_init,
    //intf_vsl_init,
    //intf_split_init,
    //sda_pktd_at_init,
    test_module_end_local_card,
    NULL,
};

/* 业务模块自行填入自己的初始化接口 */
buss_module_init_fn *buss_module_init_sequence_local_chassis_ok[] = {
    /* 业务模块在这个之间添加相关的业务模块初始化接口 ptd初始化 */
    test_module_start_local_chassis,
    //ssa_qos_module_init,
    //sda_virvlan_init,
    //sda_qinq_init,
    //intf_fwdctrl_init,
    //ssa_sflow_init,
    //sda_cpp_init,
    test_module_end_local_chassis,
    //sda_mlag_init,
    NULL,
};

/* 业务模块自行填入自己的初始化接口 */
buss_module_init_fn *buss_module_init_sequence_global_ok[] = {
    test_module_start_global,
    //ssa_ap_init_phase_2,    /* 有依赖全局dm数据 */
    //ssa_span_init,
    //sda_ebridge_init_phase2,
    //ssa_mac_init,
    //sw_route_ssa_init,
    //ssa_fp_module_init,
    //sw_overlay_ssa_init,
    //sw_me_ssa_init,
    test_module_end_global,
    NULL,
};


/* 业务模块自行填入自己需要建联的逻辑数据库 */
int connect_logic_db[] = {
    RG_MOM_ASIC_DB,
    RG_MOM_LOCAL_DB,
    RG_MOM_ASIC_FWD_DB,
    RG_MOM_IBC_DB,
};



/* 获取本卡交换芯片数量, 这个应该从DM获取, 主线程要和数据库建联, 现在现在快速支持s6120, 先打桩返回1和芯片 */
int dm_get_board_switch_unit(void)
{
    return 1;
}

int unit_vsd_thread_get_switch_chip_num(int *switch_chip_num)
{
    int card_type;
    int ret;

    ret = ndm_get_my_card_type(&card_type);
    if (ret != 0) {
        printf("ndm_get_my_card_type fail[%d]!\n", ret);
        return -1;
    }

    *switch_chip_num = ndm_get_card_switch_chip_num(card_type);
    if (*switch_chip_num <= 0) {
        printf("ndm_get_card_switch_chip_num fail, card_type=%d switch_chip_num=%d!\n", card_type, 
            *switch_chip_num);
        return -1;
    }

    printf("unit_vsd_thread_get_switch_chip_num succ, card_type=%d switch_chip_num=%d\n", card_type, 
        *switch_chip_num);

    return 0;
}

/* 线程创建接口 */
static int unit_thread_create(unit_vsd_thread_func t_func, void *unit_thread_info)
{
    pthread_t pthread;
    pthread_attr_t pthread_attr;
    int ret;

    if (pthread_attr_init(&pthread_attr) != 0) {
        vsd_unit_err("pthread_attr_init failed.\r\n");
        return -1;
    }

    ret = 0;
    if (pthread_attr_setdetachstate(&pthread_attr, PTHREAD_CREATE_DETACHED) != 0) {
        vsd_unit_err("pthread_attr_setdetachstate failed.\r\n");
        ret = -2;
        goto exit;
    }

    if (pthread_create(&pthread, &pthread_attr, (void *)t_func, (void *)unit_thread_info) != 0) {
        vsd_unit_err("pthread_create failed.\r\n");
        ret = -3;
        goto exit;
    }
exit:
    pthread_attr_destroy(&pthread_attr);

    return ret;
}

/* 主线程调用写key通知unit线程可以进行本地初始化的接口 */
int unit_vsd_thread_init_trigger(rg_global_t * global, int type)
{
    size_t set_array[1] = {0};
    int count;
    int ret;

    SFrame__SsaInitPhase ssa_init_phase = S_FRAME__SSA_INIT_PHASE__INIT;

    if (global == NULL) {
        printf("unit_vsd_thread_init_trigger invalid arg!\n");
        return -1;
    }

    printf("unit_vsd_thread_init_trigger trigger type[%d] [%u]\n", type, get_timer_now());
    if (type == LOCAL_CARD_OK) {
        ssa_init_phase.local_card_ok = 1;
        set_array[0] = 5;
    } else if (type == LOCAL_CHASSIS_OK) {
        ssa_init_phase.local_chassis_ok = 1;
        set_array[0] = 6;
    } else if (type == GLOBAL_ALL_OK) {
        ssa_init_phase.global_all_ok = 1;
        set_array[0] = 7;
    } else {
        printf("unit_vsd_thread_init_trigger invalid trigger type[%d]!\n", type);
        return -1;
    }

    count = 1;
    ret = rg_mom_hmset_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&ssa_init_phase, set_array, count);
    if (ret != 0) {
        printf("unit_vsd_thread_init_trigger hmset fail[%d]!\n", ret);
        return -1;
    }

    printf("unit_vsd_thread_init_trigger trigger type[%d] [%u] set OK\n", type, get_timer_now());
    return ret;
}

void unit_vsd_thread_glb_buss_init(vsd_unit_thread_info_t *unit_t_info)
{
    int i;
    buss_module_init_fn **buss_module_init_ptr;

    /* init global business */
    printf("unit_vsd_thread_glb_phase_init global_all_ok start[%d] [%d][%d][%d] [%u]!\n",
           unit_t_info->unit, unit_t_info->local_card_ok, unit_t_info->local_chassis_ok, unit_t_info->global_all_ok, get_timer_now());
    i = 0;
    /* 挨个业务模块接口初始化接口调用 */
    for (buss_module_init_ptr = buss_module_init_sequence_global_ok; *buss_module_init_ptr; ++buss_module_init_ptr) {
        if ((*buss_module_init_ptr)(unit_t_info->global, unit_t_info) != 0) {
            vsd_unit_err("buss_module_init_sequence_global_ok fail in [%d]!\n", i);
            continue;  /* 一个模块挂了 其他的还是要跑 */
        }
        printf("buss_module_init_sequence_global_ok[%d] [%u]!\n", i, get_timer_now());
        i++;
    }

    return;
}

int unit_vsd_thread_notify_module_ready(vsd_unit_thread_info_t *unit_info, 
    ready_module_type_t ready_module)
{
    if (!unit_info) {
        printf("unit_info is invalid");
        return -1;
    }

    if (ready_module < READY_MODULE_NDM_GLB_OK || ready_module >= MAX_READY_MODULES) {
        printf("invalid ready module type %d", ready_module);
        return -1;
    }

    unit_info->global_ready |= GLB_READY_MODULE_OFFSET << ready_module;
    printf("module type %d is ready, global_ready %d\n", ready_module, unit_info->global_ready);
    if (unit_info->global_ready == GLB_READY_MODULE_BMP) {
        unit_vsd_thread_glb_buss_init(unit_info);
    }

    return 0;
}

/* 3个阶段的key关注回调 */
static int unit_vsd_thread_init_phase_go(SFrame__SsaInitPhase *ssa_init_phase, vsd_unit_thread_info_t *unit_t_info)
{
    int i, ret;
    buss_module_init_fn **buss_module_init_ptr;

    printf("unit_vsd_thread_init_phase_go start[%d] [%d][%d][%d] [%u]!\n",
           unit_t_info->unit, unit_t_info->local_card_ok, unit_t_info->local_chassis_ok, unit_t_info->global_all_ok, get_timer_now());
    /* 这里来判断hset里面3个域的情况分情况来调用初始化接口 */
    /* 这里是判断本卡就绪 */
    if ((ssa_init_phase->local_card_ok == 1)
            && (unit_t_info->local_card_ok == 0)) {
        /* 调用本卡就绪可以跑的初始化接口 */
        printf("unit_vsd_thread_init_phase_go local_card_ok start[%d] [%d][%d][%d] [%u]!\n",
               unit_t_info->unit, unit_t_info->local_card_ok, unit_t_info->local_chassis_ok, unit_t_info->global_all_ok, get_timer_now());
        i = 0;
        /* 挨个业务模块接口初始化接口调用 */
        for (buss_module_init_ptr = buss_module_init_sequence_local_card_ok; *buss_module_init_ptr; ++buss_module_init_ptr) {
            if ((*buss_module_init_ptr)(unit_t_info->global, unit_t_info) != 0) {
                vsd_unit_err("buss_module_init_sequence_local_card_ok fail in [%d]!\n", i);
                continue;  /* 一个模块挂了 其他的还是要跑 */
            }
            printf("buss_module_init_sequence_local_card_ok[%d] [%u]!\n", i, get_timer_now());
            i++;
        }
        /* 完成后标识unit_t_info->local_card_ok为1 */
        unit_t_info->local_card_ok = 1;
    }

    /* 这里判断本机箱就绪 */
    if ((ssa_init_phase->local_chassis_ok == 1)
            && (unit_t_info->local_chassis_ok == 0)) {
        /* 调用本卡就绪可以跑的初始化接口 */
        printf("unit_vsd_thread_init_phase_go local_chassis_ok start[%d] [%d][%d][%d] [%u]!\n",
               unit_t_info->unit, unit_t_info->local_card_ok, unit_t_info->local_chassis_ok, unit_t_info->global_all_ok, get_timer_now());
        i = 0;
        /* 挨个业务模块接口初始化接口调用 */
        for (buss_module_init_ptr = buss_module_init_sequence_local_chassis_ok; *buss_module_init_ptr; ++buss_module_init_ptr) {
            if ((*buss_module_init_ptr)(unit_t_info->global, unit_t_info) != 0) {
                vsd_unit_err("buss_module_init_sequence_local_chassis_ok fail in [%d]!\n", i);
                continue;  /* 一个模块挂了 其他的还是要跑 */
            }
            printf("buss_module_init_sequence_local_chassis_ok[%d] [%u]!\n", i, get_timer_now());
            i++;
        }
        /* 完成后标识unit_t_info->local_chassis_ok为1 */
        unit_t_info->local_chassis_ok = 1;
    }

    /* 这里判断全局就绪 */
    if ((ssa_init_phase->global_all_ok == 1) && (unit_t_info->global_all_ok == 0)) {
        unit_t_info->global_all_ok = 1;
        ret = unit_vsd_thread_notify_module_ready(unit_t_info, READY_MODULE_NDM_GLB_OK);
        printf("notify ndm global ready end ret[%d] [%u]!\n", ret, get_timer_now());
    }

    printf("unit_vsd_thread_init_phase_go over[%d] [%d][%d][%d]!\n",
           unit_t_info->unit, unit_t_info->local_card_ok, unit_t_info->local_chassis_ok, unit_t_info->global_all_ok);
    return 0;
}

/* DS接口 */
int unit_vsd_thread_init_phase_ds(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    SFrame__SsaInitPhase *ssa_init_phase;

    printf("unit_vsd_thread_init_phase_ds start!\n");
    rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
    if (!res || res->error_code != RG_MOM_OK) {
        printf("unit_vsd_thread_init_phase_ds hash error happen\n");
        return 0;
    }
    ssa_init_phase = (SFrame__SsaInitPhase *)res->value;

    unit_vsd_thread_init_phase_go(ssa_init_phase, (vsd_unit_thread_info_t *)privdata);
    printf("unit_vsd_thread_init_phase_ds over!\n");
    return 0;
}

int unit_vsd_thread_init_phase_handle(rg_global_t * global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    int ret;

    SFrame__SsaInitPhase *ssa_init_phase;
    SFrame__SsaInitPhase ssa_init_phase_scan = S_FRAME__SSA_INIT_PHASE__INIT;

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        printf("unit_vsd_thread_init_phase_handle RG_MOM_SUBSCRIBE[%u]!\n", get_timer_now());

        ret = rg_mom_scan_sync(global, RG_MOM_ASIC_DB, (const rg_obj *)&ssa_init_phase_scan, 0,
                               unit_vsd_thread_init_phase_ds, privdata);
        printf("unit_vsd_thread_init_phase_handle RG_MOM_SUBSCRIBE[%d]!\n", ret);
        return 0;
    }

    if (msg->cmd == RG_MOM_HSET) {
        printf("unit_vsd_thread_init_phase_handle RG_MOM_HSET[%u]!\n", get_timer_now());
        rg_mom_hash_res_t *res = (rg_mom_hash_res_t*)msg->value;
        if (!res || res->error_code != RG_MOM_OK) {
            printf("unit_vsd_thread_init_phase_handle hash error happen\n");
            return 0;
        }
        ssa_init_phase = (SFrame__SsaInitPhase *)res->value;
    }  else {
        printf("unit_vsd_thread_init_phase_handle error cmd = %d\n", msg->cmd);
        return 0;
    }

    (void)unit_vsd_thread_init_phase_go(ssa_init_phase, (vsd_unit_thread_info_t *)privdata);

    return 0;

}

rg_mom_response_cb unit_vsd_thread_cb_arr[SSA_INIT_PHASE_NUM] = {
    unit_vsd_thread_init_phase_handle,
    unit_vsd_thread_init_phase_handle,
    unit_vsd_thread_init_phase_handle,
};

int ssa_disconnect_cb(rg_global_t *glb, int db, void *arg)
{
    vsd_unit("db %d disconnect\n", db);

    return 0;
}

int ssa_reconnect_cb(rg_global_t *glb, int db, rg_mom_reconnect_type_t type, void *arg)
{
    vsd_unit("db %d reconnect, type %d", db, type);

    if (type == RMC_CONNECT_ERROR) {
        exit(RG_MOM_RECONNECT_EXIT_CODE);
    } else {
        vsd_unit("do not care db %d reconnect, type %d\n", db, type);
        return 0;
    }

    return 0;
}

/* 具体业务线程实现 */
static void unit_vsd_thread_func_handler(void *thread_arg)
{
    vsd_unit_thread_info_t *vsd_unit_thread_info;
    int max_db_num;
    int i;
    char name[UNIT_THREAD_NAME_LEN];
    int ret;

    /* 用于unit线程的阶段初始化通告obj */
    SFrame__SsaInitPhase ssa_init_phase = S_FRAME__SSA_INIT_PHASE__INIT;
    int count;

    /* 先把入参获取出来 */
    vsd_unit_thread_info = (vsd_unit_thread_info_t *)thread_arg;

    vsd_unit("unit[%d] thread handler start!\n", vsd_unit_thread_info->unit);
    vsd_unit_thread_info->thread_is_running = 1;

    /* dump下线程管理变量 */
    ret = dump_g_vsd_unit_thread_info(vsd_unit_thread_info->unit);
    if (ret < 0) {
        goto thread_err;
    }

    memset(name, 0, sizeof(name));
    snprintf(name, UNIT_THREAD_NAME_LEN, "unit%d_thread", vsd_unit_thread_info->unit);
    prctl(PR_SET_NAME, name);
    vsd_unit("unit[%d] thread name[%s]!\n", vsd_unit_thread_info->unit, name);

    /* 初始化global */
    vsd_unit_thread_info->global = rg_global_init(name, vsd_unit_thread_info->global);
    if (vsd_unit_thread_info->global == NULL) {
        vsd_unit_err("[%s]rg_global_init fail!\n", name);
        goto thread_err;
    }
    vsd_unit("unit[%d] thread rg_global @%p!\n", vsd_unit_thread_info->unit, vsd_unit_thread_info->global);
#if 0
    /* 和数据库建联 */
    max_db_num = SSA_FRM_ARRAY_SIZE(connect_logic_db);
    ret = 0;
    for (i = 0; i < max_db_num; i++) {
        ret = rg_mom_client_connect_sync(vsd_unit_thread_info->global, connect_logic_db[i]);
        if (ret != 0) {
            vsd_unit_err("rg_mom_client_connect_sync fail[%d]!\n", connect_logic_db[i]);
            goto thread_err;
        }
        printf("connect db %d succ[%u]\n", connect_logic_db[i], get_timer_now());

        /* close ssa_unit_thread congest limit switch */ 
        (void)rg_mom_congest_limit_switch(vsd_unit_thread_info->global, connect_logic_db[i], 
            RG_MOM_CONGEST_CLOSE);
        vsd_unit("unit[%d] thread [glb:%p] [db:%d] close congest limit\n", 
            vsd_unit_thread_info->unit, vsd_unit_thread_info->global, connect_logic_db[i]);

        (void)rg_mom_client_set_disconnect_cb(vsd_unit_thread_info->global, connect_logic_db[i], 
            ssa_disconnect_cb, NULL);
        vsd_unit("REG db %d disconnect_cb [%u]\n", connect_logic_db[i], get_timer_now());
        
        (void)rg_mom_client_set_reconnect_cb(vsd_unit_thread_info->global, connect_logic_db[i], 
            ssa_reconnect_cb, NULL);
        vsd_unit("REG db %d reconnect_cb [%u]\n", connect_logic_db[i], get_timer_now()); 
    }

    vsd_unit_thread_info->cap_ctrl_info = (void *)librg_cap_ctrl_info_init(vsd_unit_thread_info->cap_ctrl_info);
    if (vsd_unit_thread_info->cap_ctrl_info == NULL) {
        printf("librg_cap_ctrl_info_init fail\n");
        goto thread_err;
    }
    ret = librg_cap_init_thread(vsd_unit_thread_info->global, name, vsd_unit_thread_info->cap_ctrl_info);
    if (ret != 0) {
        printf("librg_cap_init_thread fail, ret %d\n", ret);
        librg_cap_ctrl_info_free(vsd_unit_thread_info->cap_ctrl_info);
        goto thread_err;
    }

    /* 这里要订阅主线程写入的接续KEY */
    size_t ssa_phase_array[3] = {5, 6, 7};
    vsd_unit_thread_info_t *ssa_phase_arg_array[3] = {vsd_unit_thread_info, vsd_unit_thread_info, vsd_unit_thread_info};
    count = 3;
    /* 订阅 生测的key 广播测试 */
    ret = rg_mom_subscribe_field(vsd_unit_thread_info->global, RG_MOM_ASIC_DB,
                                 (const rg_obj *)&ssa_init_phase, 0, ssa_phase_array, unit_vsd_thread_cb_arr, (void **)ssa_phase_arg_array, count);
    if (ret < 0) {
        printf("unit_thread[%d] sub ssa phase fail\n", vsd_unit_thread_info->unit);
        goto thread_err;
    }
#endif
// 强行调用ptd init，单板调试
	ptd_init(vsd_unit_thread_info->global, vsd_unit_thread_info);

    /* 激活伪线程 */
    /* 事件驱动 */
    vsd_unit("unit[%d] thread name[%s] to rg_global_run!\n", vsd_unit_thread_info->unit, name);
    rg_global_run(vsd_unit_thread_info->global);

    /* 不该到这里 */
    rg_global_finish(vsd_unit_thread_info->global);

    librg_cap_ctrl_info_free(vsd_unit_thread_info->cap_ctrl_info);

thread_err:
    /* vsd_unit_thread_info作为主线程传入的管理变量,目前考虑不释放,用来管理和记录unit线程的情况,即使线程失败了也不释放
     * 生命周期和整个ssa进程一致
     */
    vsd_unit_thread_info->thread_is_running = 0;
    printf("unit[%d] thread fail!\n", vsd_unit_thread_info->unit);
}

static int unit_vsd_thread_data_init(int max_switch_unit)
{
    int i;

    /* 初始化访问DM的线程锁 */
    pthread_mutex_init(&ndm_mutex, NULL);

    for (i = 0; i < max_switch_unit; i++) {
        g_vsd_unit_thread_info[i].global = NULL;
        g_vsd_unit_thread_info[i].unit = i;
        g_vsd_unit_thread_info[i].cur_vsd = 0;
        g_vsd_unit_thread_info[i].old_vsd = 0;
        g_vsd_unit_thread_info[i].enable = 0;
        g_vsd_unit_thread_info[i].global_ready = 0;
        g_vsd_unit_thread_info[i].thread_is_running = 0;
        g_vsd_unit_thread_info[i].global_all_ok = 0;
        g_vsd_unit_thread_info[i].local_card_ok = 0;
        g_vsd_unit_thread_info[i].local_chassis_ok = 0;
        g_vsd_unit_thread_info[i].cap_ctrl_info = NULL;
    }

    return 0;
}

/* 线程初始化接口 */
int unit_vsd_thread_init(void)
{
    int i;
    int ret;
    char message[PSH_EVT_CAUSE_LEN_MAX];

    /* 先获取到本板所有的交换芯片数量switch_unit */
    //ret = unit_vsd_thread_get_switch_chip_num(&max_switch_unit);
	max_switch_unit = 1;
    //if (ret != 0) {
    //    vsd_unit_err("max_switch_unit:%d get error!\n", max_switch_unit);
    //    return -1;
    //}
    printf("unit_vsd_thread_init max_switch_unit:%d!\n", max_switch_unit);

    /* 初始化管理线程的变量 */
    g_vsd_unit_thread_info = (vsd_unit_thread_info_t *)malloc(max_switch_unit * sizeof(vsd_unit_thread_info_t));
    if (g_vsd_unit_thread_info == NULL) {
        vsd_unit_err("g_vsd_unit_thread_info alloc fail!\n");
        return -1;  /* 这个错误返回值先这样了,看下后续ssa有没统一的 */
    }

    printf("g_vsd_unit_thread_info alloc OK!\n");
    ret = 0;
    ret = unit_vsd_thread_data_init(max_switch_unit);
    if (ret != 0) {
        vsd_unit_err("unit_vsd_thread_data_init fail\n");
        free(g_vsd_unit_thread_info);
        return -1;
    }

    printf("unit_vsd_thread_data_init OK!\n");

    /* 根据unit数量起线程 */
    for (i = 0; i < max_switch_unit; i++) {
        ret = unit_thread_create(unit_vsd_thread_func_handler, (void *)(&g_vsd_unit_thread_info[i]));
        if (ret != 0) {
            printf("unit[%d] create fail!\n", i);

            snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "unit_thread_create occurs in unit [%d], the device will reboot.", i);
            protect_selfhealing_do_action(PSH_RELOAD_SELF_ACT, 0, "SSA-HA", message);
            protect_selfhealing_flush_buf_in_emergency();

            continue;
        }
    }

    printf("unit_vsd_thread_init OK[%u]!\n", get_timer_now());

    return 0;
}

/* for test only
int main (void)
{
    int ret;

    printf("main start!\n");
    ret = 0;
    ret = unit_vsd_thread_init();
    if (ret != 0) {
        vsd_unit_err("unit_vsd_thread_init fail!\n");
        return ret;
    }

    while(1);
    return 0;
}
*/

