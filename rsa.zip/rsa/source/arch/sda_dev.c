/*
 * Copyright(C) 2019 Ruijie Network. All rights reserved.
 */
/*
 * sda_dev.c
 * Original Author:  xieguoxiong@ruijie.com.cn, 2019-02-16
 *
 * for sda set card led
 *
 * History
 */

#include <bsp/dfd/ssa_dfd_pub.h>
#include <arch/sda_dev.h>
#include <bsp/dfd/ssa_dfd_intf.h>

int sda_dev_drv_lib_init(void)
{
    return dev_drv_init();
}

static int32_t sda_scan_SFrame__UnitEnable(rg_global_t *global, rg_mom_pubsub_msg_t *msg, rg_mom_response_cb scan_cb)
{
    int32_t ret;
    SFrame__KeyIndex key_index = S_FRAME__KEY_INDEX__INIT;
    SFrame__UnitEnable unit_enable_key_scan = S_FRAME__UNIT_ENABLE__INIT;
    unit_enable_key_scan.index = &key_index;

    printf("sda_scan_SFrame__UnitEnable, cmd = RG_MOM_SUBSCRIBE[%u]!\n", get_timer_now());

    ret = 0;
    ret = rg_mom_scan(global, msg->db, (const rg_obj *)&unit_enable_key_scan, 0, scan_cb, "scan");
    if (ret < 0) {
        printf("sda scan SFrame__UnitEnable fail, ret:%d\n", ret);
    }

    return ret;
}

static int sda_sub_SFrame__UnitEnable_cb(rg_global_t *global, rg_mom_pubsub_msg_t *msg, void *privdata)
{
    int ret;

    printf("sda_sub_SFrame__UnitEnable_cb!\n");
    if (msg == NULL) {
        printf("sda_sub_SFrame__UnitEnable_cb, pmsg is null!\n");
        return 0;
    }

    ret = 0;
    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ret = sda_scan_SFrame__UnitEnable(global, msg, sda_sub_SFrame__UnitEnable_cb);
        if (ret < 0) {
            printf("sda_scan_SFrame__UnitEnable fail, ret:%d\n", ret);
        }
    } else if (msg->cmd == RG_MOM_SET) {
        ret = drv_set_led(DFD_LED_TP_LC_STATUS, DFD_LED_ST_GREEN, 0);
        printf("drv_set_led ret:%d\n", ret);
    } else {
        printf("sda_sub_SFrame__UnitEnable_cb error cmd = %d\n", msg->cmd);
        return 0;
    }

    return ret;
}

/* 当前只支持单线程 */
int sda_sub_SFrame__UnitEnable(void)
{
    int ret;

    /* obj of system-enable */
    SFrame__KeyIndex key_index = S_FRAME__KEY_INDEX__INIT;
    SFrame__UnitEnable unit_enable_key = S_FRAME__UNIT_ENABLE__INIT;
    unit_enable_key.index = &key_index;

    ret = 0;
    /* 订阅 system-enable相关的key */
    ret = rg_mom_subscribe(g_sda_main_global, RG_MOM_ASIC_DB, (const rg_obj *)&unit_enable_key, 0, sda_sub_SFrame__UnitEnable_cb, NULL);
    if (ret) {
        printf("sda_sub_SFrame__UnitEnable system-enable fail\n");
    }

    return ret;
}


