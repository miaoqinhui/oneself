#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/prctl.h>
#include <bsp/dfd/ssa_dfd_intf.h>
#include <bsp/dfd/ssa_dfd_pub.h>
#include <bsp/dfd/ssa_dfd_private.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <libpub/rg_thread/rg_thread.h>

#include <arch/unit_thread.h>

#define SSA_MAC_TEMP_TIMER    (15)

#define SSA_DEV_STATUS_VERBOS(fmt, args...)                           \
do {                                                       \
    if (ssa_dev_status_verbose) {                                \
       printf("<%s(%d)[%s]> \r\n" fmt, __FILE__, __LINE__, __FUNCTION__, ## args); \
    }                                                      \
} while (0)                                              

int ssa_dev_status_verbose = 0;

static int ssa_get_mac_temp(int unit, dfd_mac_temp_attr_t *mac_temp_attr)
{
#if 0
    int avg_cur, max_peak,cur,peak, max_cur;
    int num_temp_out;
    int index;
    bcm_switch_temperature_monitor_t temp_out[20];
    static int scan_times = 0;

    scan_times++;

        if (SOC_IS_ARAD(unit) || SOC_IS_FE1600(unit) || SOC_IS_FIREBOLT2(unit) 
                || SOC_IS_APOLLO(unit) || SOC_IS_CONQUEROR(unit)) {
            SSA_DEV_STATUS_VERBOS("soc is not support.\r\n");
            return -1;
        }

        avg_cur = 0; 
        max_peak = -99;
        max_cur = -99;
 //       BCM_IF_ERROR_RETURN(bcm_switch_temperature_monitor_get(unit,
 //           DFD_MAC_TEMP_NUM_MAX,temp_out,&num_temp_out));
        for (index = 0; index < num_temp_out; index++) {
            cur  = temp_out[index].curr;
            peak = temp_out[index].peak;
            SSA_DEV_STATUS_VERBOS("temperature monitor %d: current=%3d.%d, peak=%3d.%d\n",
                    index, 
                    cur/10,
                    cur >=0? cur%10:(-cur)%10, /* remove minus sign */
                    peak/10,
                    peak >=0? peak%10:(-peak)%10); /*remove minus sign */
            mac_temp_attr->mac_temp[index] = cur/10;
            avg_cur += cur;
            if (max_peak < peak) {
                max_peak = peak;
            }
            if (max_cur < cur) {
                max_cur = cur;
            }
        }
        mac_temp_attr->mac_temp_num = num_temp_out;
        SSA_DEV_STATUS_VERBOS("num_temp_out[%d] = %d\r\n", unit, num_temp_out);
        avg_cur = avg_cur/index;
        SSA_DEV_STATUS_VERBOS("average current temperature is %3d.%d\n",
                  avg_cur/10,avg_cur >= 0? avg_cur%10: (-avg_cur)%10);
        SSA_DEV_STATUS_VERBOS("maximum current temperature is %d.%d\n", 
                         max_cur/10,max_cur >= 0? max_cur%10: (-max_cur)%10);
        SSA_DEV_STATUS_VERBOS("maximum peak temperature is %d.%d\n", 
                         max_peak/10,max_peak >= 0? max_peak%10: (-max_peak)%10);
        mac_temp_attr->mac_temp_avg = avg_cur / 10;
        mac_temp_attr->mac_temp_max = max_peak / 10;

        /* �������ԱȽϸ�Ϊ����ֵ�Ƚϣ���ֹ���µ�ʱ�����׳��ִ����ϱ� */
        /* avg_cur��λΪ0.1��  */
        mac_temp_attr->mac_temp_fail = ((avg_cur + 100) <= (max_cur))?1:0;
        SSA_DEV_STATUS_VERBOS("unit %d avg_cur %d max_cur %d fail_status %d.\n", unit, avg_cur,
            max_cur, mac_temp_attr->mac_temp_fail);

    mac_temp_attr->scan_times = scan_times;
    SSA_DEV_STATUS_VERBOS("scan_times = %d", scan_times);
#else
// NPS to do  pengcheng	
#endif
    return 0;
}

static int ssa_mac_temp_write(char *path, dfd_mac_temp_attr_t *mac_temp_attr)
{
    int fd;
    int rv;

    fd = open(path, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        SSA_DEV_STATUS_VERBOS("DFD_MAC_TEMP_FILE_PATH open fail rv = %d", fd);
        return -ENXIO;
    }
    
    rv = write(fd, mac_temp_attr, sizeof(dfd_mac_temp_attr_t)); 
    if (rv < 0) {
        SSA_DEV_STATUS_VERBOS("DFD_MAC_TEMP_FILE_PATH write fail rv = %d", rv);
        goto exit;
    }

exit:
    close(fd);

    return rv;
}

static void ssa_mac_temp_record(int unit)
{
	int rv;
	char path[32];
	dfd_mac_temp_attr_t mac_temp_attr;
	
	memset(path, 0,sizeof(path));
	sprintf(path, "%s%d", DFD_MAC_TEMP_FILE_PATH, unit);
	
    memset(&mac_temp_attr, 0, sizeof(dfd_mac_temp_attr_t));
    if ((rv = ssa_get_mac_temp(unit, &mac_temp_attr)) == 0) {
        /* ����ȡmac�¶�д�빲���ļ� */
        if ((rv = ssa_mac_temp_write(path, &mac_temp_attr)) < 0) {
            SSA_DEV_STATUS_VERBOS("ssa_mac_temp_write fail. rv = %d\r\n", rv);
        }
    } else {
        SSA_DEV_STATUS_VERBOS("ssa_get_mac_temp fail. rv = %d\r\n", rv);
    }
}

static int ssa_mac_temp_thd(struct rg_thread *thread)
{	
    struct rg_thread *tmp;
	int unit;

    unit = 0; 
	ssa_mac_temp_record(unit);
		
	tmp = rg_thread_add_timer(thread->master, ssa_mac_temp_thd, NULL, SSA_MAC_TEMP_TIMER);
	if (!tmp) {
		SSA_DEV_STATUS_VERBOS("Add mac temp timer failed!\n");
		return -1;
	}
	
	return 0;
}

int mac_temp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{	
    int unit;
   
    unit = get_unit_from_unit_thread_info(unit_t_info);
    
    ssa_mac_temp_record(unit);
	rg_thread_add_timer(global->master, ssa_mac_temp_thd, NULL, SSA_MAC_TEMP_TIMER);
	
	return 0;
}
