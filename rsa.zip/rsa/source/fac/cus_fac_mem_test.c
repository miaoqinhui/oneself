#include <arch/unit_thread.h>
#include <libpub/rg_thread/rg_thread.h>
#include <libpub/rg_mom/rg_mom.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <libpub/rg_protobuf_rt/s/frame/unit_sdk.pb-c.h>

rg_global_t *g_ssa_fac_mem_test_global;

void static set_result(int unit, int rv, char *message)
{
    SFrame__FacMacTableResult result = S_FRAME__FAC_MAC_TABLE_RESULT__INIT;
    SFrame__FacUnitIndex index = S_FRAME__FAC_UNIT_INDEX__INIT;

    index.unit = unit;

    result.index = &index;
    result.rv = rv;
    result.message = message;

    rg_mom_set(g_ssa_fac_mem_test_global, RG_MOM_ASIC_DB, (const rg_obj *)&result, NULL, NULL);
}

int subscribe_cb_sdk_request(rg_global_t *global, rg_mom_pubsub_msg_t* msg, void* privdata)
{
    int unit;

    unit = 0;

  //NPS to be done pengcheng
    return 0;
}

int fac_mem_test_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info)
{
    g_ssa_fac_mem_test_global = global;

    SFrame__FacMacTableRequest request = S_FRAME__FAC_MAC_TABLE_REQUEST__INIT;

    rg_mom_subscribe(g_ssa_fac_mem_test_global, RG_MOM_ASIC_DB, (const rg_obj *)&request, 0, subscribe_cb_sdk_request, NULL);

    printf("fac_mem_test_init ok\n");

    return 0;
}

