
#include <stdio.h>
#include <unistd.h>
#include <arch/sdk_init.h>
#include <arch/unit_thread.h>
#include <arch/config_end_comm.h>
#include <arch/sda_dev.h>
#include <psh/psh.h>
#include <efmp/efmp_buff.h>
#include <efmp/efmp_driver.h>

#include "arch/buss/cm_buss_init.h"
#include "arch/buss/fe_buss_init.h"
#include "arch/debug/debug_proc.h"
#include "arch/ha/arch_ha.h"

typedef enum {
    SDA_E_NONE       =  0,
    SDA_E_MEMORY     = -1,
    SDA_E_PARAM      = -2,
    SDA_E_NOT_FOUND  = -3,
    SDA_E_FAIL       = -4,
    SDA_E_INIT       = -5,
} sda_error_t;

#define SDA_CHK_EXPS_RETURN_VAL(exps, print_func, ret, fmt, args...) do { \
    if (!(exps)) { \
        print_func(fmt, ##args); \
        return (ret); \
    } \
} while(0)

#define SDA_MSG_CHECK_NULL_RET(pmsg, res, print_func) do { \
    if ((pmsg) == NULL) { \
        print_func("pmsg is null!\n"); \
        return SDA_E_PARAM; \
    } \
    if ((pmsg)->value == NULL) { \
        print_func("pmsg->value is null!\n"); \
        return SDA_E_PARAM; \
    } \
    res = (rg_mom_hash_res_t *)(pmsg)->value; \
    if ((res)->value == NULL) { \
        print_func("res->value is null!\n"); \
        return SDA_E_PARAM; \
    } \
} while (0)

extern void std_so_init(void);
//extern int sda_pktd_init(void);
extern int frame_check_ssa_one(void);
extern void ssa_rg_ham_init(void);
extern int ptd_thread_init(void);

/* 主线程使用的全局global */
rg_global_t *g_sda_main_global;

rg_cap_ctrl_info_t *g_sda_main_cap_ctrl_info = NULL; /* just used by sda main thread */

/* 这里用来标识初始化是否做过了, ssa的初始化确保只做一次 */
static int local_card_is_complete = 0;
static int local_lc_is_complete = 0;
static int all_is_complete = 0;
static int g_sda_node_type = P_DEV__DM_NODE_TYPE_E__DM_TYPE_UNKNOWN;

static int g_main_connect_logic_db[] = {
    RG_MOM_ASIC_DB,
    RG_MOM_TUNNER_DB,
    RG_MOM_IBC_DB,
};

extern int ssa_ap_key_module_reg(rg_global_t *mom_handle);
extern int ssa_mac_end_notify_reg(rg_global_t *mom_handle);
extern int sda_vlan_end_notify_reg(rg_global_t *mom_handle);
extern int sda_stp_end_notify_reg(rg_global_t *mom_handle);
extern int sda_vlan_cm_fe_init(rg_global_t *mom_handle, vsd_unit_thread_info_t *thread_info);
extern int sda_stp_cm_fe_init(rg_global_t *mom_handle, vsd_unit_thread_info_t *thread_info);
//extern int cluster_dpm_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int32_t ssa_ap_init_phase_0(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int intf_frm_serv_ptchg_init(rg_global_t *glb, vsd_unit_thread_info_t *unit_t_info);
//extern int sda_dpm_reg_key_modules_init(rg_global_t *global);
extern int ssa_intf_port_end_notify_reg(rg_global_t *mom_handle);
extern int ssa_uc_reg_key_modules_init(rg_global_t *global);
extern int ssa_fp_key_module_reg(rg_global_t *mom_handle);
extern int mac_temp_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
//extern int sda_ixn_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int sw_route_mc_fe_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int ssa_mmu_fe_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int ssa_mmu_cm_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);
extern int fac_mem_test_init(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);

vsd_unit_thread_info_t single_unit_info;

/* 关键模块初始化挂载点,主线程完成初始化 */
key_modules_reg_init_t* key_modules_register_init[] = {
    /* 业务在这添加关键模块注册初始化接口，约束为初始化接口不能有异步操作 */
    //ssa_ap_key_module_reg,
    //ssa_mac_end_notify_reg,
    //sda_vlan_end_notify_reg,
    //sda_stp_end_notify_reg,
    //sda_dpm_reg_key_modules_init,
    //ssa_uc_reg_key_modules_init,
    ssa_intf_port_end_notify_reg,
    //ssa_fp_key_module_reg,
	NULL,
};

/* 关键模块初始化挂载点,主线程完成初始化 */
buss_module_init_fn *cm_buss_module_init_sequence[] = {
    /* 业务在这添加关键模块注册初始化接口，约束为初始化接口不能有异步操作 */
	mac_temp_init,
    ptd_cm_bp_init,
    //sda_ixn_init,
    //sda_vlan_cm_fe_init,
    //sda_stp_cm_fe_init,
	//intf_frm_serv_ptchg_init,
	//ssa_ap_init_phase_0,
	//cluster_dpm_init,
    //sw_route_mc_fe_init,
	//ssa_mmu_cm_init,
    fac_mem_test_init,
    NULL,
};

/* 关键模块初始化挂载点,主线程完成初始化 */
buss_module_init_fn *fe_buss_module_init_sequence[] = {
    /* 业务在这添加关键模块注册初始化接口，约束为初始化接口不能有异步操作 */
	mac_temp_init,
    ptd_fe_bp_init,
    //sda_ixn_init,
    //sda_vlan_cm_fe_init,
    //sda_stp_cm_fe_init,
	//intf_frm_serv_ptchg_init,
	//ssa_ap_init_phase_0,
	//cluster_dpm_init,
    //sw_route_mc_fe_init,
	//ssa_mmu_fe_init,
    fac_mem_test_init,
    NULL,
};

/* 关键模块初始化 */
static void sda_lc_key_modules_init (rg_global_t *global)
{
    int i;

    char message[PSH_EVT_CAUSE_LEN_MAX];

    if (!global) {
        printf("[sda main]: main thread global is null\n");
        return;
    }

    for (i = 0; key_modules_register_init[i]; i++) {
        if ((key_modules_register_init[i](global) != 0)) {
            snprintf(message, PSH_EVT_CAUSE_LEN_MAX, "key module [%d] init fail, the device will reboot.", i);
            protect_selfhealing_do_action(PSH_RELOAD_SELF_ACT, 0, "SSA-HA", message);
            protect_selfhealing_flush_buf_in_emergency();

            printf("[sda main]: key module [%d] init failed\n", i);
            continue;
        }
        printf("[sda main]: key module [%d] init successfully\n", i);
    }
    printf("[sda main]: all key modules init complete\n");
}

static int sda_ndm_complete_notify_to_unit_thread(rg_global_t * global, PDev__DpLibComplete *dp_lib_complete, void *arg)
{
    int ret;

    /* 这里去解析ndm的三个complete, 分别作不同的事 */
    if ((dp_lib_complete->local_card_is_complete == true)
            && (local_card_is_complete == 0)) {
        printf("[sda main]: create ptd_link_thread start[%u]!\n", get_timer_now());
        ret = ptd_thread_init();
        if (ret != 0) {
            printf("[sda main]: ptd_thread_init fail[%d]!\n", ret);
            return SDA_E_INIT;
        }
        /* 本卡就位 */
        printf("[sda main]: local_card_is_complete[%u]!\n", get_timer_now());
#if 0
        /* 本卡就绪后进行线程初始化,因为里面需要关注本卡的unit数量 */
        ret = unit_vsd_thread_init();
        if (ret != 0) {
            printf("[sda main]: unit_vsd_thread_init fail[%d]!\n", ret);
            /* 业务线程都没起来大家都不要玩了直接退出 */
            return SDA_E_INIT;
        }
        /* 写key通知unit线程 */
        (void)unit_vsd_thread_init_trigger(global, LOCAL_CARD_OK);
#endif
	    local_card_is_complete = 1;

    }

    if ((dp_lib_complete->local_lc_is_complete == true) 
            && (local_lc_is_complete == 0)) {
        /* 本卡就位 */
        printf("[sda main]: local_lc_is_complete[%u]!\n", get_timer_now());

        local_lc_is_complete = 1;
#if 0
        /* 写key通知unit线程 */
        (void)unit_vsd_thread_init_trigger(global, LOCAL_CHASSIS_OK);
#endif
    }

    if ((dp_lib_complete->all_is_complete == true) 
            && (all_is_complete == 0)) {
        /* 本卡就位 */
        printf("[sda main]: all_is_complete[%u]!\n", get_timer_now());

        all_is_complete = 1;
#if 0
        /* 写key通知unit线程 */
        (void)unit_vsd_thread_init_trigger(global, GLOBAL_ALL_OK);
#endif
    }

    printf("[sda main]: sda_ndm_complete_notify_to_unit_thread over[%u]!\n", get_timer_now());

    return SDA_E_NONE;
}

static void sda_cm_buss_modules_init(void)
{
    int i;
    buss_module_init_fn **buss_module_init_ptr;
    static bool is_init = false;

    if (is_init == true) {
        printf("sda_cm_buss_modules_init already done, return!\n");
        return;
    }
    i = 0;
    memset(&single_unit_info, 0, sizeof(vsd_unit_thread_info_t));
    single_unit_info.cap_ctrl_info = (void *)g_sda_main_cap_ctrl_info;
    for (buss_module_init_ptr = cm_buss_module_init_sequence; *buss_module_init_ptr; ++buss_module_init_ptr) {
        if ((*buss_module_init_ptr)(g_sda_main_global, &single_unit_info) != 0) {
            printf("cm_buss_module_init_sequence[%d] fail!\n", i);
            continue;
        }
        printf("cm_buss_module_init_sequence[%d] [%u]!\n", i, get_timer_now());
        i++;
    }
    is_init = true;

    return;
}

static void sda_fe_buss_modules_init(void)
{
    int i;
    buss_module_init_fn **buss_module_init_ptr;
    static bool is_init = false;

    if (is_init == true) {
        printf("sda_fe_buss_modules_init already done, return!\n");
        return;
    }

    i = 0;
    memset(&single_unit_info, 0, sizeof(vsd_unit_thread_info_t));
    single_unit_info.cap_ctrl_info = (void *)g_sda_main_cap_ctrl_info;
    for (buss_module_init_ptr = fe_buss_module_init_sequence; *buss_module_init_ptr; ++buss_module_init_ptr) {
        if ((*buss_module_init_ptr)(g_sda_main_global, &single_unit_info) != 0) {
            printf("fe_buss_module_init_sequence[%d] fail!\n", i);
            continue;
        }
        printf("fe_buss_module_init_sequence[%d] [%u]!\n", i, get_timer_now());
        i++;
    }
    is_init = true;

    return;
}

static int sda_buss_modules_init(rg_global_t *glb, int node_type, PDev__DpLibComplete *dp_complete)
{
    int ret = SDA_E_NONE;

    SDA_CHK_EXPS_RETURN_VAL(dp_complete != NULL, printf, SDA_E_PARAM, "sda_buss_modules_init fail, dp_complete is null!\n");

    switch (node_type) {
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_BOX:
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_LC:
        ret = sda_ndm_complete_notify_to_unit_thread(glb, dp_complete, NULL);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_ndm_complete_notify_to_unit_thread fail, ret:%d\n", ret);
        break;
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_MB:
        if (dp_complete->local_card_is_complete == true) {
            sda_cm_buss_modules_init();
        }
        break;
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_SFC:
        if (dp_complete->local_card_is_complete == true) {
            sda_fe_buss_modules_init();
        }
        break;
    default:
        printf("[sda main]: Unknown node type=%d!\n", node_type);
        return SDA_E_PARAM;
    }

    return ret;
}

static int sda_sub_dp_complete_cb(rg_global_t *glb, int obj_type, dm_obj_update update_type,
                void *value)
{
    PDev__DpLibComplete *dp_complete;
    int ret = SDA_E_NONE;

    printf("[sda main]: obj_type=%d update_type=%d\n", obj_type, update_type);
    dp_complete = (PDev__DpLibComplete *)value;
    SDA_CHK_EXPS_RETURN_VAL(dp_complete != NULL, printf, SDA_E_PARAM, "sda_sub_dp_complete_cb dp_complete is null!\n");
    printf("[sda main]: local_card_is_complete=%d local_lc_is_complete=%d all_is_complete=%d\n", 
        dp_complete->local_card_is_complete, dp_complete->local_lc_is_complete, dp_complete->all_is_complete);
    switch (update_type) {
    case DM_OBJ_CACHE_NEW_OBJ:
    case DM_OBJ_UPDATE:
        ret = sda_buss_modules_init(glb, g_sda_node_type, dp_complete);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_buss_modules_init fail, ret:%d\n", ret);
        break;
    case DM_OBJ_DEL:
        printf("[sda main]: don't care obj_type=%d update_type=%d\n", obj_type, update_type);
        break;
    }

    return ret;
}

static int sda_lc_ndm_info_init(rg_global_t *global)
{
    int ret = SDA_E_NONE;

    /* 这里按照NDM的说法先把所有的cache都关注上 */
    /* 这里先关注本地的 */
    dm_cache_sub_obj(DM_OBJ_PORT_LOCAL, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_DP_LIB_MY_INFO, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_CARD_STATTR, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_PORT_GLOBAL, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_DP_LIB_MY_CHSS_INFO, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_DP_COMPLETE, sda_sub_dp_complete_cb, 0);
    ret = dm_cache_multi_thread_init();
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: dm_cache_multi_thread_init fail, ret:%d\n", ret);
    ret = dm_cache_init(global, "sda_main");
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: dm_cache_init fail, ret:%d\n", ret);

    return ret;
}

static int sda_mb_ndm_info_init(rg_global_t *global)
{
    int ret = SDA_E_NONE;

    /* 管理板只关注my info */    
    dm_cache_sub_obj(DM_OBJ_DP_LIB_MY_INFO, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_CARD_STATTR, NULL, 0);
    dm_cache_sub_obj(DM_OBJ_DP_COMPLETE, sda_sub_dp_complete_cb, 0);
    ret = dm_cache_multi_thread_init();
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: dm_cache_multi_thread_init fail, ret:%d\n", ret);
    ret = dm_cache_init(global, "sda_main");
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: dm_cache_init fail, ret:%d\n", ret);

    return ret;
}

static int sda_lc_init(void)
{
    int ret = SDA_E_NONE;

    sda_lc_key_modules_init(g_sda_main_global);

    ret = sda_lc_ndm_info_init(g_sda_main_global);
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_lc_ndm_info_init fail, ret:%d\n", ret);

    return ret;
}

static int sda_mb_init(void)
{
    int ret = SDA_E_NONE;

    ret = sda_mb_ndm_info_init(g_sda_main_global);
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_mb_ndm_info_init fail, ret:%d\n", ret);

    return ret;
}

static int sda_node_init(int node_type)
{
    int ret = SDA_E_NONE;

    switch (node_type) {
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_BOX:
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_LC:
        printf("sda_lc_init node_type=%d start\n", node_type);
        ret = sda_lc_init();
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_lc_init fail, ret:%d\n", ret);
        break;
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_MB:
    case P_DEV__DM_NODE_TYPE_E__DM_TYPE_SFC:
        printf("sda_mb_init node_type=%d start\n", node_type);
        ret = sda_mb_init();
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_mb_init fail, ret:%d\n", ret);
        break;
    default:
        printf("[sda main]: Unknown node type=%d!\n", node_type);
        return SDA_E_PARAM;
    }

    g_sda_node_type = node_type;
    printf("[sda main]: sda process run in node type[%d]!\n", g_sda_node_type);

    return ret;
}

static int sda_get_node_type(rg_global_t *global, rg_mom_pubsub_msg_t *msg, void *privdata)
{
    PDev__DpLibMyInfo *my_info;
    rg_mom_hash_res_t *res;
    int ret = SDA_E_NONE;

    printf("sda_get_node_type, db=%d cmd=%d time=[%u]!\n", msg->db, msg->cmd, get_timer_now());

    switch (msg->cmd) {
    case RG_MOM_HSET:
        SDA_MSG_CHECK_NULL_RET(msg, res, printf);
        my_info = (PDev__DpLibMyInfo *)res->value;
        break;
    default:
        printf("[sda main]: don't care cmd: %d\n", msg->cmd);
        return ret;
    }

    ret = sda_node_init(my_info->dm_my_node_type);
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_node_init fail, ret:%d\n", ret);

    return ret;
}

static int32_t sda_scan_PDev__DpLibMyInfo(rg_global_t *global, rg_mom_pubsub_msg_t *msg, rg_mom_response_cb scan_cb)
{
    int32_t ret = SDA_E_NONE;

    printf("sda_sub_PDev__DpLibMyInfo_cb, cmd = RG_MOM_SUBSCRIBE[%u]!\n", get_timer_now());

    PDev__DpLibMyInfo my_info = P_DEV__DP_LIB_MY_INFO__INIT;
    ret = rg_mom_scan(global, msg->db, (const rg_obj *)&my_info, 0, scan_cb, "scan");
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "scan PDev__DpLibMyInfo fail, ret:%d\n", ret);

    return ret;
}

static int sda_sub_PDev__DpLibMyInfo_cb(rg_global_t *global, rg_mom_pubsub_msg_t *msg, void *privdata)
{
    int ret = SDA_E_NONE;

    SDA_CHK_EXPS_RETURN_VAL(msg != NULL, printf, SDA_E_PARAM, "sda_sub_PDev__DpLibMyInfo_cb, pmsg is null!\n");

    if (msg->cmd == RG_MOM_SUBSCRIBE) {
        ret = sda_scan_PDev__DpLibMyInfo(global, msg, sda_get_node_type);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_scan_PDev__DpLibMyInfo fail, ret:%d\n", ret);
    } else {
        ret = sda_get_node_type(global, msg, privdata);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_get_node_type fail, ret:%d\n", ret);
    }

    return ret;
}

static int sda_sub_PDev__DpLibMyInfo(void)
{
    PDev__DpLibMyInfo my_info = P_DEV__DP_LIB_MY_INFO__INIT;
    size_t dp_lib_my_info_arr[1] = {5};
    rg_mom_response_cb dp_lib_my_info_cb_arr[1] = { sda_sub_PDev__DpLibMyInfo_cb };
    int count = 1;
    int ret = SDA_E_NONE;

    ret = rg_mom_subscribe_field(g_sda_main_global, RG_MOM_TUNNER_DB, (const rg_obj *)&my_info, 0,
        dp_lib_my_info_arr, dp_lib_my_info_cb_arr, NULL, count);
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "sda_sub_PDev__DpLibMyInfo fail, ret:%d\n", ret);

    printf("sda_sub_PDev__DpLibMyInfo over[%u]!\n", get_timer_now());

    return ret;
}

//extern int nps_sdk_init(void);
/* xgs.sda.sw / dnx.sda.sw */
int main(int argc, char *argv[])
{
    int i;
    char *app_name = "rda";
    int ret;

    /* io重定向 */
    //std_so_init();
    printf("rda main init begin!\n");

    /* 进程多实例检测 */
    frame_check_ssa_one();
    printf("frame_check_ssa_one!\n");
    /* 注册ham */
    ssa_rg_ham_init();
    printf("ssa_rg_ham_init!\n");
    /* PSH接口初始化 */
    ret = psh_lib_common_init();
    if (ret != SDA_E_NONE) {
        printf("[rda main]: psh_lib init err(ret:%d)!\n", ret);
    }
    printf("psh_lib_common_init!\n");
    /* 初始化伪线程 */
    g_sda_main_global = rg_global_init("rda_main", g_sda_main_global);
    printf("rg_global_init!\n");
    SDA_CHK_EXPS_RETURN_VAL(g_sda_main_global != NULL, printf, SDA_E_INIT, "[sda main]: rg_global_init fail\n");
    
    /* efmp lib 初始化 */
    ret = efmp_lib_init(EFMP_LIB_PROC_SDA_PKTD, g_sda_main_global->master);
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: efmp_lib_init failed, ret:%d\n", ret);
    printf("efmp_lib_init!\n");   
#if 0
    先不初始化交换芯片，后续替换为NPS的初始化
    /* SDK初始化 */
    ret = sdk_init();
    if (ret != SDA_E_NONE) {
        protect_selfhealing_do_action(PSH_RELOAD_SELF_ACT, 0, "SSA-HA",
            "error in sdk init, the device will reboot.");
        /* 请求马上刷写自愈事件到存储介质中 */
        protect_selfhealing_flush_buf_in_emergency();
    }
#else     
    //nps_sdk_init();
    //printf("nps_sdk_init!\n");
#endif
    
   /* SDA HA初始化 */
    sda_ha_init();
    printf("sda_ha_init!\n");

    /* debug-ssa配置 */
    debug_proc_run_task();
    printf("debug_proc_run_task!\n");
    /* 业务模块与SDK相关的硬件初始化放在这里(不与数据库交互,初始化硬件的部分), 顺序由业务模块自行协商决定 */
    /* added here... */
#if 0
    /* 主线程去关注NDM的初始化阶段,来操作unit线程, 这里先和asicDB建联
     * 建联回调里面去关注NDM和订阅NDM的key
     */
    for (i = 0; i < SSA_FRM_ARRAY_SIZE(g_main_connect_logic_db); i++) {
       ret = rg_mom_client_connect_sync(g_sda_main_global, g_main_connect_logic_db[i]);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: conn db:%d fail, ret:%d\n", g_main_connect_logic_db[i], ret);
        ret = rg_mom_client_set_disconnect_cb(g_sda_main_global, g_main_connect_logic_db[i], ssa_disconnect_cb, NULL);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: set_disconnect_cb db:%d fail, ret:%d\n", g_main_connect_logic_db[i], ret);
        ret = rg_mom_client_set_reconnect_cb(g_sda_main_global, g_main_connect_logic_db[i], ssa_reconnect_cb, NULL);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: set_reconnect_cb db:%d fail, ret:%d\n", g_main_connect_logic_db[i], ret);
        /* close sda main_thread congest limit switch */
        ret = rg_mom_congest_limit_switch(g_sda_main_global, g_main_connect_logic_db[i], RG_MOM_CONGEST_CLOSE);
        SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: close congest limit fail, glb:%p db:%d ret:%d\n", 
            g_sda_main_global, g_main_connect_logic_db[i], ret);
    }

    g_sda_main_cap_ctrl_info = librg_cap_ctrl_info_init(g_sda_main_cap_ctrl_info);
    SDA_CHK_EXPS_RETURN_VAL(g_sda_main_cap_ctrl_info != NULL, printf, SDA_E_INIT, "[sda main]: librg_cap_ctrl_info_init fail\n");
    ret = librg_cap_init_thread(g_sda_main_global, app_name, g_sda_main_cap_ctrl_info);
    if (ret != SDA_E_NONE) {
        printf("[sda main]: librg_cap_init_thread fail, ret:%d\n", ret);
        librg_cap_ctrl_info_free(g_sda_main_cap_ctrl_info);
        return ret;
    }
#endif 
    ret = libddm_init(g_sda_main_global, app_name);
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[rda main]: libddm_init fail, ret:%d\n", ret);
printf("libddm_init!\n");
#if 0
    ret = sda_sub_PDev__DpLibMyInfo();
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: sda_sub_PDev__DpLibMyInfo fail, ret:%d\n", ret);
printf("sda_sub_PDev__DpLibMyInfo!\n");
    ret = sda_dev_drv_lib_init();
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: sda_dev_drv_lib_init fail, ret:%d\n", ret);
printf("sda_dev_drv_lib_init!\n");
    ret = sda_sub_SFrame__UnitEnable();
    SDA_CHK_EXPS_RETURN_VAL(ret == SDA_E_NONE, printf, ret, "[sda main]: sda_sub_SFrame__UnitEnable fail, ret:%d\n", ret);
printf("sda_sub_SFrame__UnitEnable!\n"); 
#endif
    //sda_pktd_init();
	// 临时调用进行初始化，为了单板能够调试驱动

    unit_vsd_thread_init();
    /* 主线程也要创建伪线程循环 */
    printf("rda main init OVER!\n");
    rg_global_run(g_sda_main_global);

    /* 不该到这里 */
    printf("Ops I shouldn't be here!\n");
    rg_global_finish(g_sda_main_global);

    librg_cap_ctrl_info_free(g_sda_main_cap_ctrl_info);

    return SDA_E_NONE;
}

