#!/bin/bash
#/*
# * Copyright(C) 2018 Ruijie Network. All rights reserved.
# */
#/*
# * make_sda.sh
# * Original Author: sujinchi@ruijie.com.cn, 2018-01-10
# *
# * History
# * 
# */

rv_check()
{
    a_rv=$?
    [ $a_rv -ne 0 ] && exit $a_rv
}

basepath=$(cd `dirname $0`; pwd)

RGOSM_ENV_INC=TRUE ${APP_BUILD_SH} make build ${basepath}/nps_rda_rt_deb
rv_check

RGOSM_ENV_INC=TRUE ${APP_BUILD_SH} make build ${basepath}/sym_nps_rda_rt_deb

