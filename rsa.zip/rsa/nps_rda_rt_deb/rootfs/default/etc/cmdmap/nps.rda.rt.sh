#!/bin/sh
echo "nps.rda.rt was killed, restart the system!"
line=100
log=/tmp/proxy/defout/nps.rda.rw
outdir=/var/tmp/coredump/
mkdir -p $outdir
if [ -f "$log" ]; then
        tail -n $line $log > $outdir/nps.rda.rt-$(date +%Y%m%d_%H%M%S)
fi
NOWDATE="`date +"%Y-%m-%d %H:%M:%S" 2>/dev/null`"
echo "nps.rda.rt was killed!" >> /data/.rgsys_offtime
echo "$NOWDATE"   >> /data/.rgsys_offtime
sync
# "init 6" cannot be used in 12.x,PI suggest using "reboot" instead
# init 6
# 7810C当前不稳定，SSA挂了先不自动重启（20181208）
#reboot
sleep 600
