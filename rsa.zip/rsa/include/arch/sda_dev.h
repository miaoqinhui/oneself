#ifndef __SDA_DEV_H__
#define __SDA_DEV_H__
#include <stdio.h>
#include <arch/unit_thread.h>
#include <libpub/rg_mom/rg_mom_common.h>
#include <libpub/rg_mom/rg_mom_arch.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <libpub/rg_mom/rg_mom.h>
#include <libpub/rg_protobuf_rt/s/frame/config_end_comm.pb-c.h>

extern rg_global_t *g_sda_main_global;
int sda_sub_SFrame__UnitEnable(void);
int sda_dev_drv_lib_init(void);

#endif /* __SDA_DEV_H__ */
