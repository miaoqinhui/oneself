#ifndef _SDK_INIT_H
#define _SDK_INIT_H
/* sdk初始化入口 */
int sdk_init(void);
#endif /* !_SDK_INIT_H */
