#ifndef __UNIT_THREAD_H__
#define __UNIT_THREAD_H__

#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/prctl.h> 
#include <signal.h>
#include <time.h>
#include <sys/stat.h>
 
#include <libpub/rg_mom/rg_mom_common.h>
#include <libpub/rg_mom/rg_mom_arch.h>
#include <libpub/rg_mom/rg_mom_sync.h>
#include <libpub/rg_mom/rg_mom.h>
#include <libpub/rg_protobuf_rt/s/frame/unit_thread.pb-c.h>

/* SSA���ͳһ��ʼ��dm��ʹ�õ�ͷ�ļ� */
#include <libpub/rg_protobuf_rt/p/dev/dev_dp.pb-c.h>
#include <libpub/rg_protobuf_rt/p/dev/dev_local_port.pb-c.h>
#include <libpub/rg_protobuf_rt/p/dev/vsu_cfg.pb-c.h>
#include <libpub/rg_protobuf_rt/p/dev/vsl.pb-c.h>
#include <libpub/rg_protobuf_rt/p/dev/dad.pb-c.h>
#include <libpub/rg_protobuf_rt/p/dev/vsd.pb-c.h>

#include <rg_dev/dm_lib/dev_test.pb-c.h>
#include <rg_dev/dm_lib/dm_cache.h>
#include <rg_dev/dm_lib/dm_cache_obj.h>
#include <rg_dev/dm_lib/rg_ndm.h>
#include <rg_dev/kernel/dtm_common.h>
#include <rg_dev/dm_lib/ndm_cache_port_obj.h>

#include <sw_intf/ddm/libddm.h>
#include <libpub/rg_cap/librg_cap.h>

#define SSA_FRM_ARRAY_SIZE(a) (sizeof(a) /sizeof((a)[0]))

#define UNIT_THREAD_NAME_LEN 32

/* ��ʶssa��Ҫ��DM�����׶ε�ͨ�� */
#define SSA_INIT_PHASE_NUM  3

#define vsd_unit_err(fmt, ...)    \
    do { \
        if (debug_print_err) { \
            printf("\nERROR[%s %d]: "fmt, __func__, __LINE__, ##__VA_ARGS__); \
        } \
    } while (0)

#define vsd_unit(fmt, ...)    \
            do { \
                if (debug_print_err) { \
                    printf("\nproceed[%s %d]: "fmt, __func__, __LINE__, ##__VA_ARGS__); \
                } \
            } while (0)

#define NDM_CHACH_LOCK(mutex)    pthread_mutex_lock(&mutex)
#define NDM_CHACH_UNLOCK(mutex)  pthread_mutex_unlock(&mutex)
extern pthread_mutex_t ndm_mutex;

typedef enum
{
    LOCAL_CARD_OK = 0,
    LOCAL_CHASSIS_OK,
    GLOBAL_ALL_OK,
    END
} ssa_main_trigger_e;

/* ��ǰֻ��עNDMȫ�־�����MODID�����������ģ�� */
#define GLB_READY_MODULE_BMP    (0x00000003)
#define GLB_READY_MODULE_OFFSET (0x00000001)
typedef enum ready_module_type {
    READY_MODULE_NDM_GLB_OK = 0,
    READY_MODULE_MODID_OK,
    MAX_READY_MODULES
} ready_module_type_t;

/** 
 * @brief struct for unit thread managment
 */
typedef struct vsd_unit_thread_info_s {
    rg_global_t *global;      /* !< the global of this thread */
    int unit;                 /* !< the unit that this thread manages */
    int cur_vsd;              /* !< the vsdid that this unit currently belongs to */
    int old_vsd;              /* !< the vsdid that this unit used to belong to before the last vsd change of this unit */
    int thread_is_running;    /* !< the flag that indicates whether the thread is running */
    int enable;               /* !< the info that indicates whether different module's config is finish */
    int global_ready;         /* !< when set to GLB_READY_MODULE_BMP means global business can be initialized */
    void *priv_info;          /* !< the priv-info ptr that intended for business modules */
    void *dpm_prv;            /* !< use by DPM */
    int local_card_ok;        /* !< when set to 1 means local_card_ok init OK */
    int local_chassis_ok;     /* !< when set to 1 means local_chassis_ok init OK */    
    int global_all_ok;        /* !< when set to 1 means global_ok init OK */
    void *cap_ctrl_info;      /* |< cap control info per unit>| */
} vsd_unit_thread_info_t;

/* unit�̴߳����������Ͷ��� */
typedef void (* unit_vsd_thread_func)(void *);

/* ҵ�������ʼ���ӿ����Ͷ��� */
typedef int (buss_module_init_fn)(rg_global_t *global, vsd_unit_thread_info_t *unit_t_info);

/* ��ȡĳ��unit��vsd_unit_thread_info��Ϣ */
vsd_unit_thread_info_t * get_g_vsd_unit_thread_info(int unit);

/** 
 * @brief 
 * @param[in] unit_t_info pointer of vsd_unit_thread_info
 * @return returns the unit in this vsd_unit_thread_info
 */
static inline int get_unit_from_unit_thread_info(vsd_unit_thread_info_t *unit_t_info)
{
    return unit_t_info->unit;
}

/** 
 * @brief 
 * @param[in] unit_t_info pointer of vsd_unit_thread_info
 * @return returns the pointer of the priv_info in this vsd_unit_thread_info
 */
static inline void *get_priv_from_unit_thread_info(vsd_unit_thread_info_t *unit_t_info)
{
    return unit_t_info->priv_info;
}

static inline void *get_cap_ctrl_info_from_unit_thread_info(vsd_unit_thread_info_t *unit_t_info)
{
    return unit_t_info->cap_ctrl_info;
}

int dm_get_board_switch_unit(void);

int unit_vsd_thread_get_switch_chip_num(int *switch_chip_num);

/* unit��ʵ���̳߳�ʼ���ӿ� */
int unit_vsd_thread_init(void);
unsigned int get_max_switch_unit(void);
int32_t ssa_mac_init(rg_global_t *global, vsd_unit_thread_info_t *unit_thread_info);

/* dumpĳ��unit��vsd_unit_thread_info��Ϣ */
int dump_g_vsd_unit_thread_info(int unit);

int unit_vsd_thread_init_trigger(rg_global_t * global, int type);

int unit_vsd_thread_notify_module_ready(vsd_unit_thread_info_t *unit_info, 
    ready_module_type_t ready_module);

/* �����ṩһ�������õ�ʱ�����ӡ */
uint32_t get_timer_now(void);

int ssa_disconnect_cb(rg_global_t *glb, int db, void *arg);
int ssa_reconnect_cb(rg_global_t *glb, int db, rg_mom_reconnect_type_t type, void *arg);

#endif /* __UNIT_THREAD_H__ */




