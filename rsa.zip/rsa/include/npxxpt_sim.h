/*
 **************************************************************************************
 Copyright 2014 - 2015 Broadcom Corporation

 This program is the proprietary software of Broadcom Corporation and/or its licensors,
 and may only be used, duplicated, modified or distributed pursuant to the terms and
 conditions of a separate, written license agreement executed between you and
 Broadcom (an "Authorized License").Except as set forth in an Authorized License,
 Broadcom grants no license (express or implied),right to use, or waiver of any kind
 with respect to the Software, and Broadcom expressly reserves all rights in and to
 the Software and all intellectual property rights therein.
 IF YOU HAVE NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE IN ANY
 WAY,AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE ALL USE OF THE SOFTWARE.

 Except as expressly set forth in the Authorized License,

 1. This program, including its structure, sequence and organization, constitutes the
    valuable trade secrets of Broadcom, and you shall use all reasonable efforts to
    protect the confidentiality thereof,and to use this information only in connection
    with your use of Broadcom integrated circuit products.

 2. TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED "AS IS" AND WITH
    ALL FAULTS AND BROADCOM MAKES NO PROMISES, REPRESENTATIONS OR WARRANTIES, EITHER
    EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM
    SPECIFICALLY DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
    NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR
    COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR CORRESPONDENCE TO DESCRIPTION.
    YOU ASSUME THE ENTIRE RISK ARISING OUT OF USE OR PERFORMANCE OF THE SOFTWARE.

 3. TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL BROADCOM OR ITS LICENSORS
    BE LIABLE FOR (i) CONSEQUENTIAL, INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES
    WHATSOEVER ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY TO USE
    THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES;
    OR (ii) ANY AMOUNT IN EXCESS OF THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF
    OR U.S. $1, WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
    ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.
 **************************************************************************************
 */

#ifndef __NPXXPT_SIM_H
#define __NPXXPT_SIM_H

#include <stdint.h>

#include "device.h"
#include "errors.h"
#include "instruction.h"
#include "xpt_op.h"
#include <xpt_12k.h>



#ifdef __cplusplus
extern "C" {
#endif


/* Ez Driver version */
#define KBP_NPX_XPT_DRV_VER    (0)


/* Special Reason Codes for npx_xpt only
   in case of multiple errors value of the reason code returned will be ored value of the
   corresponding reason codes */
#define KBP_NPX_XPT_FATAL_ERR                   (0x1FFF)
#define KBP_NPX_XPT_PKT_ERR                     (0x1001)
#define KBP_NPX_XPT_DEV_INTERFACE_ERR           (0x1002)
#define KBP_NPX_XPT_DEV_RESPONSE_TIMEOUT_ERR    (0x1004)
#define KBP_NPX_XPT_ILA_MAC_ERR                 (0x1008)
#define KBP_NPX_XPT_CTX_ID_MISMATCH_ERR         (0x1010)
#define KBP_NPX_XPT_RSLT_FIFO_OVERFLOW_ERR      (0x1020)

/* Maximum of 512b of response is supported by EZChip transport */
#define KBP_NPX_XPT_MAX_RESPONSE_DATA           (64)

struct kbp_npxxpt_sim_resp_details {
    uint32_t m_responseOpcode;
    uint32_t m_responseContextId;
    uint32_t m_responseErrorMask; /* Contains Error mask value returned by
                                     Ezchip Interface; Only LSB 6b are valid,
                                     value of 0 indicates no error */
    /* In case of packet error contains
       packet error code in both debug mode
       and non-debug mode.  In Debug mode; if no error
       detected contains data that is read from device; */
    uint8_t m_responseData[KBP_NPX_XPT_MAX_RESPONSE_DATA];
};

/**
 * @brief Properties for Npx transport layer
 *
 * Properties that can be set with kbp_npxxpt_sim_set_property()
 *
 */

enum kbp_npxxpt_sim_properties {
    KBP_NPX_SIM_PROP_DEBUG_FLAG,             /**< Enable/Diasable the debug flag, if enables logs the response */
    KBP_NPX_SIM_PROP_EZ_FUNC,                /**< Register customer KBP function to pass the messages */
    KBP_NPX_SIM_PROP_CHANNEL_ID,             /**< EZChip transport channel ID */
    KBP_NPX_SIM_PROP_LOG,                    /**< Log transport messages to file */
    KBP_NPX_SIM_PROP_LOG_TEST_BENCH_FMT,     /**< Log in the test bench format */
    KBP_NPX_SIM_PROP_EZ_SILICON_P1,          /**< split compare command to cbwrite and compare if mkey > 320b */
    KBP_NPX_SIM_PROP_HANG_ON_ERROR,          /**< if set will be in hang state; error returned by exchip command API */
    KBP_NPX_SIM_PROP_RESEND_INST_ON_ERROR,   /**< if set will resend same inst again and be in hang state */
    KBP_NPX_SIM_PROP_SEND_RAED_RESP_ON_ERROR,/**< if set; on read the operations fails and params.uiResponseErrorMask > 0
                                              will send the response what we got from the device */
    KBP_NPX_SIM_PROP_FIX_PARITY_ERRORS,      /**< if set will fix the parity errors, and return the last state */
    KBP_NPX_SIM_PROP_PAYLOAD_SIZE,           /**< compare response size, NPX = 8, NPS = 16 */
    KBP_NPX_SIM_PROP_SIDE,                   /**< EZChip transport side */
    KBP_NPX_SIM_PROP_INVALID        /**< Invalid. This should be the last entry */
};

typedef void (*SendCommand_Ptr)(int /*eOpType*/, char* /*buffer*/, int /*length*/);
void kbp_npxxpt_sim_set_command_func( SendCommand_Ptr pFunc);

/*
 * Install callback that transports messages through the
 * EZChip transport layer. Typically one will directly
 * install the function EZapiTCAM_ExtKBPCommand
 */

typedef uint32_t (*kbp_npx_sim_kbp_handle)(uint32_t channel, uint32_t command, void *msg);

/**
 * Properties to tailor the transport layer. Supported properties
 * are defined in ::kbp_npxxpt_sim_properties
 *
 * kbp_npxxpt_sim_set_property(db, KBP_NPX_PROP_DEBUG_FLAG, <value>);
 * kbp_npxxpt_sim_set_property(db, KBP_NPX_PROP_EZ_FUNC, <fn_ptr>);
 * kbp_npxxpt_sim_set_property(db, KBP_NPX_PROP_CHANNEL_ID, id);
 * kbp_npxxpt_sim_set_property(db, KBP_NPX_PROP_LOG, fp);
 *
 * @param xpt pointer to the transport layer initialized by the function on success
 * @param property defined in ::kbp_npxxpt_sim_properties
 * @param ... variable arguments related to the property
 *
 * @returns KBP_OK on success or an error code
 */

kbp_status kbp_npxxpt_sim_set_property(void *xpt, enum kbp_npxxpt_sim_properties property, ...);
kbp_status kbp_op_npxxpt_sim_set_property(void *xpt, enum kbp_npxxpt_sim_properties property, ...);

/**
 * Initialize the EZChip Driver and return transport layer handle
 *
 * @param alloc valid allocator handle
 * @param type the device type to initialize the model for ::kbp_device_type
 * @param xpt pointer to the transport layer initialized by the function on success
 * @param debug_flag to select the mode
 *
 * @return KBP_OK on success or an error code
 */

kbp_status kbp_npxxpt_sim_init( struct kbp_allocator *alloc, enum kbp_device_type type, void **xpt);

/**
 * Destroy the resources allocated for the EZChip Driver
 *
 * @param type the device type of the driver
 * @param xpt valid initialized transport layer handle returned by kbp_npxxpt_sim_init()
 * @return KBP_OK on success or an error code
 */

kbp_status kbp_npxxpt_sim_destroy(enum kbp_device_type type, void *xpt);

/**
 * Return response information details
 *
 * @param xpt valid initialized transport layer handle returned by kbp_npxxpt_sim_init()
 *
 * @retval valid response detail or NULL
 */

struct kbp_npxxpt_sim_resp_details *kbp_npxxpt_sim_getresponse_details(kbp_xpt *self);

#ifdef __cplusplus
}
#endif
#endif /*__NPXXPT_SIM_H */
