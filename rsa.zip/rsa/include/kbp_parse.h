/*******************************************************************************
 *
 * Copyright 2011-2016 Broadcom Corporation
 *
 * This program is the proprietary software of Broadcom Corporation and/or its
 * licensors, and may only be used, duplicated, modified or distributed pursuant
 * to the terms and conditions of a separate, written license agreement executed
 * between you and Broadcom (an "Authorized License").  Except as set forth in an
 * Authorized License, Broadcom grants no license (express or implied), right to
 * use, or waiver of any kind with respect to the Software, and Broadcom expressly
 * reserves all rights in and to the Software and all intellectual property rights
 * therein.  IF YOU HAVE NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS
 * SOFTWARE IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
 * ALL USE OF THE SOFTWARE.
 *
 * Except as expressly set forth in the Authorized License,
 *
 * 1.     This program, including its structure, sequence and organization,
 * constitutes the valuable trade secrets of Broadcom, and you shall use all
 * reasonable efforts to protect the confidentiality thereof, and to use this
 * information only in connection with your use of Broadcom integrated circuit
 * products.
 *
 * 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED
 * "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES, REPRESENTATIONS
 * OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, WITH RESPECT
 * TO THE SOFTWARE. BROADCOM SPECIFICALLY DISCLAIMS ANY AND ALL IMPLIED WARRANTIES
 * OF TITLE, MERCHANTABILITY, NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE,
 * LACK OF VIRUSES, ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION
 * OR CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING OUT OF
 * USE OR PERFORMANCE OF THE SOFTWARE.
 *
 * 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL BROADCOM
 * OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL, INCIDENTAL, SPECIAL, INDIRECT,
 * OR EXEMPLARY DAMAGES WHATSOEVER ARISING OUT OF OR IN ANY WAY RELATING TO YOUR
 * USE OF OR INABILITY TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF THE AMOUNT
 * ACTUALLY PAID FOR THE SOFTWARE ITSELF OR U.S. $1, WHICHEVER IS GREATER. THESE
 * LIMITATIONS SHALL APPLY NOTWITHSTANDING ANY FAILURE OF ESSENTIAL PURPOSE OF
 * ANY LIMITED REMEDY.
 *
 *******************************************************************************/

#ifndef __KBP_PARSE_H
#define __KBP_PARSE_H

#include <stdint.h>
#include "db.h"
#include "key.h"
#include "instruction.h"
#include "hw_limits.h"

#ifdef __cplusplus
extern "C" {
#endif

#define IPv6_MAX_LEN (128)
#define IPv4_MAX_LEN (32)

/**
 *
 * @file kbp_parse.h
 *
 * KBP file parsing and printing utilities.
 *
 * @addtogroup KBP_PARSE_APIS
 * @{
 */

/**
 * @brief Parsed range information (generally useful for ACLs).
 */
struct kbp_parse_range
{
    uint16_t offset_8; /**< The byte offset to the start of range
                          in the range-modified key. In other
                          cases, such as ACL parser, it is defined
                          by the module. */
    uint16_t lo;       /**< Low end of the range used for making >= comparisons. */
    uint16_t hi;       /**< High end of range used for making <= comparisons. */
};

/**
 * @brief A single KBP parse record.
 */

struct kbp_parse_record {
    struct kbp_entry *e;                /**< Testing use. */
    struct kbp_parse_record *next;      /**< Testing use. */
    struct kbp_parse_record *next_entry;      /**< Testing use. */
    struct kbp_parse_range ranges[KBP_HW_MAX_RANGE_COMPARES];  /**< User-specified ranges. */
    struct kbp_hb *hb_e;                /**< HitBit Entry */
    uint8_t *data;                      /**< Data bits. */
    uint8_t *mask;                      /**< 1 == don't care. */
    void *ad_data;                      /**< Testing use. */
    uint8_t *user_ad_data;              /**< AD data from dataset file */
    uint64_t priority:22;               /**< Line number for ACL, or inverse prefix length for LPM. */
    uint64_t length:8;                  /**< Prefix length, for LPM only. */
    uint64_t num_ranges:3;              /**< Number of active range records. */
    uint64_t visited:2;                 /**< Used for bookkeeping. */
    uint64_t status:3;                  /**< Testing use. */
    uint64_t hit:1;                     /**< Testing use */
    uint64_t pending_del:1;             /**< Testing use */
    uint64_t counter:20;                /**< Testing use */
};

/**
 * @brief Parsed key format.
 */

struct kbp_parse_key {
    char *fname;                        /**< String name for the key. */
    uint32_t width;                     /**< Width of key in bits. */
    enum kbp_key_field_type type;       /**< Type of key field. */
    struct kbp_parse_key *next;         /**< Linked list of key fields. */
    char buf[];                         /**<< Memory for string name. */
};

/**
 *@breif parsed AD info.
 */

struct kbp_parse_ad_info {
    struct kbp_ad_db *ad_db;            /**< Valid AD Database pointer */
    struct kbp_parse_ad_info *next;     /**< Linked List of AD Databases */
    void ** dangling_ad;                /**< List of Dangling AD entries */
    int32_t ad_list_count;              /**< Stats for number of Dangling AD entries */
    uint8_t usb_bmp[KBP_HW_MAX_UDA_SB / KBP_BITS_IN_BYTE]; /**< USB bitmap, OP specific */
    uint32_t capacity;                  /**< Capacity of the AD Database */
    uint32_t ad_width_8:8;              /**< AD Datatabase width in Bytes, aligned */
    uint32_t ad_offset_8:8;             /**< AD offset, if non multiple of 32b */
    uint32_t ad_resp:8;                 /**< AD Responce type */
    uint32_t ad_align_8:8;              /**< AD Datatabase width in Bytes, non aligned */
};

/**
 * Parse a text file holding a KBP database in any of the known formats.
 * The passed-in options determine the nature of the
 * result array returned. For LPM file types, the entry priority
 * is computed as the valid prefix length. For ACLs, it is order
 * of entry in the file. If the random flag is set, the order of parsed
 * entries is randomized and the original priorities are retained.
 *
 * @param db_type ACL, LPM, or EM database types.
 * @param randomize If set to a nonzero value, will randomize the input array.
 * @param fname Name of database file.
 * @param req_num_entries used to parse the entries requested, If zero we will parse the whole dataset file.
 * @param result Used to return an array of parsed records. The memory must be freed by the caller.
 * @param num_entries Size of the array of parsed records.
 * @param key The layout of the entry fields in the file.
 *
 * It is the responsibility of the caller to free up the memory pointed
 * to by the result array
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status kbp_parse_db_file(enum kbp_db_type db_type, int32_t randomize,
                             const char *fname, uint32_t req_num_entries,
                             uint32_t num_default_entries,
                             struct kbp_parse_record **result,uint32_t * num_entries,
                             struct kbp_parse_key **key);

/**
 * Randomizes the order of entries in the input set of entries
 *
 * @param randomize If set to a nonzero value, will randomize the input array.
 * @param result Used to return an array of parsed records after randomization. The memory must be freed by the caller.
 * @param num_entries Size of the array of parsed records.
 *
 * It is the responsibility of the caller to free up the memory pointed
 * to by the result array. The memory of input array is freed
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status randomize_entries(int32_t randomize, struct kbp_parse_record **result,
                             uint32_t *num_entries);

/**
 * Frees up the memory allocated for the entries.
 *
 * @param entries The entry array returned by kbp_parse_db_file().
 *
 */
void kbp_parse_destroy(struct kbp_parse_record *entries);

/**
 * Prints the key header.
 *
 * @param key Valid key layout.
 */

void kbp_parse_print_key(struct kbp_parse_key *key);

/**
 * Destroys the parse key.
 *
 * @param key Valid key layout.
 */

void kbp_parse_destroy_key(struct kbp_parse_key *key);

/**
 * Produces a text string with standard representation of the ACL entry.
 *
 * @param key The layout of the entry.
 * @param entry The entry to be printed.
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status kbp_parse_print_record(struct kbp_parse_key *key, const struct kbp_parse_record *entry);


/**
 * Generates a single key that matches the ACL entry.
 *
 * @param e Points to the record holding the entry.
 * @param key Points to the memory region where the key should be generated.
 * @param width_8 Specifies the width of the entry.
 *
 */
kbp_status kbp_parse_generate_random_valid_key(const struct kbp_parse_record *e, uint8_t *key, uint32_t width_8);

/**
 * Computes the match results for an array of raw entries using simple linear traversal.
 *
 * @note: If the number of entries is large, this API can be very slow.
 *
 * @param entries Array of parsed records that are being searched.
 * @param num_entries Specifies how many valid entries there are in the array above.
 * @param entry_width_8 The key width of the entry above.
 * @param search_keys A flat array of search keys.
 * @param num_search_keys The number of search keys in the flat array above.
 * @param key_width_8 The width of each search key in the flat array above.
 * @param expected_entries Expected match entries.
 *
 * @return KBP_OK
 */

kbp_status kbp_parse_match_raw_entries(const struct kbp_parse_record *entries, uint32_t num_entries,
                                       uint32_t entry_width_8, const uint8_t *search_keys,
                                       uint32_t num_search_keys, uint32_t key_width_8,
                                       struct kbp_parse_record **expected_entries);


enum db_priotiry_type
{
    TEST_PRIO_SINGLE,            /**< All entries has same priority */
    TEST_PRIO_INCREMENT,         /**< Entries with incremental priority */
    TEST_PRIO_DECREMENT,         /**< Entries with decremental priority */
    TEST_PRIO_RANDOM,            /**< Entries with random priority */
    TEST_PRIO_HOLES_1,           /**< Entries where n-1 with same prio, last one < prio */
    TEST_PRIO_HOLES_2,           /**< Entries where n-1 with same prio, last one > prio */
    TEST_PRIO_INCREMENT2,        /**< Entries with incremental priority, start from bigger value */
};

struct manually_placed_resources {
    uint8_t rpt_bmp[2]; /**< 16b RPT bitmap */
    uint8_t dba_bmp[32]; /**< 256b DBA bitmap */
    uint8_t num_dba_dt; /**< Number of DBA based decision trees */
    uint8_t num_sram_dt; /**< Number of SRAM based decision tress */
    uint8_t max_lsn_size[4]; /**< Maximum LSN size of each DT */
    uint8_t udm_bmp[2][8]; /**< 64b UDM bitmap */
};

/**
 * @brief Configuration options used for setting a budget for the database resources.
 */
struct kbp_parse_db_conf {
    struct manually_placed_resources user_specified; /**< User Specified manual resources */
    enum kbp_device_type flag_device; /**< Device type. */
    int32_t num_ab;                  /**< Number of ABs to use. */
    int32_t uda_mb;                  /**< Number of megabits of UDA to use. */
    int32_t max_lsn;                 /**< Max number bricks in LSN. */
    int32_t sram_pwr_bgt;            /**< NetACL SRAM power budget. */
    int16_t range_units;             /**< Number of MCOR units. */
    int16_t ad_width;                /**< -1 if no AD, or width of AD in bits. */
    int16_t algorithmic;             /**< Set to algorithmic/nonalgorithmic mode. */
    int16_t pc;                      /**< Power-control level. */
    int16_t up;                      /**< Update rate/capacity tradeoff. */
    enum kbp_db_type db_type;        /**< Database type. */
    int32_t flag_incremental;        /**< Populate entries incrementally if set to 1. */
    uint32_t flag_shuffle_stats:1;   /**< calculate PIOWR stats*/
    uint32_t flag_sw_srchs:1;        /**< do sw searches for LPM stats*/
    uint32_t index_range:1;          /**< if index range specified */
    uint32_t supress_ix_cb:1;        /**< supress ix_callback for update rates */
    uint32_t force_to_sram:1;        /**< force the entires to sram */
    uint32_t rebuild_tree:1;         /**< to avoid re-building */
    uint32_t reduced_ix_cb:1;        /**< set prop reduced ix callbacks for LPM */
    uint32_t manual_placed_resources:1; /**< set the prop for the maunally placed resource */
    uint32_t manual_placed_pwr_bgt:1;   /**< set the prop for the maunally placed pwr bgt */
    int32_t  upd_level;              /**< update rate level */
    uint32_t index_min;              /**< min index */
    uint32_t index_max;              /**< max index */
    uint32_t num_duplicates;         /**< Num of duplicates in the dataset */
    enum db_priotiry_type ptype;     /**< Test Type */
    enum kbp_status status;          /**< Return status with reason code*/
};

/**
 * Initializes the configuration structure to defaults.
 *
 * @param dev The KBP device handle.
 * @param capacity The capacity of the database.
 * @param ad_info The inforamtion of AD Databases; zero is not used.
 * @param c Valid pointer to the configuration structure that needs to be initialized.
 */

kbp_status kbp_parse_init_conf(struct kbp_device *dev, uint32_t capacity,
                               struct kbp_parse_ad_info *ad_info, struct kbp_parse_db_conf *c);



/**
 * Determines the maximum number of entries that can fit in a database
 * of specified configuration.
 *
 * @param c Valid initialized configuration.
 * @param key The parsed key format.
 * @param entries Points to the entries to be searched.
 * @param nentries Specifies how many valid entries there are in the array.
 * @param added_entries Final list of added entries. This array must be freed by the caller.
 * @param nadded The number of entries in the array above.
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status kbp_parse_fit_db(const struct kbp_parse_db_conf *c,
                            struct kbp_parse_key *key, struct kbp_parse_record *entries,
                            uint32_t nentries, struct kbp_parse_record **added_entries, uint32_t *nadded);

/**
 * Initializes a database and populates it with given entries. If they do not all fit, it adds as many as it can (i.e. the first nadded entries), in order.
 *
 * @param device Valid KBP device handle.
 * @param c Valid initialized configuration.
 * @param ad_info Parsed AD information
 * @param dbp Pointer, initialized and returned on success.
 * @param instruction The instruction to which the database has been added for searching.
 * @param key The parsed key layout.
 * @param entries The parsed ACL entries.
 * @param nentries The number of elements in the parsed ACL entries.
 * @param build_time Approximate time taken to build the database. This includes some overhead in the populate function.
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status kbp_parse_populate_db(struct kbp_device *device,
                                 struct kbp_parse_db_conf *c,
                                 struct kbp_parse_ad_info *ad_info,
                                 struct kbp_db **dbp,
                                 struct kbp_instruction **instruction,
                                 struct kbp_parse_key *key,
                                 struct kbp_parse_record *entries, uint32_t nentries, uint32_t *build_time);

/**
 * Prints a string followed by nentries, followed by width rounded up or truncated to a width of four tabs.
 *
 * @param fname Points to the string (file name).
 * @param nentries Count of entries in the file.
 * @param width_1 The width of the user entries in bits.
 *
 * @return KBP_OK.
 */

kbp_status kbp_parse_print_file_name_4_tab(const char *fname, uint32_t nentries, uint32_t width_1);

/**
 *
 * Dynamically generates the LPM entries for the requested pattern.
 *
 * @param pattern The requested test pattern such as 801, 901, some times duplicate prefixes may prasent ....
 * @param length The maximum length of the prefix.
 * @param num_requested Number of prefixes required.
 * @param result Array for returning the parse records populated with prefixes.
 * @param num_entries The number of actual prefixes created.
 *
 * It is the responsibility of the caller to free up the memory pointed
 * to by the result array and the key.
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status kbp_parse_generate_prefixes(uint32_t pattern, uint32_t length,
                                       uint32_t num_requested,
                                       struct kbp_parse_record ** result,
                                       uint32_t *num_entries);

/**
 *
 * Dynamically generates the LPM entries for the requested pattern, where hash table is
 * used to check for the duplicate prefixes, this will make sure no duplicates are
 * generated.
 *
 * @param device_type KBP device type
 * @param pattern The requested test pattern such as 801, 901, some times duplicate prefixes may prasent ....
 * @param length The maximum length of the prefix.
 * @param num_requested Number of prefixes required.
 * @param result Array for returning the parse records populated with prefixes.
 * @param num_entries The number of actual prefixes created.
 *
 * It is the responsibility of the caller to free up the memory pointed
 * to by the result array and the key.
 *
 * @return KBP_OK on success or an error code otherwise.
 */
kbp_status kbp_parse_generate_unique_prefixes(enum kbp_device_type dev_type,
                                              uint32_t pattern,
                                              uint32_t length,
                                              uint32_t num_requested,
                                              struct kbp_parse_record ** result,
                                              uint32_t *num_entries);

/**
 *
 * API parses the char array and fill the kbp_parse_record structure in the specified format
 *
 * @param db_type database type
 * @param buf char array to be parsed
 * @param key key structure of the database
 * @param entry structure to be filled
 * @param key_width_1 width of the database
 * @param acl_priority priority to  assign for this entry
 * @param fomat1 indicates type of fomat
 * @param ad_width width of the AD
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status kbp_parse_entry(enum kbp_db_type db_type, const char * buf, struct kbp_parse_key * key,
                              struct kbp_parse_record * entry,uint32_t key_width_1,uint32_t acl_priority,
                              int32_t format1, uint32_t ad_width);


/**
 * Parse a text file holding a KBP database in any of the known formats.
 * The passed-in options determine the nature of the
 * result array returned. For LPM file types, the entry priority
 * is computed as the valid prefix length. For ACLs, it is order
 * of entry in the file.
 *
 * @param db_type ACL, LPM, or EM database types.
 * @param fname Name of database file.
 * @param result Used to return an array of parsed records. The memory must be freed by the caller.
 * @param req_num_entries used to parse the entries requested, If zero we will parse the whole dataset file.
 * @param ndefault_entries number of default entries specified in the xml file
 * @param ad_width AD width of the database if dataset has AD
 * @param num_lines Actual number of lines in the file
 * @param num_entries Size of the array of parsed records.
 * @param key The layout of the entry fields in the file.
 *
 * It is the responsibility of the caller to free up the memory pointed
 * to by the result array
 *
 * @return KBP_OK on success or an error code otherwise.
 */

kbp_status parse_standard_db_file(enum kbp_db_type db_type,const char * fname,struct kbp_parse_record * * result,
                                  uint32_t req_num_entries,uint32_t ndefault_entries,
                                  uint32_t *ad_width, uint32_t * num_lines,
                                  uint32_t * num_entries,struct kbp_parse_key * * key);

/**
 * Evaluate a KBP parsed database by showing its distribution & other metrics.
 * Current plan is to parse LPM DB's only!
 *
 * @param db_type ACL, LPM, or EM database types.
 * @param fname Name of database file.
 * @param entries The acutal DB entries to be evaluated.
 * @param num_entries Size of the array of parsed records.
 * @param key_len The length of the entry fields (LPM + VRF + ...) in the file.
 * @param histogram The histogram of the DB prefixes.
 * @param max_prefix_len The maximum prefix length of this DB.
 *
 * @return KBP_OK on success or an error code otherwise.
 */


kbp_status eval_lpm_db(enum kbp_db_type db_type, const char *fname,
        struct kbp_parse_record *entries, uint32_t num_entries,
        uint32_t key_len, uint32_t **histogram,
        uint32_t *max_prefix_len);


/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif                          /* __KBP_PARSE_H */
